"use strict";(()=>{function U(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}var Bo={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" "};function ee(o){return o.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi,(e,t)=>{if(t[0]==="#"){let n=t[1]==="x"||t[1]==="X"?parseInt(t.slice(2),16):parseInt(t.slice(1),10);return!Number.isFinite(n)||n<0||n>1114111?e:String.fromCodePoint(n)}return Bo[t.toLowerCase()]??e})}var dt=/<\s*(\/?)\s*x\s*(\d{1,4})\s*>/gi;function F(o,e){let t=[],n=[],r=new Set,i=l=>{let c=n.length?n[n.length-1].children:t,d=c[c.length-1];typeof l=="string"&&typeof d=="string"?c[c.length-1]=d+l:c.push(l)},s=[],a=0;dt.lastIndex=0;for(let l=dt.exec(o);l;l=dt.exec(o)){if(l.index>a){let u=ee(o.slice(a,l.index));u&&i(u)}a=l.index+l[0].length;let c=l[1]==="/",d=Number(l[2]);if(c){let u=s.lastIndexOf(d);if(u!==-1){s.splice(u,1);continue}let h=n.map(p=>p.slot).lastIndexOf(d);h!==-1&&(n.length=h)}else{if(r.has(d)||e&&!e.has(d)){s.push(d);continue}r.add(d);let u={slot:d,children:[]};i(u),n.push(u)}}if(a<o.length){let l=ee(o.slice(a));l&&i(l)}return t}function Y(o,e){let t=[];for(let n of o){if(typeof n=="string"){t.push(n);continue}let r=t[t.length-1];typeof r=="string"&&e(n.slot)&&(t[t.length-1]=r.replace(/\s*\n\s*$/," ")),t.push({slot:n.slot,children:Y(n.children,e)})}return t}function J(o){return o.map(e=>typeof e=="string"?e:J(e.children)).join("")}function Z(o,e=new Set){for(let t of o)typeof t!="string"&&(e.add(t.slot),Z(t.children,e));return e}function D(){try{return!!chrome.runtime?.id}catch{return!1}}async function I(o){return await chrome.runtime.sendMessage(o)}function w(o,...e){try{return chrome.i18n.getMessage(o,e)||o}catch{return o}}var pt=["togglePage","toggleMode","marquee","sweep"],ht={togglePage:["Alt","Shift","KeyY"],toggleMode:["Alt","Shift","KeyD"],marquee:["Shift","Space","KeyS"],sweep:["Shift","Space","KeyX"]},ut=["Ctrl","Alt","Shift","Meta"];function qt(o){return/^(Control|Alt|Shift|Meta|OS)(Left|Right)?$/.test(o)}function Ut(o){let e={Ctrl:o.ctrlKey,Alt:o.altKey,Shift:o.shiftKey,Meta:o.metaKey};return ut.filter(t=>e[t])}function jt(o){let e=t=>ut.includes(t);return{mods:ut.filter(t=>o.includes(t)),keys:o.filter(t=>!e(t))}}function zt(o,e){return o.length>0&&o.length===e.length&&o.every(t=>e.includes(t))}var Se="#ffffff",Kt="#1f2329",Xt="#14171c";function Vt(o){return o==="dark"?!0:o==="light"?!1:matchMedia("(prefers-color-scheme: dark)").matches}function mt(o){let e=parseInt(o.slice(1),16),t=n=>{let r=n/255;return r<=.03928?r/12.92:((r+.055)/1.055)**2.4};return .2126*t(e>>16&255)+.7152*t(e>>8&255)+.0722*t(e&255)}function Ee(o,e){let[t,n]=[mt(o),mt(e)].sort((r,i)=>i-r);return(t+.05)/(n+.05)}function Te(o,e,t=4){if(Ee(o,e)>=t)return o;let n=parseInt(o.slice(1),16),[r,i,s]=[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255],a=Math.max(r,i,s),l=Math.min(r,i,s),c=a-l,d=0;c&&(a===r?d=((i-s)/c+6)%6:a===i?d=(s-r)/c+2:d=(r-i)/c+4),d*=60;let u=(a+l)/2,h=c?c/(1-Math.abs(2*u-1)):0,p=m=>{let f=h*Math.min(m,1-m),b=v=>{let T=(v+d/30)%12;return Math.round(255*(m-f*Math.max(-1,Math.min(T-3,9-T,1)))).toString(16).padStart(2,"0")};return`#${b(0)}${b(8)}${b(4)}`},g=mt(e)<.2?.01:-.01;for(let m=u;m>=0&&m<=1;m+=g){let f=p(m);if(Ee(f,e)>=t)return f}return g>0?"#ffffff":"#000000"}var Gt=[{id:"blue",color:"#1f77f3",name:"themeBlue"},{id:"red",color:"#ea303f",name:"themeRed"},{id:"orange",color:"#d45105",name:"themeOrange"},{id:"amber",color:"#a27304",name:"themeAmber"},{id:"green",color:"#108d4f",name:"themeGreen"},{id:"teal",color:"#0f8a86",name:"themeTeal"},{id:"violet",color:"#8561f2",name:"themeViolet"},{id:"pink",color:"#e72486",name:"themePink"}];function te(o){return/^#[0-9a-f]{6}$/i.test(o)?o:(Gt.find(e=>e.id===o)??Gt[0]).color}var $o={targetLang:"zh-Hans",sourceLang:"",mode:"dual",dualStyle:"highlight",themeColor:"blue",appearance:"auto",shortcuts:ht,fontScale:100,selectionTrigger:"icon",showOriginalOnHover:!0,unlockCopy:!1,inputTranslate:!1,inputLang:"en",glossary:[],autoTranslate:!1,alwaysSites:[],neverSites:[],alwaysLangs:[],excludeSelectors:"",cacheDays:7};function Fo(o){let e=o.toLowerCase();return e==="zh-tw"||e==="zh-hk"||e==="zh-mo"||e.startsWith("zh-hant")?"zh-Hant":e.startsWith("zh")?"zh-Hans":e.split("-")[0]??"en"}async function ft(){let o=await chrome.storage.sync.get(null),e={...$o,...o,shortcuts:{...ht,...o.shortcuts}};return o.cacheDays===void 0&&o.persistentCache===!1&&(e.cacheDays=0),o.targetLang||(e.targetLang=Wo()),e}function Wo(){let o=Fo(chrome.i18n.getUILanguage());return qo.has(o)?o:"en"}function Yt(o){chrome.storage.onChanged.addListener((e,t)=>{t==="sync"&&ft().then(o)})}function gt(o,e){return e.some(t=>o===t||o.endsWith(`.${t}`))}var pe=[{code:"zh-Hans",name:"简体中文"},{code:"zh-Hant",name:"繁體中文"},{code:"yue",name:"粵語"},{code:"en",name:"English"},{code:"ja",name:"日本語"},{code:"ko",name:"한국어"},{code:"fr",name:"Français"},{code:"de",name:"Deutsch"},{code:"es",name:"Español"},{code:"pt",name:"Português"},{code:"it",name:"Italiano"},{code:"ru",name:"Русский"},{code:"uk",name:"Українська"},{code:"pl",name:"Polski"},{code:"nl",name:"Nederlands"},{code:"tr",name:"Türkçe"},{code:"ar",name:"العربية"},{code:"hi",name:"हिन्दी"},{code:"vi",name:"Tiếng Việt"},{code:"th",name:"ไทย"},{code:"id",name:"Bahasa Indonesia"}],Jt={"zh-Hans":"chinese simplified 简体 中文 汉语 jianti zhongwen","zh-Hant":"chinese traditional 繁体 繁體 中文 fanti zhongwen",yue:"cantonese 粤语 广东话 yueyu guangdonghua",en:"english 英语 英文 yingyu yingwen",ja:"japanese 日语 日文 riyu riwen",ko:"korean 韩语 韩文 朝鲜语 hanyu hanwen",fr:"french 法语 法文 fayu",de:"german 德语 德文 deyu",es:"spanish 西班牙语 xibanya",pt:"portuguese 葡萄牙语 putaoya",it:"italian 意大利语 yidali",ru:"russian 俄语 俄文 eyu",uk:"ukrainian 乌克兰语 wukelan",pl:"polish 波兰语 bolan",nl:"dutch 荷兰语 helan",tr:"turkish 土耳其语 tuerqi",ar:"arabic 阿拉伯语 alabo",hi:"hindi 印地语 yindi",vi:"vietnamese 越南语 yuenan",th:"thai 泰语 taiyu",id:"indonesian 印尼语 印度尼西亚语 yinni"},qo=new Set(pe.map(o=>o.code));var Uo=[.1,.35,.65,.9];function jo(o){for(let e=o;e&&e!==document.body&&e!==document.documentElement;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return e;return null}function zo(o){let e=null;for(let t=o;t&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t),r=parseInt(n.zIndex,10);n.position!=="static"&&!Number.isNaN(r)&&(e=r)}return e}function Zt(o){let e=new Set;for(let t of Uo)for(let n of document.elementsFromPoint(innerWidth*t,o)){if(n.localName==="yl-ui")continue;let r=jo(n);r&&r.getBoundingClientRect().height<innerHeight*.45&&e.add(r);break}return Array.from(e)}function bt(){let o=new Set,e=0;for(let r=0;r<2;r++)for(let i of Zt(e+2))o.add(i),e=Math.max(e,i.getBoundingClientRect().bottom);let t=innerHeight;for(let r of Zt(t-2))o.add(r),t=Math.min(t,r.getBoundingClientRect().top);let n=null;for(let r of o){let i=zo(r);if(i===null)return{top:e,bottom:t,stacking:null};n=n===null?i:Math.min(n,i)}return{top:e,bottom:t,stacking:n}}function ke(o,e,t){if(e<=0&&t>=innerHeight){o.style.clipPath="";return}let n=o.getBoundingClientRect(),r=i=>Number.isFinite(i)?i:-9999;o.style.clipPath=`inset(${r(e-n.top)}px -9999px ${r(n.bottom-t)}px -9999px)`}var yt=`/* Thin gradient edges in the full palette on clean, light surfaces. */
:host {
  --ink: #000000;
  --paper: #ffffff;
  --muted: #666b73;
  --line: rgba(20, 30, 50, 0.1);
  --hover: color-mix(in srgb, var(--yl-theme) 8%, var(--paper));
  --shadow: 0 8px 28px rgba(20, 40, 80, 0.13), 0 1px 3px rgba(20, 40, 80, 0.08);
  --ease: cubic-bezier(0.2, 0.8, 0.2, 1);
  --spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  --edge: linear-gradient(115deg, #4da2ff, #55db9c 35%, #ffd731 62%, #fb4903 85%, #5c4ade);
  --yl-theme: #1f77f3;
  --yl-on-theme: #ffffff;
  --sky: color-mix(in srgb, var(--yl-theme) 13%, var(--paper));
  --glass: rgba(255, 255, 255, 0.7);
  --error: #c43a02;
}

:host([data-appearance='dark']) {
  --ink: #eef0f3;
  --paper: #1f2329;
  --muted: #9aa3ae;
  --line: rgba(255, 255, 255, 0.1);
  --hover: color-mix(in srgb, var(--yl-theme) 12%, var(--paper));
  --shadow: 0 8px 28px rgba(0, 0, 0, 0.28), 0 1px 3px rgba(0, 0, 0, 0.2);
  --sky: color-mix(in srgb, var(--yl-theme) 14%, var(--paper));
  --glass: rgba(255, 255, 255, 0.1);
  --error: #ff8a5c;
}

* {
  box-sizing: border-box;
}

.layer {
  position: fixed;
  font: 400 13px/1.45 Inter, 'Segoe UI', system-ui, -apple-system, 'Microsoft YaHei', sans-serif;
  color: var(--ink);
  pointer-events: auto;
}

/* ---- selection ------------------------------------------------------------ */

/* Holds nothing itself: its parts are placed on the screen. */
.bubble {
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

.bubble-ring {
  position: absolute;
  top: 0;
  left: 0;
  width: 1px;
  height: 1px;
  overflow: visible;
  pointer-events: none;
}

.bubble-ring path {
  fill: none;
  stroke-width: 2;
  stroke-linejoin: round;
  filter: drop-shadow(0 1px 3px rgba(20, 40, 80, 0.18));
}

/* Drawn once, as the selection is made. It stays as it is when the card takes the button's place. */
.bubble .bubble-ring path {
  stroke-dasharray: 1;
  animation: ring-draw 0.34s var(--ease);
}

/* The bar holding the actions, which the bubble's tail points at. */
.bubble-tab {
  position: absolute;
  display: inline-flex;
  gap: 2px;
  padding: 3px;
  border-radius: 11px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  pointer-events: auto;
  animation: fade-in 0.18s var(--ease) 0.14s both;
}

@keyframes ring-draw {
  from {
    stroke-dashoffset: 1;
  }
}

.bubble-action {
  height: 28px;
  padding: 0 11px 0 8px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 0;
  border-radius: 8px;
  background: var(--yl-theme);
  color: var(--yl-on-theme);
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  transition: filter 0.15s, transform 0.15s var(--spring);
}

.bubble-action svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.bubble-action:hover {
  filter: brightness(1.1);
}

.bubble-action:active {
  transform: scale(0.96);
}

.card {
  width: 480px;
  max-width: calc(100vw - 16px);
  overflow: hidden;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  animation: enter 0.22s var(--ease);
}

/* Fades in without moving: while it rose into place, it could not be measured for where it is. */
.card[data-on-page] {
  z-index: 1;
  animation-name: fade-in;
}

/* The ring round the text, while its card is open. */
.source-ring {
  width: 1px;
  height: 1px;
  pointer-events: none;
}

/* Translating: dotted, and whole once the translation is in. */
.source-ring[data-pending] path {
  stroke-width: 2.6;
  stroke-linecap: round;
  stroke-dasharray: 0 7px;
}

/* Where the card is held to move it: a short bar across its top. */
.card-grip {
  height: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: grab;
  touch-action: none;
}

.card-grip::before {
  content: '';
  width: 34px;
  height: 4px;
  border-radius: 2px;
  background: var(--line);
  transition: background-color 0.15s, width 0.15s var(--ease);
}

.card-grip:hover::before,
.card[data-dragging] .card-grip::before {
  width: 42px;
  background: color-mix(in srgb, var(--yl-theme) 55%, var(--line));
}

.card[data-dragging] {
  user-select: none;
}

.card[data-dragging] .card-grip {
  cursor: grabbing;
}

.card-grip + .card-body {
  padding-top: 2px;
}

.card-body {
  max-height: 320px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba(20, 30, 50, 0.18) transparent;
  padding: 12px 14px 10px;
}

.card-source {
  /* No padding or border here: a clamped box shows its next line through its own padding. */
  margin-bottom: 10px;
  color: var(--muted);
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
  overflow-wrap: anywhere;
}

.card-result {
  padding-top: 10px;
  border-top: 1px solid var(--line);
  font-size: 14px;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  user-select: text;
}

/* The word being read. */
.card-word {
  border-radius: 3px;
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 26%, transparent);
  color: inherit;
}

/* Reading: the button stays lit, and a stop square replaces the speaker. */
.icon-btn[data-on],
.icon-btn[data-on]:hover {
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 14%, transparent);
  color: var(--yl-theme, #1f77f3);
}

.icon-btn[data-on] svg {
  fill: currentColor;
}

/* Between parts, one thin line, drawn apart from the part so its rounded corners do not bend it. */
.card-seg {
  position: relative;
}

.card-seg + .card-seg {
  margin-top: 11px;
}

.card-seg + .card-seg::before {
  content: '';
  position: absolute;
  top: -6px;
  left: 6px;
  right: 6px;
  border-top: 1px solid var(--line);
}

.card-seg[data-jump] .card-source {
  margin-bottom: 4px;
}

.card-seg[data-jump] .card-result {
  padding-top: 0;
  border-top: 0;
}


.card-seg[data-jump] {
  margin-left: -6px;
  margin-right: -6px;
  padding: 4px 6px;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.15s;
}

.card-seg[data-jump]:hover {
  background-color: var(--hover);
}

/* Shows where a part of the card came from, for a moment. */
.source-flash {
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

.source-flash-line {
  position: absolute;
  border-radius: 4px;
  background: color-mix(in srgb, var(--yl-theme) 32%, transparent);
  animation: flash-out 1.1s var(--ease) forwards;
}

@keyframes flash-out {
  0%,
  45% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}

.card-result[data-state='loading'] {
  color: var(--muted);
}

.card-result[data-state='error'] {
  color: var(--error);
}

/* Adding to the glossary, in the card itself. */
.card-glossary {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 14px;
  border-top: 1px solid var(--line);
}

.card-glossary-input {
  flex: 1;
  min-width: 0;
  height: 28px;
  padding: 0 8px;
  border-radius: 7px;
  border: 1px solid var(--line);
  background: var(--paper);
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  outline: none;
}

.card-glossary-input:focus {
  border-color: var(--yl-theme);
}

.card-glossary-arrow {
  color: var(--muted);
}

.card-glossary-save {
  height: 28px;
  padding: 0 12px;
  border: 0;
  border-radius: 7px;
  background: var(--yl-theme);
  color: var(--yl-on-theme);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}

/* The translation of a field, before anything in it changes. */
.write-pop {
  position: relative;
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  overflow: hidden;
  animation: fade-in 0.16s var(--ease);
}

/* In the corner, over the text's padding: no row of its own. */
.write-close {
  position: absolute;
  top: 4px;
  right: 4px;
}

.write-foot .grow {
  flex: 1;
}

.write-lang {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: var(--sky);
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}

.write-lang:hover {
  background: color-mix(in srgb, var(--yl-theme) 20%, var(--paper));
}

/* Part of the field or all of it. */
.write-scope {
  display: inline-flex;
  height: 30px;
  padding: 2px;
  border-radius: 8px;
  background: var(--sky);
}

.write-scope button {
  padding: 0 9px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--muted);
  font: inherit;
  font-size: 12.5px;
  white-space: nowrap;
  cursor: pointer;
}

.write-scope button:hover {
  color: var(--ink);
}

.write-scope button[aria-checked='true'] {
  background: var(--paper);
  color: var(--ink);
  font-weight: 500;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
}

.write-scope button:focus-visible {
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);
}

.write-chevron {
  width: 6px;
  height: 6px;
  margin-top: -3px;
  border-right: 1.5px solid currentColor;
  border-bottom: 1.5px solid currentColor;
  transform: rotate(45deg);
  opacity: 0.6;
}

.write-result {
  max-height: 220px;
  overflow-y: auto;
  padding: 12px 38px 12px 14px;
  font-size: 14px;
  line-height: 1.55;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  user-select: text;
}

.write-result:focus {
  outline: none;
}

.write-result[data-state='loading'] {
  color: var(--muted);
}

.write-result[data-state='error'] {
  color: var(--error);
}

.write-foot {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 10px 10px;
  border-top: 1px solid var(--line);
}

.write-copy,
.write-replace {
  height: 30px;
  padding: 0 14px;
  border-radius: 8px;
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}

.write-copy {
  border: 1px solid var(--line);
  background: var(--paper);
  color: var(--ink);
}

.write-copy:hover {
  background: var(--hover);
}

.write-replace {
  border: 0;
  background: var(--yl-theme);
  color: var(--yl-on-theme);
  font-weight: 500;
}

.write-replace:focus-visible,
.write-copy:focus-visible,
.write-lang:focus-visible {
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);
  outline-offset: 1px;
}

.write-copy:disabled,
.write-replace:disabled {
  opacity: 0.5;
  cursor: default;
}

.lang-menu-item[data-current]::after {
  content: '✓';
  float: right;
  color: var(--yl-theme);
}

/* Which language to write in, this once. */
.lang-menu {
  width: 240px;
  display: flex;
  flex-direction: column;
  padding: 6px;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  animation: fade-in 0.14s var(--ease);
}

.lang-menu-search {
  height: 32px;
  margin-bottom: 4px;
  padding: 0 10px;
  border-radius: 8px;
  border: 1px solid var(--line);
  background: var(--paper);
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  outline: none;
}

.lang-menu-search:focus {
  border-color: var(--yl-theme);
}

.lang-menu-list {
  max-height: 228px;
  overflow-y: auto;
  scrollbar-width: thin;
}

.lang-menu-item {
  display: block;
  width: 100%;
  padding: 6px 10px;
  border: 0;
  border-radius: 7px;
  background: transparent;
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  text-align: left;
  cursor: pointer;
}

.lang-menu-item:hover,
.lang-menu-item[data-active] {
  background: var(--hover);
}

.lang-menu-item[data-active] {
  color: var(--yl-theme);
  font-weight: 500;
}

.lang-menu-empty {
  padding: 10px;
  color: var(--muted);
  font-size: 13px;
}

/* While a field is being translated. */
.input-busy {
  padding: 3px 9px;
  border-radius: 999px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  font-size: 12px;
  color: var(--muted);
  pointer-events: none;
  animation: fade-in 0.15s var(--ease);
}

.card-foot {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px 6px 4px 14px;
  border-top: 1px solid var(--line);
  color: var(--muted);
  font-size: 12px;
}

.card-foot .grow {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.icon-btn {
  width: 28px;
  height: 28px;
  padding: 0;
  display: grid;
  place-items: center;
  flex: none;
  border: 0;
  border-radius: 7px;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  transition: background-color 0.15s, color 0.15s, transform 0.15s var(--spring);
}

.icon-btn:hover {
  background: var(--hover);
  color: var(--ink);
}

.icon-btn:active {
  transform: scale(0.9);
}

.icon-btn svg {
  width: 15px;
  height: 15px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.tooltip {
  max-width: 420px;
  padding: 7px 10px;
  border-radius: 8px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  overflow-wrap: anywhere;
  pointer-events: none;
  animation: enter 0.16s var(--ease);
}

.toast {
  left: 50%;
  bottom: 28px;
  translate: -50% 0;
  max-width: min(480px, calc(100vw - 32px));
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 9px 14px;
  border-radius: 10px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  animation: rise 0.22s var(--ease);
}

.toast button {
  flex: none;
  padding: 0;
  border: 0;
  background: none;
  color: var(--ink);
  font: inherit;
  font-weight: 500;
  text-decoration: underline;
  cursor: pointer;
}

/* ---- frame ---------------------------------------------------------------- */

.region-box {
  border-radius: 10px;
  pointer-events: none;
}

/* Drawn as a stroke, so all four sides have one width at any screen scale. */
.flow-ring {
  position: absolute;
  overflow: visible;
  pointer-events: none;
}

.flow-line {
  fill: none;
}

/* Waiting for the translation: the frame breathes. */
.region-box[data-pending] .flow-ring {
  animation: frame-wait 0.9s ease-in-out infinite alternate;
}

.region-cover {
  box-sizing: border-box;
  width: max-content;
  overflow-wrap: anywhere;
  user-select: text;
  animation: fade-in 0.2s var(--ease);
}

.region-cover-inner {
  white-space: normal;
}

/* ---- scan card ------------------------------------------------------------ */

.scan-card {
  display: flex;
  flex-direction: column;
  max-width: calc(100vw - 16px);
  overflow: hidden;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
}

.scan-immersive {
  animation: enter 0.24s var(--ease);
}

/* What scrolls passes under the head, which stands clear of it. */
.scan-immersive .scan-head {
  position: relative;
  z-index: 1;
  box-shadow: 0 1px 0 var(--line), 0 6px 12px -8px rgba(20, 30, 50, 0.35);
}

.scan-card[data-exporting] {
  pointer-events: none;
}

/* While the picture is made. Turning needs nothing from the page, which is busy drawing. */
.scan-making {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: grid;
  place-items: center;
  background: color-mix(in srgb, var(--paper) 62%, transparent);
  animation: fade-in 0.16s var(--ease);
}

.scan-making-note {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border-radius: 10px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  color: var(--ink);
  font-size: 13px;
}

.scan-making-spin {
  width: 14px;
  height: 14px;
  border-radius: 50%;
  border: 2px solid color-mix(in srgb, var(--yl-theme) 22%, transparent);
  border-top-color: var(--yl-theme);
  animation: making-turn 0.7s linear infinite;
}

@keyframes making-turn {
  to {
    transform: rotate(360deg);
  }
}

/* Being photographed, the slow way: nothing on the result that is not the result, and square
   and flat, or every screen brings its rounded corners and shadow into the joins. */
.scan-card[data-photographing] .scan-track,
.scan-card[data-photographing] .scan-making {
  visibility: hidden;
}

.scan-card[data-photographing] {
  border-radius: 0;
  background: var(--paper);
  box-shadow: none;
}

.scan-card[data-photographing] .scan-head {
  box-shadow: none;
}

.scan-closing {
  animation: leave 0.17s var(--ease) forwards !important;
  pointer-events: none;
}

.scan-track {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 12px;
  cursor: pointer;
  touch-action: none;
}

.scan-thumb {
  position: absolute;
  top: 0;
  right: 3px;
  width: 6px;
  border-radius: 3px;
  background: rgba(20, 30, 50, 0.26);
  transition: background-color 0.15s, width 0.15s var(--ease);
}

.scan-track:hover .scan-thumb {
  width: 8px;
  background: rgba(20, 30, 50, 0.42);
}

/* Small until there is something to say. */
.scan-find {
  flex: none;
  display: flex;
  align-items: center;
  gap: 5px;
  width: 148px;
  height: 26px;
  margin: 0 6px 0 10px;
  padding: 0 4px 0 8px;
  border: 1px solid var(--line);
  border-radius: 7px;
  background: var(--paper);
  color: var(--muted);
  cursor: text;
  transition: width 0.2s var(--ease), border-color 0.15s;
}

.scan-find:focus-within {
  border-color: var(--yl-theme);
}

.scan-find[data-typed] {
  width: 214px;
}

.scan-find > svg {
  flex: none;
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.scan-find-input {
  flex: 1;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: 0;
  outline: 0;
  background: none;
  color: var(--ink);
  font: inherit;
  font-size: 12px;
  user-select: text;
}

.scan-find-input::placeholder {
  color: var(--muted);
}

.scan-find-count {
  flex: none;
  display: none;
  font-size: 11px;
  font-variant-numeric: tabular-nums;
}

.scan-find .icon-btn {
  display: none;
  width: 20px;
  height: 20px;
  border-radius: 5px;
}

.scan-find .icon-btn svg {
  width: 13px;
  height: 13px;
}

.scan-find[data-typed] .scan-find-count,
.scan-find[data-found] .icon-btn {
  display: grid;
}

.scan-find[data-typed] .scan-find-count {
  display: block;
}

.scan-find[data-none] .scan-find-count {
  color: var(--error);
}

.scan-animate {
  transition: top 0.3s var(--ease), left 0.3s var(--ease), height 0.3s var(--ease), bottom 0.3s var(--ease);
}

.scan-backdrop {
  inset: 0;
  /* The page shows only through small holes in a veil, with its colour taken down: tidy on
     any page and with any theme colour. The same recipe as element-plus.org's navigation. */
  background-image: radial-gradient(transparent 1px, var(--paper) 1px);
  background-size: 4px 4px;
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(1.7);
  -webkit-backdrop-filter: var(--veil);
  backdrop-filter: var(--veil);
  animation: fade-in 0.28s var(--ease);
}

/* A light page through a dark veil is a harsh grid unless the page comes down to its level. */
:host([data-appearance='dark']) .scan-backdrop {
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(0.4);
}

/* Only ever seen at full screen. */
.scan-card[data-hidden] {
  visibility: hidden;
  pointer-events: none;
}

.scan-bar {
  display: flex;
  align-items: center;
  gap: 2px;
  height: 36px;
  padding: 0 4px 0 12px;
  border: 1.5px solid transparent;
  border-radius: 10px;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  font-size: 12px;
  white-space: nowrap;
  animation: enter 0.2s var(--ease);
}

.scan-bar .grow {
  margin-right: 8px;
}

.scan-head {
  cursor: default;
}

.scan-grip {
  position: absolute;
  z-index: 2;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  cursor: ns-resize;
  touch-action: none;
}

.scan-head {
  flex: none;
  display: flex;
  align-items: center;
  gap: 2px;
  height: 36px;
  padding: 0 6px 0 14px;
  background: var(--sky);
  color: var(--ink);
  font-size: 12px;
  user-select: none;
}

.scan-head .icon-btn {
  color: var(--ink);
}

.scan-head .icon-btn:hover {
  background: var(--glass);
}

.scan-head .grow {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Shows a copy of the page, whose text assumes the page's own background. */
.scan-body {
  background: #fff;
  position: relative;
  flex: 1;
  min-height: 0;
  overflow: hidden;
}

.scan-body iframe {
  position: absolute;
  border: 0;
  background: transparent;
}

/* ---- marquee -------------------------------------------------------------- */

.marquee-shade {
  inset: 0;
  cursor: crosshair;
  background: rgba(20, 40, 80, 0.05);
  touch-action: none;
  user-select: none;
  animation: fade-in 0.15s var(--ease);
}

.marquee-hint {
  left: 50%;
  top: 16px;
  translate: -50% 0;
  padding: 6px 12px;
  border-radius: 8px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  white-space: nowrap;
  pointer-events: none;
  animation: rise 0.2s var(--ease);
}

.leaving {
  animation: leave 0.16s var(--ease) forwards !important;
  pointer-events: none;
}

@keyframes frame-wait {
  to {
    opacity: 0.5;
  }
}

@keyframes enter {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.985);
  }
}

@keyframes leave {
  to {
    opacity: 0;
    transform: translateY(4px) scale(0.985);
  }
}

@keyframes pop {
  from {
    opacity: 0;
    transform: scale(0.7);
  }
}

@keyframes rise {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}

@keyframes fade-in {
  from {
    opacity: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
`;var G="http://www.w3.org/2000/svg",Ko=2,Xo=3,Vo=12,he=[["0","#4da2ff"],["0.35","#55db9c"],["0.62","#ffd731"],["0.85","#fb4903"],["1","#5c4ade"]],Yo=0,Qt=2147483646;function en(o){for(let e of["keydown","keyup","keypress"])o.addEventListener(e,t=>t.stopPropagation())}function _(o){let e=devicePixelRatio||1;return Math.round(o*e)/e}var Jo={copy:["M9 9h10v11H9z","M5 15V4h10"],speak:["M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z","M15.5 9a4 4 0 0 1 0 6","M18 6.5a8 8 0 0 1 0 11"],close:["M6 6l12 12","M18 6L6 18"],stop:["M7 7h10v10H7z"],check:["M5 12.5l4.5 4.5L19 7.5"],expand:["M4 9V4h5","M20 9V4h-5","M4 15v5h5","M20 15v5h-5"],collapse:["M9 4v5H4","M15 4v5h5","M9 20v-5H4","M15 20v-5h5"],search:["M11 5a6 6 0 1 1 0 12a6 6 0 0 1 0-12z","M15.5 15.5L20 20"],up:["M6 15l6-6 6 6"],down:["M6 9l6 6 6-6"],image:["M4 5h16v14H4z","M4 16l5-5 4 4 3-3 4 4","M15.5 8.5h.01"],download:["M12 4v11","M7.5 11L12 15.5 16.5 11","M5 19.5h14"],glossary:["M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z","M5 19.5A1.5 1.5 0 0 0 6.5 21H19","M12 7.5v6","M9 10.5h6"],translate:["M4 5h7","M9 3v2c0 4.418-2.239 8-5 8","M5 9c0 2.144 2.952 3.908 6.7 4","M12 20l4-9 4 9","M19.1 18h-6.2"]};function ne(o){let e=document.createElementNS(G,"svg");e.setAttribute("viewBox","0 0 24 24");for(let t of Jo[o]){let n=document.createElementNS(G,"path");n.setAttribute("d",t),e.append(n)}return e}function x(o,e,t){let n=document.createElement(o);return n.className=e,t!==void 0&&(n.textContent=t),n}function O(o,e,t){let n=x("button","icon-btn");return n.type="button",n.title=e,n.setAttribute("aria-label",e),n.append(ne(o)),n.addEventListener("click",t),n}var Me=class{host;root;toastEl;toastTimer;theme;dark=!1;pageHost;pageRoot;tooltipEl;setTheme(e,t){this.theme=e,this.dark=t;for(let n of[this.host,this.pageHost])n&&this.paint(n)}settleUnderBars(){let e=bt(),t=e.stacking!==null&&e.stacking>1;return this.pageHost&&(this.pageHost.style.zIndex=String(t?e.stacking-1:Qt)),t?{top:-1/0,bottom:1/0}:{top:e.top>0?e.top:-1/0,bottom:e.bottom<innerHeight?e.bottom:1/0}}paint(e){this.theme&&(e.style.setProperty("--yl-theme",this.theme),e.style.setProperty("--yl-on-theme",Ee("#ffffff",this.theme)>=3?"#ffffff":"#14161b")),e.dataset.appearance=this.dark?"dark":"light"}get hostElement(){return this.host}isHost(e){return!!e&&(e===this.host||e===this.pageHost)}ownsEvent(e){return e.composedPath().some(t=>t===this.host||t===this.pageHost)}ensurePage(){if(this.pageRoot&&this.pageHost?.isConnected)return this.pageRoot;this.pageHost=document.createElement("yl-ui"),this.pageHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${Qt};`,this.paint(this.pageHost),en(this.pageHost),this.pageRoot=this.pageHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=yt,this.pageRoot.append(e),document.documentElement.append(this.pageHost),this.pageRoot}addToPage(e){return e.classList.add("layer"),e.style.position="absolute",this.ensurePage().append(e),e}ensure(){if(this.root&&this.host?.isConnected)return this.root;this.host=document.createElement("yl-ui"),this.host.style.cssText="all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",this.paint(this.host),en(this.host),this.root=this.host.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=yt,this.root.append(e),document.documentElement.append(this.host),this.root}add(e){return e.classList.add("layer"),this.ensure().append(e),e}addBelow(e,t){return e.classList.add("layer"),t.parentNode?.insertBefore(e,t),e}place(e,t,n=8,r){let{left:i,top:s}=this.spot(e,t,n,r);e.style.left=`${i}px`,e.style.top=`${s}px`}spot(e,t,n=8,r){let i=e.offsetWidth,s=e.offsetHeight,a=bt(),l=Math.max(a.top,r?.top??0)+8,c=Math.min(a.bottom,r?.bottom??innerHeight)-8,d=Math.max(8,Math.min(t.left,innerWidth-i-8)),u=t.bottom+n;return u+s>c&&(u=t.top-s-n),{left:d,top:Math.max(l,Math.min(u,c-s))}}ring(e){let t=document.createElementNS(G,"svg");t.setAttribute("class","flow-ring"),t.setAttribute("aria-hidden","true");let n=`yl-edge-${++Yo}`,r=document.createElementNS(G,"defs"),i=document.createElementNS(G,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[u,h]of he){let p=document.createElementNS(G,"stop");p.setAttribute("offset",u),p.setAttribute("stop-color",h),i.append(p)}if(!matchMedia("(prefers-reduced-motion: reduce)").matches){let u=document.createElementNS(G,"animateTransform");u.setAttribute("attributeName","gradientTransform"),u.setAttribute("type","rotate"),u.setAttribute("from","0 0.5 0.5"),u.setAttribute("to","360 0.5 0.5"),u.setAttribute("dur","6s"),u.setAttribute("repeatCount","indefinite"),i.append(u)}r.append(i);let s=Math.max(1/(devicePixelRatio||1),_(Ko)),a=_(Xo);t.style.left=t.style.top=`${-a}px`,t.style.width=`calc(100% + ${a*2}px)`,t.style.height=`calc(100% + ${a*2}px)`;let c=(u=>{let h=document.createElementNS(G,"rect");return h.setAttribute("class",u),h.setAttribute("x",String(s/2)),h.setAttribute("y",String(s/2)),h.setAttribute("stroke-width",String(s)),h.setAttribute("rx",String(Vo)),h})("flow-line");c.setAttribute("stroke",`url(#${n})`),t.append(r,c),e.append(t);let d=()=>{let u=e.getBoundingClientRect(),h=Math.max(0,u.width+a*2-s),p=Math.max(0,u.height+a*2-s);c.setAttribute("width",String(h)),c.setAttribute("height",String(p))};new ResizeObserver(d).observe(e),d()}addFrame(e=!1,t=!1){let n=x("div","region-box");return e&&(n.dataset.pending=""),t?this.addToPage(n):this.add(n),this.ring(n),n}setFramePending(e,t){t?e.dataset.pending="":delete e.dataset.pending}dismiss(e){if(!e)return;e.classList.add("leaving");let t=()=>e.remove();e.addEventListener("animationend",t,{once:!0}),setTimeout(t,220)}toast(e,t,n=5e3){this.dismiss(this.toastEl),clearTimeout(this.toastTimer);let r=x("div","toast");if(r.setAttribute("role","status"),r.append(x("span","",e)),t){let i=x("button","",t.label);i.type="button",i.addEventListener("click",()=>{r.remove(),t.run()}),r.append(i)}this.toastEl=this.add(r),this.toastTimer=setTimeout(()=>this.dismiss(r),n)}showTooltip(e,t){this.hideTooltip();let n=x("div","tooltip",e);this.tooltipEl=this.add(n),this.place(n,t,6)}hideTooltip(){this.dismiss(this.tooltipEl),this.tooltipEl=void 0}errorMessage(e){return w(`error_${e}`)||w("error_unavailable")}};var tn=700,nn=3,Zo=5e3,Qo=new Set(["","text","search"]),q=8,er=300,tr=360,nr=460,vt=o=>pe.find(e=>e.code===o)?.name??o;function or(o){if(o instanceof HTMLTextAreaElement)return o.readOnly||o.disabled?null:o;if(o instanceof HTMLInputElement)return!Qo.has(o.type.toLowerCase())||o.readOnly||o.disabled?null:o;if(o instanceof HTMLElement&&o.isContentEditable){let e=o;for(;e.parentElement?.isContentEditable;)e=e.parentElement;return e}return null}function oe(o){return o instanceof HTMLInputElement||o instanceof HTMLTextAreaElement}function on(o){return(oe(o)?o.value:o.innerText??"").replace(/[\s ]+$/,"")}function rn(o){return!!o.trim()&&o.length<=Zo&&new RegExp("\\p{L}","u").test(o)}function an(o){let e=getSelection();e?.removeAllRanges(),e?.addRange(o)}function wt(o,e,t){let n=o.value.slice(e,t);return{text:n,select(){let r=e;return o.value.slice(e,t)!==n&&(r=o.value.indexOf(n),r<0)?!1:(o.focus(),o.setSelectionRange(r,r+n.length),!0)}}}function xt(o,e){return{text:e.toString(),select(){return!o.contains(e.commonAncestorContainer)||!e.toString().trim()?!1:(o.focus(),an(e.cloneRange()),!0)}}}function rr(o){if(oe(o))return{...wt(o,0,o.value.length),text:on(o)};let e=document.createRange();return e.selectNodeContents(o),{...xt(o,e),text:on(o)}}function ln(o,e,t){for(;e<t&&/\s/.test(o[e]);)e++;for(;t>e&&/\s/.test(o[t-1]);)t--;return[e,t]}function cn(o){if(oe(o)){let{selectionStart:n,selectionEnd:r}=o;if(n===null||r===null||n===r)return null;let[i,s]=ln(o.value,n,r);return i<s?wt(o,i,s):null}let e=getSelection();if(!e?.rangeCount||e.isCollapsed)return null;let t=e.getRangeAt(0);return!o.contains(t.commonAncestorContainer)||!t.toString().trim()?null:xt(o,t.cloneRange())}function ir(o){return cn(o)!==null}function sr(o){if(oe(o)){let n=o.selectionStart;if(n===null)return null;let r=o.value,i=r.lastIndexOf(`
`,n-1)+1,s=r.indexOf(`
`,n),[a,l]=ln(r,i,s<0?r.length:s);return a<l?wt(o,a,l):null}let e=getSelection();if(!e?.rangeCount)return null;let t=e.getRangeAt(0).startContainer;if(!o.contains(t))return null;for(;t&&t!==o;t=t.parentNode){if(!(t instanceof HTMLElement))continue;let n=getComputedStyle(t).display;if(n.startsWith("inline")||n==="contents")continue;if(!t.innerText.trim())return null;let r=document.createRange();return r.selectNodeContents(t),xt(o,r)}return null}function sn(o,e){if(!document.execCommand("insertText",!1,e))if(oe(o))o.setRangeText(e,o.selectionStart??0,o.selectionEnd??o.value.length,"end"),o.dispatchEvent(new Event("input",{bubbles:!0}));else{let t=getSelection()?.getRangeAt(0);t?.deleteContents(),t?.insertNode(document.createTextNode(e))}}function ar(o,e){if(oe(o)){if(o.selectionStart===null)return;let s=o.selectionStart,a=o.value.slice(Math.max(0,s-e),s);a.length===e&&!a.trim()&&(o.setSelectionRange(s-e,s),document.execCommand("delete")||o.setRangeText("",s-e,s,"end"));return}let t=getSelection();if(!t?.rangeCount||!t.isCollapsed)return;let{startContainer:n,startOffset:r}=t.getRangeAt(0);if(!(n instanceof Text)||r<e||!/^[  ]+$/.test(n.data.slice(r-e,r)))return;let i=document.createRange();i.setStart(n,r-e),i.setEnd(n,r),an(i),document.execCommand("delete")}var Ce=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("keydown",this.onKeyDown,!0)}presses=[];preview;menu;update(e,t){this.settings=e,this.enabled=t,this.active||this.preview?.close(!1)}get active(){return this.enabled&&this.settings.inputTranslate&&D()}onKeyDown=e=>{if(!this.active||this.preview)return;if(e.key!==" "||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||e.repeat){this.release(),this.presses=[];return}let t=or(e.composedPath()[0]??e.target);if(this.held&&this.held.field!==t&&this.release(),!t)return;let n=performance.now();this.presses=[...this.presses.filter(i=>n-i<tn),n];let r=this.presses.length>=nn;if(r&&(this.presses=[]),this.held||ir(t)){if(e.preventDefault(),r){this.forget(),this.openPreview(t);return}let i=(this.held?.count??0)+1;this.forget(),this.held={field:t,count:i,timer:setTimeout(()=>this.release(),tn)},document.addEventListener("pointerdown",this.release,!0);return}r&&(e.preventDefault(),ar(t,nn-1),this.openPreview(t))};held;forget(){this.held&&(clearTimeout(this.held.timer),this.held=void 0,document.removeEventListener("pointerdown",this.release,!0))}release=()=>{let e=this.held;e&&(this.forget(),document.activeElement!==e.field&&!e.field.contains(document.activeElement)&&e.field.focus(),sn(e.field," ".repeat(e.count)))};openPreview(e){let t=rr(e);if(!rn(t.text))return;let n=cn(e),r=n??sr(e);r&&(!rn(r.text)||r.text.trim()===t.text.trim())&&(r=null);let i={part:r,all:t},s=r?"part":"all";this.preview?.close(!1);let a=x("div","write-pop");a.setAttribute("role","dialog"),a.setAttribute("aria-label",w("sectionInput"));let l=x("button","write-lang");l.type="button",l.title=w("inputOtherLanguage"),l.setAttribute("aria-haspopup","listbox");let c=x("span","","");l.append(c,x("i","write-chevron"));let d=O("close",w("close"),()=>k(!0));d.classList.add("write-close");let u=x("div","write-result",w("translating"));u.dataset.state="loading",u.tabIndex=-1;let h=x("div","write-foot"),p=x("button","write-copy",w("copy"));p.type="button";let g=x("button","write-replace",w("writeReplace"));g.type="button",h.append(l);let m=new Map;if(r){let E=x("div","write-scope");E.setAttribute("role","radiogroup");for(let[A,R]of[["part",w(n?"writeScopePicked":"writeScopeLine")],["all",w("writeScopeAll")]]){let P=x("button","",R);P.type="button",P.setAttribute("role","radio"),P.addEventListener("click",()=>{s!==A&&(s=A,f(),$(T))}),m.set(A,P),E.append(P)}h.append(E)}let f=()=>{for(let[E,A]of m)A.setAttribute("aria-checked",String(E===s))};f(),h.append(x("span","grow"),p,g),a.append(d,u,h),this.ui.add(a);let b=new Map,v=()=>i[s].text.trim(),T=this.settings.inputLang,S="",N=0,H=!1,$=async E=>{T=E,c.textContent=vt(E);let A=++N,R=`${s} ${E}`,P=v(),ue=b.get(R);if(ue!==void 0){B(ue);return}S="",u.dataset.state="loading",u.textContent=w("translating"),g.setAttribute("aria-busy","true"),p.disabled=!0,y();try{let lt=await I({type:"translate",items:[U(P)],from:"",to:E});if(A!==N||this.preview?.node!==a)return;let ct=lt?.results?.[0];if(ct?.ok){let Wt=ee(ct.text);b.set(R,Wt),B(Wt)}else L(this.ui.errorMessage(ct?.code??"network"))}catch{A===N&&D()&&L(this.ui.errorMessage("network"))}},B=E=>{if(S=E,delete u.dataset.state,u.textContent=E,g.removeAttribute("aria-busy"),p.disabled=!1,H){C();return}y(),g.focus()},L=E=>{H=!1,g.removeAttribute("aria-busy"),u.dataset.state="error",u.textContent=E,y()},C=()=>{let E=S,A=i[s];k(!1),A.select()?sn(e,E):e.focus()},y=()=>{let E=e.getBoundingClientRect(),R=Math.min(nr,Math.max(r?tr:er,E.width),innerWidth-q*2);a.style.width=`${R}px`;let P=a.offsetHeight,ue=E.top-P-q,lt=ue>=q?ue:Math.min(E.bottom+q,innerHeight-P-q);a.style.left=`${Math.max(q,Math.min(E.left,innerWidth-R-q))}px`,a.style.top=`${Math.max(q,lt)}px`},k=E=>{++N,document.removeEventListener("pointerdown",M,!0),this.menu?.remove(),this.menu=void 0,a.remove(),this.preview?.node===a&&(this.preview=void 0),E&&e.focus()},M=E=>{this.ui.ownsEvent(E)||k(!1)};g.addEventListener("click",()=>{S?C():u.dataset.state==="loading"&&(H=!0)}),p.addEventListener("click",()=>{S&&navigator.clipboard.writeText(S).then(()=>{p.textContent=w("copied"),setTimeout(()=>p.textContent=w("copy"),1200)})}),l.addEventListener("click",()=>{this.chooseLanguage(l.getBoundingClientRect(),T,E=>void $(E))}),a.addEventListener("keydown",E=>{if(E.key==="Escape"){E.preventDefault(),k(!0);return}if(!(E.ctrlKey||E.metaKey)||E.altKey||E.shiftKey)return;let A=E.key.toLowerCase();if(A==="a")E.preventDefault(),getSelection()?.selectAllChildren(u);else if(A==="c"&&S){let R=getSelection()?.toString()??"";(!R.trim()||!S.includes(R.trim()))&&(E.preventDefault(),navigator.clipboard.writeText(S))}}),document.addEventListener("pointerdown",M,!0),this.preview={node:a,field:e,close:k},y(),g.focus(),$(T)}chooseLanguage(e,t,n){this.menu?.remove();let r=x("div","lang-menu");r.setAttribute("role","dialog"),r.setAttribute("aria-label",w("inputLang"));let i=x("input","lang-menu-search");i.placeholder=w("searchLanguage");let s=x("div","lang-menu-list");s.setAttribute("role","listbox"),r.append(i,s),this.menu=this.ui.add(r);let a=[],l=Math.max(0,pe.findIndex(m=>m.code===t)),c=()=>{let m=i.value.trim().toLowerCase(),f=pe.map(v=>v.code),b=v=>!m||vt(v).toLowerCase().includes(m)||v.toLowerCase().startsWith(m)||(Jt[v]??"").includes(m);a=f.filter(b),l=Math.min(l,Math.max(0,a.length-1)),s.replaceChildren(...a.map((v,T)=>{let S=x("button","lang-menu-item",vt(v));return S.type="button",S.toggleAttribute("data-active",T===l),S.toggleAttribute("data-current",v===t),S.addEventListener("mousedown",N=>N.preventDefault()),S.addEventListener("click",()=>u(v)),S})),a.length||s.append(x("div","lang-menu-empty",w("noLanguage"))),s.children[l]?.scrollIntoView({block:"nearest"})},d=()=>{r.remove(),this.menu===r&&(this.menu=void 0)},u=m=>{d(),n(m)};i.addEventListener("input",()=>{l=0,c()}),i.addEventListener("keydown",m=>{m.key==="ArrowDown"||m.key==="ArrowUp"?(m.preventDefault(),l=(l+(m.key==="ArrowDown"?1:-1)+a.length)%Math.max(1,a.length),c()):m.key==="Enter"?(m.preventDefault(),a[l]&&u(a[l])):m.key==="Escape"&&(m.preventDefault(),m.stopPropagation(),d())}),c();let h=r.offsetHeight,p=r.offsetWidth,g=innerHeight-e.bottom-q;r.style.left=`${Math.max(q,Math.min(e.left,innerWidth-p-q))}px`,r.style.top=`${g>=h||g>=e.top?e.bottom+4:e.top-h-4}px`,i.focus()}};function dn(o,e){let t=new Set,n=r=>{let i=r.composedPath()[0];return i instanceof Element?i.localName==="yl-ui"?!0:i.matches("input,textarea,select")||!!i.closest('[contenteditable]:not([contenteditable="false"]),[role="textbox"]'):!1};window.addEventListener("keydown",r=>{if(qt(r.code))return;t.add(r.code);let i=Ut(r);if(n(r)&&!i.some(c=>c!=="Shift"))return;let s=[...i,...t],a=o();for(let c of pt){let d=a[c];if(zt(d,s)){r.preventDefault(),r.stopPropagation(),r.repeat||e(c);return}}pt.some(c=>{let{mods:d,keys:u}=jt(a[c]);return u.length>1&&u.includes(r.code)&&d.length===i.length&&d.every(h=>i.includes(h))})&&(r.preventDefault(),r.stopPropagation())},!0),window.addEventListener("keyup",r=>t.delete(r.code),!0),window.addEventListener("blur",()=>t.clear())}var un=8,Ae=36,Re=18,Ne=class{constructor(e){this.ui=e}shade;box;hint;start;pointer={x:0,y:0};raf=0;onDone;get running(){return this.shade!==void 0}begin(e){this.running||(this.onDone=e,this.shade=this.ui.add(x("div","marquee-shade")),this.hint=this.ui.add(x("div","marquee-hint",w("marqueeHint"))),this.shade.addEventListener("pointerdown",this.onDown),this.shade.addEventListener("pointermove",this.onMove),this.shade.addEventListener("pointerup",this.onUp),this.shade.addEventListener("wheel",this.onWheel,{passive:!1}),addEventListener("keydown",this.onKey,!0),addEventListener("scroll",this.draw,!0),addEventListener("blur",this.cancel))}cancel=()=>this.end();end(){cancelAnimationFrame(this.raf),this.raf=0,removeEventListener("keydown",this.onKey,!0),removeEventListener("scroll",this.draw,!0),removeEventListener("blur",this.cancel),this.shade?.remove(),this.box?.remove(),this.hint?.remove(),this.shade=this.box=this.hint=void 0,this.start=void 0}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.end())};onDown=e=>{e.button===0&&(e.preventDefault(),this.shade.setPointerCapture(e.pointerId),this.start={x:e.clientX+scrollX,y:e.clientY+scrollY},this.pointer={x:e.clientX,y:e.clientY},this.box=this.ui.addFrame(),this.hint?.remove(),this.hint=void 0,this.draw(),this.raf=requestAnimationFrame(this.edgeScroll))};onMove=e=>{this.start&&(this.pointer={x:e.clientX,y:e.clientY},this.draw())};onUp=()=>{if(!this.start)return;let e=this.currentRect();this.end(),e.right-e.left>=un&&e.bottom-e.top>=un&&this.onDone?.(e)};onWheel=e=>{e.preventDefault(),this.scrollTarget().scrollBy(e.deltaX,e.deltaY)};scrollTarget(){let e=document.elementsFromPoint(this.pointer.x,this.pointer.y);for(let t of e)if(!this.ui.isHost(t)){for(let n=t;n&&n!==document.documentElement;n=n.parentElement){let r=getComputedStyle(n).overflowY;if((r==="auto"||r==="scroll")&&n.scrollHeight>n.clientHeight)return n}break}return window}edgeScroll=()=>{if(!this.start)return;let{x:e,y:t}=this.pointer,n=t<Ae?-Re:t>innerHeight-Ae?Re:0,r=e<Ae?-Re:e>innerWidth-Ae?Re:0;(r||n)&&window.scrollBy(r,n),this.raf=requestAnimationFrame(this.edgeScroll)};currentRect(){let e=this.start.x-scrollX,t=this.start.y-scrollY;return{left:Math.min(e,this.pointer.x),top:Math.min(t,this.pointer.y),right:Math.max(e,this.pointer.x),bottom:Math.max(t,this.pointer.y)}}draw=()=>{if(!this.start||!this.box)return;let e=this.currentRect();Object.assign(this.box.style,{left:`${_(e.left)}px`,top:`${_(e.top)}px`,width:`${_(e.right-e.left)}px`,height:`${_(e.bottom-e.top)}px`})}};var re=new Set(["yl-t","yl-r","yl-ui"]),lr=new Set(["script","style","noscript","template","head","meta","link","title","base","datalist","area","map","param","source","track","rp"]),cr=new Set(["pre","textarea","input","select","option","optgroup","canvas","video","audio","iframe","frame","frameset","object","embed","applet","listing","xmp","plaintext"]),dr=new Set(["code","kbd","samp","var","tt","img","picture","svg","math","ruby","wbr"]),ur=new Set(["CodeMirror","cm-editor","cm-content","cm-line","monaco-editor","monaco-diff-editor","ace_editor","hljs","prism-code","shiki","astro-code","xterm","blob-code","blob-code-inner","blob-wrapper","blob-num","react-code-lines","react-code-text","react-file-line","react-syntax-highlighter","syntaxhighlighter","code-block","codeblock","code-toolbar","sourceCode","gist-file","gist-data","d2h-wrapper","d2h-file-wrapper","mw-highlight","rouge-table","rouge-code","linenums","line-numbers","lineno","hljs-ln","katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),pr=new Set(["highlight","highlighter-rouge","codehilite","code","prism","terminal","gist","source","snippet","example"]),hr=["language-","lang-","highlight-source-","highlight-text-","brush:"],mr=new Set(["code","textbox","searchbox","combobox","math","img","slider","spinbutton"]),fr=/^\s*"?'?(monospace|ui-monospace|consolas|menlo|monaco|courier|courier new|lucida console|lucida sans typewriter|sfmono-regular|sf mono|fira code|fira mono|source code pro|jetbrains mono|roboto mono|ibm plex mono|dejavu sans mono|liberation mono|cascadia code|cascadia mono|ubuntu mono|hack|inconsolata)\b/i,gr='nav,button,[role="navigation"],[role="menu"],[role="menubar"],[role="tablist"],[role="toolbar"],[role="button"],[role="menuitem"],[role="tab"]';function Et(o){return fr.test(o)}function pn(o){let e=o.classList;for(let t=0;t<e.length;t++){let n=e[t];if(ur.has(n)||(pr.has(n)||hr.some(r=>n.startsWith(r)))&&br(o))return!0}return!1}function br(o){for(let e of Array.from(o.children)){let t=e.localName;if(t==="pre"||t==="code"||t==="table"||e.firstElementChild?.localName==="pre")return!0}return!1}var yr=/^(material-icons(-[\w-]+)?|material-symbols(-[\w-]+)?|mdi|mdi-[\w-]+|fa|fas|far|fab|fal|fa-[\w-]+|bi|bi-[\w-]+|glyphicon|glyphicon-[\w-]+|iconfont|anticon|anticon-[\w-]+)$/;function vr(o){if(o.childElementCount>0)return!1;let e=(o.textContent??"").trim();if(e.length>40||/\s/.test(e))return!1;let t=o.classList;for(let n=0;n<t.length;n++)if(yr.test(t[n]))return!0;return o.getAttribute("aria-hidden")==="true"&&/^[a-z0-9_]+$/.test(e)}function wr(o){if(o.getAttribute("translate")==="no")return!0;let e=o.getAttribute("contenteditable");if(e!==null&&e!=="false")return!0;let t=o.getAttribute("role");return!!(t&&mr.has(t))}var Le=class{excludeSelector=null;setExcludes(e){let t=e.split(`
`).map(n=>n.trim()).filter(n=>n&&kr(n));this.excludeSelector=t.length?t.join(","):null}classify(e){let t=e.localName;if(t==="br")return"br";if(re.has(t))return"own";if(lr.has(t))return"hidden";let n=getComputedStyle(e);if(cr.has(t))return n.display==="none"?"hidden":"skip";if(n.display==="none"||n.visibility==="hidden"||n.visibility==="collapse")return"collapsed";if(n.position==="absolute"&&parseFloat(n.width)<=1&&parseFloat(n.height)<=1)return"hidden";let r=Sr(n.display);if(dr.has(t)||vr(e)||wr(e)||pn(e)||this.isExcluded(e))return r?"atomic":"skip";if(Et(n.fontFamily)){let i=e.parentElement,s=i?Et(getComputedStyle(i).fontFamily):!1;if(r&&!s)return"atomic";if(!r&&n.whiteSpace.startsWith("pre"))return"skip"}return t==="button"||e.getAttribute("role")==="button"||e.localName.includes("-")&&Tr(e)?"block":r?"inline":"block"}isExcluded(e){return this.excludeSelector!==null&&e.matches(this.excludeSelector)}},xr=new Set(["katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),Er=new Set(["pre","code","samp","kbd","listing","xmp","plaintext"]);function hn(o){if(Er.has(o.localName)||o.querySelector("pre"))return!0;let e=o.classList;for(let n=0;n<e.length;n++){let r=e[n];if(xr.has(r))return!1}if(pn(o))return!0;let t=getComputedStyle(o);return Et(t.fontFamily)&&t.whiteSpace.startsWith("pre")}function Pe(o){return o.matches(gr)}function mn(o,e){let t=n=>{let r=n.toLowerCase(),i=r.split("-")[0];return i!=="zh"&&i!=="yue"?i:/hant|-tw|-hk|-mo/.test(r)||i==="yue"?"zh-hant":"zh-hans"};return t(o)===t(e)}function Sr(o){return o==="inline"||o==="inline-block"||o==="inline-flex"||o==="inline-grid"||o===""||o==="ruby"}function ie(o){if(o.shadowRoot)return o.shadowRoot;if(!o.localName.includes("-"))return null;try{return chrome.dom?.openOrClosedShadowRoot?.(o)??null}catch{return null}}function Tr(o){return ie(o)!==null}function kr(o){try{return document.createDocumentFragment().querySelector(o),!0}catch{return!1}}function Ie(o){let e=o.trim();return!new RegExp("\\p{L}","u").test(e)||/^(https?:\/\/|www\.)\S+$/i.test(e)||/^\S+@\S+\.\S+$/.test(e)?!1:!Mr(e)}function Mr(o){let e=o.replace(/^[("'“‘[]+|[.,:;!?)"'”’\]]+$/g,"");return/^[\w$.:/\\#()<>=\-[\]{}]+$/.test(e)?/\w_\w|\w\.\w|\(\)|::|^--|\w=|\w[/\\]\w|^[#$.]\w/.test(e):!1}var Cr=/[這個們來時會對說為學國還過發現點開關與實體後經機於從無見長問間電動應當將麼樣邊裡寫話讀請]/,Ar=/[这个们来时会对说为学国还过发现点开关与实体后经机于从无见长问间电动应当将么样边里写话读请]/;function me(o,e){let t=o.match(new RegExp("\\p{L}","gu"));if(!t)return!1;let n=i=>(o.match(i)?.length??0)/t.length,r=e.split("-")[0];return r==="zh"?/[぀-ヿ]/.test(o)||n(new RegExp("\\p{Script=Han}","gu"))<.6?!1:e==="zh-Hant"?!Ar.test(o):!Cr.test(o):r==="ja"?n(/[぀-ヿ]/g)>.2:r==="ko"?n(new RegExp("\\p{Script=Hangul}","gu"))>.5:!1}var Rr=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,Nr=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,bn="data-yl-mirror",fn=new Set(["script","noscript","iframe","frame","object","embed","meta","title","base","style","link","yl-ui","yl-t","yl-r"]),Lr=["class","style","open","hidden"],gn=`
*, *::before, *::after { visibility: hidden !important; transition: none !important; animation: none !important; }
html, body { visibility: visible !important; scroll-behavior: auto !important; overscroll-behavior: contain; }

* { scrollbar-color: transparent transparent !important; }
html { overflow-x: hidden !important; }
[data-yl-pinned], [data-yl-pinned] *, [data-yl-pinned]::before, [data-yl-pinned]::after { visibility: hidden !important; background: none !important; box-shadow: none !important; border-color: transparent !important; }
mark[data-yl-find] { background: rgba(255, 215, 49, 0.6) !important; color: inherit !important; border-radius: 2px; }
mark[data-yl-find][data-active] { background: #ff9632 !important; }
[data-yl-box] { visibility: visible !important; }
[data-yl-box]::before, [data-yl-box]::after { visibility: visible !important; }
yl-m { display: contents !important; }
yl-m, yl-m *, yl-m *::before, yl-m *::after,
[data-yl-all], [data-yl-all] *, [data-yl-all]::before, [data-yl-all]::after,
[data-yl-all] *::before, [data-yl-all] *::after { visibility: visible !important; }
yl-m[data-pending] > * , yl-m[data-pending] { opacity: 0.45; }
[data-yl-hidden] { display: none !important; }
`;function yn(){try{return!!window.frameElement?.hasAttribute(bn)}catch{return!1}}var He=class{constructor(e,t,n,r){this.sourceScroller=t;this.onClick=n;this.onKey=r;this.frame=document.createElement("iframe"),this.frame.setAttribute(bn,""),this.frame.setAttribute("sandbox","allow-same-origin"),this.frame.setAttribute("tabindex","-1"),e.append(this.frame),this.build()}frame;doc;map=new WeakMap;observer;build(){let e=this.frame.contentDocument;if(!e)throw new Error("mirror frame has no document");this.doc=e;let t=e.importNode(document.documentElement,!0),n=[];this.pair(document.documentElement,t,n);for(let r of n)r.remove();e.replaceChild(t,e.documentElement),this.addStyles(t),e.addEventListener("click",this.handleClick,!0),e.addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutations),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:Lr}),this.copyScroll()}pair(e,t,n){if(this.map.set(e,t),t.nodeType===Node.ELEMENT_NODE){let s=t;if(fn.has(s.localName)){n.push(s);return}this.clean(s);let a=ie(e);a&&this.copyShadow(a,s,n)}let r=e.childNodes,i=t.childNodes;for(let s=0;s<r.length;s++){let a=r[s],l=i[s];a&&l&&this.pair(a,l,n)}}copyShadow(e,t,n){let r;try{r=t.attachShadow({mode:"open"})}catch{return}let i=this.doc.createElement("style");i.textContent=gn,r.append(i);for(let s of Array.from(e.childNodes)){let a=this.doc.importNode(s,!0);r.append(a),!(s.nodeType===Node.ELEMENT_NODE&&s.localName==="style")&&this.pair(s,a,n)}}clean(e){for(let n of Array.from(e.attributes))n.name.toLowerCase().startsWith("on")&&e.removeAttribute(n.name);let t=e.localName;(t==="video"||t==="audio")&&(e.removeAttribute("autoplay"),e.removeAttribute("src")),t==="img"&&e.removeAttribute("loading")}addStyles(e){let t=e.querySelector("head");t||(t=this.doc.createElement("head"),e.prepend(t));let n=(i,s)=>{let a=this.doc.createElement("style");s&&(a.media=s),a.textContent=Array.from(i,l=>l.cssText).join(`
`),t.append(a)};for(let i of Array.from(document.styleSheets)){let s=i.ownerNode;if(s&&s.closest("yl-ui"))continue;let a=null;try{a=i.cssRules}catch{}if(a)n(a,i.media.mediaText||void 0);else if(i.href){let l=this.doc.createElement("link");l.rel="stylesheet",l.href=i.href,i.media.mediaText&&(l.media=i.media.mediaText);let c=s?.getAttribute("crossorigin");c!=null&&l.setAttribute("crossorigin",c),t.append(l)}}try{for(let i of Array.from(document.adoptedStyleSheets??[]))n(i.cssRules)}catch{}let r=this.doc.createElement("style");r.textContent=gn,t.append(r)}onMutations=e=>{for(let t of e){if(t.type==="attributes"){let r=this.map.get(t.target),i=t.attributeName;if(!r||!i)continue;let s=t.target.getAttribute(i);s===null?r.removeAttribute(i):r.setAttribute(i,s);continue}let n=this.map.get(t.target);if(n)for(let r of Array.from(t.addedNodes)){if(this.map.has(r)||r.nodeType===Node.ELEMENT_NODE&&fn.has(r.localName))continue;let i=this.doc.importNode(r,!0),s=[];this.pair(r,i,s);for(let l of s)l.remove();let a=r.nextSibling?this.map.get(r.nextSibling):null;n.insertBefore(i,a&&a.parentNode===n?a:null)}}};handleClick=e=>{let t=e.target;if(!t||t.nodeType!==Node.ELEMENT_NODE)return;let n=t,r=n.closest("a[href]");if(e.preventDefault(),r&&/^https?:/i.test(r.href)){window.open(r.href,"_blank","noopener");return}this.onClick(n,e)};revealBoxes(e){for(let t=e;t&&t.nodeType===Node.ELEMENT_NODE;t=t.parentNode){let n=t;if(n.hasAttribute("data-yl-box"))return;n.setAttribute("data-yl-box","")}}showRun(e,t){let n=e.map(s=>this.map.get(s)).filter(s=>!!s&&!!s.parentNode),r=n[0];if(!r?.parentNode)return null;let i=this.doc.createElement("yl-m");t&&i.setAttribute("data-pending",""),r.parentNode.insertBefore(i,r);for(let s of n)i.append(s);return this.revealBoxes(i.parentNode),i}showWhole(e){let t=this.map.get(e);return t?(t.setAttribute("data-yl-all",""),this.revealBoxes(t.parentNode),t):null}setTranslation(e,t,n,r){let i=this.doc.createDocumentFragment();this.append(i,t,n);let s=Z(t);for(let a of r){let l=n[a];if(l?.atomic&&!s.has(a)){let c=this.copyAtomic(l);c&&i.append(this.doc.createTextNode(" "),c)}}e.replaceChildren(i),e.removeAttribute("data-pending")}setKept(e){e.removeAttribute("data-pending")}copyAtomic(e){let t=this.map.get(e.el);return t?t.cloneNode(!0):this.doc.importNode(e.el,!0)}append(e,t,n){t.forEach((r,i)=>{if(typeof r=="string"){r.split(`
`).forEach((c,d)=>{d>0&&e.appendChild(this.doc.createElement("br")),c&&e.appendChild(this.doc.createTextNode(c))});return}let s=n[r.slot];if(!s)return;if(s.atomic){let c=t[i-1],d=t[i+1];typeof c=="string"&&Rr.test(c)&&e.appendChild(this.doc.createTextNode(" "));let u=this.copyAtomic(s);u&&e.appendChild(u),typeof d=="string"&&Nr.test(d)&&e.appendChild(this.doc.createTextNode(" "));return}let a=this.map.get(s.el),l=a?a.cloneNode(!1):this.doc.importNode(s.el,!1);this.append(l,r.children,n),e.appendChild(l)})}get scroller(){return this.sourceScroller?this.map.get(this.sourceScroller)??null:this.doc.scrollingElement}copyScroll(){let e=this.scroller;e&&(e.scrollTop=this.sourceScroller?this.sourceScroller.scrollTop:scrollY)}get scrollerTop(){let e=this.scroller;return!e||e===this.doc.scrollingElement?0:Math.max(0,e.getBoundingClientRect().top)}alignTo(e,t){let n=this.scroller;if(!n)return;let r=this.doc.createRange();r.selectNodeContents(e);let i=r.getBoundingClientRect();if(!i.width&&!i.height)return;let s=i.top-t;Math.abs(s)>.5&&(n.scrollTop+=s)}hidePinned(){for(let e of Array.from(this.doc.querySelectorAll("body *"))){let t=this.frame.contentWindow?.getComputedStyle(e).position;(t==="fixed"||t==="sticky")&&e.setAttribute("data-yl-pinned","")}}textOf(e){return e.textContent??""}destroy(){this.observer?.disconnect(),this.observer=void 0,this.frame.remove()}};var Pr=new Set(["a","b","strong","i","em","u","s","del","ins","mark","sub","sup","abbr","cite","q","small","big","font","dfn","strike","label"]),Ir=["fontWeight","fontStyle","color","backgroundColor","textDecorationLine","fontSize","fontFamily"];function Hr(o){let e=o.parentElement;if(!e)return!0;let t=getComputedStyle(o),n=getComputedStyle(e);return t.display!=="inline"?!0:Ir.some(r=>t[r]!==n[r])}var vn=4;function St(o){return o==="inline-block"||o==="inline-flex"||o==="inline-grid"}function Dr(o){let e=getComputedStyle(o);return St(e.display)?!0:parseFloat(e.marginLeft)>=vn||parseFloat(e.marginRight)>=vn}function _r(o){let e=[];for(let n of o)if(n.nodeType===Node.TEXT_NODE)e.push(n);else if(n.nodeType===Node.ELEMENT_NODE){let r=document.createTreeWalker(n,NodeFilter.SHOW_TEXT);for(let i=r.nextNode();i;i=r.nextNode())e.push(i)}let t=[];for(let n=e.length-1;n>=0;n--){let r=e[n];if(De(r.data)||t.some(s=>s.contains(r)))continue;let i=Or(r,o);if(!i)break;t.unshift(i)}return new Set(t)}function Or(o,e){let t=null;for(let n=o.parentElement;n;n=n.parentElement){if(e.includes(n))return t;St(getComputedStyle(n).display)&&(t=n)}return null}function De(o){return!/[^ \t\r\n\f]/.test(o)}var se=class{classifier=new Le;kinds=new WeakMap;blockDescendant=new WeakMap;reset(){this.kinds=new WeakMap,this.blockDescendant=new WeakMap}kindOf(e){let t=this.kinds.get(e);return t===void 0&&(t=this.classifier.classify(e),this.kinds.set(e,t)),t}*scan(e,t,n=!1){let r=[],i=0,s=()=>{if(r.length){let a=this.buildRun(r,e,n);a?t.emit(a):t.plain?.(r,e)}r=[],i=0};for(let a of Array.from(e.childNodes)){if(t.consume(a)){s();continue}if(a.nodeType===Node.TEXT_NODE){let d=De(a.data);d||(i=0),(!d||r.length)&&r.push(a);continue}if(a.nodeType!==Node.ELEMENT_NODE)continue;let l=a;switch(this.kindOf(l)){case"own":case"hidden":break;case"collapsed":yield*this.scan(l,t,n||Pe(l));break;case"skip":s(),t.skipped?.(l);break;case"br":r.length&&r.push(l),++i>=2&&s();break;case"atomic":i=0,r.push(l);break;case"inline":this.isolatedInlineBlock(l,e)||this.hasBlockDescendant(l)?(s(),yield*this.scan(l,t,n||Pe(l))):(i=0,r.push(l));break;case"block":{s();let d=n||Pe(l);yield*this.scan(l,t,d);let u=ie(l);u&&(t.shadowRoot(u),yield*this.scan(u,t,d)),yield;break}}}if(s(),e.nodeType===Node.ELEMENT_NODE&&!Br(e)){let a=ie(e);a&&(t.shadowRoot(a),yield*this.scan(a,t,n))}}isolatedInlineBlock(e,t){if(!St(getComputedStyle(e).display))return!1;for(let n of Array.from(t.childNodes))if(n.nodeType===Node.TEXT_NODE&&!De(n.data))return!1;return!0}hasBlockDescendant(e){let t=this.blockDescendant.get(e);if(t!==void 0)return t;let n=!1;for(let r of Array.from(e.children)){let i=this.kindOf(r);if(i==="block"||i==="skip"||i==="inline"&&this.hasBlockDescendant(r)){n=!0;break}}return this.blockDescendant.set(e,n),n}buildRun(e,t,n){let r=[],i=t.nodeType===Node.ELEMENT_NODE?t:t.host,s=getComputedStyle(i).whiteSpace,a=s==="pre-line"||s==="pre-wrap"||s==="pre"||s==="break-spaces",l=[],c=[],d=_r(e);for(let p of e)this.serialize(p,a,r,c,l,d);for(let p of d){c.push(`
`);let g=r.length;this.serialize(p,a,r,c,l);let m=r[g];m&&(m.detached=!0)}let u=wn(l.join(""));if(!Ie(u))return null;let h=e.slice();for(;h.length>1;){let p=h[h.length-1];if(!(p.nodeType===Node.TEXT_NODE?De(p.data):p.localName==="br"))break;h.pop()}return{nodes:h,parent:t,markup:wn(c.join("")),slots:r,text:u,compact:n}}serialize(e,t,n,r,i,s){if(s?.has(e))return;if(e.nodeType===Node.TEXT_NODE){let h=e.data,p=t?h.replace(/[ \t\r\f]+/g," "):h.replace(/[ \t\r\n\f]+/g," ");r.push(U(p)),i.push(p);return}if(e.nodeType!==Node.ELEMENT_NODE)return;let a=e,l=this.kindOf(a);if(l==="br"){r.push(`
`),i.push(`
`);return}if(l==="hidden"||l==="collapsed"||l==="own"||l==="skip")return;if(l==="atomic"){let h=n.length;n.push({el:a,atomic:!0});let p=(a.textContent??"").replace(/\s+/g," ").trim()||a.getAttribute("alt")||"•";r.push(`<x${h}>${U(p)}</x${h}>`);return}let c=Pr.has(a.localName)||Hr(a),d=c?n.length:-1,u=Dr(a);u&&(r.push(" "),i.push(" ")),c&&(n.push({el:a,atomic:!1}),r.push(`<x${d}>`));for(let h of Array.from(a.childNodes))this.serialize(h,t,n,r,i,s);c&&r.push(`</x${d}>`),u&&(r.push(" "),i.push(" "))}};function Br(o){return o.localName.includes("-")}function wn(o){return o.replace(/ *\n */g,`
`).replace(/ {2,}/g," ").trim()}function xn(o,e){let t=o.nodeType===Node.ELEMENT_NODE?o:o.parentNode;for(;t;){if(t.nodeType===Node.DOCUMENT_FRAGMENT_NODE)return t;if(t.nodeType!==Node.ELEMENT_NODE)return null;let n=t,r=e.kindOf(n);if(r==="block"||r==="collapsed"||n===document.body)return n;if(r==="skip"||r==="hidden")return null;t=n.parentNode}return null}var _e=new WeakSet;function Tt(o){for(let e of Array.from(o.querySelectorAll("yl-t,yl-r")))_e.has(e)||e.remove();for(let e of Array.from(o.querySelectorAll("[data-yl-hidden]")))_e.has(e)||e.removeAttribute("data-yl-hidden")}var $r=.98;function Fr(o){let e=/^rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(o);return e?.2126*Number(e[1])+.7152*Number(e[2])+.0722*Number(e[3])>140:!1}function Oe(o,e,t){if(!e||!o.detected||o.score===void 0||o.score>=$r)return!1;let n=o.detected.split("-")[0];return n!==e&&n!==t.split("-")[0]}var kt=new WeakMap,Wr=24,qr=new Set(["en","fr","de","es","pt","it","nl","pl","tr","vi","id"]),Ur=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,jr=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,ae=class{constructor(e){this.run=e;this.wire=e.markup}state="idle";raw;wire;from="";fallback;hoverHost=null;tree;renderedMode;inserted;textBackup=new Map;written=new Map;hidden=[];unclamped;get markup(){return this.run.markup}get text(){return this.run.text}get compact(){return this.run.compact}get isRendered(){return this.renderedMode!==void 0}get rendersInPlace(){return this.renderedMode==="replace"}get anchor(){let e=this.parentElement;for(let t of this.run.nodes)if(t.nodeType===Node.ELEMENT_NODE){e=t;break}for(;e.parentElement&&getComputedStyle(e).display==="contents";)e=e.parentElement;return e}get parentElement(){let e=this.run.parent;return e.nodeType===Node.ELEMENT_NODE?e:e.host}sourceHint(){if(this.text.length>Wr||/[^\p{Script=Latin}\P{L}]/u.test(this.text))return"";let t=this.parentElement.closest("[lang]")?.getAttribute("lang")?.split("-")[0]?.toLowerCase()??"";return qr.has(t)?t:""}regionContent(e){let t=this.parentElement,n=this.sourceHint();if(this.rendersInPlace){let f=this.hoverHost;return{markup:this.markup,slots:this.run.slots,text:this.text,hint:n,block:t,rect:()=>f?.getBoundingClientRect()??null}}let r=new Map(this.run.slots.map((f,b)=>[f.el,b])),i=[],s=[],a=f=>{let b=f.left+f.width/2,v=f.top+f.height/2;return f.width>0&&b>=e.left&&b<=e.right&&v>=e.top&&v<=e.bottom},l=document.createRange(),c=!1,d=(f,b,v,T)=>{c||(l.setStart(f,b),c=!0),l.setEnd(v,T)},u=new Intl.Segmenter(void 0,{granularity:"word"}),h=document.createRange(),p=f=>{if(f.nodeType===Node.TEXT_NODE){for(let S of u.segment(f.data)){if(!S.isWordLike&&!/\S/.test(S.segment)){i.push(" "),s.push(" ");continue}h.setStart(f,S.index),h.setEnd(f,S.index+S.segment.length),a(h.getBoundingClientRect())&&(i.push(U(S.segment)),s.push(S.segment),d(f,S.index,f,S.index+S.segment.length))}return}if(f.nodeType!==Node.ELEMENT_NODE)return;let b=f;if(b.localName==="br"){i.push(`
`);return}if(re.has(b.localName))return;let v=r.get(b);if(v!==void 0&&this.run.slots[v].atomic){if(Array.from(b.getClientRects()).some(a)){i.push(`<x${v}>${U((b.textContent??"").trim()||"•")}</x${v}>`);let S=b.parentNode,N=Array.from(S.childNodes).indexOf(b);d(S,N,S,N+1)}return}let T=i.length;v!==void 0&&i.push(`<x${v}>`);for(let S of Array.from(b.childNodes))p(S);v!==void 0&&(i.slice(T+1).join("").trim()?i.push(`</x${v}>`):i.length=T)};for(let f of this.run.nodes)p(f);let g=i.join("").replace(/\s+/g,f=>f.includes(`
`)?`
`:" ").trim(),m=s.join("").replace(/\s+/g," ").trim();return!c||!Ie(m)?null:{markup:g,slots:this.run.slots,text:m,hint:n,block:t,rect:()=>l.getBoundingClientRect()}}clientRects(){let e=this.run.nodes,t=e[0],n=e[e.length-1];if(!t||!n||!t.isConnected)return[];if(this.rendersInPlace&&this.inserted)return Array.from(this.inserted.getClientRects());let r=document.createRange();return r.setStartBefore(t),r.setEndAfter(n),Array.from(r.getClientRects())}setTranslation(e){this.raw=e;let t=new Set(this.run.slots.map((n,r)=>r));this.tree=Y(F(e,t),n=>!!this.run.slots[n]?.detached)}renderStatus(e,t,n){if(t.mode!=="dual"||this.renderedMode||this.compact)return;this.removeInserted();let r=document.createElement("yl-t");r.setAttribute("data-state",e),r.style.setProperty("--yl-theme",t.theme),e==="error"&&(r.setAttribute("data-yl-retry",""),r.textContent=n),this.insertAfterRun(r),this.inserted=r}clearStatus(){this.renderedMode||this.removeInserted()}render(e){this.tree&&(this.unrender(),e.mode==="dual"&&!this.compact?(this.renderDual(e),this.renderedMode="dual"):(this.renderReplace(e),this.renderedMode="replace"))}unrender(){this.removeInserted();for(let[e,t]of this.textBackup)e.data===this.written.get(e)&&(e.data=t);this.textBackup.clear(),this.written.clear();for(let e of this.hidden)e.removeAttribute("data-yl-hidden");this.hidden=[],this.unclamped?.removeAttribute("data-yl-unclamp"),this.unclamped=void 0,this.renderedMode=void 0,this.hoverHost=null}isIntact(){for(let e of this.run.nodes)if(!e.isConnected||e.parentNode!==this.run.parent)return!1;for(let[e,t]of this.written)if(e.data!==t)return!1;return!0}applyDualStyle(e){this.renderedMode==="dual"&&this.inserted&&this.decorate(this.inserted,e)}renderDual(e){let t=document.createElement("yl-t");t.setAttribute("lang",e.targetLang),t.setAttribute("dir","auto"),this.decorate(t,e),this.shouldBeInline()&&t.setAttribute("data-inline","");let n=document.createElement("yl-i");n.append(this.buildFragment()),t.append(n),this.insertAfterRun(t),this.inserted=t,this.hoverHost=t;let r=this.parentElement;getComputedStyle(r).webkitLineClamp!=="none"&&getComputedStyle(r).webkitLineClamp!==""&&(r.setAttribute("data-yl-unclamp",""),this.unclamped=r)}decorate(e,t){t.dualStyle==="plain"?e.removeAttribute("data-style"):e.setAttribute("data-style",t.dualStyle);let n=e,r=Fr(getComputedStyle(this.parentElement).color);n.style.setProperty("--yl-theme",Te(t.theme,r?Xt:Se)),r?e.setAttribute("data-tone","dark"):e.removeAttribute("data-tone"),n.style.fontSize=t.fontScale===100?"":`${t.fontScale}%`}shouldBeInline(){let e=this.parentElement,t=getComputedStyle(e);return t.whiteSpace==="nowrap"||t.whiteSpace==="pre"||t.display==="inline"||t.display==="inline-block"?!0:t.display.includes("flex")?!t.flexDirection.startsWith("column"):t.display.includes("grid")}renderReplace(e){let t=this.run.nodes,n=this.tree.some(s=>typeof s=="string"&&s.includes(`
`));if(t.every(s=>s.nodeType===Node.TEXT_NODE)&&!n&&this.run.slots.length===0){let s=this.tree.map(a=>typeof a=="string"?a:"").join("");t.forEach((a,l)=>{let c=a;this.textBackup.set(c,c.data);let d="";l===0&&(d=(/^\s/.test(c.data)?" ":"")+s),c.data=d,this.written.set(c,d)}),this.hoverHost=this.parentElement;return}for(let s of t)if(s.nodeType===Node.TEXT_NODE){let a=s;this.textBackup.set(a,a.data),a.data="",this.written.set(a,"")}else if(s.nodeType===Node.ELEMENT_NODE){let a=s;a.setAttribute("data-yl-hidden",""),_e.add(a),this.hidden.push(a)}let i=document.createElement("yl-r");i.setAttribute("lang",e.targetLang),i.append(this.buildFragment()),this.insertAfterRun(i),this.inserted=i,this.hoverHost=i}insertAfterRun(e){_e.add(e);let t=this.run.nodes[this.run.nodes.length-1];t.parentNode?.insertBefore(e,t.nextSibling)}removeInserted(){this.inserted?.remove(),this.inserted=void 0}buildFragment(){let e=document.createDocumentFragment();this.appendNodes(e,this.tree);let t=Z(this.tree);return this.run.slots.forEach((n,r)=>{n.atomic&&!t.has(r)&&e.append(" ",this.cloneSlot(n))}),e}appendNodes(e,t){t.forEach((n,r)=>{if(typeof n=="string"){this.appendText(e,n);return}let i=this.run.slots[n.slot];if(!i)return;if(i.atomic){let a=t[r-1],l=t[r+1];typeof a=="string"&&Ur.test(a)&&e.appendChild(document.createTextNode(" ")),e.appendChild(this.cloneSlot(i)),typeof l=="string"&&jr.test(l)&&e.appendChild(document.createTextNode(" "));return}let s=this.cloneShell(i);this.appendNodes(s,n.children),e.appendChild(s)})}appendText(e,t){t.split(`
`).forEach((r,i)=>{i>0&&e.appendChild(document.createElement("br")),r&&e.appendChild(document.createTextNode(r))})}cloneSlot(e){let t=e.el.cloneNode(!0);t.removeAttribute("id"),t.removeAttribute("data-yl-hidden");for(let n of t.querySelectorAll("[id]"))n.removeAttribute("id");return t}cloneShell(e){let t=e.el.cloneNode(!1);return t.removeAttribute("id"),t.removeAttribute("data-yl-hidden"),kt.set(t,e.el),t.style?.setProperty("--yl-c",getComputedStyle(e.el).color),t}};var En=`/* Injected into pages and shadow roots. Fonts and colours are inherited on purpose. */

yl-t {
  display: block !important;
  margin: 0.3em 0 0 !important;
  padding: 0;
  font-family: inherit;
  font-weight: inherit;
  line-height: inherit;
  color: inherit;
  white-space: normal !important;
  text-indent: 0;
  letter-spacing: normal;
  overflow-wrap: break-word;
  max-width: 100%;
  float: none !important;
  position: static !important;
}

yl-t[data-inline] {
  display: inline !important;
  margin: 0 0 0 0.5em !important;
  white-space: inherit !important;
}

yl-r {
  display: inline;
  font: inherit;
  color: inherit;
}

/*
 * One colour the reader picks, the same on every page. Its value is set on each translation.
 * The full palette belongs on thin frames only.
 */
/* Copying allowed again, by the reader's choice: text can be selected whatever the page says. */
html[data-yl-unlock] *:not(input):not(textarea) {
  -webkit-user-select: text !important;
  user-select: text !important;
}

yl-t {
  --yl-theme: #1f77f3;
  --yl-pen: 30%;
}

/* See-through colour dims over black: this much more looks the same as it does on white. */
yl-t[data-tone='dark'] {
  --yl-pen: 62%;
}

yl-t[data-style='accent'] {
  color: var(--yl-theme);
}

/* Links stay recognisably links; other coloured text leans to the ink. */
yl-t[data-style='accent'] a[style*='--yl-c'] {
  color: color-mix(in oklab, var(--yl-c) 65%, var(--yl-theme)) !important;
}

yl-t[data-style='accent'] [style*='--yl-c']:not(a) {
  color: color-mix(in oklab, var(--yl-c) 20%, var(--yl-theme)) !important;
}

yl-t[data-style='faded'] {
  opacity: 0.72;
}

yl-t[data-style='underline'] {
  text-decoration: underline dashed 1px var(--yl-theme);
  text-underline-offset: 0.32em;
}

/* A capsule that stops short of the block's ends, so it sits beside the text and not on it. */
yl-t[data-style='bar']:not([data-inline]) {
  position: relative !important;
  padding-left: 0.8em !important;
}

yl-t[data-style='bar']:not([data-inline])::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0.22em;
  bottom: 0.22em;
  width: 3px;
  border-radius: 3px;
  background: linear-gradient(180deg, var(--yl-theme), color-mix(in srgb, var(--yl-theme) 55%, transparent));
}

yl-t[data-style='bar'][data-inline] {
  color: var(--yl-theme);
}

/*
 * A highlighter pen that fades out upward, with no top edge to read as a band. It has to be
 * drawn on an inline box, because that is what follows each line of the text.
 */
yl-i {
  display: inline;
}

yl-t[data-style='highlight'] yl-i {
  background: linear-gradient(to top, color-mix(in srgb, var(--yl-theme) var(--yl-pen), transparent), transparent 78%);
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}

yl-t[data-state='loading'] {
  display: inline-block !important;
  width: 1.5em;
  height: 0.7em;
  margin: 0 0 0 0.4em !important;
  vertical-align: baseline;
  background-image:
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent);
  background-position: 0 50%, 50% 50%, 100% 50%;
  background-repeat: no-repeat;
  background-size: 0.26em 0.26em;
  opacity: 0.7;
  animation: yl-wave 1.05s ease-in-out infinite;
}

yl-t[data-state='error'] {
  font-size: 0.82em;
  color: #c62828;
  cursor: pointer;
  text-decoration: underline;
  text-underline-offset: 0.2em;
}

[data-yl-hidden] {
  display: none !important;
}

[data-yl-unclamp] {
  -webkit-line-clamp: unset !important;
  max-height: none !important;
  overflow: visible !important;
}

@keyframes yl-wave {
  0%,
  100% {
    background-size: 0.42em 0.42em, 0.26em 0.26em, 0.26em 0.26em;
  }
  33% {
    background-size: 0.26em 0.26em, 0.42em 0.42em, 0.26em 0.26em;
  }
  66% {
    background-size: 0.26em 0.26em, 0.26em 0.26em, 0.42em 0.42em;
  }
}

@media (prefers-reduced-motion: reduce) {
  yl-t[data-state='loading'] {
    animation: none;
  }
}
`;var Gr=30,Kr=5e3,Sn=4,Xr=60,Vr=400,Yr=300,Jr=8,Zr="800px 0px",Qr=8,ei=3e4,ti=450,ni=2,oi=3e3,Be=class{constructor(e,t){this.ui=t;this.settings=e,this.scanner.classifier.setExcludes(e.excludeSelectors),document.addEventListener("click",this.onClick,!0),document.addEventListener("mouseover",this.onMouseOver,!0),document.addEventListener("mouseout",this.onMouseOut,!0)}settings;scanner=new se;segments=new Set;byNode=new WeakMap;byAnchor=new Map;styledRoots=new WeakSet;watchedRoots=[];pageActive=!1;generation=0;io;mo;queue=[];inFlight=0;flushTimer;dirty=new Set;dirtyTimer;rebuilds=new WeakMap;lastError;errorToastShown=!1;statusTimer;pageLang;hoverTimer;hoverSeg;hoverHosts=new WeakMap;get active(){return this.pageActive}get hasTranslations(){for(let e of this.segments)if(e.isRendered||e.state==="loading"||e.state==="queued")return!0;return!1}setPageLang(e){this.pageLang=e}get display(){let e=this.settings;return{mode:e.mode,dualStyle:e.dualStyle,fontScale:e.fontScale,targetLang:e.targetLang,theme:te(e.themeColor)}}status(){let e=0,t=0,n=0,r=0;for(let s of this.segments)s.state!=="idle"&&(e++,s.state==="done"||s.state==="same"?t++:s.state==="failed"?n++:r++);let i={active:this.pageActive||this.hasTranslations,mode:this.settings.mode,total:e,done:t,failed:n,pending:r};return this.pageLang&&(i.pageLang=this.pageLang),location.hostname&&(i.host=location.hostname),n>0&&this.lastError&&(i.error=this.lastError),i}reportStatus(){this.statusTimer===void 0&&(this.statusTimer=setTimeout(()=>{this.statusTimer=void 0,D()&&I({type:"status",status:this.status()}).catch(()=>{})},150))}async startPage(){this.pageActive||!document.body||(this.pageActive=!0,this.errorToastShown=!1,this.startObservers(),await this.scanRoot(document.body),this.observeAllEligible(),this.reportStatus())}togglePage(){this.pageActive||this.hasTranslations?this.restore():this.startPage()}retire(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.ownWrite(()=>{for(let e of this.segments)e.state==="loading"&&e.clearStatus()})}restore(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.lastError=void 0;for(let e of this.segments)this.dropSegment(e,!0);this.segments.clear(),this.byAnchor.clear(),this.ui.hideTooltip(),this.reportStatus()}setMode(e){this.settings={...this.settings,mode:e},this.rerenderAll(),this.pageActive&&this.observeAllEligible(),this.reportStatus()}retryFailed(){this.errorToastShown=!1,this.lastError=void 0;for(let e of this.segments)e.state==="failed"&&(e.clearStatus(),this.enqueue(e))}applySettings(e){let t=this.settings;if(this.settings=e,e.excludeSelectors!==t.excludeSelectors&&this.scanner.classifier.setExcludes(e.excludeSelectors),(t.targetLang!==e.targetLang||t.sourceLang!==e.sourceLang)&&(this.pageActive||this.hasTranslations)){let r=this.pageActive,i=[...this.segments].filter(s=>s.isRendered);this.generation++,this.queue=[];for(let s of this.segments)s.unrender(),s.clearStatus(),s.state="idle",s.raw=void 0,s.wire=s.markup,s.from="",s.fallback=void 0;if(r)this.observeAllEligible();else for(let s of i)this.enqueue(s);return}t.mode!==e.mode?this.setMode(e.mode):(t.dualStyle!==e.dualStyle||t.fontScale!==e.fontScale||t.themeColor!==e.themeColor)&&this.ownWrite(()=>{for(let r of this.segments)r.applyDualStyle(this.display)})}async collectRegion(e){if(!document.body)return[];await this.scanRoot(document.body);let t=[];for(let n of this.segments){let r=n.clientRects();if(!ii(r,e))continue;let i=n.regionContent(e);!i||me(i.text,this.settings.targetLang)||t.push({top:r[0]?.top??0,left:r[0]?.left??0,content:i})}return this.pruneIdle(),t.sort((n,r)=>n.top-r.top||n.left-r.left).map(n=>n.content)}pruneIdle(){if(!this.pageActive){for(let e of this.segments)if(e.state==="idle"&&!e.isRendered){this.segments.delete(e);for(let t of e.run.nodes)this.byNode.delete(t)}}}hooks={consume:e=>{let t=this.byNode.get(e);return t?.rendersInPlace?t.isIntact()?(this.seen?.add(t),!0):(this.ownWrite(()=>this.dropSegment(t,!0)),this.segments.delete(t),!1):!1},emit:e=>this.register(e),shadowRoot:e=>this.adoptShadowRoot(e)};seen;async scanRoot(e){this.ownWrite(()=>Tt(e)),this.scanner.reset(),this.seen=new Set;let t=this.scanner.scan(e,this.hooks),n=performance.now();for(let r=t.next();!r.done;r=t.next())performance.now()-n>Jr&&(await new Promise(i=>setTimeout(i,0)),n=performance.now());this.seen=void 0}register(e){let t=e.nodes[0],n=this.byNode.get(t);if(n&&n.markup===e.markup){this.seen?.add(n);return}n&&(this.ownWrite(()=>this.dropSegment(n,!0)),this.segments.delete(n));let r=new ae(e);this.segments.add(r),this.seen?.add(r);for(let i of e.nodes)this.byNode.set(i,r);this.pageActive&&this.observeSegment(r)}observeSegment(e){if(!this.io||e.state!=="idle")return;let t=e.anchor,n=this.byAnchor.get(t);n||(n=new Set,this.byAnchor.set(t,n),this.io.observe(t)),n.add(e)}observeAllEligible(){for(let e of this.segments)this.observeSegment(e)}dropSegment(e,t){t&&(e.unrender(),e.clearStatus()),e.state="idle";for(let r of e.run.nodes)this.byNode.get(r)===e&&this.byNode.delete(r);let n=this.byAnchor.get(e.anchor);n&&(n.delete(e),n.size||(this.byAnchor.delete(e.anchor),this.io?.unobserve(e.anchor)))}adoptShadowRoot(e){if(this.styledRoots.has(e))return;this.styledRoots.add(e);let t=document.createElement("style");t.setAttribute("data-yl",""),t.textContent=En,e.append(t),this.watchedRoots.push(e),this.mo?.observe(e,Mt)}startObservers(){this.io=new IntersectionObserver(this.onIntersect,{rootMargin:Zr}),this.mo=new MutationObserver(this.onMutations),document.body&&this.mo.observe(document.body,Mt);for(let e of this.watchedRoots)this.mo.observe(e,Mt)}stopObservers(){this.io?.disconnect(),this.mo?.disconnect(),this.io=void 0,this.mo=void 0}onIntersect=e=>{for(let t of e){if(!t.isIntersecting)continue;let n=this.byAnchor.get(t.target);if(n){for(let r of n)this.enqueue(r);this.byAnchor.delete(t.target)}this.io?.unobserve(t.target)}};ownWrite(e){let t=this.mo?.takeRecords();t?.length&&this.onMutations(t),e(),this.mo?.takeRecords()}onMutations=e=>{for(let t of e){if(Tn(t.target))continue;if(t.type==="childList"){let r=[...Array.from(t.addedNodes),...Array.from(t.removedNodes)];if(r.length&&r.every(Tn))continue}let n=xn(t.target,this.scanner);n&&this.dirty.add(n)}this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},Yr))};async flushDirty(){let e=this.generation,t=[...this.dirty].filter(n=>{for(let r of this.dirty)if(r!==n&&r.contains(n))return!1;return n.isConnected});this.dirty.clear();for(let n of t){if(e!==this.generation||!this.pageActive)return;if(!this.allowRebuild(n)){this.dirty.add(n);continue}let r=[...this.segments].filter(s=>n.contains(s.run.parent));this.ownWrite(()=>Tt(n)),this.scanner.reset(),this.seen=new Set;let i=this.seen;for(let s of this.scanner.scan(n,this.hooks));this.seen=void 0;for(let s of r)i.has(s)||(this.ownWrite(()=>this.dropSegment(s,!0)),this.segments.delete(s))}for(let n of this.segments)n.anchor.isConnected||(this.dropSegment(n,!1),this.segments.delete(n));this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},oi)),this.reportStatus()}allowRebuild(e){let t=Date.now(),n=this.rebuilds.get(e);return!n||t-n.since>ei?(this.rebuilds.set(e,{n:1,since:t}),!0):(n.n++,n.n<=Qr)}enqueue(e,t=!1){if(!(e.state==="done"||e.state==="loading"||e.state==="same")&&!(e.state==="queued"&&!t)){if(me(e.text,this.settings.targetLang)){e.state="same";return}e.state!=="queued"&&(e.state="queued",t||this.queue.push(e)),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},Xr)),this.reportStatus()}}prioritizeQueue(){if(this.queue=this.queue.filter(n=>n.state==="queued"),this.queue.length<2)return;let e=innerHeight,t=new Map;for(let n of this.queue){let r=n.anchor.getBoundingClientRect();t.set(n,r.bottom<0?-r.bottom:r.top>e?r.top-e:0)}this.queue.sort((n,r)=>t.get(n)-t.get(r))}pump(){if(!(this.inFlight>=Sn))for(this.prioritizeQueue();this.inFlight<Sn&&this.queue.length;){let e=this.settings.sourceLang||this.queue[0].from,t=[],n=[],r=0;for(let i of this.queue)t.length<Gr&&(t.length===0||r+i.wire.length<=Kr)&&(this.settings.sourceLang||i.from)===e?(t.push(i),r+=i.wire.length):n.push(i);this.queue=n,this.sendBatch(t,e)}}async sendBatch(e,t){let n=this.generation;this.inFlight++;for(let s of e)s.state="loading";let r=setTimeout(()=>{n===this.generation&&this.ownWrite(()=>{for(let s of e)s.state==="loading"&&s.renderStatus("loading",this.display,"")})},Vr),i;for(let s=0;s<=ni&&!i;s++)try{let a=await I({type:"translate",items:e.map(l=>l.wire),from:t,to:this.settings.targetLang});a?.results?.length===e.length&&(i=a.results)}catch{if(!D())break}if(clearTimeout(r),this.inFlight--,!D()){this.retire();return}n===this.generation&&this.applyResults(e,i),this.pump(),this.reportStatus()}applyResults(e,t){this.ownWrite(()=>{e.forEach((n,r)=>{if(!this.segments.has(n))return;let i=t?.[r]??{ok:!1,code:"network"};if(!i.ok){n.state="failed",this.lastError=i.code,n.clearStatus(),n.renderStatus("error",this.display,w("retryInline"));return}if(n.clearStatus(),!this.settings.sourceLang&&!n.from&&Oe(i,n.sourceHint(),this.settings.targetLang)){n.fallback=i.text,n.from=n.sourceHint(),n.state="idle",this.enqueue(n);return}let s=n.fallback!==void 0&&this.isUnchanged(n,i.text,void 0)?n.fallback:i.text;if(this.isUnchanged(n,s,i.detected)){if(n.wire===n.markup&&/\s[—–]\s/.test(n.markup)){n.wire=n.markup.replace(/\s[—–]\s/g," - "),n.state="idle",this.enqueue(n);return}n.state="same";return}n.setTranslation(s),n.state="done",n.render(this.display),n.hoverHost&&this.hoverHosts.set(n.hoverHost,n)})}),this.lastError&&!this.errorToastShown&&e.some(n=>n.state==="failed")&&(this.errorToastShown=!0,this.ui.toast(this.ui.errorMessage(this.lastError),{label:w("retry"),run:()=>this.retryFailed()}))}isUnchanged(e,t,n){if(!t.trim())return!0;let r=this.settings.targetLang;return n&&n.split("-")[0]===r.split("-")[0]&&(n===r||!r.startsWith("zh"))?!0:J(F(t)).trim()===J(F(e.markup)).trim()}rerenderAll(){this.ownWrite(()=>{for(let e of this.segments)e.state==="done"?(e.render(this.display),e.hoverHost&&this.hoverHosts.set(e.hoverHost,e)):e.state==="failed"&&(e.clearStatus(),e.renderStatus("error",this.display,w("retryInline")))})}onClick=e=>{let t=e.composedPath();for(let n of t){if(!(n instanceof Element))continue;if(n.localName==="yl-t"&&n.hasAttribute("data-yl-retry")){e.preventDefault(),e.stopPropagation(),this.retryFailed();return}let r=kt.get(n);if(r){if(e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault(),e.stopPropagation(),r.click();return}if(re.has(n.localName))return}};onMouseOver=e=>{if(!this.settings.showOriginalOnHover)return;let t=this.segmentAt(e);if(t===this.hoverSeg||(this.hoverSeg=t,clearTimeout(this.hoverTimer),this.ui.hideTooltip(),!t?.hoverHost))return;let n=t.hoverHost;this.hoverTimer=setTimeout(()=>{t.isRendered&&n.isConnected&&this.ui.showTooltip(J(F(t.markup)),ri(n))},ti)};onMouseOut=e=>{this.hoverSeg&&!e.relatedTarget&&(this.hoverSeg=void 0,clearTimeout(this.hoverTimer),this.ui.hideTooltip())};segmentAt(e){for(let t of e.composedPath()){if(!(t instanceof Element))continue;let n=this.hoverHosts.get(t);if(n?.rendersInPlace)return n;if(t===document.body)break}}},Mt={childList:!0,characterData:!0,subtree:!0};function Tn(o){let e=o;for(;e;){if(e.nodeType===Node.ELEMENT_NODE&&re.has(e.localName))return!0;e=e.parentNode}return!1}function ri(o){return o.getBoundingClientRect()}function ii(o,e){for(let t of o){let n=Math.min(t.bottom,e.bottom)-Math.max(t.top,e.top),r=Math.min(t.right,e.right)-Math.max(t.left,e.left),i=t.bottom-t.top;if(i>0&&n>=i/2&&r>=Math.min(24,(t.right-t.left)/2))return!0}return!1}var z=class{constructor(e,t){this.node=e;this.scrollers=t}animations=[];ranges="";movedByY=[];movedByX=[];left=NaN;top=NaN;place(e,t){this.follow();let n=this.node.getRootNode(),r=n instanceof ShadowRoot?n.host.getBoundingClientRect():{left:0,top:0},i=e-r.left,s=t-r.top;for(let a of this.movedByX)i+=a.scrollLeft;for(let a of this.movedByY)s+=a.scrollTop;Math.abs(i-this.left)<.5&&Math.abs(s-this.top)<.5||(this.left=i,this.top=s,this.node.style.left=`${i}px`,this.node.style.top=`${s}px`)}follow(){let e=globalThis.ScrollTimeline;if(!e)return;let t=this.scrollers.map(r=>[r,r.scrollHeight-r.clientHeight,r.scrollWidth-r.clientWidth]),n=t.map(([,r,i])=>`${r},${i}`).join(";");if(n!==this.ranges){this.ranges=n;for(let r of this.animations)r.cancel();this.animations=[],this.movedByY=[],this.movedByX=[];for(let[r,i,s]of t)i>0&&(this.animations.push(this.travel(new e({source:r,axis:"block"}),`translateY(${-i}px)`)),this.movedByY.push(r)),s>0&&(this.animations.push(this.travel(new e({source:r,axis:"inline"}),`translateX(${-s}px)`)),this.movedByX.push(r))}}travel(e,t){return this.node.animate({transform:["translate(0, 0)",t]},{timeline:e,fill:"both",easing:"linear",composite:"add"})}};var Ct=["color","font-family","font-size","font-weight","font-style","line-height","letter-spacing","text-decoration-line","text-decoration-color","text-decoration-style","text-transform","vertical-align"],kn=["background-color","padding-top","padding-right","padding-bottom","padding-left","border-top-width","border-right-width","border-bottom-width","border-left-width","border-top-style","border-right-style","border-bottom-style","border-left-style","border-top-color","border-right-color","border-bottom-color","border-left-color","border-top-left-radius","border-top-right-radius","border-bottom-left-radius","border-bottom-right-radius"],si=["white-space","tab-size","word-break","overflow-wrap"],ai=new Set(["a","b","strong","i","em","u","s","del","ins","mark","sub","sup","abbr","cite","q","small","big","dfn","strike","span","label","font","code","kbd","samp","var","tt"]),li=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,ci=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/;function fe(o,e,t){for(let n of t)o.style.setProperty(n,e.getPropertyValue(n))}function di(o){let e=o.href;return typeof e=="string"&&/^(https?:|mailto:|tel:)/i.test(e)?e:null}function Mn(o,e){for(let t of["title","lang","dir","alt"]){let n=e.getAttribute(t);n!==null&&o.setAttribute(t,n)}if(e.localName==="a"){let t=di(e);t&&(o.setAttribute("href",t),o.setAttribute("target","_blank"),o.setAttribute("rel","noopener noreferrer"))}}function ui(o){let e=ai.has(o.localName)?o.localName:"span",t=document.createElement(e),n=getComputedStyle(o);return fe(t,n,Ct),fe(t,n,kn),t.style.setProperty("display",n.display==="inline-block"?"inline-block":"inline"),Mn(t,o),t}function Cn(o){let e=o.cloneNode(!0),t=(n,r)=>{for(let c of Array.from(r.attributes)){let d=c.name.toLowerCase(),u=d==="id"||d==="class"||d==="style"||d.startsWith("on")||d.startsWith("data-"),h=(d==="href"||d==="xlink:href")&&!/^(https?:|mailto:|tel:|#)/i.test(c.value.trim());(u||h)&&r.removeAttribute(c.name)}if(n.localName==="img"){let c=n;c.currentSrc&&r.setAttribute("src",c.currentSrc),r.removeAttribute("srcset"),r.style.setProperty("max-width","100%")}n.localName==="a"&&(r.removeAttribute("href"),Mn(r,n));let i=getComputedStyle(n),s=r;if(s.style){fe(s,i,Ct),fe(s,i,kn),(n.localName==="img"||n.localName==="svg")&&(s.style.setProperty("width",i.width),s.style.setProperty("height",i.height)),s.style.setProperty("display",i.display);for(let c of si)s.style.setProperty(c,i.getPropertyValue(c))}let a=Array.from(n.children),l=Array.from(r.children);a.forEach((c,d)=>{let u=l[d];u&&(/^(script|style|iframe|object|embed|link|meta)$/.test(u.localName)?u.remove():t(c,u))})};return t(o,e),e}function pi(o,e){e.split(`
`).forEach((t,n)=>{n>0&&o.appendChild(document.createElement("br")),t&&o.appendChild(document.createTextNode(t))})}function An(o,e,t){e.forEach((n,r)=>{if(typeof n=="string"){pi(o,n);return}let i=t[n.slot];if(!i)return;if(i.atomic){let a=e[r-1],l=e[r+1];typeof a=="string"&&li.test(a)&&o.appendChild(document.createTextNode(" ")),o.appendChild(Cn(i.el)),typeof l=="string"&&ci.test(l)&&o.appendChild(document.createTextNode(" "));return}let s=ui(i.el);An(s,n.children,t),o.appendChild(s)})}function Rn(o,e,t,n){An(o,e,t);let r=Z(e);for(let i of n){let s=t[i];s?.atomic&&!r.has(i)&&(o.appendChild(document.createTextNode(" ")),o.appendChild(Cn(s.el)))}}function $e(o){let e=new Set;for(let t of o.matchAll(/<x(\d+)>/g))e.add(Number(t[1]));return e}function Nn(o){for(let e=o;e;e=e.parentElement){let t=getComputedStyle(e).backgroundColor;if(t&&t!=="transparent"&&!/rgba\(.*,\s*0\)$/.test(t))return t}return matchMedia("(prefers-color-scheme: dark)").matches&&getComputedStyle(document.documentElement).colorScheme.includes("dark")?"#1f2125":"#ffffff"}function Ln(o,e){let t=getComputedStyle(e);fe(o,t,Ct),o.style.setProperty("text-align",t.textAlign)}var Pn=o=>J(F(o)).trim();async function Fe(o,e,t){let r=(await I({type:"translate",items:o.map(i=>i.markup),from:e,to:t}))?.results;return!r||r.length!==o.length?o.map(()=>({ok:!1,code:"network"})):(e||await Promise.all(r.map(async(i,s)=>{let a=o[s];if(!i.ok||!Oe(i,a.hint,t))return;let c=(await I({type:"translate",items:[a.markup],from:a.hint,to:t}))?.results?.[0];c?.ok&&c.text.trim()&&Pn(c.text)!==Pn(a.markup)&&(r[s]=c)})),r)}var hi=.7,In=.05,mi=2,fi=1.17,gi=4,We=8,bi=.6;function K(o){let e=[];for(let t=o;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t);(/auto|scroll/.test(n.overflowY)||/auto|scroll/.test(n.overflowX))&&(t.scrollHeight>t.clientHeight+1||t.scrollWidth>t.clientWidth+1)&&e.push({el:t,top:t.scrollTop,left:t.scrollLeft})}return e}function yi(o,e){let t=o.getBoundingClientRect();if(e.top>=t.top-We&&e.bottom<=t.bottom+We&&e.left>=t.left-We&&e.right<=t.right+We)return!0;let r=getComputedStyle(o);return/auto|scroll/.test(r.overflowY)&&o.scrollHeight>o.clientHeight+1&&o.clientHeight>=innerHeight*bi}var qe=class{constructor(e,t){this.ui=e;this.settings=t}box;covers=[];requestId=0;rect;scrollers=[];windowTop=0;windowLeft=0;frameRequest=0;bounds={top:-1/0,bottom:1/0};framePin;showPending(e,t=!0){this.removeAll(),this.rect=e;let n=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scrollers=K(n).filter(r=>yi(r.el,e)),this.windowTop=scrollY,this.windowLeft=scrollX,t&&(this.box=this.ui.addFrame(!0,!0),this.framePin=new z(this.box,this.scrollers.map(r=>r.el))),this.reposition(),addEventListener("scroll",this.requestReposition,!0),addEventListener("resize",this.requestReposition)}async show(e){let t=++this.requestId;if(!e.length)return this.removeAll(),!1;let n=this.settings(),r;try{r=await Fe(e,n.sourceLang,n.targetLang)}catch{r=void 0}if(t!==this.requestId||!D())return!0;this.box&&this.ui.setFramePending(this.box,!1);let i=r?.find(s=>!s.ok);if(!r||!r.some(s=>s.ok))return this.removeAll(),this.ui.toast(this.ui.errorMessage(i&&!i.ok?i.code:"network")),!0;r.forEach((s,a)=>{let l=e[a];s.ok&&s.text.trim()&&this.addCover(l,s.text)}),this.reposition();for(let s of this.covers)this.fit(s);return this.box&&this.ui.addToPage(this.box),!0}addCover(e,t){let n=x("div","region-cover"),r=x("div","region-cover-inner");Ln(r,e.block),n.style.background=Nn(e.block);let i=new Set(e.slots.map((s,a)=>a));Rn(r,Y(F(t,i),s=>!!e.slots[s]?.detached),e.slots,$e(e.markup)),n.append(r),this.ui.addToPage(n),this.covers.push({node:n,inner:r,content:e,area:K(e.block)[0]?.el,pin:new z(n,K(e.block).map(s=>s.el))})}leading(e){let t=getComputedStyle(e.inner),n=parseFloat(t.lineHeight),r=parseFloat(t.fontSize);return!n||!r?0:Math.max(0,(n-r*fi)/2)}fit(e){let t=e.content.rect();if(!t)return;let n=t.height+this.leading(e)*2+mi;for(let r=1-In;r>=hi&&e.node.offsetHeight>n;r-=In)e.inner.style.setProperty("zoom",String(r))}clip(e,t,n,r,i){let s=t?.getBoundingClientRect(),a=Math.max(0,Math.max(s?.top??-1/0,this.bounds.top)-n),l=Math.max(0,r-Math.min(s?.bottom??1/0,this.bounds.bottom)),c=d=>d?`${d}px`:`-${i}px`;e.style.clipPath=a||l?`inset(${c(a)} -${i}px ${c(l)} -${i}px)`:""}requestReposition=()=>{this.frameRequest||(this.frameRequest=requestAnimationFrame(this.reposition))};reposition=()=>{this.frameRequest=0,this.bounds=this.ui.settleUnderBars();for(let t of this.covers){let n=t.content.rect();if(!n||!n.width&&!n.height){t.node.style.display="none";continue}t.node.style.display="";let r=this.leading(t),i=n.top-r,s=n.height+r*2;t.pin.place(n.left,i),t.node.style.minWidth=`${n.width}px`,t.node.style.minHeight=`${s}px`;let a=parseFloat(getComputedStyle(t.inner).lineHeight)||24,l=Math.max(n.width,innerWidth-n.left-8);t.node.style.maxWidth=`${n.height>a*1.6?n.width:l}px`,this.clip(t.node,t.area,i,i+s,0)}let e=this.rect;if(this.box&&e){let t=this.windowTop-scrollY,n=this.windowLeft-scrollX;for(let s of this.scrollers)t+=s.top-s.el.scrollTop,n+=s.left-s.el.scrollLeft;let r=e.top+t,i=e.bottom-e.top;this.framePin?.place(_(e.left+n),_(r)),Object.assign(this.box.style,{width:`${_(e.right-e.left)}px`,height:`${_(i)}px`}),this.clip(this.box,this.scrollers[0]?.el,r,r+i,gi)}};removeAll(){removeEventListener("scroll",this.requestReposition,!0),removeEventListener("resize",this.requestReposition),cancelAnimationFrame(this.frameRequest),this.frameRequest=0,this.box?.remove(),this.box=void 0,this.framePin=void 0,this.rect=void 0,this.scrollers=[];for(let e of this.covers)e.node.remove();this.covers=[]}close(){this.requestId++,this.removeAll()}get emptyMessage(){return w("marqueeEmpty")}};var vi={curl:"bash",bash:"bash",shell:"bash","command line":"bash",命令行:"bash",ruby:"ruby",python:"python",node:"javascript","node.js":"javascript",javascript:"javascript",typescript:"typescript",go:"go",java:"java",php:"php",".net":"csharp","c#":"csharp",html:"html",css:"css",json:"json",yaml:"yaml",sql:"sql"},Hn={js:"javascript",jsx:"jsx",ts:"typescript",tsx:"tsx",py:"python",rb:"ruby",sh:"bash",html:"html",css:"css",json:"json",yml:"yaml",yaml:"yaml",go:"go",java:"java",php:"php",cs:"csharp",sql:"sql",md:"markdown",vue:"vue"};function Dn(o){return o.ownerDocument.defaultView?.getComputedStyle(o)??null}function _n(o){return o.getAttribute("aria-hidden")==="true"?!0:Dn(o)?.userSelect==="none"}function wi(o){let e=Dn(o)?.display??"";return e==="block"||e==="flex"||e==="grid"||e==="list-item"||e==="table-row"}function On(o,e){for(let t of Array.from(o.childNodes))if(t.nodeType===3)e.push(t.data);else if(t.nodeType===1){let n=t;if(_n(n))continue;if(n.localName==="br"){e.push(`
`);continue}On(n,e),wi(n)&&!(e[e.length-1]??"").endsWith(`
`)&&e.push(`
`)}}function xi(o){let e=o.localName==="pre"?o:o.querySelector("pre")??o,t=[];return On(e,t),t.join("").replace(/\n+$/,"")}function Ei(o){let e=[o,...Array.from(o.querySelectorAll("pre,code"))];for(let t of e){let n=/(?:^|\s)(?:language|lang|highlight-source)-([\w+#-]+)/.exec(t.getAttribute("class")??"");if(n?.[1])return n[1].toLowerCase()}return""}function Bn(o){let e=o.trim().toLowerCase(),t=/\.([a-z0-9]+)$/.exec(e);return t?.[1]&&Hn[t[1]]?Hn[t[1]]:vi[e]??""}function Si(o){let e=o.parentElement;for(let t=0;e&&t<4;t++,e=e.parentElement){if(e.querySelectorAll("pre").length>1)return"";for(let n of Array.from(e.querySelectorAll("*"))){if(n.children.length||o.contains(n))continue;let r=Bn(n.textContent??"");if(r)return r}}return""}function Ti(o){let e=2;for(let t of o.matchAll(/`+/g))e=Math.max(e,t[0].length);return"`".repeat(e+1)}function ki(o){let e=o.replace(/\s+/g," ").trim();return e?(e.includes("`")?"``":"`")==="``"?`\`\` ${e} \`\``:`\`${e}\``:""}function At(o,e){let t=/^(\s*)([\s\S]*?)(\s*)$/.exec(e);return t?.[2]?`${t[1]}${o}${t[2]}${o}${t[3]}`:e}function Q(o){let e="";for(let t of Array.from(o.childNodes)){if(t.nodeType===3){e+=t.data.replace(/\s+/g," ");continue}if(t.nodeType!==1)continue;let n=t,r=n.localName;if(r==="br")e+=`  
`;else if(r==="code"||r==="kbd"||r==="samp"||r==="tt")e+=ki(n.textContent??"");else if(r==="strong"||r==="b")e+=At("**",Q(n));else if(r==="em"||r==="i")e+=At("*",Q(n));else if(r==="del"||r==="s")e+=At("~~",Q(n));else if(r==="img"){let i=n.getAttribute("src");i&&(e+=`![${n.getAttribute("alt")??""}](${n.src||i})`)}else if(r==="a"){let i=Q(n).trim(),s=n.href;e+=i&&/^https?:/i.test(s)?`[${i}](${s})`:i}else r!=="svg"&&!_n(n)&&(e+=Q(n))}return e}function Mi(o){let e=0;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&e++;return Math.max(0,e-1)}function Ci(o){let e=o;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&(e=t);return e}function Ai(o){if(o.closest('button,[role="button"],nav,[role="navigation"],[role="tablist"]'))return null;let e=Q(o).replace(/[ \t]+/g," ").trim();if(!e)return null;let t=o.closest("h1,h2,h3,h4,h5,h6");if(t)return{text:`${"#".repeat(Number(t.localName[1]))} ${e.replace(/\s*\n\s*/g," ")}`};let n=o.closest("li");if(n){let r=n.parentElement,i=r?.localName==="ol"?`${Array.from(r.children).indexOf(n)+1}.`:"-";return{text:`${"  ".repeat(Mi(n))}${i} ${e}`,group:Ci(n)}}return o.closest("blockquote")?{text:e.split(`
`).map(r=>`> ${r}`).join(`
`)}:{text:e}}function Ri(o){if((o.textContent??"").trim().length>40)return null;let e=o.parentElement;for(let t=0;e&&t<6;t++,e=e.parentElement){if(e.localName==="body"||e.localName==="main"||e.localName==="article")return null;let n=e.querySelectorAll("pre");if(n.length===1)return n[0];if(n.length>1)return null}return null}function Ni(o){let e=new Map,t=new Set;for(let{copy:n}of o){let r=n.closest("table");if(!r||t.has(r))continue;t.add(r);let i=Array.from(r.querySelectorAll("tr")).map(a=>Array.from(a.children).map(l=>Q(l).replace(/\s+/g," ").replace(/\|/g,"\\|").trim())).filter(a=>a.some(Boolean));if(!i.length)continue;let s=i.map(a=>`| ${a.join(" | ")} |`);s.splice(1,0,`| ${i[0].map(()=>"---").join(" | ")} |`),e.set(r,s.join(`
`))}return e}function $n(o){let e=new Map,t=new Set;for(let a of o){if(a.kind==="code")continue;let l=Ri(a.copy);if(!l)continue;t.add(a.copy);let c=Bn(a.copy.textContent??"");c&&!e.has(l)&&e.set(l,c)}let n=Ni(o),r=new Set,i=[];for(let a of o){if(t.has(a.copy))continue;if(a.kind==="code"){let d=xi(a.copy);if(!d.trim())continue;let u=a.copy.localName==="pre"?a.copy:a.copy.querySelector("pre"),h=u&&(e.get(u)||Si(u))||Ei(a.copy),p=Ti(d);i.push({text:`${p}${h}
${d}
${p}`});continue}let l=a.copy.closest("table");if(l&&n.has(l)){r.has(l)||i.push({text:n.get(l)}),r.add(l);continue}let c=Ai(a.copy);c&&i.push(c)}let s="";return i.forEach((a,l)=>{l&&(s+=a.group&&a.group===i[l-1].group?`
`:`

`),s+=a.text}),s}var ge=16,Li=32,Pi=28,Ii="data-yl-find",Ue=class{constructor(e,t,n){this.mirror=e;this.copies=n;this.track.append(this.thumb),t.append(this.track),this.mirror.doc.addEventListener("scroll",this.onScroll,!0),this.track.addEventListener("pointerdown",this.onPointerDown)}track=x("div","scan-track");thumb=x("i","scan-thumb");min=0;max=0;visible=0;origin=0;open=!1;marks=[];active=-1;measure(){let e=1/0,t=-1/0,n=this.mirror.doc.createRange();for(let r of this.copies()){if(!r.isConnected)continue;n.selectNodeContents(r);let i=n.getBoundingClientRect();!i.width&&!i.height||(e=Math.min(e,i.top),t=Math.max(t,i.bottom))}return e===1/0?null:{top:e,bottom:t}}get contentHeight(){let e=this.measure();return e?e.bottom-e.top+ge*2:0}start(e,t){let n=this.mirror.scroller,r=this.measure();if(this.visible=e,this.origin=t,this.open=!0,!n||!r)return;let i=n.scrollTop;this.min=i+r.top-t-ge,this.max=Math.max(this.min,i+r.bottom+ge-t-e),this.scrollTo(Math.max(this.min,Math.min(i,this.max))),this.alignToBlock(),this.paint()}alignToBlock(){let e=this.mirror.doc.createRange(),t=1/0;for(let n of this.copies()){if(!n.isConnected)continue;e.selectNodeContents(n);let r=e.getBoundingClientRect();(r.width||r.height)&&r.bottom>this.origin&&r.top<t&&(t=r.top)}t!==1/0&&this.scrollBy(t-this.origin-Li)}stop(){this.open=!1,this.clearFind(),this.track.style.display="none"}get extent(){return{from:this.min,to:this.max,visible:this.visible}}get position(){return this.mirror.scroller?.scrollTop??0}moveTo(e){this.scrollTo(e)}scrollBy(e){let t=this.mirror.scroller;t&&this.scrollTo(t.scrollTop+e)}scrollTo(e){let t=this.mirror.scroller;t&&(t.scrollTop=Math.max(this.min,Math.min(e,this.max)))}onScroll=()=>{if(!this.open)return;let e=this.mirror.scroller;e&&((e.scrollTop<this.min-1||e.scrollTop>this.max+1)&&this.scrollTo(e.scrollTop),this.paint())};thumbHeight(){return Math.max(Pi,this.visible*this.visible/(this.max-this.min+this.visible))}paint(){let e=this.mirror.scroller,t=this.max-this.min;if(!e||t<=0){this.track.style.display="none";return}this.track.style.display="";let n=this.thumbHeight();this.thumb.style.height=`${n}px`,this.thumb.style.transform=`translateY(${(e.scrollTop-this.min)/t*(this.visible-n)}px)`}onPointerDown=e=>{e.preventDefault(),this.track.setPointerCapture(e.pointerId);let t=this.track.getBoundingClientRect().top,n=this.thumbHeight(),r=this.max-this.min,i=this.thumb.getBoundingClientRect().top,s=e.target===this.thumb?e.clientY-i:n/2,a=c=>{let d=(c.clientY-t-s)/(this.visible-n);this.scrollTo(this.min+Math.max(0,Math.min(1,d))*r)};a(e);let l=()=>{this.track.removeEventListener("pointermove",a),this.track.removeEventListener("pointerup",l)};this.track.addEventListener("pointermove",a),this.track.addEventListener("pointerup",l)};get hasQuery(){return this.marks.length>0}clearFind(){let e=new Set;for(let t of this.marks){let n=t.parentNode;n&&(t.replaceWith(...Array.from(t.childNodes)),e.add(n))}for(let t of e)t.normalize();this.marks=[],this.active=-1}find(e){this.clearFind();let t=e.trim().toLowerCase();if(!t)return 0;let n=this.mirror.doc;for(let r of this.copies()){if(!r.isConnected)continue;let i=n.createTreeWalker(r,NodeFilter.SHOW_TEXT),s=[];for(let a=i.nextNode();a;a=i.nextNode())s.push(a);for(let a of s)this.markIn(a,t)}return this.step(1),this.marks.length}markIn(e,t){let n=[],r=e;for(let i=r.data.toLowerCase().indexOf(t);i!==-1;i=r.data.toLowerCase().indexOf(t)){let s=r.splitText(i);r=s.splitText(t.length);let a=this.mirror.doc.createElement("mark");a.setAttribute(Ii,""),s.replaceWith(a),a.append(s),n.push(a)}this.marks.push(...n)}step(e){if(!this.marks.length)return 0;this.marks[this.active]?.removeAttribute("data-active"),this.active=(this.active+e+this.marks.length)%this.marks.length;let t=this.marks[this.active];t.setAttribute("data-active","");let n=t.getBoundingClientRect(),r=n.top-this.origin;return(r<ge||n.bottom-this.origin>this.visible-ge)&&this.scrollBy(r-this.visible/3),this.active+1}};var Gn="[modern-screenshot]",X=typeof window<"u",Hi=X&&"Worker"in window,rc=X&&"atob"in window,ic=X&&"btoa"in window,Lt=X?window.navigator?.userAgent:"",Kn=Lt.includes("Chrome"),je=Lt.includes("AppleWebKit")&&!Kn,Pt=Lt.includes("Firefox"),Di=o=>o&&"__CONTEXT__"in o,_i=o=>o.constructor.name==="CSSFontFaceRule",Oi=o=>o.constructor.name==="CSSImportRule",Bi=o=>o.constructor.name==="CSSLayerBlockRule",j=o=>o.nodeType===1,we=o=>typeof o.className=="object",Xn=o=>o.tagName==="image",$i=o=>o.tagName==="use",be=o=>j(o)&&typeof o.style<"u"&&!we(o),Fi=o=>o.nodeType===8,Wi=o=>o.nodeType===3,ce=o=>o.tagName==="IMG",ze=o=>o.tagName==="VIDEO",qi=o=>o.tagName==="CANVAS",Ui=o=>o.tagName==="TEXTAREA",ji=o=>o.tagName==="INPUT",zi=o=>o.tagName==="STYLE",Gi=o=>o.tagName==="SCRIPT",Ki=o=>o.tagName==="SELECT",Xi=o=>o.tagName==="SLOT",Vi=o=>o.tagName==="IFRAME",Yi=(...o)=>console.warn(Gn,...o);function Ji(o){let e=o?.createElement?.("canvas");return e&&(e.height=e.width=1),!!e&&"toDataURL"in e&&!!e.toDataURL("image/webp").includes("image/webp")}var Rt=o=>o.startsWith("data:");function Vn(o,e){if(o.match(/^[a-z]+:\/\//i))return o;if(X&&o.match(/^\/\//))return window.location.protocol+o;if(o.match(/^[a-z]+:/i)||!X)return o;let t=Ge().implementation.createHTMLDocument(),n=t.createElement("base"),r=t.createElement("a");return t.head.appendChild(n),t.body.appendChild(r),e&&(n.href=e),r.href=o,r.href}function Ge(o){return(o&&j(o)?o?.ownerDocument:o)??window.document}var Ke="http://www.w3.org/2000/svg";function Zi(o,e,t){let n=Ge(t).createElementNS(Ke,"svg");return n.setAttributeNS(null,"width",o.toString()),n.setAttributeNS(null,"height",e.toString()),n.setAttributeNS(null,"viewBox",`0 0 ${o} ${e}`),n}function Qi(o,e){let t=new XMLSerializer().serializeToString(o);return e&&(t=t.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu,"")),`data:image/svg+xml;charset=utf-8,${encodeURIComponent(t)}`}function es(o,e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t(r.result),r.onerror=()=>n(r.error),r.onabort=()=>n(new Error(`Failed read blob to ${e}`)),e==="dataUrl"?r.readAsDataURL(o):e==="arrayBuffer"&&r.readAsArrayBuffer(o)})}var ts=o=>es(o,"dataUrl");function le(o,e){let t=Ge(e).createElement("img");return t.decoding="sync",t.loading="eager",t.src=o,t}function ye(o,e){return new Promise(t=>{let{timeout:n,ownerDocument:r,onError:i,onWarn:s}=e??{},a=typeof o=="string"?le(o,Ge(r)):o,l=null,c=null;function d(){t(a),l&&clearTimeout(l),c?.()}if(n&&(l=setTimeout(d,n)),ze(a)){let u=a.currentSrc||a.src;if(!u)return a.poster?ye(a.poster,e).then(t):d();if(a.readyState>=2)return d();let h=d,p=g=>{s?.("Failed video load",u,g),i?.(g),d()};c=()=>{a.removeEventListener("loadeddata",h),a.removeEventListener("error",p)},a.addEventListener("loadeddata",h,{once:!0}),a.addEventListener("error",p,{once:!0})}else{let u=Xn(a)?a.href.baseVal:a.currentSrc||a.src;if(!u)return d();let h=async()=>{if(ce(a)&&"decode"in a)try{await a.decode()}catch(g){s?.("Failed to decode image, trying to render anyway",a.dataset.originalSrc||u,g)}d()},p=g=>{s?.("Failed image load",a.dataset.originalSrc||u,g),d()};if(ce(a)&&a.complete)return h();c=()=>{a.removeEventListener("load",h),a.removeEventListener("error",p)},a.addEventListener("load",h,{once:!0}),a.addEventListener("error",p,{once:!0})}})}async function ns(o,e){be(o)&&(ce(o)||ze(o)?await ye(o,e):await Promise.all(["img","video"].flatMap(t=>Array.from(o.querySelectorAll(t)).map(n=>ye(n,e)))))}var Yn=function(){let e=0,t=()=>`0000${(Math.random()*36**4<<0).toString(36)}`.slice(-4);return()=>(e+=1,`u${t()}${e}`)}();function Jn(o){return o?.split(",").map(e=>e.trim().replace(/"|'/g,"").toLowerCase()).filter(Boolean)}var Fn=0;function os(o){let e=`${Gn}[#${Fn}]`;return Fn++,{time:t=>o&&console.time(`${e} ${t}`),timeEnd:t=>o&&console.timeEnd(`${e} ${t}`),warn:(...t)=>o&&Yi(...t)}}function rs(o){return{cache:o?"no-cache":"force-cache"}}async function Zn(o,e){return Di(o)?o:It(o,{...e,autoDestruct:!0})}async function It(o,e){let{scale:t=1,workerUrl:n,workerNumber:r=1}=e||{},i=!!e?.debug,s=e?.features??!0,a=o.ownerDocument??(X?window.document:void 0),l=o.ownerDocument?.defaultView??(X?window:void 0),c=new Map,d={width:0,height:0,quality:1,type:"image/png",scale:t,backgroundColor:null,style:null,filter:null,maximumCanvasSize:0,timeout:3e4,progress:null,debug:i,fetch:{requestInit:rs(e?.fetch?.bypassingCache),placeholderImage:"data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",bypassingCache:!1,...e?.fetch},fetchFn:null,font:{},drawImageInterval:100,workerUrl:null,workerNumber:r,onCloneEachNode:null,onCloneNode:null,onEmbedNode:null,onCreateForeignObjectSvg:null,includeStyleProperties:null,autoDestruct:!1,...e,__CONTEXT__:!0,log:os(i),node:o,ownerDocument:a,ownerWindow:l,dpi:t===1?null:96*t,svgStyleElement:Qn(a),svgDefsElement:a?.createElementNS(Ke,"defs"),svgStyles:new Map,defaultComputedStyles:new Map,workers:[...Array.from({length:Hi&&n&&r?r:0})].map(()=>{try{let p=new Worker(n);return p.onmessage=async g=>{let{url:m,result:f}=g.data;f?c.get(m)?.resolve?.(f):c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},p.onmessageerror=g=>{let{url:m}=g.data;c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},p}catch(p){return d.log.warn("Failed to new Worker",p),null}}).filter(Boolean),fontFamilies:new Map,fontCssTexts:new Map,acceptOfImage:`${[Ji(a)&&"image/webp","image/svg+xml","image/*","*/*"].filter(Boolean).join(",")};q=0.8`,requests:c,drawImageCount:0,tasks:[],features:s,isEnable:p=>p==="restoreScrollPosition"?typeof s=="boolean"?!1:s[p]??!1:typeof s=="boolean"?s:s[p]??!0,shadowRoots:[]};d.log.time("wait until load"),await ns(o,{timeout:d.timeout,onWarn:d.log.warn}),d.log.timeEnd("wait until load");let{width:u,height:h}=is(o,d);return d.width=u,d.height=h,d}function Qn(o){if(!o)return;let e=o.createElement("style"),t=e.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);return e.appendChild(t),e}function is(o,e){let{width:t,height:n}=e;if(j(o)&&(!t||!n)){let r=o.getBoundingClientRect();t=t||r.width||Number(o.getAttribute("width"))||0,n=n||r.height||Number(o.getAttribute("height"))||0}return{width:t,height:n}}async function ss(o,e){let{log:t,timeout:n,drawImageCount:r,drawImageInterval:i}=e;t.time("image to canvas");let s=await ye(o,{timeout:n,onWarn:e.log.warn}),{canvas:a,context2d:l}=as(o.ownerDocument,e),c=()=>{try{l?.drawImage(s,0,0,a.width,a.height)}catch(d){e.log.warn("Failed to drawImage",d)}};if(c(),e.isEnable("fixSvgXmlDecode"))for(let d=0;d<r;d++)await new Promise(u=>{setTimeout(()=>{l?.clearRect(0,0,a.width,a.height),c(),u()},d+i)});return e.drawImageCount=0,t.timeEnd("image to canvas"),a}function as(o,e){let{width:t,height:n,scale:r,backgroundColor:i,maximumCanvasSize:s}=e,a=o.createElement("canvas");a.width=Math.floor(t*r),a.height=Math.floor(n*r),a.style.width=`${t}px`,a.style.height=`${n}px`,s&&(a.width>s||a.height>s)&&(a.width>s&&a.height>s?a.width>a.height?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s):a.width>s?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s));let l=a.getContext("2d");return l&&i&&(l.fillStyle=i,l.fillRect(0,0,a.width,a.height)),{canvas:a,context2d:l}}function eo(o,e){if(o.ownerDocument)try{let i=o.toDataURL();if(i!=="data:,")return le(i,o.ownerDocument)}catch(i){e.log.warn("Failed to clone canvas",i)}let t=o.cloneNode(!1),n=o.getContext("2d"),r=t.getContext("2d");try{return n&&r&&r.putImageData(n.getImageData(0,0,o.width,o.height),0,0),t}catch(i){e.log.warn("Failed to clone canvas",i)}return t}function ls(o,e){try{if(o?.contentDocument?.documentElement)return Ht(o.contentDocument.documentElement,e)}catch(t){e.log.warn("Failed to clone iframe",t)}return o.cloneNode(!1)}function cs(o){let e=o.cloneNode(!1);return o.currentSrc&&o.currentSrc!==o.src&&(e.src=o.currentSrc,e.srcset=""),e.loading==="lazy"&&(e.loading="eager"),e}async function ds(o,e){if(o.ownerDocument&&!o.currentSrc&&o.poster)return le(o.poster,o.ownerDocument);let t=o.cloneNode(!1);t.crossOrigin="anonymous",o.currentSrc&&o.currentSrc!==o.src&&(t.src=o.currentSrc);let n=t.ownerDocument;if(n){let r=!0;if(await ye(t,{onError:()=>r=!1,onWarn:e.log.warn}),!r)return o.poster?le(o.poster,o.ownerDocument):t;t.currentTime=o.currentTime,await new Promise(s=>{t.addEventListener("seeked",s,{once:!0})});let i=n.createElement("canvas");i.width=o.offsetWidth,i.height=o.offsetHeight;try{let s=i.getContext("2d");s&&s.drawImage(t,0,0,i.width,i.height)}catch(s){return e.log.warn("Failed to clone video",s),o.poster?le(o.poster,o.ownerDocument):t}return eo(i,e)}return t}function us(o,e){return qi(o)?eo(o,e):Vi(o)?ls(o,e):ce(o)?cs(o):ze(o)?ds(o,e):o.cloneNode(!1)}function ps(o){let e=o.sandbox;if(!e){let{ownerDocument:t}=o;try{t&&(e=t.createElement("iframe"),e.id=`__SANDBOX__${Yn()}`,e.width="0",e.height="0",e.style.visibility="hidden",e.style.position="fixed",t.body.appendChild(e),e.srcdoc='<!DOCTYPE html><meta charset="UTF-8"><title></title><body>',o.sandbox=e)}catch(n){o.log.warn("Failed to getSandBox",n)}}return e}var hs=["width","height","-webkit-text-fill-color"],ms=["stroke","fill"];function to(o,e,t){let{defaultComputedStyles:n}=t,r=o.nodeName.toLowerCase(),i=we(o)&&r!=="svg",s=i?ms.map(m=>[m,o.getAttribute(m)]).filter(([,m])=>m!==null):[],a=[i&&"svg",r,s.map((m,f)=>`${m}=${f}`).join(","),e].filter(Boolean).join(":");if(n.has(a))return n.get(a);let c=ps(t)?.contentWindow;if(!c)return new Map;let d=c?.document,u,h;i?(u=d.createElementNS(Ke,"svg"),h=u.ownerDocument.createElementNS(u.namespaceURI,r),s.forEach(([m,f])=>{h.setAttributeNS(null,m,f)}),u.appendChild(h)):u=h=d.createElement(r),h.textContent=" ",d.body.appendChild(u);let p=c.getComputedStyle(h,e),g=new Map;for(let m=p.length,f=0;f<m;f++){let b=p.item(f);hs.includes(b)||g.set(b,p.getPropertyValue(b))}return d.body.removeChild(u),n.set(a,g),g}function no(o,e,t){let n=new Map,r=[],i=new Map;if(t)for(let a of t)s(a);else for(let a=o.length,l=0;l<a;l++){let c=o.item(l);s(c)}for(let a=r.length,l=0;l<a;l++)i.get(r[l])?.forEach((c,d)=>n.set(d,c));function s(a){let l=o.getPropertyValue(a),c=o.getPropertyPriority(a),d=a.lastIndexOf("-"),u=d>-1?a.substring(0,d):void 0;if(u){let h=i.get(u);h||(h=new Map,i.set(u,h)),h.set(a,[l,c])}e.get(a)===l&&!c||(u?r.push(u):n.set(a,[l,c]))}return n}function fs(o,e,t,n){let{ownerWindow:r,includeStyleProperties:i,currentParentNodeStyle:s}=n,a=e.style,l=r.getComputedStyle(o),c=to(o,null,n);s?.forEach((u,h)=>{c.delete(h)});let d=no(l,c,i);d.delete("transition-property"),d.delete("all"),d.delete("d"),d.delete("content"),t&&(d.delete("position"),d.delete("margin-top"),d.delete("margin-right"),d.delete("margin-bottom"),d.delete("margin-left"),d.delete("margin-block-start"),d.delete("margin-block-end"),d.delete("margin-inline-start"),d.delete("margin-inline-end"),d.set("box-sizing",["border-box",""])),d.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text"),Kn&&(d.has("font-kerning")||d.set("font-kerning",["normal",""]),(d.get("overflow-x")?.[0]==="hidden"||d.get("overflow-y")?.[0]==="hidden")&&d.get("text-overflow")?.[0]==="ellipsis"&&o.scrollWidth===o.clientWidth&&d.set("text-overflow",["clip",""]));for(let u=a.length,h=0;h<u;h++)a.removeProperty(a.item(h));return d.forEach(([u,h],p)=>{a.setProperty(p,u,h)}),d}function gs(o,e){(Ui(o)||ji(o)||Ki(o))&&e.setAttribute("value",o.value)}var bs=["::before","::after"],ys=["::-webkit-scrollbar","::-webkit-scrollbar-button","::-webkit-scrollbar-thumb","::-webkit-scrollbar-track","::-webkit-scrollbar-track-piece","::-webkit-scrollbar-corner","::-webkit-resizer"];function vs(o,e,t,n,r){let{ownerWindow:i,svgStyleElement:s,svgStyles:a,currentNodeStyle:l}=n;if(!s||!i)return;function c(d){let u=i.getComputedStyle(o,d),h=u.getPropertyValue("content");if(!h||h==="none")return;r?.(h),h=h.replace(/(')|(")|(counter\(.+\))/g,"");let p=[Yn()],g=to(o,d,n);l?.forEach((T,S)=>{g.delete(S)});let m=no(u,g,n.includeStyleProperties);m.delete("content"),m.delete("-webkit-locale"),m.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text");let f=[`content: '${h}';`];if(m.forEach(([T,S],N)=>{f.push(`${N}: ${T}${S?" !important":""};`)}),f.length===1)return;try{e.className=[e.className,...p].join(" ")}catch(T){n.log.warn("Failed to copyPseudoClass",T);return}let b=f.join(`
  `),v=a.get(b);v||(v=[],a.set(b,v)),v.push(`.${p[0]}${d}`)}bs.forEach(c),t&&ys.forEach(c)}var Wn=new Set(["symbol"]);async function qn(o,e,t,n,r){if(j(t)&&(zi(t)||Gi(t))||n.filter&&!n.filter(t))return;Wn.has(e.nodeName)||Wn.has(t.nodeName)?n.currentParentNodeStyle=void 0:n.currentParentNodeStyle=n.currentNodeStyle;let i=await Ht(t,n,!1,r);n.isEnable("restoreScrollPosition")&&ws(o,i),e.appendChild(i)}async function Un(o,e,t,n){let r=o.firstChild;j(o)&&o.shadowRoot&&(r=o.shadowRoot?.firstChild,t.shadowRoots.push(o.shadowRoot));for(let i=r;i;i=i.nextSibling)if(!Fi(i))if(j(i)&&Xi(i)&&typeof i.assignedNodes=="function"){let s=i.assignedNodes();for(let a=0;a<s.length;a++)await qn(o,e,s[a],t,n)}else await qn(o,e,i,t,n)}function ws(o,e){if(!be(o)||!be(e))return;let{scrollTop:t,scrollLeft:n}=o;if(!t&&!n)return;let{transform:r}=e.style,i=new DOMMatrix(r),{a:s,b:a,c:l,d:c}=i;i.a=1,i.b=0,i.c=0,i.d=1,i.translateSelf(-n,-t),i.a=s,i.b=a,i.c=l,i.d=c,e.style.transform=i.toString()}function xs(o,e){let{backgroundColor:t,width:n,height:r,style:i}=e,s=o.style;if(t&&s.setProperty("background-color",t,"important"),n&&s.setProperty("width",`${n}px`,"important"),r&&s.setProperty("height",`${r}px`,"important"),i)for(let a in i)s[a]=i[a]}var Es=/^[\w-:]+$/;async function Ht(o,e,t=!1,n){let{ownerDocument:r,ownerWindow:i,fontFamilies:s,onCloneEachNode:a}=e;if(r&&Wi(o))return n&&/\S/.test(o.data)&&n(o.data),r.createTextNode(o.data);if(r&&i&&j(o)&&(be(o)||we(o))){let c=await us(o,e);if(e.isEnable("removeAbnormalAttributes")){let m=c.getAttributeNames();for(let f=m.length,b=0;b<f;b++){let v=m[b];Es.test(v)||c.removeAttribute(v)}}let d=e.currentNodeStyle=fs(o,c,t,e);t&&xs(c,e);let u=!1;if(e.isEnable("copyScrollbar")){let m=[d.get("overflow-x")?.[0],d.get("overflow-y")?.[0]];u=m.includes("scroll")||(m.includes("auto")||m.includes("overlay"))&&(o.scrollHeight>o.clientHeight||o.scrollWidth>o.clientWidth)}let h=d.get("text-transform")?.[0],p=Jn(d.get("font-family")?.[0]),g=p?m=>{h==="uppercase"?m=m.toUpperCase():h==="lowercase"?m=m.toLowerCase():h==="capitalize"&&(m=m[0].toUpperCase()+m.substring(1)),p.forEach(f=>{let b=s.get(f);b||s.set(f,b=new Set),m.split("").forEach(v=>b.add(v))})}:void 0;return vs(o,c,u,e,g),gs(o,c),ze(o)||await Un(o,c,e,g),await a?.(c),c}let l=o.cloneNode(!1);return await Un(o,l,e),await a?.(l),l}function Ss(o){if(o.ownerDocument=void 0,o.ownerWindow=void 0,o.svgStyleElement=void 0,o.svgDefsElement=void 0,o.svgStyles.clear(),o.defaultComputedStyles.clear(),o.sandbox){try{o.sandbox.remove()}catch(e){o.log.warn("Failed to destroyContext",e)}o.sandbox=void 0}o.workers=[],o.fontFamilies.clear(),o.fontCssTexts.clear(),o.requests.clear(),o.tasks=[],o.shadowRoots=[]}function Ts(o){let{url:e,timeout:t,responseType:n,...r}=o,i=new AbortController,s=t?setTimeout(()=>i.abort(),t):void 0;return fetch(e,{signal:i.signal,...r}).then(a=>{if(!a.ok)throw new Error("Failed fetch, not 2xx response",{cause:a});switch(n){case"arrayBuffer":return a.arrayBuffer();case"dataUrl":return a.blob().then(ts);case"text":default:return a.text()}}).finally(()=>clearTimeout(s))}function ve(o,e){let{url:t,requestType:n="text",responseType:r="text",imageDom:i}=e,s=t,{timeout:a,acceptOfImage:l,requests:c,fetchFn:d,fetch:{requestInit:u,bypassingCache:h,placeholderImage:p},font:g,workers:m,fontFamilies:f}=o;n==="image"&&(je||Pt)&&o.drawImageCount++;let b=c.get(t);if(!b){h&&h instanceof RegExp&&h.test(s)&&(s+=(/\?/.test(s)?"&":"?")+new Date().getTime());let v=n.startsWith("font")&&g&&g.minify,T=new Set;v&&n.split(";")[1].split(",").forEach($=>{f.has($)&&f.get($).forEach(B=>T.add(B))});let S=v&&T.size,N={url:s,timeout:a,responseType:S?"arrayBuffer":r,headers:n==="image"?{accept:l}:void 0,...u};b={type:n,resolve:void 0,reject:void 0,response:null},b.response=(async()=>{if(d&&n==="image"){let H=await d(t);if(H)return H}return!je&&t.startsWith("http")&&m.length?new Promise((H,$)=>{m[c.size&m.length-1].postMessage({rawUrl:t,...N}),b.resolve=H,b.reject=$}):Ts(N)})().catch(H=>{if(c.delete(t),n==="image"&&p)return o.log.warn("Failed to fetch image base64, trying to use placeholder image",s),typeof p=="string"?p:p(i);throw H}),c.set(t,b)}return b.response}async function oo(o,e,t,n){if(!ro(o))return o;for(let[r,i]of ks(o,e))try{let s=await ve(t,{url:i,requestType:n?"image":"text",responseType:"dataUrl"});o=o.replace(Ms(r),`$1${s}$3`)}catch(s){t.log.warn("Failed to fetch css data url",r,s)}return o}function ro(o){return/url\((['"]?)([^'"]+?)\1\)/.test(o)}var io=/url\((['"]?)([^'"]+?)\1\)/g;function ks(o,e){let t=[];return o.replace(io,(n,r,i)=>(t.push([i,Vn(i,e)]),n)),t.filter(([n])=>!Rt(n))}function Ms(o){let e=o.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1");return new RegExp(`(url\\(['"]?)(${e})(['"]?\\))`,"g")}var Cs=["background-image","border-image-source","-webkit-border-image","-webkit-mask-image","list-style-image"];function As(o,e){return Cs.map(t=>{let n=o.getPropertyValue(t);return!n||n==="none"?null:((je||Pt)&&e.drawImageCount++,oo(n,null,e,!0).then(r=>{!r||n===r||o.setProperty(t,r,o.getPropertyPriority(t))}))}).filter(Boolean)}function Rs(o,e){if(ce(o)){let t=o.currentSrc||o.src;if(!Rt(t))return[ve(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.srcset="",o.dataset.originalSrc=t,o.src=n||"")})];(je||Pt)&&e.drawImageCount++}else if(we(o)&&!Rt(o.href.baseVal)){let t=o.href.baseVal;return[ve(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.dataset.originalSrc=t,o.href.baseVal=n||"")})]}return[]}function Ns(o,e){let{ownerDocument:t,svgDefsElement:n}=e,r=o.getAttribute("href")??o.getAttribute("xlink:href");if(!r)return[];let[i,s]=r.split("#");if(s){let a=`#${s}`,l=e.shadowRoots.reduce((c,d)=>c??d.querySelector(`svg ${a}`),t?.querySelector(`svg ${a}`));if(i&&o.setAttribute("href",a),n?.querySelector(a))return[];if(l)return n?.appendChild(l.cloneNode(!0)),[];if(i)return[ve(e,{url:i,responseType:"text"}).then(c=>{n?.insertAdjacentHTML("beforeend",c)})]}return[]}function so(o,e){let{tasks:t}=e;j(o)&&((ce(o)||Xn(o))&&t.push(...Rs(o,e)),$i(o)&&t.push(...Ns(o,e))),be(o)&&t.push(...As(o.style,e)),o.childNodes.forEach(n=>{so(n,e)})}async function Ls(o,e){let{ownerDocument:t,svgStyleElement:n,fontFamilies:r,fontCssTexts:i,tasks:s,font:a}=e;if(!(!t||!n||!r.size))if(a&&a.cssText){let l=zn(a.cssText,e);n.appendChild(t.createTextNode(`${l}
`))}else{let l=Array.from(t.styleSheets).filter(p=>{try{return"cssRules"in p&&!!p.cssRules.length}catch(g){return e.log.warn(`Error while reading CSS rules from ${p.href}`,g),!1}}),c=t.implementation.createHTMLDocument(""),d=c.createElement("style");c.head.appendChild(d);let u=d.sheet;await Promise.all(l.flatMap(p=>Array.from(p.cssRules).map(async g=>{if(Oi(g)){let m=g.href,f="";try{f=await ve(e,{url:m,requestType:"text",responseType:"text"})}catch(v){e.log.warn(`Error fetch remote css import from ${m}`,v)}let b=f.replace(io,(v,T,S)=>v.replace(S,Vn(S,m)));for(let v of Is(b))try{u.insertRule(v,u.cssRules.length)}catch(T){e.log.warn("Error inserting rule from remote css import",{rule:v,error:T})}}}))),u.cssRules.length&&l.push(u);let h=[];l.forEach(p=>{Nt(p.cssRules,h)}),h.filter(p=>_i(p)&&ro(p.style.getPropertyValue("src"))&&Jn(p.style.getPropertyValue("font-family"))?.some(g=>r.has(g))).forEach(p=>{let g=p,m=i.get(g.cssText);m?n.appendChild(t.createTextNode(`${m}
`)):s.push(oo(g.cssText,g.parentStyleSheet?g.parentStyleSheet.href:null,e).then(f=>{f=zn(f,e),i.set(g.cssText,f),n.appendChild(t.createTextNode(`${f}
`))}))})}}var Ps=/(\/\*[\s\S]*?\*\/)/g,jn=/((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;function Is(o){if(o==null)return[];let e=[],t=o.replace(Ps,"");for(;;){let i=jn.exec(t);if(!i)break;e.push(i[0])}t=t.replace(jn,"");let n=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,r=new RegExp("((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})","gi");for(;;){let i=n.exec(t);if(i)r.lastIndex=n.lastIndex;else if(i=r.exec(t),i)n.lastIndex=r.lastIndex;else break;e.push(i[0])}return e}var Hs=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,Ds=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function zn(o,e){let{font:t}=e,n=t?t?.preferredFormat:void 0;return n?o.replace(Ds,r=>{for(;;){let[i,,s]=Hs.exec(r)||[];if(!s)return"";if(s===n)return`src: ${i};`}}):o}function Nt(o,e=[]){for(let t of Array.from(o))Bi(t)?e.push(...Nt(t.cssRules)):"cssRules"in t?Nt(t.cssRules,e):e.push(t);return e}var _s=/\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;function Os(o){return _s.test(o.innerHTML)}async function Bs(o,e){let t=await Zn(o,e);if(j(t.node)&&we(t.node)&&!Os(t.node))return t.node;let{ownerDocument:n,log:r,tasks:i,svgStyleElement:s,svgDefsElement:a,svgStyles:l,font:c,progress:d,autoDestruct:u,onCloneNode:h,onEmbedNode:p,onCreateForeignObjectSvg:g}=t;r.time("clone node");let m=await Ht(t.node,t,!0);if(s&&n){let S="";l.forEach((N,H)=>{S+=`${N.join(`,
`)} {
  ${H}
}
`}),s.appendChild(n.createTextNode(S))}r.timeEnd("clone node"),await h?.(m),c!==!1&&j(m)&&(r.time("embed web font"),await Ls(m,t),r.timeEnd("embed web font")),r.time("embed node"),so(m,t);let f=i.length,b=0,v=async()=>{for(;;){let S=i.pop();if(!S)break;try{await S}catch(N){t.log.warn("Failed to run task",N)}d?.(++b,f)}};d?.(b,f),await Promise.all([...Array.from({length:4})].map(v)),r.timeEnd("embed node"),await p?.(m);let T=$s(m,t);return a&&T.insertBefore(a,T.children[0]),s&&T.insertBefore(s,T.children[0]),u&&Ss(t),await g?.(T),T}function $s(o,e){let{width:t,height:n}=e,r=Zi(t,n,o.ownerDocument),i=r.ownerDocument.createElementNS(r.namespaceURI,"foreignObject");return i.setAttributeNS(null,"x","0%"),i.setAttributeNS(null,"y","0%"),i.setAttributeNS(null,"width","100%"),i.setAttributeNS(null,"height","100%"),i.append(o),r.appendChild(i),r}async function ao(o,e){let t=await Zn(o,e),n=await Bs(t),r=Qi(n,t.isEnable("removeControlCharacter"));t.autoDestruct||(t.svgStyleElement=Qn(t.ownerDocument),t.svgDefsElement=t.ownerDocument?.createElementNS(Ke,"defs"),t.svgStyles.clear());let i=le(r,n.ownerDocument);return await ss(i,t)}var lo=3e4;async function co(o){return o.startsWith("data:")?o:await I({type:"asset:fetch",url:o}).catch(()=>null)??!1}async function uo(o,e,t){if(e.height*t>lo||e.width*t>lo)throw new Error("too large");let n=_t(o),r=await It(document.createElement("div"),{scale:t,backgroundColor:n,width:e.width,height:e.height,style:{width:`${o.offsetWidth}px`,height:`${o.scrollHeight}px`,maxHeight:"none",counterReset:Ws(o),overflow:"visible",margin:"0",transformOrigin:"0 0",transform:`translate(${-e.left}px, ${-e.top}px)`},fetchFn:co,timeout:15e3,filter:Fs(o,e),autoDestruct:!0,includeStyleProperties:Us(o),features:{fixSvgXmlDecode:!1}});r.node=o;let i=new Dt(o.ownerDocument.defaultView??window);r.ownerWindow=i.view,r.onCreateForeignObjectSvg=l=>i.restore(l);let s=await ao(r),a=s.getContext("2d");if(!a)throw new Error("no canvas");if(js(a,s))throw new Error("blank");return s}function Fs(o,e){let t=new WeakSet,n,r=o.ownerDocument.defaultView??window,i=o.getBoundingClientRect(),s=o!==o.ownerDocument.body,a=s?o.scrollTop:0,l=s?o.scrollLeft:0,c=e.top,d=e.top+e.height,u=e.left,h=e.left+e.width;return p=>{let g=p.parentNode;if(g&&t.has(g))return!1;if(p.nodeType!==Node.ELEMENT_NODE)return!0;let m=p,f=r.getComputedStyle(m).display;if(f==="none")return!1;if(f.startsWith("inline")||f==="contents"||f.startsWith("table-"))return!0;let b=m.getBoundingClientRect(),v=b.top-i.top+a,T=b.left-i.left+l;return(v+b.height<c||v>d||T+b.width<u||T>h)&&(v>d||!(n??=qs(o,r)).has(m))&&t.add(m),!0}}function Ws(o){let e=o.ownerDocument.defaultView??window,t=[];for(let n=o;n;n=n.parentElement){let r=e.getComputedStyle(n).counterReset;r&&r!=="none"&&t.unshift(r)}return t.join(" ")||"none"}function qs(o,e){let t=(r,i)=>{let s=e.getComputedStyle(r,i);return s.counterIncrement!=="none"||s.counterReset!=="none"||s.counterSet!=="none"},n=new WeakSet;for(let r of Array.from(o.querySelectorAll("*")))if(!(!t(r)&&!t(r,"::before")&&!t(r,"::after")))for(let i=r;i&&i!==o&&!n.has(i);i=i.parentElement)n.add(i);return n}var Dt=class{kept=[];view;constructor(e){let t=(n,r)=>{let i=e.getComputedStyle(n,r);if(!r||!i.content.includes("counter"))return i;let s=this.keep(i.content);return new Proxy(i,{get:(a,l)=>{if(l==="getPropertyValue")return d=>d==="content"?s:a.getPropertyValue(d);let c=Reflect.get(a,l,a);return typeof c=="function"?c.bind(a):c}})};this.view={getComputedStyle:t}}keep(e){return this.kept.push(e),`YLKEPT${this.kept.length-1}X`}async restore(e){let t=e.querySelector("style");if(!t?.textContent)return;let n=t.textContent.replace(/content: 'YLKEPT(\d+)X';/g,(i,s)=>`content: ${this.kept[Number(s)]};`),r=new Set(Array.from(n.matchAll(/url\("(https?:[^"]+)"\)/g),i=>i[1]));await Promise.all(Array.from(r,async i=>{let s=await co(i);s&&(n=n.split(i).join(s))})),t.textContent=n}};function _t(o){let e=o.ownerDocument.defaultView??window;for(let t=o;t;t=t.parentElement){let n=e.getComputedStyle(t).backgroundColor;if(n&&n!=="transparent"&&!/rgba(.*, 0)$/.test(n))return n}return"#ffffff"}function Us(o){let e=(o.ownerDocument.defaultView??window).getComputedStyle(o),t=[];for(let n=0;n<e.length;n++){let r=e.item(n);!r.startsWith("--")&&!/^(animation|transition|view-timeline|scroll-timeline|animation-timeline)/.test(r)&&t.push(r)}return t}function js(o,e){let t=Math.max(1,Math.floor(e.height/400)),{data:n}=o.getImageData(0,0,e.width,e.height),[r,i,s]=[n[0],n[1],n[2]];for(let a=0;a<e.height;a+=t)for(let l=0;l<e.width;l+=3){let c=(a*e.width+l)*4;if(n[c]!==r||n[c+1]!==i||n[c+2]!==s)return!1}return!0}var W={margin:12,line:1.5,radius:12,top:18,foot:38};function po(o,e,t,n){let r=(W.margin+W.line)*n,i=document.createElement("canvas");i.width=o.width+Math.round(r*2),i.height=o.height+Math.round(r*2+(W.top+W.foot)*n);let s=i.getContext("2d");if(!s)throw new Error("no canvas");let{width:a,height:l}=i;s.fillStyle="#ffffff",s.fillRect(0,0,a,l),s.fillStyle=e,s.fillRect(0,0,a,l);let[c=255,d=255,u=255]=s.getImageData(0,0,1,1).data,h=.299*c+.587*d+.114*u<128;return s.save(),s.beginPath(),s.roundRect(r,r,a-r*2,l-r*2,W.radius*n),s.clip(),s.drawImage(o,Math.round(r),Math.round(r+W.top*n)),s.restore(),s.fillStyle=h?"#9aa3ae":"#7c828b",s.font=`${12*n}px -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif`,s.textAlign="center",s.textBaseline="middle",s.fillText(t,a/2,l-r-W.foot/2*n),zs(s,a,l,n),i}function zs(o,e,t,n){let r=(W.margin+W.line/2)*n,i=(W.radius+W.line/2)*n,s={x:e-r,y:t-r},a=e/2,l=[],c=r+i,d=s.y-i;l.push([0,0,e,c,r,0,s.x,0],[a,c,a,d-c,0,c,0,d],[0,d,e,t-d,s.x,0,r,0],[0,c,a,d-c,0,d,0,c]);for(let[u,h,p,g,m,f,b,v]of l){let T=o.createLinearGradient(m,f,b,v);for(let[S,N]of he)T.addColorStop(Number(S),N);o.save(),o.beginPath(),o.rect(u,h,p,g),o.clip(),o.beginPath(),o.roundRect(r,r,s.x-r,s.y-r,i),o.lineWidth=W.line*n,o.strokeStyle=T,o.stroke(),o.restore()}}var Gs=200,Ks=700,Xs=8,Vs=120,Ys=20,Js=2,Zs=360,ho=180,xe=16,mo=18,Ot=39,Qs=36,Xe=8,ea=.25,ta=24,na=260,oa=170,ra=120,ia=560,sa=80,aa=3e4,la=60,ca='img,svg,picture,hr,video,canvas,button,input,select,textarea,yl-r,[role="button"],[role="img"]';function da(){return new Promise(o=>{let e=setTimeout(o,120);requestAnimationFrame(()=>requestAnimationFrame(()=>{clearTimeout(e),o()}))})}function fo(o){return new Promise((e,t)=>o.toBlob(n=>n?e(n):t(new Error("no image")),"image/png"))}function ua(o){let e=atob(o.slice(o.indexOf(",")+1)),t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return new Blob([t],{type:"image/png"})}function go(o){let e=o[0],t=o[o.length-1];if(!e||!t||!e.isConnected||!t.isConnected)return null;let n=document.createRange();return n.setStartBefore(e),n.setEndAfter(t),n.getBoundingClientRect()}function Ve(o){return getComputedStyle(o).visibility==="visible"}function Ye(o,e){let t=[],n=!1;for(let r=o;r;r=r.parentElement){let i=e.get(r);if(i!==void 0){n=i;break}t.push(r);let s=getComputedStyle(r).position;if(s==="fixed"||s==="sticky"){n=!0;break}}for(let r of t)e.set(r,n);return n}var Je=class{constructor(e,t,n){this.ui=e;this.settings=t;this.pageTranslated=n}rect;scroller=null;band={top:0,bottom:0};box;card;body;bar;labels=[];mirror;scanner=new se;entries=[];byCopy=new WeakMap;seenNodes=new WeakSet;seenText=new Map;queue=[];inFlight=0;scanTimer;flushTimer;scanning=!1;rescan=!1;frame=0;backdrop;view;findInput;findCount;closeTimer;exporting=!1;restoreCard;observer;session=0;get running(){return this.rect!==void 0}start(e){this.stop(),this.session++,this.rect=e,this.scanner.classifier.setExcludes(this.settings().excludeSelectors);let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scroller=t?this.findScroller(t):null,this.band={top:this.toContent(e.top),bottom:this.toContent(e.bottom)},this.box=this.ui.addFrame(),Object.assign(this.box.style,{left:`${_(e.left)}px`,top:`${_(e.top)}px`,width:`${_(e.right-e.left)}px`,height:`${_(e.bottom-e.top)}px`}),this.buildBar(e),this.buildCard(e),addEventListener("scroll",this.onScroll,!0),addEventListener("resize",this.syncView),addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutation),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0}),this.scan()}stop(){this.session++,removeEventListener("scroll",this.onScroll,!0),removeEventListener("resize",this.syncView),removeEventListener("keydown",this.onKey,!0),this.observer?.disconnect(),this.observer=void 0,clearTimeout(this.scanTimer),clearTimeout(this.flushTimer),cancelAnimationFrame(this.frame),this.scanTimer=this.flushTimer=void 0,this.frame=0,clearTimeout(this.closeTimer),this.closeTimer=void 0,this.exporting=!1,this.view=this.findInput=this.findCount=void 0,this.mirror?.destroy(),this.mirror=void 0;for(let e of this.entries)e.segment?.unrender();this.box?.remove(),this.ui.dismiss(this.bar),this.ui.dismiss(this.card),this.box=this.bar=this.card=this.body=void 0,this.labels=[],this.rect=void 0,this.scroller=null,this.entries=[],this.byCopy=new WeakMap,this.queue=[],this.seenNodes=new WeakSet,this.seenText.clear(),this.inFlight=0,this.scanning=!1,this.rescan=!1,this.backdrop?.remove(),this.backdrop=void 0,this.restoreCard=void 0}findScroller(e){for(let t=e;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t).overflowY;if((n==="auto"||n==="scroll")&&t.scrollHeight>t.clientHeight+1)return t}return null}get origin(){return this.scroller?this.scroller.getBoundingClientRect().top+this.scroller.clientTop:0}get scrollPos(){return this.scroller?this.scroller.scrollTop:scrollY}atScrollEnd(){let e=this.scroller;if(e)return e.scrollTop+e.clientHeight>=e.scrollHeight-2;let t=document.documentElement;return scrollY+innerHeight>=t.scrollHeight-2}toContent(e){return e-this.origin+this.scrollPos}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.exporting?this.exporting=!1:this.findInput?.value?this.clearFind():this.restoreCard?this.exitImmersive():this.stop())};enterImmersive(){let e=this.card,t=this.view;if(!e||!t||this.restoreCard)return;let n=e.getBoundingClientRect();this.restoreCard={left:e.style.left,top:e.style.top,bottom:e.style.bottom,height:e.style.height};let r=this.ui.addBelow(x("div","scan-backdrop"),e);r.addEventListener("click",()=>this.exitImmersive()),r.addEventListener("wheel",a=>a.preventDefault(),{passive:!1}),this.backdrop=r,e.removeAttribute("data-hidden"),this.mirror?.hidePinned(),this.placeFrame();let i=innerHeight-ta*2,s=Math.min(i,Math.max(na,t.contentHeight+Ot));t.start(s-Ot,this.mirror?.scrollerTop??0),e.style.top=`${n.top}px`,e.style.bottom="auto",e.style.left=`${n.left}px`,e.style.height=`${n.height}px`,e.offsetHeight,e.classList.add("scan-animate","scan-immersive"),e.style.top=`${Math.round((innerHeight-s)/2)}px`,e.style.left=`${Math.round((innerWidth-n.width)/2)}px`,e.style.height=`${s}px`}exitImmersive(){let e=this.card;!e||!this.restoreCard||this.closeTimer!==void 0||(this.ui.dismiss(this.backdrop),this.backdrop=void 0,e.classList.add("scan-closing"),this.closeTimer=setTimeout(()=>{this.closeTimer=void 0;let t=this.restoreCard;this.restoreCard=void 0,this.clearFind(),this.view?.stop(),e.classList.remove("scan-immersive","scan-animate","scan-closing"),e.setAttribute("data-hidden",""),t&&Object.assign(e.style,t),this.placeFrame(),this.requestSync()},oa))}clearFind(){this.findInput&&(this.findInput.value=""),this.view?.clearFind(),this.paintFind(0,0,!1)}paintFind(e,t,n){this.findCount&&(this.findCount.textContent=t?`${e}/${t}`:n?"0/0":"");let r=this.findInput?.parentElement;r?.toggleAttribute("data-none",n),r?.toggleAttribute("data-found",t>0),r?.toggleAttribute("data-typed",t>0||n)}buildFind(){let e=x("div","scan-find"),t=x("input","scan-find-input");t.type="text",t.placeholder=w("findPlaceholder"),t.spellcheck=!1;let n=x("span","scan-find-count","");e.addEventListener("click",()=>t.focus({preventScroll:!0})),this.findInput=t,this.findCount=n;let r=0,i,s=c=>{r&&this.paintFind(this.view?.step(c)??0,r,!1)};t.addEventListener("input",()=>{clearTimeout(i),i=setTimeout(()=>{r=this.view?.find(t.value)??0,this.paintFind(r?1:0,r,!r&&!!t.value.trim())},ra)}),t.addEventListener("keydown",c=>{c.stopPropagation(),c.key==="Enter"&&(c.preventDefault(),s(c.shiftKey?-1:1))});for(let c of["keyup","keypress"])t.addEventListener(c,d=>d.stopPropagation());let a=O("up",w("findPrevious"),()=>s(-1)),l=O("down",w("findNext"),()=>s(1));for(let c of[a,l])c.addEventListener("mousedown",d=>d.preventDefault());return e.append(ne("search"),t,n,a,l),e}onScroll=e=>{if(this.ui.ownsEvent(e))return;if(this.scroller&&e.target!==this.scroller){this.requestSync();return}let t=this.rect;if(!t)return;let n=this.toContent(t.top),r=this.toContent(t.bottom),i=n<this.band.top||r>this.band.bottom;this.band.top=Math.min(this.band.top,n),this.band.bottom=Math.max(this.band.bottom,r);let s=this.atScrollEnd()&&this.band.bottom!==1/0;s&&(this.band.bottom=1/0),(i||s)&&this.scheduleScan(Gs),this.requestSync()};onMutation=()=>this.scheduleScan(Ks);scheduleScan(e){this.scanTimer===void 0&&(this.scanTimer=setTimeout(()=>{this.scanTimer=void 0,this.scan()},e))}isCovered(e){let t=this.rect;if(!t||!e.width||!e.height)return!1;let n=Math.min(e.right,t.right)-Math.max(e.left,t.left),r=t.right-t.left;if(n<e.width*.5&&n<r*.6)return!1;let i=this.toContent(e.top),s=this.toContent(e.bottom);return Math.min(s,this.band.bottom)-Math.max(i,this.band.top)>=(s-i)*.5}async scan(){if(!this.rect)return;if(this.scanning){this.rescan=!0;return}this.scanning=!0;let e=this.session;this.scanner.reset();let t=new Map,n=this.settings().targetLang,r=this.scroller??document.body;if(r){let i={consume:()=>!1,shadowRoot:()=>{},emit:a=>this.considerRun(a,n,t),skipped:a=>this.considerSkipped(a,t),plain:(a,l)=>this.considerPlain(a,l,t)},s=performance.now();for(let a of this.scanner.scan(r,i))if(performance.now()-s>Xs){if(await new Promise(l=>setTimeout(l,0)),e!==this.session)return;s=performance.now()}this.revealLeaves(r,t)}this.scanning=!1,this.requestSync(),this.rescan&&(this.rescan=!1,this.scan())}revealLeaves(e,t){for(let n of Array.from(e.querySelectorAll(ca)))this.seenNodes.has(n)||Ye(n,t)||!Ve(n)||this.isCovered(n.getBoundingClientRect())&&(this.seenNodes.add(n),this.mirror?.showWhole(n))}alreadyHave(e,t,n){return this.seenNodes.has(e)?!0:!!this.seenText.get(t)?.some(r=>Math.abs(r-n)<la)}remember(e,t,n){this.seenNodes.add(e);let r=this.seenText.get(t);r?r.push(n):this.seenText.set(t,[n])}considerRun(e,t,n){let r=e.nodes[0];if(this.seenNodes.has(r))return;let i=new ae(e),s=i.parentElement;if(Ye(s,n)||!Ve(s))return;let a=go(e.nodes);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,e.markup,l))return;this.remember(r,e.markup,l);let c=me(e.text,t),d=this.mirror?.showRun(e.nodes,!c);if(!d)return;let u=this.addEntry("text",a,d);u.segment=i,c?this.setState(u,"kept"):(this.queue.push(u),this.scheduleFlush())}considerSkipped(e,t){if(this.seenNodes.has(e)||Ye(e,t)||!Ve(e))return;let n=e.getBoundingClientRect();if(!this.isCovered(n))return;let r=e.textContent??"",i=hn(e)&&!!r.trim(),s=this.toContent(n.top);if(i&&this.alreadyHave(e,r,s))return;i?this.remember(e,r,s):this.seenNodes.add(e);let a=this.mirror?.showWhole(e);if(!a||!i)return;let l=this.addEntry("code",n,a);this.setState(l,"kept")}considerPlain(e,t,n){let r=e[0];if(!r||this.seenNodes.has(r))return;let i=e.map(u=>u.textContent??"").join("").trim();if(!i)return;let s=t.nodeType===Node.ELEMENT_NODE?t:t.host;if(Ye(s,n)||!Ve(s))return;let a=go(e);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,i,l))return;this.remember(r,i,l);let c=this.mirror?.showRun(e,!1);if(!c)return;let d=this.addEntry("verbatim",a,c);this.setState(d,"kept")}addEntry(e,t,n){let r={kind:e,state:"pending",top:this.toContent(t.top),bottom:this.toContent(t.bottom),left:t.left,right:t.right,copy:n};this.byCopy.set(n,r);let i=this.entries.length;for(;i>0;){let s=this.entries[i-1];if(s.top<r.top||s.top===r.top&&s.left<=r.left)break;i--}return this.entries.splice(i,0,r),this.updateLabel(),r}setState(e,t){e.state=t,this.updateLabel()}buildBar(e){let t=x("div","scan-bar"),n=x("span","grow","");this.labels.push(n),t.append(n,O("expand",w("immersive"),()=>this.enterImmersive()),O("copy",w("copyMarkdown"),()=>this.copyAll()),O("close",w("close"),()=>this.stop()));let r=e.top-Qs-Xe;Object.assign(t.style,{top:`${_(r>=Xe?r:e.top+Xe)}px`,right:`${_(Math.max(Xe,innerWidth-e.right))}px`}),this.bar=this.ui.add(t)}buildCard(e){let t=x("div","scan-card");t.setAttribute("role","log"),t.setAttribute("aria-label",w("marqueeScan")),t.setAttribute("data-hidden","");let n=x("div","scan-head"),r=x("span","grow","");this.labels.push(r),n.append(r,this.buildFind(),O("image",w("copyImage"),()=>this.copyImage()),O("download",w("exportImage"),()=>void this.saveImage()),O("collapse",w("exitImmersive"),()=>this.exitImmersive()),O("copy",w("copyMarkdown"),()=>this.copyAll()),O("close",w("close"),()=>this.stop())),n.addEventListener("wheel",c=>{c.preventDefault(),this.view?.scrollBy(c.deltaY)},{passive:!1});let i=x("div","scan-body");t.append(n,i),this.body=i;let s=e.bottom-e.top+Ot,a=innerHeight-e.bottom-xe*2,l=a>=ho?Math.min(a,s):Math.round(innerHeight*.42);Object.assign(t.style,{height:`${Math.max(ho,l)}px`,bottom:`${xe}px`}),this.card=this.ui.add(t),this.updateLabel(),this.mirror=new He(i,this.scroller,()=>{},this.onKey),this.view=new Ue(this.mirror,i,()=>this.entries.map(c=>c.copy)),this.view.stop(),this.placeFrame()}placeFrame(){let e=this.mirror?.frame,t=this.rect,n=this.body,r=this.card;if(!e||!t||!n||!r)return;let i=(t.right-t.left)*ea,s=t.left,a=t.right;for(let l of this.entries)s=Math.min(s,Math.max(l.left,t.left-i)),a=Math.max(a,Math.min(l.right,t.right+i));if(s=Math.max(0,s-mo),a=Math.min(innerWidth,a+mo),!this.restoreCard){let l=Math.min(innerWidth-xe*2,Math.max(Zs,a-s));r.style.width=`${l}px`,r.style.left=`${Math.max(xe,Math.min(s,innerWidth-l-xe))}px`}if(this.restoreCard){let l=this.mirror?.scrollerTop??0;Object.assign(e.style,{left:`${-s}px`,top:`${-l}px`,width:`${innerWidth}px`,height:`${innerHeight+l}px`});return}Object.assign(e.style,{left:`${-s}px`,top:`${-t.top}px`,width:`${innerWidth}px`,height:`${Math.max(innerHeight,t.top+n.clientHeight)}px`})}paintPending(){this.box&&this.ui.setFramePending(this.box,this.inFlight>0||this.queue.length>0)}scheduleFlush(){this.paintPending(),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},Vs))}pump(){for(;this.inFlight<Js&&this.queue.length;)this.send(this.queue.splice(0,Ys))}async send(e){let t=this.session,n=this.settings();this.inFlight++;let r;try{r=await Fe(e.map(s=>({markup:s.segment.markup,hint:s.segment.sourceHint()})),n.sourceLang,n.targetLang)}catch{r=void 0}if(t!==this.session||!D())return;this.inFlight--;let i;e.forEach((s,a)=>{let l=r?.[a],c=s.segment.run;if(l?.ok&&l.text.trim()){let d=new Set(c.slots.map((u,h)=>h));this.mirror?.setTranslation(s.copy,Y(F(l.text,d),u=>!!c.slots[u]?.detached),c.slots,$e(c.markup)),this.replaceOnPage(s,l.text,n),this.setState(s,"done")}else this.mirror?.setKept(s.copy),this.setState(s,"failed"),i??=l&&!l.ok?l.code:"network"}),i&&this.ui.toast(this.ui.errorMessage(i)),this.requestSync(),this.pump(),this.paintPending()}replaceOnPage(e,t,n){let r=e.segment;!r||this.pageTranslated()||(r.setTranslation(t),r.render({mode:"replace",dualStyle:"plain",fontScale:100,targetLang:n.targetLang,theme:te(n.themeColor)}))}updateLabel(){if(!this.labels.length)return;let e=0,t=0;for(let n of this.entries)n.kind==="code"?t++:n.state==="done"&&e++;for(let n of this.labels)n.textContent=w("scanStatus",String(e),String(t))}copyAll(){let e=$n(this.entries);navigator.clipboard.writeText(e).then(()=>{for(let t of this.labels)t.textContent=w("copied");setTimeout(()=>this.updateLabel(),1200)})}async withPicture(e){let t=this.card;if(!t||!this.restoreCard||this.exporting)return;this.exporting=!0;let n=this.session;t.setAttribute("data-exporting",""),this.clearFind();let r=x("div","scan-making"),i=x("div","scan-making-note");i.append(x("span","scan-making-spin"),x("span","",w("exportingFast"))),r.append(i),this.body?.append(r),await da();try{let s=await this.drawResult().catch(()=>null)??await this.photographResult();if(!s||n!==this.session)return;let a=this.mirror?.scroller??this.mirror?.doc.body;return await e(po(s,a?_t(a):"#ffffff",w("pictureMark",w("extName")),devicePixelRatio||1))}catch{this.ui.toast(w("exportFailed"));return}finally{r.remove(),n===this.session&&(this.exporting=!1,t.removeAttribute("data-exporting"),this.updateLabel())}}async drawResult(){let e=this.mirror,t=this.view,n=this.body,r=e?.scroller;if(!e||!t||!n||!r)throw new Error("not ready");let i=r!==e.doc.scrollingElement,s=i?r:e.doc.body,{from:a,to:l,visible:c}=t.extent,d=devicePixelRatio||1,u=n.getBoundingClientRect().left-e.frame.getBoundingClientRect().left,h=s.getBoundingClientRect();return uo(s,{left:u-h.left,top:i?a:a-(h.top+(e.doc.defaultView?.scrollY??0)),width:n.clientWidth,height:l-a+c},d)}async photographResult(){let e=this.view,t=this.body;if(!e||!t)return null;let n=this.session,r=e.position;this.card?.setAttribute("data-photographing","");try{await new Promise(p=>setTimeout(p,340));let{from:i,to:s,visible:a}=e.extent,l=t.getBoundingClientRect(),c=devicePixelRatio||1,d=document.createElement("canvas");d.width=Math.round(l.width*c),d.height=Math.min(Math.round((s-i+a)*c),aa);let u=d.getContext("2d");if(!u)throw new Error("no canvas");let h=Math.ceil(d.height/c/a);for(let p=0;p<h;p++){if(!this.exporting||n!==this.session)return null;for(let b of this.labels)b.textContent=w("exporting",String(p+1),String(h));e.moveTo(i+p*a),await new Promise(b=>setTimeout(b,p?ia:sa));let g=await I({type:"capture:screen"});if(!g)throw new Error("refused");let m=await createImageBitmap(ua(g)),f=m.width/innerWidth;u.drawImage(m,l.left*f,l.top*f,l.width*f,l.height*f,0,Math.round((e.position-i)*c),d.width,Math.round(l.height*c)),m.close()}return d}finally{this.card?.removeAttribute("data-photographing"),n===this.session&&e.moveTo(r)}}async saveImage(){await this.withPicture(async e=>{let t=await fo(e),n=document.createElement("a");n.href=URL.createObjectURL(t),n.download=`yilan-${location.hostname}-${new Date().toISOString().slice(0,10)}.png`,n.click(),setTimeout(()=>URL.revokeObjectURL(n.href),1e4)})}copyImage(){if(!this.restoreCard||this.exporting)return;if(!navigator.clipboard?.write){this.ui.toast(w("copyImageFailed"));return}let e=()=>{},t=()=>{},n=new Promise((i,s)=>{e=i,t=s}),r=navigator.clipboard.write([new ClipboardItem({"image/png":n})]);this.withPicture(async i=>(e(await fo(i)),await r,this.ui.toast(w("copiedImage"),void 0,1800),!0)).then(i=>{i||t(new Error("no picture"))}),r.catch(()=>this.ui.toast(w("copyImageFailed")))}requestSync(){this.frame||(this.frame=requestAnimationFrame(this.syncView))}syncView=()=>{this.frame=0;let e=this.rect;if(!e)return;this.placeFrame();let t=this.toContent(e.top),n=this.toContent(e.bottom),r=this.entries.find(i=>i.bottom>t&&i.top<n);r&&!this.restoreCard&&this.mirror?.alignTo(r.copy,e.top+(r.top-t))}};var de="http://www.w3.org/2000/svg",tt=8,Bt=5,Ft=16,V=8,Ze=13,Qe=8,pa=24,ha=22,ma=1.6,fa=2e3,ga=80,ba=48,ya=96,et=3,va=1100,wa=0;function xa(o){for(let e=o.parentElement;e;e=e.parentElement){let t=getComputedStyle(e).display;if(!t.startsWith("inline")&&t!=="contents")return e}return null}function bo(o){let e=o.commonAncestorContainer,t=new Map,n=document.createRange(),r=i=>{if(!i.data.trim()||!o.intersectsNode(i))return;let s=i===o.startContainer?o.startOffset:0,a=i===o.endContainer?o.endOffset:i.length;n.setStart(i,s),n.setEnd(i,a);let l=Array.from(n.getClientRects()).filter(u=>u.width&&u.height);if(!l.length)return;let c=xa(i);if(!c)return;let d=t.get(c);d?(d.rects.push(...l),d.end=[i,a]):t.set(c,{el:c,rects:l,start:[i,s],end:[i,a]})};if(e.nodeType===Node.TEXT_NODE)r(e);else{let i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let s=i.nextNode(),a=0;s&&a<fa;s=i.nextNode(),a++)r(s)}return Array.from(t.values())}function yo(o){return bo(o).map(e=>({el:e.el,members:[e.el],lines:vo(e.rects)}))}function vo(o){let e=[];for(let n of o){let r=e.find(i=>Math.min(i.bottom,n.bottom)-Math.max(i.top,n.top)>Math.min(i.bottom-i.top,n.bottom-n.top)/2);r?(r.left=Math.min(r.left,n.left),r.right=Math.max(r.right,n.right),r.top=Math.min(r.top,n.top),r.bottom=Math.max(r.bottom,n.bottom)):e.push({left:n.left,top:n.top,right:n.right,bottom:n.bottom})}return e.sort((n,r)=>n.top-r.top),e.some((n,r)=>r>0&&(n.left>e[r-1].right||n.right<e[r-1].left))?[{left:Math.min(...e.map(n=>n.left)),top:e[0].top,right:Math.max(...e.map(n=>n.right)),bottom:Math.max(...e.map(n=>n.bottom))}]:e}function Ea(o){for(let e=o;e&&e!==document.body;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return!0;return!1}function nt(o){return{left:Math.min(...o.map(e=>e.left)),top:Math.min(...o.map(e=>e.top)),right:Math.max(...o.map(e=>e.right)),bottom:Math.max(...o.map(e=>e.bottom))}}function wo(o,e){let t=Math.max(o.left,e.left)-Math.min(o.right,e.right),n=Math.max(o.top,e.top)-Math.min(o.bottom,e.bottom);return t<=0&&n<=ga||n<=0&&t<=ba}function Sa(o){let e=o.map(t=>({el:t.el,members:[...t.members],lines:[...t.lines]}));for(let t=!0;t;){t=!1;for(let n=0;n<e.length&&!t;n++)for(let r=n+1;r<e.length&&!t;r++)wo(nt(e[n].lines),nt(e[r].lines))&&(e[n].lines.push(...e[r].lines),e[n].members.push(...e[r].members),e.splice(r,1),t=!0)}return e.map(t=>({el:t.el,members:t.members,lines:vo(t.lines)}))}function rt(o){let e=yo(o).map(r=>({el:r.el,members:r.members,lines:r.lines.filter(i=>i.top>=0&&i.bottom<=innerHeight&&i.left>=0&&i.right<=innerWidth)})).filter(r=>r.lines.length),t=e.filter(r=>!Ea(r.el)),n=Sa(t.length?t:e);return n.length===1?{tail:n[0]}:null}function xo(o){let e=[];for(let t of bo(o)){let n=nt(t.rects),r=e[e.length-1],i=!!r&&Math.min(r.box.bottom,n.bottom)>Math.max(r.box.top,n.top)&&n.left-r.box.right<=ya;if(r&&i){r.range.setEnd(t.end[0],t.end[1]),r.box=nt([r.box,n]);continue}let s=document.createRange();s.setStart(t.start[0],t.start[1]),s.setEnd(t.end[0],t.end[1]),e.push({el:t.el,range:s,newPlace:!!r&&!wo(r.box,n),box:n})}return e}function Eo(o,e){let t=x("div","source-flash");for(let n of yo(e).flatMap(r=>r.lines)){let r=x("div","source-flash-line");r.style.left=`${n.left-3}px`,r.style.top=`${n.top-2}px`,r.style.width=`${n.right-n.left+6}px`,r.style.height=`${n.bottom-n.top+4}px`,t.append(r)}o.add(t),setTimeout(()=>t.remove(),va)}function Ta(o){let e=[];for(let t of o){let n=e[e.length-1];(!n||Math.abs(n[0]-t[0])>.5||Math.abs(n[1]-t[1])>.5)&&e.push(t)}return e.filter((t,n)=>{let r=e[(n-1+e.length)%e.length],i=e[(n+1)%e.length];return!(Math.abs(r[0]-t[0])<.5&&Math.abs(i[0]-t[0])<.5)&&!(Math.abs(r[1]-t[1])<.5&&Math.abs(i[1]-t[1])<.5)})}function ka(o){let e=o.length,t="";return o.forEach((n,r)=>{let i=o[(r-1+e)%e],s=o[(r+1)%e],a=Math.hypot(i[0]-n[0],i[1]-n[1]),l=Math.hypot(s[0]-n[0],s[1]-n[1]),c=Math.min(Ft,a/2,l/2),d=[n[0]+(i[0]-n[0])/a*c,n[1]+(i[1]-n[1])/a*c],u=[n[0]+(s[0]-n[0])/l*c,n[1]+(s[1]-n[1])/l*c];t+=`${r?"L":"M"}${d[0]} ${d[1]}Q${n[0]} ${n[1]} ${u[0]} ${u[1]}`}),`${t}Z`}function Ma(o){let e=document.createElementNS(de,"path");e.setAttribute("d",o);let t=e.getTotalLength(),n=Math.max(10,Math.round(t/ha)),r=[];for(let i=0;i<n;i++){let s=e.getPointAtLength(i/n*t);r.push([s.x,s.y])}return r.map((i,s)=>{let a=r[(s-1+n)%n],l=r[(s+1)%n],c=l[0]-a[0],d=l[1]-a[1],u=Math.hypot(c,d)||1,h=ma*(Math.sin(s*.9)*.6+Math.sin(s*.37+1.3)*.7);return[i[0]+d/u*-h,i[1]+c/u*h]})}function $t(o,e,t){let n=o.length,r=s=>o[(s%n+n)%n],i="";for(let s=0;s<t;s++){let a=e+s,[l,c,d,u]=[r(a-1),r(a),r(a+1),r(a+2)];i+=`C${c[0]+(d[0]-l[0])/6} ${c[1]+(d[1]-l[1])/6} ${d[0]-(u[0]-c[0])/6} ${d[1]-(u[1]-c[1])/6} ${d[0]} ${d[1]}`}return i}function Ca(o){let{lines:e}=o,t=e[0],n=e[e.length-1],r=parseFloat(getComputedStyle(o.el).lineHeight),i=t.bottom-t.top,s=Bt+(r>i&&r<i*3?(r-i)/2:0),a=Math.max(et,t.top-s),l=Math.min(innerHeight-et,n.bottom+s),c=p=>Math.max(et,p.left-tt),d=p=>Math.min(innerWidth-et,p.right+tt),u=[[c(t),a],[d(t),a]],h=(p,g,m)=>(p.bottom+g.top)/2+(m?Bt:-Bt);e.forEach((p,g)=>{let m=e[g+1];if(!m)return;let f=h(p,m,d(p)>d(m));u.push([d(p),f],[d(m),f])}),u.push([d(n),l],[c(n),l]);for(let p=e.length-1;p>0;p--){let g=h(e[p-1],e[p],c(e[p-1])<c(e[p]));u.push([c(e[p]),g],[c(e[p-1]),g])}return{points:Ma(ka(Ta(u))),top:a,bottom:l,padY:s}}function So(o,e,t,n=!0){let{points:r,top:i,bottom:s,padY:a}=Ca(o),l=o.lines[0],c=o.lines[o.lines.length-1],d=s+Ze+t<=innerHeight-V,u=i-Ze-t>=V;if(!n||!d&&!u)return{path:"M"+r[0][0]+" "+r[0][1]+$t(r,0,r.length)+"Z",left:Math.max(V,Math.min(l.left,innerWidth-e-V)),top:Math.max(V,innerHeight-t-V)};let h=d,p=h?c:l,g=h?s:i,m=p.left-tt+Ft+Qe,f=p.right+tt-Ft-Qe,b=h?f-12:m+12,v=f>m?Math.max(m,Math.min(b,f)):(p.left+p.right)/2,T=h?g+Ze:g-Ze,S=Math.min(pa,e/2),N=Math.max(V,v-e+S),H=Math.min(innerWidth-e-V,v-S),$=Math.max(N,Math.min(l.left,H)),B=r.length,L=-1,C=-1;r.forEach((E,A)=>{if(Math.abs(E[1]-g)>=a+6)return;let R=E[0]-v;R>=Qe*.6&&(L<0||R<r[L][0]-v)&&(L=A),R<=-Qe*.6&&(C<0||R>r[C][0]-v)&&(C=A)});let[y,k]=h?[L,C]:[C,L],M;if(y<0||k<0)M=`M${r[0][0]} ${r[0][1]}${$t(r,0,B)}Z`;else{let E=(y-k+B)%B||B;M=`M${r[k][0]} ${r[k][1]}${$t(r,k,E)}L${v} ${T}Z`}return{path:M,left:$,top:h?T-1:T-t+1}}function To(o,e=!0){let t=document.createElementNS(de,"svg");t.setAttribute("class","bubble-ring"),t.setAttribute("aria-hidden","true");let n=`yl-ring-${++wa}`,r=document.createElementNS(de,"defs"),i=document.createElementNS(de,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[s,a]of he){let l=document.createElementNS(de,"stop");l.setAttribute("offset",s),l.setAttribute("stop-color",a),i.append(l)}r.append(i),t.append(r);for(let s of o){let a=document.createElementNS(de,"path");a.setAttribute("d",s),e&&a.setAttribute("pathLength","1"),a.setAttribute("stroke",`url(#${n})`),t.append(a)}return t}function ko(o,e,t){let{path:n,left:r,top:i}=So(t.tail,e.offsetWidth,e.offsetHeight);e.style.left=`${r}px`,e.style.top=`${i}px`,o.insertBefore(To([n]),e)}var ot=class{constructor(e,t,n){this.range=t;this.anchor=n.tail.el;let r=this.anchor.getBoundingClientRect();this.first={plan:n,top:r.top,left:r.left};let i=K(this.anchor).map(s=>s.el);this.area=i[0],e.addToPage(this.node),this.pin=new z(this.node,i)}node=x("div","source-ring");pin;area;anchor;first;get anchorBox(){return this.anchor.getBoundingClientRect()}retarget(e){this.anchor=e}tailless=!1;detachTail(){this.tailless=!0}setPending(e){this.node.toggleAttribute("data-pending",e)}layout(e,t){let n=this.anchor.getBoundingClientRect(),r=Math.abs(n.top-this.first.top)<1&&Math.abs(n.left-this.first.left)<1,i=rt(this.range)??(r?this.first.plan:null);if(!i)return null;let{path:s,left:a,top:l}=So(i.tail,e,t,!this.tailless),c=this.anchorBox,d=To([s],!1);return d.style.left=`${-c.left}px`,d.style.top=`${-c.top}px`,this.node.replaceChildren(d),this.pin.place(c.left,c.top),{left:a,top:l}}follow(){let e=this.anchorBox;(e.width||e.height)&&this.pin.place(e.left,e.top)}clip(e,t){let n=this.area?.getBoundingClientRect();ke(this.node,Math.max(e,n?.top??-1/0),Math.min(t,n?.bottom??1/0))}remove(){this.node.remove()}};function Aa(o){return o==="zh-Hans"?"zh-CN":o==="zh-Hant"?"zh-TW":o==="yue"?"zh-HK":o}function Ra(o,e){let t=e.toLowerCase(),n=t.split("-")[0],r=a=>{let l=a.lang.toLowerCase().replace("_","-");return l!==t&&l.split("-")[0]!==n?-1:(l===t?2:0)+(a.localService?1:0)},i,s=-1;for(let a of o){let l=r(a);l>s&&(i=a,s=l)}return i}function Na(o,e,t){let n=Intl.Segmenter;if(!n)return Math.min(o.length,e+1);for(let r of new n(t,{granularity:"word"}).segment(o.slice(e)))if(r.segment.trim())return e+r.index+r.segment.length;return o.length}var it=class{constructor(e,t=n=>new SpeechSynthesisUtterance(n)){this.synth=e;this.create=t}current;callbacks;get reading(){return this.current!==void 0}start(e,t,n){this.stop();let r=Aa(t),i=this.synth.getVoices(),s=Ra(i,r);if(i.length&&!s){n.onEnd("noVoice");return}let a=this.create(e);a.lang=r,s&&(a.voice=s),a.onboundary=l=>{a!==this.current||l.name==="sentence"||n.onWord(l.charIndex,l.charLength?l.charIndex+l.charLength:Na(e,l.charIndex,r))},a.onend=()=>this.finish(a),a.onerror=l=>this.finish(a,l.error==="canceled"||l.error==="interrupted"?void 0:"failed"),this.current=a,this.callbacks=n,this.synth.speak(a)}stop(){let e=this.callbacks,t=this.current!==void 0;this.current=void 0,this.callbacks=void 0,t&&(this.synth.cancel(),e?.onEnd())}finish(e,t){if(e!==this.current)return;let n=this.callbacks;this.current=void 0,this.callbacks=void 0,n?.onEnd(t)}};var Pa=5e3,Ia='yl-t,yl-r,pre,code,kbd,samp,textarea,input,select,[contenteditable]:not([contenteditable="false"]),.CodeMirror,.cm-editor,.monaco-editor,.ace_editor,.blob-code,.hljs,[role="textbox"],[role="code"]',Ha="yl-t,yl-ui,script,style,noscript,template",Da=3e3,_a=4,st="	";function Oa(o){let e=o;for(;e.parentElement&&getComputedStyle(e).display.startsWith("inline");)e=e.parentElement;return e}function Ba(o,e){return Math.min(o.bottom,e.bottom)-Math.max(o.top,e.top)>=Math.min(o.height,e.height)/2}function Mo(o){let e=o.commonAncestorContainer,t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),n=[""],r,i=0;for(let s=e.nodeType===Node.TEXT_NODE?e:t.nextNode();s;s=t.nextNode()){if(++i>Da)return"";if(!o.intersectsNode(s))continue;let a=s.parentElement;if(!a||a.closest(Ha))continue;let l=getComputedStyle(a);if(l.visibility!=="visible"||l.userSelect==="none")continue;let c=s.data,d=s===o.startContainer?o.startOffset:0,u=s===o.endContainer?o.endOffset:c.length,h=document.createRange();h.setStart(s,d),h.setEnd(s,u);let p=h.getClientRects(),g=p[0],m=p[p.length-1];if(!g||!m||!g.width)continue;let b=l.whiteSpace.startsWith("pre")||l.whiteSpace==="break-spaces"?c.slice(d,u).replace(/\t/g,"  "):c.slice(d,u).replace(/\s+/g," ");if(!b.trim()&&!r)continue;let v=Oa(a);if(r){let S=Ba(r.rect,g);r.flow!==v&&!S?n.push(""):r.flow!==v?n[n.length-1]+=st:S&&g.left-r.rect.right>=_a&&(n[n.length-1]+=" ")}let T=b.split(`
`);n[n.length-1]+=T[0]??"",n.push(...T.slice(1)),b.trim()&&(r={flow:v,rect:m})}return n.map(s=>s.replace(/ {2,}/g," ").replace(/ *\t[ \t]*/g,st).replace(/^\t+|\t+$/g,"").trim()).filter(Boolean).join(`
`)}function $a(o,e){let t=[...o.matchAll(/[\t\n]/g)].map(r=>r[0]),n=e.split(`
`);return!t.includes(st)||n.length!==t.length+1?e:n.reduce((r,i,s)=>r+(t[s-1]===st?" ":`
`)+i)}function Co(o,e){try{return new Intl.DisplayNames([e],{type:"language"}).of(o)??o}catch{return o}}var Ao=60,Fa=6,Wa=40,Po=.6;function Ro(o){if(!o)return;let e=o.startContainer,t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement,n=K(t).map(i=>i.el).find(i=>i.clientHeight>=innerHeight*Po);if(!n)return;let r=n.getBoundingClientRect();return{top:r.top,bottom:r.bottom}}async function qa(o){let e=NaN,t=0,n=performance.now();for(;t<5&&performance.now()-n<1200;){await new Promise(i=>requestAnimationFrame(i));let r=o.getBoundingClientRect().top;t=r===e?t+1:0,e=r}}function No(o,e){return new DOMRect(o,e,0,0)}var at=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("mouseup",this.onMouseUp),document.addEventListener("mousedown",this.onMouseDown,!0),document.addEventListener("keydown",this.onKeyDown,!0),addEventListener("scroll",this.onScroll,{passive:!0,capture:!0}),addEventListener("resize",this.onResize)}bubble;card;followFrame=0;reader=new it(speechSynthesis);update(e,t){this.settings=e,this.enabled=t,t||this.closeAll()}translateText(e){let t=getSelection(),n=t&&t.rangeCount?t.getRangeAt(0).cloneRange():void 0,r=n?.getBoundingClientRect();n&&r&&r.width?this.openCard(e,r,{range:n,plan:rt(n),x:r.right,y:r.bottom}):this.openCard(e,new DOMRect(innerWidth/2-240,80,0,0))}isOwnEvent(e){return this.ui.ownsEvent(e)}onMouseDown=e=>{this.isOwnEvent(e)||this.closeAll()};onKeyDown=e=>{e.key==="Escape"&&this.closeAll()};onScroll=e=>{this.isOwnEvent(e)||(this.bubble?.remove(),this.bubble=void 0,this.followFrame||(this.followFrame=requestAnimationFrame(this.followSource)))};onResize=()=>{this.card&&this.placeCard(this.card)};followSource=()=>{this.followFrame=0;let e=this.card;if(!e?.ring)return;e.ring.follow();let t=e.ring.anchorBox;(t.width||t.height)&&e.pin?.place(t.left+e.dx,t.top+e.dy),this.clearOfBars(e)};placeCard(e){if(!e.ring||!e.pin)return;let t=e.ring.anchorBox,n=()=>e.pin?.place(t.left+e.dx,t.top+e.dy);if(t.bottom<0||t.top>innerHeight){n();return}let r=e.ring.layout(e.node.offsetWidth,e.node.offsetHeight);if(!r||e.moved){n();return}e.dx=r.left-t.left,e.dy=r.top-t.top,e.pin.place(r.left,r.top),this.clearOfBars(e)}clearOfBars(e){if(!e.ring)return;let t=this.ui.settleUnderBars(),n=e.area&&e.area.clientHeight>=innerHeight*Po?e.area.getBoundingClientRect():void 0,r=Math.max(t.top,n?.top??-1/0),i=Math.min(t.bottom,n?.bottom??1/0);ke(e.node,r,i),e.ring.clip(t.top,t.bottom)}closeCard(e){e.alive=!1,this.card===e&&(this.card=void 0),this.reader.stop(),e.ring?.remove(),this.ui.dismiss(e.node)}onMouseUp=e=>{D()&&(!this.enabled||this.settings.selectionTrigger==="off"||this.isOwnEvent(e)||setTimeout(()=>this.evaluate(e),0))};evaluate(e){let t=getSelection();if(!t||t.isCollapsed||!t.rangeCount)return;let n=t.getRangeAt(0),r=Mo(n)||t.toString().trim();if(!r||r.length>Pa||!new RegExp("\\p{L}","u").test(r)||Ua(n))return;let i=n.getBoundingClientRect();if(!i.width&&!i.height)return;let s=n.cloneRange(),a=rt(s);if(this.settings.selectionTrigger==="auto"){this.openCard(r,No(e.clientX,e.clientY),{range:s,plan:a,x:e.clientX,y:e.clientY});return}this.showBubble(r,e.clientX,e.clientY,s,a)}showBubble(e,t,n,r,i){this.bubble?.remove();let s=x("div","bubble"),a=x("div","bubble-tab"),l=x("button","bubble-action");l.type="button",l.title=w("selectionBubble"),l.setAttribute("aria-label",w("selectionBubble")),l.append(ne("translate"),x("span","",w("selectionAction"))),l.addEventListener("click",()=>{s.remove(),this.bubble=void 0,this.openCard(e,No(t,n),{range:r,plan:i,x:t,y:n})}),a.append(l),s.append(a),this.bubble=this.ui.add(s),i?ko(s,a,i):(a.style.left=`${Math.max(8,Math.min(t+6,innerWidth-a.offsetWidth-8))}px`,a.style.top=`${Math.max(8,Math.min(n+10,innerHeight-a.offsetHeight-8))}px`)}glossaryEditor(e,t,n,r){let i=x("div","card-glossary"),s=x("input","card-glossary-input");s.value=e,s.setAttribute("aria-label",w("glossaryTerm"));let a=x("input","card-glossary-input");a.value=t.length<=Ao?t:"",a.placeholder=w("glossaryKeep"),a.setAttribute("aria-label",w("glossaryTranslation"));let l=x("button","card-glossary-save",w("glossarySave"));l.type="button";let c=async()=>{let d=s.value.trim();if(!d)return;let u=(await chrome.storage.sync.get("glossary")).glossary,h=a.value.trim(),p=h?{from:d,to:h,lang:n}:{from:d,to:""},g=(u??[]).filter(f=>!(f.from.toLowerCase()===d.toLowerCase()&&(f.lang??"")===(p.lang??"")));await chrome.storage.sync.set({glossary:[...g,p].slice(-200)}),i.remove();let m=r.textContent;r.textContent=w("glossaryAdded"),setTimeout(()=>r.textContent=m,1800)};l.addEventListener("click",()=>void c());for(let d of[s,a])d.addEventListener("keydown",u=>{u.key==="Enter"&&c()});return i.append(s,x("span","card-glossary-arrow","→"),a,l),setTimeout(()=>a.focus(),0),i}startDrag(e,t,n){if(n.button!==0)return;n.preventDefault(),t.setPointerCapture(n.pointerId);let r={x:n.clientX,y:n.clientY},i=e.node.getBoundingClientRect(),s={dx:e.dx,dy:e.dy};e.node.toggleAttribute("data-dragging",!0),e.moved||(e.moved=!0,e.ring?.detachTail(),e.ring?.layout(e.node.offsetWidth,e.node.offsetHeight));let a=c=>{let d=Math.max(8,Math.min(i.left+c.clientX-r.x,innerWidth-i.width-8)),u=Math.max(8,Math.min(i.top+c.clientY-r.y,innerHeight-40));if(e.ring&&e.pin){e.dx=s.dx+d-i.left,e.dy=s.dy+u-i.top;let h=e.ring.anchorBox;e.pin.place(h.left+e.dx,h.top+e.dy)}else e.node.style.left=`${d}px`,e.node.style.top=`${u}px`},l=()=>{t.removeEventListener("pointermove",a),t.removeEventListener("pointerup",l),t.removeEventListener("pointercancel",l),e.node.removeAttribute("data-dragging"),this.clearOfBars(e)};t.addEventListener("pointermove",a),t.addEventListener("pointerup",l),t.addEventListener("pointercancel",l)}async jumpTo(e,t){let n=t.el.getBoundingClientRect();if(!(n.top>=0&&n.bottom<=innerHeight)){if(t.el.scrollIntoView({block:"center",behavior:"instant"}),await qa(t.el),!e.alive)return;e.ring&&(e.ring.retarget(t.el),this.placeCard(e))}Eo(this.ui,t.range)}openCard(e,t,n){this.closeAll();let r=this.settings.targetLang,i=x("div","card");i.setAttribute("role","dialog"),i.setAttribute("aria-label",w("selectionBubble"));let s=x("div","card-body"),l=(n?xo(n.range):[]).map(C=>({segment:C,text:Mo(C.range)||C.range.toString().trim()})).filter(C=>new RegExp("\\p{L}","u").test(C.text)),d=(l.length>1&&l.length<=Wa?l:[{segment:void 0,text:e}]).map(C=>{let y=x("div","card-seg"),k=x("div","card-source",C.text);k.title=C.text;let M=x("div","card-result",w("translating"));M.dataset.state="loading",y.append(k,M);let{segment:E}=C;if(E){y.title=w("jumpToSource"),y.dataset.jump="";let A=[0,0];y.addEventListener("mousedown",R=>A=[R.clientX,R.clientY]),y.addEventListener("click",R=>{Math.hypot(R.clientX-A[0],R.clientY-A[1])<4&&this.jumpTo(L,E)})}return s.append(y),{text:C.text,result:M,translated:"",start:0}}),u=chrome.i18n.getUILanguage(),h=Co(r,u),p=x("span","grow",h),g,m="",f=O("copy",w("copy"),()=>{navigator.clipboard.writeText(m).then(()=>{let C=p.textContent;p.textContent=w("copied"),clearTimeout(g),g=setTimeout(()=>p.textContent=C,1200)})}),b=(C,y)=>{let k=d.find(P=>P.translated&&C>=P.start&&C<P.start+P.translated.length);if(!k)return;for(let P of d)P!==k&&P.translated&&(P.result.textContent=P.translated);let M=C-k.start,E=Math.min(y-k.start,k.translated.length),A=x("mark","card-word",k.translated.slice(M,E));k.result.replaceChildren(k.translated.slice(0,M),A,k.translated.slice(E));let R=A.offsetTop-s.offsetTop;(R<s.scrollTop||R+A.offsetHeight>s.scrollTop+s.clientHeight)&&(s.scrollTop=R-24)},v=C=>{if(T.toggleAttribute("data-on",C),T.title=C?w("stopSpeaking"):w("speak"),T.setAttribute("aria-label",T.title),T.replaceChildren(ne(C?"stop":"speak")),!C)for(let y of d)y.translated&&(y.result.textContent=y.translated)},T=O("speak",w("speak"),()=>{if(this.reader.reading){this.reader.stop();return}m&&(v(!0),this.reader.start(m,r,{onWord:b,onEnd:C=>{if(v(!1),!C)return;let y=p.textContent;p.textContent=w(C==="noVoice"?"noVoice":"speakFailed"),setTimeout(()=>p.textContent=y,2400)}}))}),S=O("close",w("close"),()=>this.closeCard(L)),N=x("div","card-foot"),H=d.length===1&&e.length<=Ao&&e.split(/\s+/).length<=Fa,$=O("glossary",w("addToGlossary"),()=>{i.querySelector(".card-glossary")||(i.insertBefore(this.glossaryEditor(e.trim(),d[0]?.translated??"",r,p),N),this.placeCard(L))});H?N.append(p,$,f,T,S):N.append(p,f,T,S);let B=x("div","card-grip");B.title=w("moveCard"),B.setAttribute("aria-label",w("moveCard")),B.addEventListener("pointerdown",C=>this.startDrag(L,B,C)),i.append(B,s,N);let L={node:i,dx:0,dy:0,alive:!0};if(this.card=L,n?.plan){let C=K(n.plan.tail.el).map(y=>y.el);L.area=C[0],L.ring=new ot(this.ui,n.range,n.plan),L.ring.setPending(!0),i.dataset.onPage="",this.ui.addToPage(i),L.pin=new z(i,C),this.placeCard(L)}else this.ui.add(i),this.ui.place(i,t,8,Ro(n?.range));(async()=>{try{let C=await I({type:"translate",items:d.map(M=>U(M.text.replace(/\t/g,`
`))),from:this.settings.sourceLang,to:r});if(!L.alive)return;d.forEach((M,E)=>{let A=C?.results?.[E];A?.ok?(delete M.result.dataset.state,M.translated=$a(M.text,ee(A.text)),M.result.textContent=M.translated,A.detected&&(p.textContent=`${Co(A.detected,u)} → ${h}`)):(M.result.dataset.state="error",M.result.textContent=this.ui.errorMessage(A?.code??"network"))});let y=0,k=d.filter(M=>M.translated);for(let M of k)M.start=y,y+=M.translated.length+2;m=k.map(M=>M.translated).join(`

`)}catch{if(!L.alive||!D())return;for(let C of d)C.result.dataset.state="error",C.result.textContent=this.ui.errorMessage("network")}L.alive&&(L.ring?.setPending(!1),s.style.overscrollBehavior=s.scrollHeight>s.clientHeight?"contain":"",L.ring?this.placeCard(L):L.moved||this.ui.place(i,t,8,Ro(n?.range)))})()}closeAll(){this.ui.dismiss(this.bubble),this.bubble=void 0,this.card&&this.closeCard(this.card)}};function Ua(o){let e=o.commonAncestorContainer;if(Lo(e))return!0;if(e.nodeType===Node.TEXT_NODE)return!1;let t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let n=t.nextNode();n;n=t.nextNode()){if(!o.intersectsNode(n))continue;let r=n,i=n===o.startContainer?o.startOffset:0,s=n===o.endContainer?o.endOffset:r.length;if(r.data.slice(i,s).trim()&&!Lo(n))return!1}return!0}function Lo(o){return!!(o.nodeType===Node.ELEMENT_NODE?o:o.parentElement)?.closest(Ia)}var Io="__yilan_region_ask__",_o=1500,ja=2e3,Oo="__yilan_handover__",Ho=globalThis;async function za(){let o=document.documentElement.lang?.trim();if(o)return o;let e=document.body?.innerText?.slice(0,_o)??"";if(e.trim())try{let n=(await chrome.i18n.detectLanguage(e)).languages?.[0];return n&&n.percentage>=50?n.language:void 0}catch{return}}async function Do(o){let e=document.body?.innerText?.slice(0,_o)??"",t;if(e.trim())try{let r=(await chrome.i18n.detectLanguage(e)).languages?.[0];r&&r.percentage>=50&&(t=r.language)}catch{}return t??=document.documentElement.lang?.trim()||void 0,t!==void 0&&!mn(t,o)}function Ga(o,e){let t=o.toLowerCase().split("-")[0];return e.some(n=>n.toLowerCase()===o.toLowerCase()||n.toLowerCase().split("-")[0]===t)}async function Ka(){let o=await ft(),e=location.hostname,t=y=>!gt(e,y.neverSites),n=new Me,r=()=>{let y=Vt(o.appearance);n.setTheme(Te(te(o.themeColor),y?Kt:Se),y)};r(),matchMedia("(prefers-color-scheme: dark)").addEventListener("change",r);let i=new Be(o,n),s=new at(o,n,t(o)),a=new Ce(o,n,t(o)),l=new qe(n,()=>o),c=new Je(n,()=>o,()=>i.hasTranslations),d=new Set,u=(y,k)=>{let M=0;for(let E of Array.from(document.querySelectorAll("iframe"))){let A=E.getBoundingClientRect(),R={left:y.left-A.left-E.clientLeft,top:y.top-A.top-E.clientTop,right:y.right-A.left-E.clientLeft,bottom:y.bottom-A.top-E.clientTop};R.right<=0||R.bottom<=0||R.left>=A.width||R.top>=A.height||(E.contentWindow?.postMessage({[Io]:!0,rect:R,token:k},"*"),M++)}return M},h=async y=>(l.showPending(y,window===top),l.show(await i.collectRegion(y)));addEventListener("message",y=>{let k=y.data;if(!k||typeof k!="object"||typeof k.token!="string"||!(Io in k)||y.source!==parent||!d.has(k.token)||!k.rect)return;let{left:M,top:E,right:A,bottom:R}=k.rect;[M,E,A,R].every(Number.isFinite)&&(u({left:M,top:E,right:A,bottom:R},k.token),h({left:M,top:E,right:A,bottom:R}))});let p=()=>{l.close(),c.stop()},g=()=>{p(),I({type:"region:closeAll"}).catch(()=>{})},m=!1,f=y=>{y.key!=="Escape"||!m||(y.preventDefault(),y.stopPropagation(),m=!1,removeEventListener("keydown",f,!0),g())},b=new Ne(n),v=y=>{if(window!==top){I({type:"marquee:request",mode:y}).catch(()=>{});return}g(),focus(),b.begin(k=>{if(y==="scan"){c.start(k);return}m=!0,addEventListener("keydown",f,!0);let M=crypto.randomUUID();(async()=>{await I({type:"region:arm",token:M}).catch(()=>{}),await new Promise(R=>setTimeout(R,50));let E=u(k,M);!await h(k)&&!E&&n.toast(l.emptyMessage)})()})},T=!1,S=!1,N=()=>{T||(T=!0,clearInterval(H),m=!1,removeEventListener("keydown",f,!0),b.cancel(),p(),i.retire(),s.update(o,!1),a.update(o,!1))},H=setInterval(()=>{D()||N()},ja);addEventListener(Oo,()=>{D()||(S=!0,N())});let $=w("refreshAfterUpdate");return dn(()=>o.shortcuts,y=>{if(!D()){N(),S||n.toast($);return}y==="marquee"?v("cover"):y==="sweep"?v("scan"):I({type:"shortcut:page",action:y}).catch(()=>{})}),Yt(y=>{!o.autoTranslate&&y.autoTranslate&&t(y)&&Do(y.targetLang).then(k=>k?i.startPage():void 0),o=y,r(),i.applySettings(y),s.update(y,t(y)),a.update(y,t(y))}),{handle:(y,k)=>{switch(y.type){case"page:translate":i.startPage();break;case"page:restore":i.restore();break;case"page:toggle":i.togglePage();break;case"page:retry":i.retryFailed();break;case"page:status":k(i.status());return;case"mode:toggle":{let M=o.mode==="dual"?"replace":"dual";o={...o,mode:M},i.setMode(M),window===top&&chrome.storage.sync.set({mode:M});break}case"marquee:start":v(y.mode??"cover");break;case"region:arm":d.add(y.token),setTimeout(()=>d.delete(y.token),5e3);break;case"region:close":p();break;case"selection:translate":s.translateText(y.text);break}k(!0)},afterReady:async()=>{let y=await za();i.setPageLang(y),(t(o)&&(gt(e,o.alwaysSites)||y!==void 0&&Ga(y,o.alwaysLangs)||o.autoTranslate&&await Do(o.targetLang))||await I({type:"tab:hello"}).catch(()=>!1))&&await i.startPage()}}}function Xa(){if(document.contentType!=="text/html"&&document.contentType!=="application/xhtml+xml"||yn()||Ho.__yilanAlive?.())return;Ho.__yilanAlive=D,dispatchEvent(new Event(Oo));let o=Ka();chrome.runtime.onMessage.addListener((e,t,n)=>(o.then(({handle:r})=>r(e,n)),!0)),o.then(({afterReady:e})=>e())}Xa();})();
