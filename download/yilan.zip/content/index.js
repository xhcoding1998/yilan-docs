"use strict";(()=>{function X(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}var Xo={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" "};function re(o){return o.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi,(e,t)=>{if(t[0]==="#"){let n=t[1]==="x"||t[1]==="X"?parseInt(t.slice(2),16):parseInt(t.slice(1),10);return!Number.isFinite(n)||n<0||n>1114111?e:String.fromCodePoint(n)}return Xo[t.toLowerCase()]??e})}var vt=/<\s*(\/?)\s*x\s*(\d{1,4})\s*>/gi;function V(o,e){let t=[],n=[],r=new Set,i=l=>{let c=n.length?n[n.length-1].children:t,d=c[c.length-1];typeof l=="string"&&typeof d=="string"?c[c.length-1]=d+l:c.push(l)},s=[],a=0;vt.lastIndex=0;for(let l=vt.exec(o);l;l=vt.exec(o)){if(l.index>a){let u=re(o.slice(a,l.index));u&&i(u)}a=l.index+l[0].length;let c=l[1]==="/",d=Number(l[2]);if(c){let u=s.lastIndexOf(d);if(u!==-1){s.splice(u,1);continue}let h=n.map(p=>p.slot).lastIndexOf(d);h!==-1&&(n.length=h)}else{if(r.has(d)||e&&!e.has(d)){s.push(d);continue}r.add(d);let u={slot:d,children:[]};i(u),n.push(u)}}if(a<o.length){let l=re(o.slice(a));l&&i(l)}return t}function Ee(o,e){let t=[];for(let n of o){if(typeof n=="string"){t.push(n);continue}let r=t[t.length-1];typeof r=="string"&&e(n.slot)&&(t[t.length-1]=r.replace(/\s*\n\s*$/," ")),t.push({slot:n.slot,children:Ee(n.children,e)})}return t}function ie(o){return o.map(e=>typeof e=="string"?e:ie(e.children)).join("")}function ce(o,e=new Set){for(let t of o)typeof t!="string"&&(e.add(t.slot),ce(t.children,e));return e}function j(){try{return!!chrome.runtime?.id}catch{return!1}}async function B(o){return await chrome.runtime.sendMessage(o)}var Yt=[{code:"zh_CN",name:"简体中文",bcp47:"zh-CN"},{code:"zh_TW",name:"繁體中文",bcp47:"zh-TW"},{code:"en",name:"English",bcp47:"en"},{code:"ja",name:"日本語",bcp47:"ja"},{code:"ko",name:"한국어",bcp47:"ko"},{code:"es",name:"Español",bcp47:"es"},{code:"fr",name:"Français",bcp47:"fr"},{code:"de",name:"Deutsch",bcp47:"de"}];var de=null;function Jt(o){return Yt.some(e=>e.code===o)}var Zt=async o=>{let e=await fetch(chrome.runtime.getURL(`_locales/${o}/messages.json`));return e.ok?await e.json():null};function Qt(o){Zt=o}async function Vo(o){if(!Jt(o))return null;try{return await Zt(o)}catch{return null}}async function wt(o){if(!Jt(o)){de=null;return}if(de?.code===o)return;let e=await Vo(o);de=e?{code:o,messages:e}:null}function en(){if(de)return Yt.find(o=>o.code===de.code)?.bcp47??"en";try{return chrome.i18n.getUILanguage()}catch{return"en"}}function Yo(o,e){let t=n=>n.replace(/\$(\d)/g,(r,i)=>e[Number(i)-1]??"");return o.message.replace(/\$([A-Za-z0-9_@]+)\$/g,(n,r)=>{let i=o.placeholders?.[r.toLowerCase()];return i?t(i.content):n}).replace(/\$\$/g,"$")}function y(o,...e){let t=de?.messages[o];if(t)return Yo(t,e);try{return chrome.i18n.getMessage(o,e)||o}catch{return o}}var He=["togglePage","toggleMode","marquee","sweep"],Pe={togglePage:["Shift","Space","KeyT"],toggleMode:["Shift","Space","KeyD"],marquee:["Shift","Space","KeyS"],sweep:["Shift","Space","KeyX"]},Jo={togglePage:["Alt","Shift","KeyY"],toggleMode:["Alt","Shift","KeyD"]};function tn(o){let e={...Pe,...o};for(let t of He){let n=Jo[t];n&&Et(e[t],n)&&(e[t]=Pe[t])}return e}var xt=["Ctrl","Alt","Shift","Meta"];function nn(o){return/^(Control|Alt|Shift|Meta|OS)(Left|Right)?$/.test(o)}function on(o){let e={Ctrl:o.ctrlKey,Alt:o.altKey,Shift:o.shiftKey,Meta:o.metaKey};return xt.filter(t=>e[t])}function rn(o){let e=t=>xt.includes(t);return{mods:xt.filter(t=>o.includes(t)),keys:o.filter(t=>!e(t))}}function Et(o,e){return o.length>0&&o.length===e.length&&o.every(t=>e.includes(t))}var De="#ffffff",an="#1f2329",ln="#14171c";function cn(o){return o==="dark"?!0:o==="light"?!1:matchMedia("(prefers-color-scheme: dark)").matches}function St(o){let e=parseInt(o.slice(1),16),t=n=>{let r=n/255;return r<=.03928?r/12.92:((r+.055)/1.055)**2.4};return .2126*t(e>>16&255)+.7152*t(e>>8&255)+.0722*t(e&255)}function Ie(o,e){let[t,n]=[St(o),St(e)].sort((r,i)=>i-r);return(t+.05)/(n+.05)}function _e(o,e,t=4){if(Ie(o,e)>=t)return o;let n=parseInt(o.slice(1),16),[r,i,s]=[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255],a=Math.max(r,i,s),l=Math.min(r,i,s),c=a-l,d=0;c&&(a===r?d=((i-s)/c+6)%6:a===i?d=(s-r)/c+2:d=(r-i)/c+4),d*=60;let u=(a+l)/2,h=c?c/(1-Math.abs(2*u-1)):0,p=m=>{let g=h*Math.min(m,1-m),b=x=>{let E=(x+d/30)%12;return Math.round(255*(m-g*Math.max(-1,Math.min(E-3,9-E,1)))).toString(16).padStart(2,"0")};return`#${b(0)}${b(8)}${b(4)}`},f=St(e)<.2?.01:-.01;for(let m=u;m>=0&&m<=1;m+=f){let g=p(m);if(Ie(g,e)>=t)return g}return f>0?"#ffffff":"#000000"}var sn=[{id:"blue",color:"#1f77f3",name:"themeBlue"},{id:"red",color:"#ea303f",name:"themeRed"},{id:"orange",color:"#d45105",name:"themeOrange"},{id:"amber",color:"#a27304",name:"themeAmber"},{id:"green",color:"#108d4f",name:"themeGreen"},{id:"teal",color:"#0f8a86",name:"themeTeal"},{id:"violet",color:"#8561f2",name:"themeViolet"},{id:"pink",color:"#e72486",name:"themePink"}];function ue(o){return/^#[0-9a-f]{6}$/i.test(o)?o:(sn.find(e=>e.id===o)??sn[0]).color}var Zo={uiLang:"auto",targetLang:"zh-Hans",sourceLang:"",mode:"dual",dualStyle:"highlight",themeColor:"blue",appearance:"auto",shortcuts:Pe,fontScale:100,selectionTrigger:"icon",showOriginalOnHover:!0,unlockCopy:!1,inputTranslate:!1,inputLang:"en",glossary:[],autoTranslate:!1,alwaysSites:[],neverSites:[],alwaysLangs:[],excludeSelectors:"",cacheDays:7};function Qo(o){let e=o.toLowerCase();return e==="zh-tw"||e==="zh-hk"||e==="zh-mo"||e.startsWith("zh-hant")?"zh-Hant":e.startsWith("zh")?"zh-Hans":e.split("-")[0]??"en"}async function Tt(){let o=await chrome.storage.sync.get(null),e={...Zo,...o,shortcuts:tn(o.shortcuts)};return o.cacheDays===void 0&&o.persistentCache===!1&&(e.cacheDays=0),o.targetLang||(e.targetLang=er()),e}function er(){let o=Qo(chrome.i18n.getUILanguage());return tr.has(o)?o:"en"}function dn(o){chrome.storage.onChanged.addListener((e,t)=>{t==="sync"&&Tt().then(o)})}function kt(o,e){return e.some(t=>o===t||o.endsWith(`.${t}`))}var se=[{code:"zh-Hans",name:"简体中文"},{code:"zh-Hant",name:"繁體中文"},{code:"yue",name:"粵語"},{code:"en",name:"English"},{code:"ja",name:"日本語"},{code:"ko",name:"한국어"},{code:"fr",name:"Français"},{code:"de",name:"Deutsch"},{code:"es",name:"Español"},{code:"pt",name:"Português"},{code:"it",name:"Italiano"},{code:"ru",name:"Русский"},{code:"uk",name:"Українська"},{code:"pl",name:"Polski"},{code:"nl",name:"Nederlands"},{code:"tr",name:"Türkçe"},{code:"ar",name:"العربية"},{code:"hi",name:"हिन्दी"},{code:"vi",name:"Tiếng Việt"},{code:"th",name:"ไทย"},{code:"id",name:"Bahasa Indonesia"}],un={"zh-Hans":"chinese simplified 简体 中文 汉语 jianti zhongwen","zh-Hant":"chinese traditional 繁体 繁體 中文 fanti zhongwen",yue:"cantonese 粤语 广东话 yueyu guangdonghua",en:"english 英语 英文 yingyu yingwen",ja:"japanese 日语 日文 riyu riwen",ko:"korean 韩语 韩文 朝鲜语 hanyu hanwen",fr:"french 法语 法文 fayu",de:"german 德语 德文 deyu",es:"spanish 西班牙语 xibanya",pt:"portuguese 葡萄牙语 putaoya",it:"italian 意大利语 yidali",ru:"russian 俄语 俄文 eyu",uk:"ukrainian 乌克兰语 wukelan",pl:"polish 波兰语 bolan",nl:"dutch 荷兰语 helan",tr:"turkish 土耳其语 tuerqi",ar:"arabic 阿拉伯语 alabo",hi:"hindi 印地语 yindi",vi:"vietnamese 越南语 yuenan",th:"thai 泰语 taiyu",id:"indonesian 印尼语 印度尼西亚语 yinni"},tr=new Set(se.map(o=>o.code));var nr=[.1,.35,.65,.9];function or(o){for(let e=o;e&&e!==document.body&&e!==document.documentElement;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return e;return null}function rr(o){let e=null;for(let t=o;t&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t),r=parseInt(n.zIndex,10);n.position!=="static"&&!Number.isNaN(r)&&(e=r)}return e}function pn(o){let e=new Set;for(let t of nr)for(let n of document.elementsFromPoint(innerWidth*t,o)){if(n.localName==="yl-ui")continue;let r=or(n);r&&r.getBoundingClientRect().height<innerHeight*.45&&e.add(r);break}return Array.from(e)}function Se(){let o=new Set,e=0;for(let r=0;r<2;r++)for(let i of pn(e+2))o.add(i),e=Math.max(e,i.getBoundingClientRect().bottom);let t=innerHeight;for(let r of pn(t-2))o.add(r),t=Math.min(t,r.getBoundingClientRect().top);let n=null;for(let r of o){let i=rr(r);if(i===null)return{top:e,bottom:t,stacking:null};n=n===null?i:Math.min(n,i)}return{top:e,bottom:t,stacking:n}}function Oe(o,e,t){if(e<=0&&t>=innerHeight){o.style.clipPath="";return}let n=o.getBoundingClientRect(),r=i=>Number.isFinite(i)?i:-9999;o.style.clipPath=`inset(${r(e-n.top)}px -9999px ${r(n.bottom-t)}px -9999px)`}var Be=`/* Thin gradient edges in the full palette on clean, light surfaces. */\r
:host {\r
  --ink: #000000;\r
  --paper: #ffffff;\r
  --muted: #666b73;\r
  --line: rgba(20, 30, 50, 0.1);\r
  --hover: color-mix(in srgb, var(--yl-theme) 8%, var(--paper));\r
  --shadow: 0 8px 28px rgba(20, 40, 80, 0.13), 0 1px 3px rgba(20, 40, 80, 0.08);\r
  --ease: cubic-bezier(0.2, 0.8, 0.2, 1);\r
  --spring: cubic-bezier(0.34, 1.56, 0.64, 1);\r
  --edge: linear-gradient(115deg, #4da2ff, #55db9c 35%, #ffd731 62%, #fb4903 85%, #5c4ade);\r
  --yl-theme: #1f77f3;\r
  --yl-on-theme: #ffffff;\r
  --sky: color-mix(in srgb, var(--yl-theme) 13%, var(--paper));\r
  --glass: rgba(255, 255, 255, 0.7);\r
  --error: #c43a02;\r
}\r
\r
:host([data-appearance='dark']) {\r
  --ink: #eef0f3;\r
  --paper: #1f2329;\r
  --muted: #9aa3ae;\r
  --line: rgba(255, 255, 255, 0.1);\r
  --hover: color-mix(in srgb, var(--yl-theme) 12%, var(--paper));\r
  --shadow: 0 8px 28px rgba(0, 0, 0, 0.28), 0 1px 3px rgba(0, 0, 0, 0.2);\r
  --sky: color-mix(in srgb, var(--yl-theme) 14%, var(--paper));\r
  --glass: rgba(255, 255, 255, 0.1);\r
  --error: #ff8a5c;\r
}\r
\r
* {\r
  box-sizing: border-box;\r
}\r
\r
.layer {\r
  position: fixed;\r
  font: 400 13px/1.45 Inter, 'Segoe UI', system-ui, -apple-system, 'Microsoft YaHei', sans-serif;\r
  color: var(--ink);\r
  pointer-events: auto;\r
}\r
\r
/* ---- selection ------------------------------------------------------------ */\r
\r
/* Holds nothing itself: its parts are placed on the screen. */\r
.bubble {\r
  top: 0;\r
  left: 0;\r
  width: 0;\r
  height: 0;\r
  pointer-events: none;\r
}\r
\r
.bubble-ring {\r
  position: absolute;\r
  top: 0;\r
  left: 0;\r
  width: 1px;\r
  height: 1px;\r
  overflow: visible;\r
  pointer-events: none;\r
}\r
\r
.bubble-ring path {\r
  fill: none;\r
  stroke-width: 2;\r
  stroke-linejoin: round;\r
  filter: drop-shadow(0 1px 3px rgba(20, 40, 80, 0.18));\r
}\r
\r
/* Drawn once, as the selection is made. It stays as it is when the card takes the button's place. */\r
.bubble .bubble-ring path {\r
  stroke-dasharray: 1;\r
  animation: ring-draw 0.34s var(--ease);\r
}\r
\r
/* The bar holding the actions, which the bubble's tail points at. */\r
.bubble-tab {\r
  position: absolute;\r
  display: inline-flex;\r
  gap: 2px;\r
  padding: 3px;\r
  border-radius: 11px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  pointer-events: auto;\r
  animation: fade-in 0.18s var(--ease) 0.14s both;\r
}\r
\r
@keyframes ring-draw {\r
  from {\r
    stroke-dashoffset: 1;\r
  }\r
}\r
\r
.bubble-action {\r
  height: 28px;\r
  padding: 0 11px 0 8px;\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 5px;\r
  border: 0;\r
  border-radius: 8px;\r
  background: var(--yl-theme);\r
  color: var(--yl-on-theme);\r
  font-size: 13px;\r
  font-weight: 500;\r
  white-space: nowrap;\r
  cursor: pointer;\r
  transition: filter 0.15s, transform 0.15s var(--spring);\r
}\r
\r
.bubble-action svg {\r
  width: 16px;\r
  height: 16px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.bubble-action:hover {\r
  filter: brightness(1.1);\r
}\r
\r
.bubble-action:active {\r
  transform: scale(0.96);\r
}\r
\r
.card {\r
  width: 480px;\r
  max-width: calc(100vw - 16px);\r
  overflow: hidden;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  animation: enter 0.22s var(--ease);\r
}\r
\r
/* Fades in without moving: while it rose into place, it could not be measured for where it is. */\r
.card[data-on-page] {\r
  z-index: 1;\r
  animation-name: fade-in;\r
}\r
\r
/* The ring round the text, while its card is open. */\r
.source-ring {\r
  width: 1px;\r
  height: 1px;\r
  pointer-events: none;\r
}\r
\r
/* Translating: dotted, and whole once the translation is in. */\r
.source-ring[data-pending] path {\r
  stroke-width: 2.6;\r
  stroke-linecap: round;\r
  stroke-dasharray: 0 7px;\r
}\r
\r
/* Where the card is held to move it: a short bar across its top. */\r
.card-grip {\r
  height: 14px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  cursor: grab;\r
  touch-action: none;\r
}\r
\r
.card-grip::before {\r
  content: '';\r
  width: 34px;\r
  height: 4px;\r
  border-radius: 2px;\r
  background: var(--line);\r
  transition: background-color 0.15s, width 0.15s var(--ease);\r
}\r
\r
.card-grip:hover::before,\r
.card[data-dragging] .card-grip::before {\r
  width: 42px;\r
  background: color-mix(in srgb, var(--yl-theme) 55%, var(--line));\r
}\r
\r
.card[data-dragging] {\r
  user-select: none;\r
}\r
\r
.card[data-dragging] .card-grip {\r
  cursor: grabbing;\r
}\r
\r
.card-grip + .card-body {\r
  padding-top: 2px;\r
}\r
\r
.card-body {\r
  max-height: 320px;\r
  overflow-y: auto;\r
  scrollbar-width: thin;\r
  scrollbar-color: rgba(20, 30, 50, 0.18) transparent;\r
  padding: 12px 14px 10px;\r
}\r
\r
.card-source {\r
  /* No padding or border here: a clamped box shows its next line through its own padding. */\r
  margin-bottom: 10px;\r
  color: var(--muted);\r
  display: -webkit-box;\r
  -webkit-box-orient: vertical;\r
  -webkit-line-clamp: 2;\r
  overflow: hidden;\r
  overflow-wrap: anywhere;\r
}\r
\r
.card-result {\r
  padding-top: 10px;\r
  border-top: 1px solid var(--line);\r
  font-size: 14px;\r
  white-space: pre-wrap;\r
  overflow-wrap: anywhere;\r
  user-select: text;\r
}\r
\r
/* The word being read. */\r
.card-word {\r
  border-radius: 3px;\r
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 26%, transparent);\r
  color: inherit;\r
}\r
\r
/* Reading: the button stays lit, and a stop square replaces the speaker. */\r
.icon-btn[data-on],\r
.icon-btn[data-on]:hover {\r
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 14%, transparent);\r
  color: var(--yl-theme, #1f77f3);\r
}\r
\r
.icon-btn[data-on] svg {\r
  fill: currentColor;\r
}\r
\r
/* Between parts, one thin line, drawn apart from the part so its rounded corners do not bend it. */\r
.card-seg {\r
  position: relative;\r
}\r
\r
.card-seg + .card-seg {\r
  margin-top: 11px;\r
}\r
\r
.card-seg + .card-seg::before {\r
  content: '';\r
  position: absolute;\r
  top: -6px;\r
  left: 6px;\r
  right: 6px;\r
  border-top: 1px solid var(--line);\r
}\r
\r
.card-seg[data-jump] .card-source {\r
  margin-bottom: 4px;\r
}\r
\r
.card-seg[data-jump] .card-result {\r
  padding-top: 0;\r
  border-top: 0;\r
}\r
\r
\r
.card-seg[data-jump] {\r
  margin-left: -6px;\r
  margin-right: -6px;\r
  padding: 4px 6px;\r
  border-radius: 8px;\r
  cursor: pointer;\r
  transition: background-color 0.15s;\r
}\r
\r
.card-seg[data-jump]:hover {\r
  background-color: var(--hover);\r
}\r
\r
/* Shows where a part of the card came from, for a moment. */\r
.source-flash {\r
  top: 0;\r
  left: 0;\r
  width: 0;\r
  height: 0;\r
  pointer-events: none;\r
}\r
\r
.source-flash-line {\r
  position: absolute;\r
  border-radius: 4px;\r
  background: color-mix(in srgb, var(--yl-theme) 32%, transparent);\r
  animation: flash-out 1.1s var(--ease) forwards;\r
}\r
\r
@keyframes flash-out {\r
  0%,\r
  45% {\r
    opacity: 1;\r
  }\r
  100% {\r
    opacity: 0;\r
  }\r
}\r
\r
.card-result[data-state='loading'] {\r
  color: var(--muted);\r
}\r
\r
.card-result[data-state='error'] {\r
  color: var(--error);\r
}\r
\r
/* Adding to the glossary, in the card itself. */\r
.card-glossary {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  padding: 8px 14px;\r
  border-top: 1px solid var(--line);\r
}\r
\r
.card-glossary-input {\r
  flex: 1;\r
  min-width: 0;\r
  height: 28px;\r
  padding: 0 8px;\r
  border-radius: 7px;\r
  border: 1px solid var(--line);\r
  background: var(--paper);\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  outline: none;\r
}\r
\r
.card-glossary-input:focus {\r
  border-color: var(--yl-theme);\r
}\r
\r
.card-glossary-arrow {\r
  color: var(--muted);\r
}\r
\r
.card-glossary-save {\r
  height: 28px;\r
  padding: 0 12px;\r
  border: 0;\r
  border-radius: 7px;\r
  background: var(--yl-theme);\r
  color: var(--yl-on-theme);\r
  font: inherit;\r
  font-size: 13px;\r
  font-weight: 500;\r
  cursor: pointer;\r
}\r
\r
/* The translation of a field, before anything in it changes. */\r
.write-pop {\r
  position: relative;\r
  display: flex;\r
  flex-direction: column;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  overflow: hidden;\r
  animation: fade-in 0.16s var(--ease);\r
}\r
\r
/* In the corner, over the text's padding: no row of its own. */\r
.write-close {\r
  position: absolute;\r
  top: 4px;\r
  right: 4px;\r
}\r
\r
.write-foot .grow {\r
  flex: 1;\r
}\r
\r
.write-lang {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 6px;\r
  height: 30px;\r
  padding: 0 10px;\r
  border: 0;\r
  border-radius: 8px;\r
  background: var(--sky);\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  font-weight: 500;\r
  cursor: pointer;\r
}\r
\r
.write-lang:hover {\r
  background: color-mix(in srgb, var(--yl-theme) 20%, var(--paper));\r
}\r
\r
/* Part of the field or all of it. */\r
.write-scope {\r
  display: inline-flex;\r
  height: 30px;\r
  padding: 2px;\r
  border-radius: 8px;\r
  background: var(--sky);\r
}\r
\r
.write-scope button {\r
  padding: 0 9px;\r
  border: 0;\r
  border-radius: 6px;\r
  background: transparent;\r
  color: var(--muted);\r
  font: inherit;\r
  font-size: 12.5px;\r
  white-space: nowrap;\r
  cursor: pointer;\r
}\r
\r
.write-scope button:hover {\r
  color: var(--ink);\r
}\r
\r
.write-scope button[aria-checked='true'] {\r
  background: var(--paper);\r
  color: var(--ink);\r
  font-weight: 500;\r
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);\r
}\r
\r
.write-scope button:focus-visible {\r
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);\r
}\r
\r
.write-chevron {\r
  width: 6px;\r
  height: 6px;\r
  margin-top: -3px;\r
  border-right: 1.5px solid currentColor;\r
  border-bottom: 1.5px solid currentColor;\r
  transform: rotate(45deg);\r
  opacity: 0.6;\r
}\r
\r
.write-result {\r
  max-height: 220px;\r
  overflow-y: auto;\r
  padding: 12px 38px 12px 14px;\r
  font-size: 14px;\r
  line-height: 1.55;\r
  white-space: pre-wrap;\r
  overflow-wrap: anywhere;\r
  user-select: text;\r
}\r
\r
/* The translation put back into the writer's language, to check it says what they meant. */\r
.write-back {\r
  display: flex;\r
  gap: 8px;\r
  margin: -4px 14px 10px;\r
  padding: 7px 10px;\r
  border-radius: 8px;\r
  background: var(--sky);\r
  color: var(--muted);\r
  font-size: 12.5px;\r
  line-height: 1.5;\r
}\r
\r
.write-back[hidden] {\r
  display: none;\r
}\r
\r
.write-back-label {\r
  flex: none;\r
  color: var(--yl-theme);\r
  font-weight: 600;\r
}\r
\r
.write-back-text {\r
  min-width: 0;\r
  max-height: 72px;\r
  overflow-y: auto;\r
  overflow-wrap: anywhere;\r
  white-space: pre-wrap;\r
  color: var(--ink);\r
}\r
\r
.write-back[data-loading] .write-back-text {\r
  color: var(--muted);\r
}\r
\r
.write-result:focus {\r
  outline: none;\r
}\r
\r
.write-result[data-state='loading'] {\r
  color: var(--muted);\r
}\r
\r
.write-result[data-state='error'] {\r
  color: var(--error);\r
}\r
\r
.write-foot {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  padding: 8px 10px 10px;\r
  border-top: 1px solid var(--line);\r
}\r
\r
.write-copy,\r
.write-replace {\r
  height: 30px;\r
  padding: 0 14px;\r
  border-radius: 8px;\r
  font: inherit;\r
  font-size: 13px;\r
  cursor: pointer;\r
}\r
\r
.write-copy {\r
  border: 1px solid var(--line);\r
  background: var(--paper);\r
  color: var(--ink);\r
}\r
\r
.write-copy:hover {\r
  background: var(--hover);\r
}\r
\r
.write-replace {\r
  border: 0;\r
  background: var(--yl-theme);\r
  color: var(--yl-on-theme);\r
  font-weight: 500;\r
}\r
\r
.write-replace:focus-visible,\r
.write-copy:focus-visible,\r
.write-lang:focus-visible {\r
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);\r
  outline-offset: 1px;\r
}\r
\r
.write-copy:disabled,\r
.write-replace:disabled {\r
  opacity: 0.5;\r
  cursor: default;\r
}\r
\r
.lang-menu-item[data-current]::after {\r
  content: '✓';\r
  float: right;\r
  color: var(--yl-theme);\r
}\r
\r
/* Which language to write in, this once. */\r
.lang-menu {\r
  width: 240px;\r
  display: flex;\r
  flex-direction: column;\r
  padding: 6px;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  animation: fade-in 0.14s var(--ease);\r
}\r
\r
.lang-menu-search {\r
  height: 32px;\r
  margin-bottom: 4px;\r
  padding: 0 10px;\r
  border-radius: 8px;\r
  border: 1px solid var(--line);\r
  background: var(--paper);\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  outline: none;\r
}\r
\r
.lang-menu-search:focus {\r
  border-color: var(--yl-theme);\r
}\r
\r
.lang-menu-list {\r
  max-height: 228px;\r
  overflow-y: auto;\r
  scrollbar-width: thin;\r
}\r
\r
.lang-menu-item {\r
  display: block;\r
  width: 100%;\r
  padding: 6px 10px;\r
  border: 0;\r
  border-radius: 7px;\r
  background: transparent;\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
\r
.lang-menu-item:hover,\r
.lang-menu-item[data-active] {\r
  background: var(--hover);\r
}\r
\r
.lang-menu-item[data-active] {\r
  color: var(--yl-theme);\r
  font-weight: 500;\r
}\r
\r
.lang-menu-empty {\r
  padding: 10px;\r
  color: var(--muted);\r
  font-size: 13px;\r
}\r
\r
/* While a field is being translated. */\r
.input-busy {\r
  padding: 3px 9px;\r
  border-radius: 999px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  font-size: 12px;\r
  color: var(--muted);\r
  pointer-events: none;\r
  animation: fade-in 0.15s var(--ease);\r
}\r
\r
.card-foot {\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  padding: 4px 6px 4px 14px;\r
  border-top: 1px solid var(--line);\r
  color: var(--muted);\r
  font-size: 12px;\r
}\r
\r
.card-foot .grow {\r
  flex: 1;\r
  min-width: 0;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
/* "English → 简体中文": the language translated into can be changed for this card. */\r
.card-langs {\r
  display: flex;\r
  align-items: center;\r
}\r
\r
.card-from {\r
  flex: none;\r
}\r
\r
.card-lang {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 5px;\r
  min-width: 0;\r
  height: 22px;\r
  margin-left: -2px;\r
  padding: 0 6px;\r
  border: 0;\r
  border-radius: 6px;\r
  background: transparent;\r
  color: var(--ink);\r
  font: inherit;\r
  font-weight: 500;\r
  cursor: pointer;\r
}\r
\r
/* Alone in the foot, its text lines up where the label's did. */\r
.card-from:empty + .card-lang {\r
  margin-left: -6px;\r
}\r
\r
.card-lang span {\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
.card-lang:hover,\r
.card-lang[aria-expanded='true'] {\r
  background: var(--sky);\r
}\r
\r
.card-lang:focus-visible {\r
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);\r
}\r
\r
.card-lang-chevron {\r
  flex: none;\r
  width: 5px;\r
  height: 5px;\r
  margin-top: -3px;\r
  border-right: 1.5px solid currentColor;\r
  border-bottom: 1.5px solid currentColor;\r
  transform: rotate(45deg);\r
  opacity: 0.55;\r
}\r
\r
.icon-btn {\r
  width: 28px;\r
  height: 28px;\r
  padding: 0;\r
  display: grid;\r
  place-items: center;\r
  flex: none;\r
  border: 0;\r
  border-radius: 7px;\r
  background: transparent;\r
  color: var(--muted);\r
  cursor: pointer;\r
  transition: background-color 0.15s, color 0.15s, transform 0.15s var(--spring);\r
}\r
\r
.icon-btn:hover {\r
  background: var(--hover);\r
  color: var(--ink);\r
}\r
\r
.icon-btn:active {\r
  transform: scale(0.9);\r
}\r
\r
.icon-btn svg {\r
  width: 15px;\r
  height: 15px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 1.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.tooltip {\r
  max-width: 420px;\r
  padding: 7px 10px;\r
  border-radius: 8px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  overflow-wrap: anywhere;\r
  pointer-events: none;\r
  animation: enter 0.16s var(--ease);\r
}\r
\r
.toast {\r
  left: 50%;\r
  bottom: 28px;\r
  translate: -50% 0;\r
  max-width: min(480px, calc(100vw - 32px));\r
  display: flex;\r
  align-items: center;\r
  gap: 12px;\r
  padding: 9px 14px;\r
  border-radius: 10px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  animation: rise 0.22s var(--ease);\r
}\r
\r
.toast button {\r
  flex: none;\r
  padding: 0;\r
  border: 0;\r
  background: none;\r
  color: var(--ink);\r
  font: inherit;\r
  font-weight: 500;\r
  text-decoration: underline;\r
  cursor: pointer;\r
}\r
\r
/* ---- frame ---------------------------------------------------------------- */\r
\r
.region-box {\r
  border-radius: 10px;\r
  pointer-events: none;\r
}\r
\r
/* Drawn as a stroke, so all four sides have one width at any screen scale. */\r
.flow-ring {\r
  position: absolute;\r
  overflow: visible;\r
  pointer-events: none;\r
}\r
\r
.flow-line {\r
  fill: none;\r
}\r
\r
/* Waiting for the translation: the frame breathes. */\r
.region-box[data-pending] .flow-ring {\r
  animation: frame-wait 0.9s ease-in-out infinite alternate;\r
}\r
\r
/* ---- scan card ------------------------------------------------------------ */\r
\r
.scan-card {\r
  display: flex;\r
  flex-direction: column;\r
  max-width: calc(100vw - 16px);\r
  overflow: hidden;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
}\r
\r
.scan-immersive {\r
  animation: enter 0.24s var(--ease);\r
}\r
\r
/* What scrolls passes under the head, which stands clear of it. */\r
.scan-immersive .scan-head {\r
  position: relative;\r
  z-index: 1;\r
  box-shadow: 0 1px 0 var(--line), 0 6px 12px -8px rgba(20, 30, 50, 0.35);\r
}\r
\r
.scan-card[data-exporting] {\r
  pointer-events: none;\r
}\r
\r
/* While the picture is made. Turning needs nothing from the page, which is busy drawing. */\r
.scan-making {\r
  position: absolute;\r
  inset: 0;\r
  z-index: 2;\r
  display: grid;\r
  place-items: center;\r
  background: color-mix(in srgb, var(--paper) 62%, transparent);\r
  animation: fade-in 0.16s var(--ease);\r
}\r
\r
.scan-making-note {\r
  display: flex;\r
  align-items: center;\r
  gap: 10px;\r
  padding: 10px 16px;\r
  border-radius: 10px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  color: var(--ink);\r
  font-size: 13px;\r
}\r
\r
.scan-making-spin {\r
  width: 14px;\r
  height: 14px;\r
  border-radius: 50%;\r
  border: 2px solid color-mix(in srgb, var(--yl-theme) 22%, transparent);\r
  border-top-color: var(--yl-theme);\r
  animation: making-turn 0.7s linear infinite;\r
}\r
\r
@keyframes making-turn {\r
  to {\r
    transform: rotate(360deg);\r
  }\r
}\r
\r
/* Being photographed, the slow way: nothing on the result that is not the result, and square\r
   and flat, or every screen brings its rounded corners and shadow into the joins. */\r
.scan-card[data-photographing] .scan-track,\r
.scan-card[data-photographing] .scan-making {\r
  visibility: hidden;\r
}\r
\r
.scan-card[data-photographing] {\r
  border-radius: 0;\r
  background: var(--paper);\r
  box-shadow: none;\r
}\r
\r
.scan-card[data-photographing] .scan-head {\r
  box-shadow: none;\r
}\r
\r
.scan-closing {\r
  animation: leave 0.17s var(--ease) forwards !important;\r
  pointer-events: none;\r
}\r
\r
.scan-track {\r
  position: absolute;\r
  top: 0;\r
  right: 0;\r
  bottom: 0;\r
  width: 12px;\r
  cursor: pointer;\r
  touch-action: none;\r
}\r
\r
.scan-thumb {\r
  position: absolute;\r
  top: 0;\r
  right: 3px;\r
  width: 6px;\r
  border-radius: 3px;\r
  background: rgba(20, 30, 50, 0.26);\r
  transition: background-color 0.15s, width 0.15s var(--ease);\r
}\r
\r
.scan-track:hover .scan-thumb {\r
  width: 8px;\r
  background: rgba(20, 30, 50, 0.42);\r
}\r
\r
/* Small until there is something to say. */\r
.scan-find {\r
  flex: none;\r
  display: flex;\r
  align-items: center;\r
  gap: 5px;\r
  width: 148px;\r
  height: 26px;\r
  margin: 0 6px 0 10px;\r
  padding: 0 4px 0 8px;\r
  border: 1px solid var(--line);\r
  border-radius: 7px;\r
  background: var(--paper);\r
  color: var(--muted);\r
  cursor: text;\r
  transition: width 0.2s var(--ease), border-color 0.15s;\r
}\r
\r
.scan-find:focus-within {\r
  border-color: var(--yl-theme);\r
}\r
\r
.scan-find[data-typed] {\r
  width: 214px;\r
}\r
\r
.scan-find > svg {\r
  flex: none;\r
  width: 13px;\r
  height: 13px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 1.6;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.scan-find-input {\r
  flex: 1;\r
  min-width: 0;\r
  height: 100%;\r
  padding: 0;\r
  border: 0;\r
  outline: 0;\r
  background: none;\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 12px;\r
  user-select: text;\r
}\r
\r
.scan-find-input::placeholder {\r
  color: var(--muted);\r
}\r
\r
.scan-find-count {\r
  flex: none;\r
  display: none;\r
  font-size: 11px;\r
  font-variant-numeric: tabular-nums;\r
}\r
\r
.scan-find .icon-btn {\r
  display: none;\r
  width: 20px;\r
  height: 20px;\r
  border-radius: 5px;\r
}\r
\r
.scan-find .icon-btn svg {\r
  width: 13px;\r
  height: 13px;\r
}\r
\r
.scan-find[data-typed] .scan-find-count,\r
.scan-find[data-found] .icon-btn {\r
  display: grid;\r
}\r
\r
.scan-find[data-typed] .scan-find-count {\r
  display: block;\r
}\r
\r
.scan-find[data-none] .scan-find-count {\r
  color: var(--error);\r
}\r
\r
.scan-animate {\r
  transition: top 0.3s var(--ease), left 0.3s var(--ease), height 0.3s var(--ease), bottom 0.3s var(--ease);\r
}\r
\r
.scan-backdrop {\r
  inset: 0;\r
  /* The page shows only through small holes in a veil, with its colour taken down: tidy on\r
     any page and with any theme colour. The same recipe as element-plus.org's navigation. */\r
  background-image: radial-gradient(transparent 1px, var(--paper) 1px);\r
  background-size: 4px 4px;\r
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(1.7);\r
  -webkit-backdrop-filter: var(--veil);\r
  backdrop-filter: var(--veil);\r
  animation: fade-in 0.28s var(--ease);\r
}\r
\r
/* A light page through a dark veil is a harsh grid unless the page comes down to its level. */\r
:host([data-appearance='dark']) .scan-backdrop {\r
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(0.4);\r
}\r
\r
/* Only ever seen at full screen. */\r
.scan-card[data-hidden] {\r
  visibility: hidden;\r
  pointer-events: none;\r
}\r
\r
.scan-bar {\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  height: 36px;\r
  padding: 0 4px 0 12px;\r
  border: 1.5px solid transparent;\r
  border-radius: 10px;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  font-size: 12px;\r
  white-space: nowrap;\r
  animation: enter 0.2s var(--ease);\r
}\r
\r
.scan-bar .grow {\r
  margin-right: 8px;\r
}\r
\r
.scan-head {\r
  cursor: default;\r
}\r
\r
.scan-grip {\r
  position: absolute;\r
  z-index: 2;\r
  top: 0;\r
  left: 0;\r
  right: 0;\r
  height: 6px;\r
  cursor: ns-resize;\r
  touch-action: none;\r
}\r
\r
.scan-head {\r
  flex: none;\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  height: 36px;\r
  padding: 0 6px 0 14px;\r
  background: var(--sky);\r
  color: var(--ink);\r
  font-size: 12px;\r
  user-select: none;\r
}\r
\r
.scan-head .icon-btn {\r
  color: var(--ink);\r
}\r
\r
.scan-head .icon-btn:hover {\r
  background: var(--glass);\r
}\r
\r
.scan-head .grow {\r
  flex: 1 1 0;\r
  min-width: 0;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
/* Shows a copy of the page, whose text assumes the page's own background. */\r
.scan-body {\r
  background: #fff;\r
  position: relative;\r
  flex: 1;\r
  min-height: 0;\r
  overflow: hidden;\r
}\r
\r
.scan-body iframe {\r
  position: absolute;\r
  border: 0;\r
  background: transparent;\r
}\r
\r
/* ---- marquee -------------------------------------------------------------- */\r
\r
.marquee-shade {\r
  inset: 0;\r
  cursor: crosshair;\r
  background: rgba(20, 40, 80, 0.05);\r
  touch-action: none;\r
  user-select: none;\r
  animation: fade-in 0.15s var(--ease);\r
}\r
\r
.marquee-hint {\r
  left: 50%;\r
  top: 16px;\r
  translate: -50% 0;\r
  padding: 6px 12px;\r
  border-radius: 8px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  white-space: nowrap;\r
  pointer-events: none;\r
  animation: rise 0.2s var(--ease);\r
}\r
\r
.leaving {\r
  animation: leave 0.16s var(--ease) forwards !important;\r
  pointer-events: none;\r
}\r
\r
@keyframes frame-wait {\r
  to {\r
    opacity: 0.5;\r
  }\r
}\r
\r
@keyframes enter {\r
  from {\r
    opacity: 0;\r
    transform: translateY(6px) scale(0.985);\r
  }\r
}\r
\r
@keyframes leave {\r
  to {\r
    opacity: 0;\r
    transform: translateY(4px) scale(0.985);\r
  }\r
}\r
\r
@keyframes pop {\r
  from {\r
    opacity: 0;\r
    transform: scale(0.7);\r
  }\r
}\r
\r
@keyframes rise {\r
  from {\r
    opacity: 0;\r
    transform: translateY(6px);\r
  }\r
}\r
\r
@keyframes fade-in {\r
  from {\r
    opacity: 0;\r
  }\r
}\r
\r
@media (prefers-reduced-motion: reduce) {\r
  * {\r
    animation-duration: 0.01ms !important;\r
    transition-duration: 0.01ms !important;\r
  }\r
}\r
`;var Z="http://www.w3.org/2000/svg",sr=2,ar=3,lr=12,Te=[["0","#4da2ff"],["0.35","#55db9c"],["0.62","#ffd731"],["0.85","#fb4903"],["1","#5c4ade"]],cr=0,Mt=2147483646;function Ct(o){for(let e of["keydown","keyup","keypress"])o.addEventListener(e,t=>t.stopPropagation())}function U(o){let e=devicePixelRatio||1;return Math.round(o*e)/e}var dr={copy:["M9 9h10v11H9z","M5 15V4h10"],speak:["M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z","M15.5 9a4 4 0 0 1 0 6","M18 6.5a8 8 0 0 1 0 11"],close:["M6 6l12 12","M18 6L6 18"],stop:["M7 7h10v10H7z"],check:["M5 12.5l4.5 4.5L19 7.5"],expand:["M4 9V4h5","M20 9V4h-5","M4 15v5h5","M20 15v5h-5"],collapse:["M9 4v5H4","M15 4v5h5","M9 20v-5H4","M15 20v-5h5"],search:["M11 5a6 6 0 1 1 0 12a6 6 0 0 1 0-12z","M15.5 15.5L20 20"],up:["M6 15l6-6 6 6"],down:["M6 9l6 6 6-6"],image:["M4 5h16v14H4z","M4 16l5-5 4 4 3-3 4 4","M15.5 8.5h.01"],download:["M12 4v11","M7.5 11L12 15.5 16.5 11","M5 19.5h14"],glossary:["M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z","M5 19.5A1.5 1.5 0 0 0 6.5 21H19","M12 7.5v6","M9 10.5h6"],translate:["M4 5h7","M9 3v2c0 4.418-2.239 8-5 8","M5 9c0 2.144 2.952 3.908 6.7 4","M12 20l4-9 4 9","M19.1 18h-6.2"]};function pe(o){let e=document.createElementNS(Z,"svg");e.setAttribute("viewBox","0 0 24 24");for(let t of dr[o]){let n=document.createElementNS(Z,"path");n.setAttribute("d",t),e.append(n)}return e}function v(o,e,t){let n=document.createElement(o);return n.className=e,t!==void 0&&(n.textContent=t),n}function q(o,e,t){let n=v("button","icon-btn");return n.type="button",n.title=e,n.setAttribute("aria-label",e),n.append(pe(o)),n.addEventListener("click",t),n}var $e=class{host;root;toastEl;toastTimer;theme;dark=!1;pageHost;pageRoot;overHost;overRoot;tooltipEl;setTheme(e,t){this.theme=e,this.dark=t;for(let n of[this.host,this.pageHost,this.overHost])n&&this.paint(n)}settleUnderBars(){let e=Se(),t=e.stacking!==null&&e.stacking>1;return this.pageHost&&(this.pageHost.style.zIndex=String(t?e.stacking-1:Mt)),t?{top:-1/0,bottom:1/0}:{top:e.top>0?e.top:-1/0,bottom:e.bottom<innerHeight?e.bottom:1/0}}paint(e){this.theme&&(e.style.setProperty("--yl-theme",this.theme),e.style.setProperty("--yl-on-theme",Ie("#ffffff",this.theme)>=3?"#ffffff":"#14161b")),e.dataset.appearance=this.dark?"dark":"light"}get hostElement(){return this.host}isHost(e){return!!e&&(e===this.host||e===this.pageHost||e===this.overHost)}ownsEvent(e){return e.composedPath().some(t=>t===this.host||t===this.pageHost||t===this.overHost)}ensurePage(){if(this.pageRoot&&this.pageHost?.isConnected)return this.pageRoot;this.pageHost=document.createElement("yl-ui"),this.pageHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${Mt};`,this.paint(this.pageHost),Ct(this.pageHost),this.pageRoot=this.pageHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=Be,this.pageRoot.append(e),document.documentElement.append(this.pageHost),this.pageRoot}ensureOver(){if(this.overRoot&&this.overHost?.isConnected)return this.overRoot;this.overHost=document.createElement("yl-ui"),this.overHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${Mt};`,this.paint(this.overHost),Ct(this.overHost),this.overRoot=this.overHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=Be,this.overRoot.append(e),document.documentElement.append(this.overHost),this.overRoot}addToPage(e,t=!1){return e.classList.add("layer"),e.style.position="absolute",(t?this.ensureOver():this.ensurePage()).append(e),e}ensure(){if(this.root&&this.host?.isConnected)return this.root;this.host=document.createElement("yl-ui"),this.host.style.cssText="all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",this.paint(this.host),Ct(this.host),this.root=this.host.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=Be,this.root.append(e),document.documentElement.append(this.host),this.root}add(e){return e.classList.add("layer"),this.ensure().append(e),e}addBelow(e,t){return e.classList.add("layer"),t.parentNode?.insertBefore(e,t),e}place(e,t,n=8,r){let{left:i,top:s}=this.spot(e,t,n,r);e.style.left=`${i}px`,e.style.top=`${s}px`}spot(e,t,n=8,r){let i=e.offsetWidth,s=e.offsetHeight,a=Se(),l=Math.max(a.top,r?.top??0)+8,c=Math.min(a.bottom,r?.bottom??innerHeight)-8,d=Math.max(8,Math.min(t.left,innerWidth-i-8)),u=t.bottom+n;return u+s>c&&(u=t.top-s-n),{left:d,top:Math.max(l,Math.min(u,c-s))}}ring(e){let t=document.createElementNS(Z,"svg");t.setAttribute("class","flow-ring"),t.setAttribute("aria-hidden","true");let n=`yl-edge-${++cr}`,r=document.createElementNS(Z,"defs"),i=document.createElementNS(Z,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[u,h]of Te){let p=document.createElementNS(Z,"stop");p.setAttribute("offset",u),p.setAttribute("stop-color",h),i.append(p)}if(!matchMedia("(prefers-reduced-motion: reduce)").matches){let u=document.createElementNS(Z,"animateTransform");u.setAttribute("attributeName","gradientTransform"),u.setAttribute("type","rotate"),u.setAttribute("from","0 0.5 0.5"),u.setAttribute("to","360 0.5 0.5"),u.setAttribute("dur","6s"),u.setAttribute("repeatCount","indefinite"),i.append(u)}r.append(i);let s=Math.max(1/(devicePixelRatio||1),U(sr)),a=U(ar);t.style.left=t.style.top=`${-a}px`,t.style.width=`calc(100% + ${a*2}px)`,t.style.height=`calc(100% + ${a*2}px)`;let c=(u=>{let h=document.createElementNS(Z,"rect");return h.setAttribute("class",u),h.setAttribute("x",String(s/2)),h.setAttribute("y",String(s/2)),h.setAttribute("stroke-width",String(s)),h.setAttribute("rx",String(lr)),h})("flow-line");c.setAttribute("stroke",`url(#${n})`),t.append(r,c),e.append(t);let d=()=>{let u=e.getBoundingClientRect(),h=Math.max(0,u.width+a*2-s),p=Math.max(0,u.height+a*2-s);c.setAttribute("width",String(h)),c.setAttribute("height",String(p))};new ResizeObserver(d).observe(e),d()}addFrame(e=!1,t=!1,n=!1){let r=v("div","region-box");return e&&(r.dataset.pending=""),t?this.addToPage(r,n):this.add(r),this.ring(r),r}setFramePending(e,t){t?e.dataset.pending="":delete e.dataset.pending}dismiss(e){if(!e)return;e.classList.add("leaving");let t=()=>e.remove();e.addEventListener("animationend",t,{once:!0}),setTimeout(t,220)}toast(e,t,n=5e3){this.dismiss(this.toastEl),clearTimeout(this.toastTimer);let r=v("div","toast");if(r.setAttribute("role","status"),r.append(v("span","",e)),t){let i=v("button","",t.label);i.type="button",i.addEventListener("click",()=>{r.remove(),t.run()}),r.append(i)}this.toastEl=this.add(r),this.toastTimer=setTimeout(()=>this.dismiss(r),n)}showTooltip(e,t){this.hideTooltip();let n=v("div","tooltip",e);this.tooltipEl=this.add(n),this.place(n,t,6)}hideTooltip(){this.dismiss(this.tooltipEl),this.tooltipEl=void 0}errorMessage(e){return y(`error_${e}`)||y("error_unavailable")}};var At=8,hn=o=>se.find(e=>e.code===o)?.name??o;function Fe(o,e,t,n,r){let i=v("div","lang-menu");i.setAttribute("role","dialog"),i.setAttribute("aria-label",n);let s=v("input","lang-menu-search");s.placeholder=y("searchLanguage");let a=v("div","lang-menu-list");a.setAttribute("role","listbox"),i.append(s,a),o.add(i);let l=[],c=Math.max(0,se.findIndex(E=>E.code===t)),d=()=>{let E=s.value.trim().toLowerCase(),T=C=>!E||hn(C).toLowerCase().includes(E)||C.toLowerCase().startsWith(E)||(un[C]??"").includes(E);l=se.map(C=>C.code).filter(T),c=Math.min(c,Math.max(0,l.length-1)),a.replaceChildren(...l.map((C,$)=>{let D=v("button","lang-menu-item",hn(C));return D.type="button",D.toggleAttribute("data-active",$===c),D.toggleAttribute("data-current",C===t),D.addEventListener("mousedown",P=>P.preventDefault()),D.addEventListener("click",()=>m(C)),D})),l.length||a.append(v("div","lang-menu-empty",y("noLanguage"))),a.children[c]?.scrollIntoView({block:"nearest"})},u=!1,h=()=>u=!0,p=()=>{u=!1,setTimeout(()=>{u||f()})};i.addEventListener("pointerdown",h),addEventListener("pointerdown",p,!0);let f=()=>{removeEventListener("pointerdown",p,!0),i.remove()},m=E=>{f(),r(E)};s.addEventListener("input",()=>{c=0,d()}),s.addEventListener("keydown",E=>{E.key==="ArrowDown"||E.key==="ArrowUp"?(E.preventDefault(),c=(c+(E.key==="ArrowDown"?1:-1)+l.length)%Math.max(1,l.length),d()):E.key==="Enter"?(E.preventDefault(),l[c]&&m(l[c])):E.key==="Escape"&&(E.preventDefault(),E.stopPropagation(),f())}),d();let g=i.offsetHeight,b=i.offsetWidth,x=innerHeight-e.bottom-At;return i.style.left=`${Math.max(At,Math.min(e.left,innerWidth-b-At))}px`,i.style.top=`${x>=g||x>=e.top?e.bottom+4:e.top-g-4}px`,s.focus(),{close:f,isOpen:()=>i.isConnected}}var mn=700,fn=3,ur=5e3,pr=new Set(["","text","search"]),Q=8,hr=300,mr=360,fr=460,gr=o=>se.find(e=>e.code===o)?.name??o;function br(o){if(o instanceof HTMLTextAreaElement)return o.readOnly||o.disabled?null:o;if(o instanceof HTMLInputElement)return!pr.has(o.type.toLowerCase())||o.readOnly||o.disabled?null:o;if(o instanceof HTMLElement&&o.isContentEditable){let e=o;for(;e.parentElement?.isContentEditable;)e=e.parentElement;return e}return null}function he(o){return o instanceof HTMLInputElement||o instanceof HTMLTextAreaElement}function gn(o){return(he(o)?o.value:o.innerText??"").replace(/[\s ]+$/,"")}function bn(o){return!!o.trim()&&o.length<=ur&&new RegExp("\\p{L}","u").test(o)}function vn(o){let e=getSelection();e?.removeAllRanges(),e?.addRange(o)}function Rt(o,e,t){let n=o.value.slice(e,t);return{text:n,select(){let r=e;return o.value.slice(e,t)!==n&&(r=o.value.indexOf(n),r<0)?!1:(o.focus(),o.setSelectionRange(r,r+n.length),!0)}}}function Nt(o,e){return{text:e.toString(),select(){return!o.contains(e.commonAncestorContainer)||!e.toString().trim()?!1:(o.focus(),vn(e.cloneRange()),!0)}}}function yr(o){if(he(o))return{...Rt(o,0,o.value.length),text:gn(o)};let e=document.createRange();return e.selectNodeContents(o),{...Nt(o,e),text:gn(o)}}function wn(o,e,t){for(;e<t&&/\s/.test(o[e]);)e++;for(;t>e&&/\s/.test(o[t-1]);)t--;return[e,t]}function xn(o){if(he(o)){let{selectionStart:n,selectionEnd:r}=o;if(n===null||r===null||n===r)return null;let[i,s]=wn(o.value,n,r);return i<s?Rt(o,i,s):null}let e=getSelection();if(!e?.rangeCount||e.isCollapsed)return null;let t=e.getRangeAt(0);return!o.contains(t.commonAncestorContainer)||!t.toString().trim()?null:Nt(o,t.cloneRange())}function vr(o){return xn(o)!==null}function wr(o){if(he(o)){let n=o.selectionStart;if(n===null)return null;let r=o.value,i=r.lastIndexOf(`
`,n-1)+1,s=r.indexOf(`
`,n),[a,l]=wn(r,i,s<0?r.length:s);return a<l?Rt(o,a,l):null}let e=getSelection();if(!e?.rangeCount)return null;let t=e.getRangeAt(0).startContainer;if(!o.contains(t))return null;for(;t&&t!==o;t=t.parentNode){if(!(t instanceof HTMLElement))continue;let n=getComputedStyle(t).display;if(n.startsWith("inline")||n==="contents")continue;if(!t.innerText.trim())return null;let r=document.createRange();return r.selectNodeContents(t),Nt(o,r)}return null}function yn(o,e){if(!document.execCommand("insertText",!1,e))if(he(o))o.setRangeText(e,o.selectionStart??0,o.selectionEnd??o.value.length,"end"),o.dispatchEvent(new Event("input",{bubbles:!0}));else{let t=getSelection()?.getRangeAt(0);t?.deleteContents(),t?.insertNode(document.createTextNode(e))}}function xr(o,e){if(he(o)){if(o.selectionStart===null)return;let s=o.selectionStart,a=o.value.slice(Math.max(0,s-e),s);a.length===e&&!a.trim()&&(o.setSelectionRange(s-e,s),document.execCommand("delete")||o.setRangeText("",s-e,s,"end"));return}let t=getSelection();if(!t?.rangeCount||!t.isCollapsed)return;let{startContainer:n,startOffset:r}=t.getRangeAt(0);if(!(n instanceof Text)||r<e||!/^[  ]+$/.test(n.data.slice(r-e,r)))return;let i=document.createRange();i.setStart(n,r-e),i.setEnd(n,r),vn(i),document.execCommand("delete")}var We=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("keydown",this.onKeyDown,!0)}presses=[];preview;menu;update(e,t){this.settings=e,this.enabled=t,this.active||this.preview?.close(!1)}get active(){return this.enabled&&this.settings.inputTranslate&&j()}onKeyDown=e=>{if(!this.active||this.preview)return;if(e.key!==" "||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||e.repeat){this.release(),this.presses=[];return}let t=br(e.composedPath()[0]??e.target);if(this.held&&this.held.field!==t&&this.release(),!t)return;let n=performance.now();this.presses=[...this.presses.filter(i=>n-i<mn),n];let r=this.presses.length>=fn;if(r&&(this.presses=[]),this.held||vr(t)){if(e.preventDefault(),r){this.forget(),this.openPreview(t);return}let i=(this.held?.count??0)+1;this.forget(),this.held={field:t,count:i,timer:setTimeout(()=>this.release(),mn)},document.addEventListener("pointerdown",this.release,!0);return}r&&(e.preventDefault(),xr(t,fn-1),this.openPreview(t))};held;forget(){this.held&&(clearTimeout(this.held.timer),this.held=void 0,document.removeEventListener("pointerdown",this.release,!0))}release=()=>{let e=this.held;e&&(this.forget(),document.activeElement!==e.field&&!e.field.contains(document.activeElement)&&e.field.focus(),yn(e.field," ".repeat(e.count)))};openPreview(e){let t=yr(e);if(!bn(t.text))return;let n=xn(e),r=n??wr(e);r&&(!bn(r.text)||r.text.trim()===t.text.trim())&&(r=null);let i={part:r,all:t},s=r?"part":"all";this.preview?.close(!1);let a=v("div","write-pop");a.setAttribute("role","dialog"),a.setAttribute("aria-label",y("sectionInput"));let l=v("button","write-lang");l.type="button",l.title=y("inputOtherLanguage"),l.setAttribute("aria-haspopup","listbox");let c=v("span","","");l.append(c,v("i","write-chevron"));let d=q("close",y("close"),()=>J(!0));d.classList.add("write-close");let u=v("div","write-result",y("translating"));u.dataset.state="loading",u.tabIndex=-1;let h=v("div","write-foot"),p=v("button","write-copy",y("copy"));p.type="button";let f=v("button","write-replace",y("writeReplace"));f.type="button",h.append(l);let m=new Map;if(r){let w=v("div","write-scope");w.setAttribute("role","radiogroup");for(let[N,I]of[["part",y(n?"writeScopePicked":"writeScopeLine")],["all",y("writeScopeAll")]]){let A=v("button","",I);A.type="button",A.setAttribute("role","radio"),A.addEventListener("click",()=>{s!==N&&(s=N,g(),S(D))}),m.set(N,A),w.append(A)}h.append(w)}let g=()=>{for(let[w,N]of m)N.setAttribute("aria-checked",String(w===s))};g(),h.append(v("span","grow"),p,f);let b=v("div","write-back");b.hidden=!0,b.title=y("writeBackHint");let x=v("span","write-back-text");b.append(v("span","write-back-label",y("writeBack")),x),a.append(d,u,b,h),this.ui.add(a);let E=new Map,T=new Map,C="",$=()=>i[s].text.trim(),D=this.settings.inputLang,P="",z=0,G=!1,S=async w=>{D=w,c.textContent=gr(w);let N=++z,I=`${s} ${w}`,A=$(),F=E.get(I);if(F!==void 0){R(F),this.preview?.node===a&&L(I,F,w,N);return}P="",b.hidden=!0,u.dataset.state="loading",u.textContent=y("translating"),f.setAttribute("aria-busy","true"),p.disabled=!0,H();try{let _=await B({type:"translate",items:[X(A)],from:"",to:w});if(N!==z||this.preview?.node!==a)return;let W=_?.results?.[0];if(W?.ok){let le=re(W.text);E.set(I,le),W.detected&&(C=W.detected),R(le),this.preview?.node===a&&L(I,le,w,N)}else k(this.ui.errorMessage(W?.code??"network"))}catch{N===z&&j()&&k(this.ui.errorMessage("network"))}},R=w=>{if(P=w,delete u.dataset.state,u.textContent=w,f.removeAttribute("aria-busy"),p.disabled=!1,G){O();return}H(),f.focus()},L=async(w,N,I,A)=>{let F=W=>W.toLowerCase().split("-")[0];if(!C||F(C)===F(I)){b.hidden=!0,H();return}let _=T.get(w);if(b.hidden=!1,b.toggleAttribute("data-loading",_===void 0),x.textContent=_??y("translating"),H(),_===void 0){try{let W=await B({type:"translate",items:[X(N)],from:I,to:C});if(A!==z||this.preview?.node!==a)return;let le=W?.results?.[0];if(le?.ok){let Vt=re(le.text);T.set(w,Vt),b.removeAttribute("data-loading"),x.textContent=Vt}else b.hidden=!0}catch{A===z&&(b.hidden=!0)}H()}},k=w=>{b.hidden=!0,G=!1,f.removeAttribute("aria-busy"),u.dataset.state="error",u.textContent=w,H()},O=()=>{let w=P,N=i[s];J(!1),N.select()?yn(e,w):e.focus()},H=()=>{let w=e.getBoundingClientRect(),I=Math.min(fr,Math.max(r?mr:hr,w.width),innerWidth-Q*2);a.style.width=`${I}px`;let A=a.offsetHeight,F=w.top-A-Q,_=F>=Q?F:Math.min(w.bottom+Q,innerHeight-A-Q);a.style.left=`${Math.max(Q,Math.min(w.left,innerWidth-I-Q))}px`,a.style.top=`${Math.max(Q,_)}px`},J=w=>{++z,document.removeEventListener("pointerdown",M,!0),this.menu?.close(),this.menu=void 0,a.remove(),this.preview?.node===a&&(this.preview=void 0),w&&e.focus()},M=w=>{this.ui.ownsEvent(w)||J(!1)};f.addEventListener("click",()=>{P?O():u.dataset.state==="loading"&&(G=!0)}),p.addEventListener("click",()=>{P&&navigator.clipboard.writeText(P).then(()=>{p.textContent=y("copied"),setTimeout(()=>p.textContent=y("copy"),1200)})}),l.addEventListener("click",()=>{this.menu?.close(),this.menu=Fe(this.ui,l.getBoundingClientRect(),D,y("inputLang"),w=>void S(w))}),a.addEventListener("keydown",w=>{if(w.key==="Escape"){w.preventDefault(),J(!0);return}if(!(w.ctrlKey||w.metaKey)||w.altKey||w.shiftKey)return;let N=w.key.toLowerCase();if(N==="a")w.preventDefault(),getSelection()?.selectAllChildren(u);else if(N==="c"&&P){let I=getSelection()?.toString()??"";(!I.trim()||!P.includes(I.trim()))&&(w.preventDefault(),navigator.clipboard.writeText(P))}}),document.addEventListener("pointerdown",M,!0),this.preview={node:a,field:e,close:J},H(),f.focus(),S(D)}};function En(o,e){let t=new Set,n=r=>{let i=r.composedPath()[0];return i instanceof Element?i.localName==="yl-ui"?!0:i.matches("input,textarea,select")||!!i.closest('[contenteditable]:not([contenteditable="false"]),[role="textbox"]'):!1};window.addEventListener("keydown",r=>{if(nn(r.code))return;t.add(r.code);let i=on(r);if(n(r)&&!i.some(c=>c!=="Shift"))return;let s=[...i,...t],a=o();for(let c of He){let d=a[c];if(Et(d,s)){r.preventDefault(),r.stopPropagation(),r.repeat||e(c);return}}He.some(c=>{let{mods:d,keys:u}=rn(a[c]);return u.length>1&&u.includes(r.code)&&d.length===i.length&&d.every(h=>i.includes(h))})&&(r.preventDefault(),r.stopPropagation())},!0),window.addEventListener("keyup",r=>t.delete(r.code),!0),window.addEventListener("blur",()=>t.clear())}var Sn=8,Ue=36,qe=18,je=class{constructor(e){this.ui=e}shade;box;hint;start;pointer={x:0,y:0};raf=0;onDone;get running(){return this.shade!==void 0}begin(e){this.running||(this.onDone=e,this.shade=this.ui.add(v("div","marquee-shade")),this.hint=this.ui.add(v("div","marquee-hint",y("marqueeHint"))),this.shade.addEventListener("pointerdown",this.onDown),this.shade.addEventListener("pointermove",this.onMove),this.shade.addEventListener("pointerup",this.onUp),this.shade.addEventListener("wheel",this.onWheel,{passive:!1}),addEventListener("keydown",this.onKey,!0),addEventListener("scroll",this.draw,!0),addEventListener("blur",this.cancel))}cancel=()=>this.end();end(){cancelAnimationFrame(this.raf),this.raf=0,removeEventListener("keydown",this.onKey,!0),removeEventListener("scroll",this.draw,!0),removeEventListener("blur",this.cancel),this.shade?.remove(),this.box?.remove(),this.hint?.remove(),this.shade=this.box=this.hint=void 0,this.start=void 0}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.end())};onDown=e=>{e.button===0&&(e.preventDefault(),this.shade.setPointerCapture(e.pointerId),this.start={x:e.clientX+scrollX,y:e.clientY+scrollY},this.pointer={x:e.clientX,y:e.clientY},this.box=this.ui.addFrame(),this.hint?.remove(),this.hint=void 0,this.draw(),this.raf=requestAnimationFrame(this.edgeScroll))};onMove=e=>{this.start&&(this.pointer={x:e.clientX,y:e.clientY},this.draw())};onUp=()=>{if(!this.start)return;let e=this.currentRect();this.end(),e.right-e.left>=Sn&&e.bottom-e.top>=Sn&&this.onDone?.(e)};onWheel=e=>{e.preventDefault(),this.scrollTarget().scrollBy(e.deltaX,e.deltaY)};scrollTarget(){let e=document.elementsFromPoint(this.pointer.x,this.pointer.y);for(let t of e)if(!this.ui.isHost(t)){for(let n=t;n&&n!==document.documentElement;n=n.parentElement){let r=getComputedStyle(n).overflowY;if((r==="auto"||r==="scroll")&&n.scrollHeight>n.clientHeight)return n}break}return window}edgeScroll=()=>{if(!this.start)return;let{x:e,y:t}=this.pointer,n=t<Ue?-qe:t>innerHeight-Ue?qe:0,r=e<Ue?-qe:e>innerWidth-Ue?qe:0;(r||n)&&window.scrollBy(r,n),this.raf=requestAnimationFrame(this.edgeScroll)};currentRect(){let e=this.start.x-scrollX,t=this.start.y-scrollY;return{left:Math.min(e,this.pointer.x),top:Math.min(t,this.pointer.y),right:Math.max(e,this.pointer.x),bottom:Math.max(t,this.pointer.y)}}draw=()=>{if(!this.start||!this.box)return;let e=this.currentRect();Object.assign(this.box.style,{left:`${U(e.left)}px`,top:`${U(e.top)}px`,width:`${U(e.right-e.left)}px`,height:`${U(e.bottom-e.top)}px`})}};var me=new Set(["yl-t","yl-r","yl-ui"]),Er=new Set(["script","style","noscript","template","head","meta","link","title","base","datalist","area","map","param","source","track","rp"]),Sr=new Set(["pre","textarea","input","select","option","optgroup","canvas","video","audio","iframe","frame","frameset","object","embed","applet","listing","xmp","plaintext"]),Tr=new Set(["code","kbd","samp","var","tt","img","picture","svg","math","ruby","wbr"]),kr=new Set(["CodeMirror","cm-editor","cm-content","cm-line","monaco-editor","monaco-diff-editor","ace_editor","hljs","prism-code","shiki","astro-code","xterm","blob-code","blob-code-inner","blob-wrapper","blob-num","react-code-lines","react-code-text","react-file-line","react-syntax-highlighter","syntaxhighlighter","code-block","codeblock","code-toolbar","sourceCode","gist-file","gist-data","d2h-wrapper","d2h-file-wrapper","mw-highlight","rouge-table","rouge-code","linenums","line-numbers","lineno","hljs-ln","katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),Mr=new Set(["highlight","highlighter-rouge","codehilite","code","prism","terminal","gist","source","snippet","example"]),Cr=["language-","lang-","highlight-source-","highlight-text-","brush:"],Ar=new Set(["code","textbox","searchbox","combobox","math","img","slider","spinbutton"]),Rr=/^\s*"?'?(monospace|ui-monospace|consolas|menlo|monaco|courier|courier new|lucida console|lucida sans typewriter|sfmono-regular|sf mono|fira code|fira mono|source code pro|jetbrains mono|roboto mono|ibm plex mono|dejavu sans mono|liberation mono|cascadia code|cascadia mono|ubuntu mono|hack|inconsolata)\b/i,Nr='nav,button,[role="navigation"],[role="menu"],[role="menubar"],[role="tablist"],[role="toolbar"],[role="button"],[role="menuitem"],[role="tab"]';function Lt(o){return Rr.test(o)}function Tn(o){let e=o.classList;for(let t=0;t<e.length;t++){let n=e[t];if(kr.has(n)||(Mr.has(n)||Cr.some(r=>n.startsWith(r)))&&Lr(o))return!0}return!1}function Lr(o){for(let e of Array.from(o.children)){let t=e.localName;if(t==="pre"||t==="code"||t==="table"||e.firstElementChild?.localName==="pre")return!0}return!1}var Pr=/^(material-icons(-[\w-]+)?|material-symbols(-[\w-]+)?|mdi|mdi-[\w-]+|fa|fas|far|fab|fal|fa-[\w-]+|bi|bi-[\w-]+|glyphicon|glyphicon-[\w-]+|iconfont|anticon|anticon-[\w-]+)$/;function Hr(o){if(o.childElementCount>0)return!1;let e=(o.textContent??"").trim();if(e.length>40||/\s/.test(e))return!1;let t=o.classList;for(let n=0;n<t.length;n++)if(Pr.test(t[n]))return!0;return o.getAttribute("aria-hidden")==="true"&&/^[a-z0-9_]+$/.test(e)}function Ir(o){if(o.getAttribute("translate")==="no")return!0;let e=o.getAttribute("contenteditable");if(e!==null&&e!=="false")return!0;let t=o.getAttribute("role");return!!(t&&Ar.has(t))}var ze=class{excludeSelector=null;setExcludes(e){let t=e.split(`
`).map(n=>n.trim()).filter(n=>n&&$r(n));this.excludeSelector=t.length?t.join(","):null}classify(e){let t=e.localName;if(t==="br")return"br";if(me.has(t))return"own";if(Er.has(t))return"hidden";let n=getComputedStyle(e);if(Sr.has(t))return n.display==="none"?"hidden":"skip";if(n.display==="none"||n.visibility==="hidden"||n.visibility==="collapse")return"collapsed";if(n.position==="absolute"&&parseFloat(n.width)<=1&&parseFloat(n.height)<=1)return"hidden";let r=Or(n.display);if(Tr.has(t)||Hr(e)||Ir(e)||Tn(e)||this.isExcluded(e))return r?"atomic":"skip";if(Lt(n.fontFamily)){let i=e.parentElement,s=i?Lt(getComputedStyle(i).fontFamily):!1;if(r&&!s)return"atomic";if(!r&&n.whiteSpace.startsWith("pre"))return"skip"}return t==="button"||e.getAttribute("role")==="button"||e.localName.includes("-")&&Br(e)?"block":r?"inline":"block"}isExcluded(e){return this.excludeSelector!==null&&e.matches(this.excludeSelector)}},Dr=new Set(["katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),_r=new Set(["pre","code","samp","kbd","listing","xmp","plaintext"]);function kn(o){if(_r.has(o.localName)||o.querySelector("pre"))return!0;let e=o.classList;for(let n=0;n<e.length;n++){let r=e[n];if(Dr.has(r))return!1}if(Tn(o))return!0;let t=getComputedStyle(o);return Lt(t.fontFamily)&&t.whiteSpace.startsWith("pre")}function Ge(o){return o.matches(Nr)}function Mn(o,e){let t=n=>{let r=n.toLowerCase(),i=r.split("-")[0];return i!=="zh"&&i!=="yue"?i:/hant|-tw|-hk|-mo/.test(r)||i==="yue"?"zh-hant":"zh-hans"};return t(o)===t(e)}function Or(o){return o==="inline"||o==="inline-block"||o==="inline-flex"||o==="inline-grid"||o===""||o==="ruby"}function fe(o){if(o.shadowRoot)return o.shadowRoot;if(!o.localName.includes("-"))return null;try{return chrome.dom?.openOrClosedShadowRoot?.(o)??null}catch{return null}}function Br(o){return fe(o)!==null}function $r(o){try{return document.createDocumentFragment().querySelector(o),!0}catch{return!1}}function Ke(o){let e=o.trim();return!new RegExp("\\p{L}","u").test(e)||/^(https?:\/\/|www\.)\S+$/i.test(e)||/^\S+@\S+\.\S+$/.test(e)?!1:!Fr(e)}function Fr(o){let e=o.replace(/^[("'“‘[]+|[.,:;!?)"'”’\]]+$/g,"");return/^[\w$.:/\\#()<>=\-[\]{}]+$/.test(e)?/\w_\w|\w\.\w|\(\)|::|^--|\w=|\w[/\\]\w|^[#$.]\w/.test(e):!1}var Wr=/[這個們來時會對說為學國還過發現點開關與實體後經機於從無見長問間電動應當將麼樣邊裡寫話讀請]/,Ur=/[这个们来时会对说为学国还过发现点开关与实体后经机于从无见长问间电动应当将么样边里写话读请]/;function ke(o,e){let t=o.match(new RegExp("\\p{L}","gu"));if(!t)return!1;let n=i=>(o.match(i)?.length??0)/t.length,r=e.split("-")[0];return r==="zh"?/[぀-ヿ]/.test(o)||n(new RegExp("\\p{Script=Han}","gu"))<.6?!1:e==="zh-Hant"?!Ur.test(o):!Wr.test(o):r==="ja"?n(/[぀-ヿ]/g)>.2:r==="ko"?n(new RegExp("\\p{Script=Hangul}","gu"))>.5:!1}var qr=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,jr=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,Rn="data-yl-mirror",Cn=new Set(["script","noscript","iframe","frame","object","embed","meta","title","base","style","link","yl-ui","yl-t","yl-r"]),zr=["class","style","open","hidden"],An=`
*, *::before, *::after { visibility: hidden !important; transition: none !important; animation: none !important; }
html, body { visibility: visible !important; scroll-behavior: auto !important; overscroll-behavior: contain; }

* { scrollbar-color: transparent transparent !important; }
html { overflow-x: hidden !important; }
[data-yl-pinned], [data-yl-pinned] *, [data-yl-pinned]::before, [data-yl-pinned]::after { visibility: hidden !important; background: none !important; box-shadow: none !important; border-color: transparent !important; }
mark[data-yl-find] { background: rgba(255, 215, 49, 0.6) !important; color: inherit !important; border-radius: 2px; }
mark[data-yl-find][data-active] { background: #ff9632 !important; }
[data-yl-box] { visibility: visible !important; }
[data-yl-box]::before, [data-yl-box]::after { visibility: visible !important; }
yl-m { display: contents !important; }
yl-m, yl-m *, yl-m *::before, yl-m *::after,
[data-yl-all], [data-yl-all] *, [data-yl-all]::before, [data-yl-all]::after,
[data-yl-all] *::before, [data-yl-all] *::after { visibility: visible !important; }
yl-m[data-pending] > * , yl-m[data-pending] { opacity: 0.45; }
[data-yl-hidden] { display: none !important; }
`;function Nn(){try{return!!window.frameElement?.hasAttribute(Rn)}catch{return!1}}var Xe=class{constructor(e,t,n,r){this.sourceScroller=t;this.onClick=n;this.onKey=r;this.frame=document.createElement("iframe"),this.frame.setAttribute(Rn,""),this.frame.setAttribute("sandbox","allow-same-origin"),this.frame.setAttribute("tabindex","-1"),e.append(this.frame),this.build()}frame;doc;map=new WeakMap;observer;build(){let e=this.frame.contentDocument;if(!e)throw new Error("mirror frame has no document");this.doc=e;let t=e.importNode(document.documentElement,!0),n=[];this.pair(document.documentElement,t,n);for(let r of n)r.remove();e.replaceChild(t,e.documentElement),this.addStyles(t),e.addEventListener("click",this.handleClick,!0),e.addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutations),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:zr}),this.copyScroll()}pair(e,t,n){if(this.map.set(e,t),t.nodeType===Node.ELEMENT_NODE){let s=t;if(Cn.has(s.localName)){n.push(s);return}this.clean(s);let a=fe(e);a&&this.copyShadow(a,s,n)}let r=e.childNodes,i=t.childNodes;for(let s=0;s<r.length;s++){let a=r[s],l=i[s];a&&l&&this.pair(a,l,n)}}copyShadow(e,t,n){let r;try{r=t.attachShadow({mode:"open"})}catch{return}let i=this.doc.createElement("style");i.textContent=An,r.append(i);for(let s of Array.from(e.childNodes)){let a=this.doc.importNode(s,!0);r.append(a),!(s.nodeType===Node.ELEMENT_NODE&&s.localName==="style")&&this.pair(s,a,n)}}clean(e){for(let n of Array.from(e.attributes))n.name.toLowerCase().startsWith("on")&&e.removeAttribute(n.name);let t=e.localName;(t==="video"||t==="audio")&&(e.removeAttribute("autoplay"),e.removeAttribute("src")),t==="img"&&e.removeAttribute("loading")}addStyles(e){let t=e.querySelector("head");t||(t=this.doc.createElement("head"),e.prepend(t));let n=(i,s)=>{let a=this.doc.createElement("style");s&&(a.media=s),a.textContent=Array.from(i,l=>l.cssText).join(`
`),t.append(a)};for(let i of Array.from(document.styleSheets)){let s=i.ownerNode;if(s&&s.closest("yl-ui"))continue;let a=null;try{a=i.cssRules}catch{}if(a)n(a,i.media.mediaText||void 0);else if(i.href){let l=this.doc.createElement("link");l.rel="stylesheet",l.href=i.href,i.media.mediaText&&(l.media=i.media.mediaText);let c=s?.getAttribute("crossorigin");c!=null&&l.setAttribute("crossorigin",c),t.append(l)}}try{for(let i of Array.from(document.adoptedStyleSheets??[]))n(i.cssRules)}catch{}let r=this.doc.createElement("style");r.textContent=An,t.append(r)}onMutations=e=>{for(let t of e){if(t.type==="attributes"){let r=this.map.get(t.target),i=t.attributeName;if(!r||!i)continue;let s=t.target.getAttribute(i);s===null?r.removeAttribute(i):r.setAttribute(i,s);continue}let n=this.map.get(t.target);if(n)for(let r of Array.from(t.addedNodes)){if(this.map.has(r)||r.nodeType===Node.ELEMENT_NODE&&Cn.has(r.localName))continue;let i=this.doc.importNode(r,!0),s=[];this.pair(r,i,s);for(let l of s)l.remove();let a=r.nextSibling?this.map.get(r.nextSibling):null;n.insertBefore(i,a&&a.parentNode===n?a:null)}}};handleClick=e=>{let t=e.target;if(!t||t.nodeType!==Node.ELEMENT_NODE)return;let n=t,r=n.closest("a[href]");if(e.preventDefault(),r&&/^https?:/i.test(r.href)){window.open(r.href,"_blank","noopener");return}this.onClick(n,e)};revealBoxes(e){for(let t=e;t&&t.nodeType===Node.ELEMENT_NODE;t=t.parentNode){let n=t;if(n.hasAttribute("data-yl-box"))return;n.setAttribute("data-yl-box","")}}showRun(e,t){let n=e.map(s=>this.map.get(s)).filter(s=>!!s&&!!s.parentNode),r=n[0];if(!r?.parentNode)return null;let i=this.doc.createElement("yl-m");t&&i.setAttribute("data-pending",""),r.parentNode.insertBefore(i,r);for(let s of n)i.append(s);return this.revealBoxes(i.parentNode),i}showWhole(e){let t=this.map.get(e);return t?(t.setAttribute("data-yl-all",""),this.revealBoxes(t.parentNode),t):null}setTranslation(e,t,n,r){let i=this.doc.createDocumentFragment();this.append(i,t,n);let s=ce(t);for(let a of r){let l=n[a];if(l?.atomic&&!s.has(a)){let c=this.copyAtomic(l);c&&i.append(this.doc.createTextNode(" "),c)}}e.replaceChildren(i),e.removeAttribute("data-pending")}setKept(e){e.removeAttribute("data-pending")}copyAtomic(e){let t=this.map.get(e.el);return t?t.cloneNode(!0):this.doc.importNode(e.el,!0)}append(e,t,n){t.forEach((r,i)=>{if(typeof r=="string"){r.split(`
`).forEach((c,d)=>{d>0&&e.appendChild(this.doc.createElement("br")),c&&e.appendChild(this.doc.createTextNode(c))});return}let s=n[r.slot];if(!s)return;if(s.atomic){let c=t[i-1],d=t[i+1];typeof c=="string"&&qr.test(c)&&e.appendChild(this.doc.createTextNode(" "));let u=this.copyAtomic(s);u&&e.appendChild(u),typeof d=="string"&&jr.test(d)&&e.appendChild(this.doc.createTextNode(" "));return}let a=this.map.get(s.el),l=a?a.cloneNode(!1):this.doc.importNode(s.el,!1);this.append(l,r.children,n),e.appendChild(l)})}get scroller(){return this.sourceScroller?this.map.get(this.sourceScroller)??null:this.doc.scrollingElement}copyScroll(){let e=this.scroller;e&&(e.scrollTop=this.sourceScroller?this.sourceScroller.scrollTop:scrollY)}get scrollerTop(){let e=this.scroller;return!e||e===this.doc.scrollingElement?0:Math.max(0,e.getBoundingClientRect().top)}alignTo(e,t){let n=this.scroller;if(!n)return;let r=this.doc.createRange();r.selectNodeContents(e);let i=r.getBoundingClientRect();if(!i.width&&!i.height)return;let s=i.top-t;Math.abs(s)>.5&&(n.scrollTop+=s)}hidePinned(){for(let e of Array.from(this.doc.querySelectorAll("body *"))){let t=this.frame.contentWindow?.getComputedStyle(e).position;(t==="fixed"||t==="sticky")&&e.setAttribute("data-yl-pinned","")}}textOf(e){return e.textContent??""}destroy(){this.observer?.disconnect(),this.observer=void 0,this.frame.remove()}};var Gr=new Set(["a","b","strong","i","em","u","s","del","ins","mark","sub","sup","abbr","cite","q","small","big","font","dfn","strike","label"]),Kr=["fontWeight","fontStyle","color","backgroundColor","textDecorationLine","fontSize","fontFamily"];function Xr(o){let e=o.parentElement;if(!e)return!0;let t=getComputedStyle(o),n=getComputedStyle(e);return t.display!=="inline"?!0:Kr.some(r=>t[r]!==n[r])}var Ln=4;function Pt(o){return o==="inline-block"||o==="inline-flex"||o==="inline-grid"}function Vr(o){let e=getComputedStyle(o);return Pt(e.display)?!0:parseFloat(e.marginLeft)>=Ln||parseFloat(e.marginRight)>=Ln}function Yr(o){let e=[];for(let n of o)if(n.nodeType===Node.TEXT_NODE)e.push(n);else if(n.nodeType===Node.ELEMENT_NODE){let r=document.createTreeWalker(n,NodeFilter.SHOW_TEXT);for(let i=r.nextNode();i;i=r.nextNode())e.push(i)}let t=[];for(let n=e.length-1;n>=0;n--){let r=e[n];if(Ve(r.data)||t.some(s=>s.contains(r)))continue;let i=Jr(r,o);if(!i)break;t.unshift(i)}return new Set(t)}function Jr(o,e){let t=null;for(let n=o.parentElement;n;n=n.parentElement){if(e.includes(n))return t;Pt(getComputedStyle(n).display)&&(t=n)}return null}function Ve(o){return!/[^ \t\r\n\f]/.test(o)}var ge=class{classifier=new ze;kinds=new WeakMap;blockDescendant=new WeakMap;reset(){this.kinds=new WeakMap,this.blockDescendant=new WeakMap}kindOf(e){let t=this.kinds.get(e);return t===void 0&&(t=this.classifier.classify(e),this.kinds.set(e,t)),t}*scan(e,t,n=!1){let r=[],i=0,s=()=>{if(r.length){let a=this.buildRun(r,e,n);a?t.emit(a):t.plain?.(r,e)}r=[],i=0};for(let a of Array.from(e.childNodes)){if(t.consume(a)){s();continue}if(a.nodeType===Node.TEXT_NODE){let d=Ve(a.data);d||(i=0),(!d||r.length)&&r.push(a);continue}if(a.nodeType!==Node.ELEMENT_NODE)continue;let l=a;switch(this.kindOf(l)){case"own":case"hidden":break;case"collapsed":yield*this.scan(l,t,n||Ge(l));break;case"skip":s(),t.skipped?.(l);break;case"br":r.length&&r.push(l),++i>=2&&s();break;case"atomic":i=0,r.push(l);break;case"inline":this.isolatedInlineBlock(l,e)||this.hasBlockDescendant(l)?(s(),yield*this.scan(l,t,n||Ge(l))):(i=0,r.push(l));break;case"block":{s();let d=n||Ge(l);yield*this.scan(l,t,d);let u=fe(l);u&&(t.shadowRoot(u),yield*this.scan(u,t,d)),yield;break}}}if(s(),e.nodeType===Node.ELEMENT_NODE&&!Zr(e)){let a=fe(e);a&&(t.shadowRoot(a),yield*this.scan(a,t,n))}}isolatedInlineBlock(e,t){if(!Pt(getComputedStyle(e).display))return!1;for(let n of Array.from(t.childNodes))if(n.nodeType===Node.TEXT_NODE&&!Ve(n.data))return!1;return!0}hasBlockDescendant(e){let t=this.blockDescendant.get(e);if(t!==void 0)return t;let n=!1;for(let r of Array.from(e.children)){let i=this.kindOf(r);if(i==="block"||i==="skip"||i==="inline"&&this.hasBlockDescendant(r)){n=!0;break}}return this.blockDescendant.set(e,n),n}buildRun(e,t,n){let r=[],i=t.nodeType===Node.ELEMENT_NODE?t:t.host,s=getComputedStyle(i).whiteSpace,a=s==="pre-line"||s==="pre-wrap"||s==="pre"||s==="break-spaces",l=[],c=[],d=Yr(e);for(let p of e)this.serialize(p,a,r,c,l,d);for(let p of d){c.push(`
`);let f=r.length;this.serialize(p,a,r,c,l);let m=r[f];m&&(m.detached=!0)}let u=Pn(l.join(""));if(!Ke(u))return null;let h=e.slice();for(;h.length>1;){let p=h[h.length-1];if(!(p.nodeType===Node.TEXT_NODE?Ve(p.data):p.localName==="br"))break;h.pop()}return{nodes:h,parent:t,markup:Pn(c.join("")),slots:r,text:u,compact:n}}serialize(e,t,n,r,i,s){if(s?.has(e))return;if(e.nodeType===Node.TEXT_NODE){let h=e.data,p=t?h.replace(/[ \t\r\f]+/g," "):h.replace(/[ \t\r\n\f]+/g," ");r.push(X(p)),i.push(p);return}if(e.nodeType!==Node.ELEMENT_NODE)return;let a=e,l=this.kindOf(a);if(l==="br"){r.push(`
`),i.push(`
`);return}if(l==="hidden"||l==="collapsed"||l==="own"||l==="skip")return;if(l==="atomic"){let h=n.length;n.push({el:a,atomic:!0});let p=(a.textContent??"").replace(/\s+/g," ").trim()||a.getAttribute("alt")||"•";r.push(`<x${h}>${X(p)}</x${h}>`);return}let c=Gr.has(a.localName)||Xr(a),d=c?n.length:-1,u=Vr(a);u&&(r.push(" "),i.push(" ")),c&&(n.push({el:a,atomic:!1}),r.push(`<x${d}>`));for(let h of Array.from(a.childNodes))this.serialize(h,t,n,r,i,s);c&&r.push(`</x${d}>`),u&&(r.push(" "),i.push(" "))}};function Zr(o){return o.localName.includes("-")}function Pn(o){return o.replace(/ *\n */g,`
`).replace(/ {2,}/g," ").trim()}function Hn(o,e){let t=o.nodeType===Node.ELEMENT_NODE?o:o.parentNode;for(;t;){if(t.nodeType===Node.DOCUMENT_FRAGMENT_NODE)return t;if(t.nodeType!==Node.ELEMENT_NODE)return null;let n=t,r=e.kindOf(n);if(r==="block"||r==="collapsed"||n===document.body)return n;if(r==="skip"||r==="hidden")return null;t=n.parentNode}return null}var Ye=new WeakSet;function Ht(o){for(let e of Array.from(o.querySelectorAll("yl-t,yl-r")))Ye.has(e)||e.remove();for(let e of Array.from(o.querySelectorAll("[data-yl-hidden]")))Ye.has(e)||e.removeAttribute("data-yl-hidden")}var Qr=.98;function ei(o){let e=/^rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(o);return e?.2126*Number(e[1])+.7152*Number(e[2])+.0722*Number(e[3])>140:!1}function Je(o,e,t){if(!e||!o.detected||o.score===void 0||o.score>=Qr)return!1;let n=o.detected.split("-")[0];return n!==e&&n!==t.split("-")[0]}var It=new WeakMap,ti=24,ni=new Set(["en","fr","de","es","pt","it","nl","pl","tr","vi","id"]),oi=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,ri=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,be=class{constructor(e){this.run=e;this.wire=e.markup}state="idle";raw;wire;from="";fallback;hoverHost=null;tree;renderedMode;inserted;textBackup=new Map;written=new Map;hidden=[];unclamped;get markup(){return this.run.markup}get text(){return this.run.text}get compact(){return this.run.compact}get isRendered(){return this.renderedMode!==void 0}get rendersInPlace(){return this.renderedMode==="replace"}get anchor(){let e=this.parentElement;for(let t of this.run.nodes)if(t.nodeType===Node.ELEMENT_NODE){e=t;break}for(;e.parentElement&&getComputedStyle(e).display==="contents";)e=e.parentElement;return e}get parentElement(){let e=this.run.parent;return e.nodeType===Node.ELEMENT_NODE?e:e.host}sourceHint(){if(this.text.length>ti||/[^\p{Script=Latin}\P{L}]/u.test(this.text))return"";let t=this.parentElement.closest("[lang]")?.getAttribute("lang")?.split("-")[0]?.toLowerCase()??"";return ni.has(t)?t:""}regionContent(e){let t=this.parentElement,n=this.sourceHint();if(this.rendersInPlace){let g=this.hoverHost;return{markup:this.markup,slots:this.run.slots,text:this.text,hint:n,block:t,rect:()=>g?.getBoundingClientRect()??null}}let r=new Map(this.run.slots.map((g,b)=>[g.el,b])),i=[],s=[],a=g=>{let b=g.left+g.width/2,x=g.top+g.height/2;return g.width>0&&b>=e.left&&b<=e.right&&x>=e.top&&x<=e.bottom},l=document.createRange(),c=!1,d=(g,b,x,E)=>{c||(l.setStart(g,b),c=!0),l.setEnd(x,E)},u=new Intl.Segmenter(void 0,{granularity:"word"}),h=document.createRange(),p=g=>{if(g.nodeType===Node.TEXT_NODE){for(let T of u.segment(g.data)){if(!T.isWordLike&&!/\S/.test(T.segment)){i.push(" "),s.push(" ");continue}h.setStart(g,T.index),h.setEnd(g,T.index+T.segment.length),a(h.getBoundingClientRect())&&(i.push(X(T.segment)),s.push(T.segment),d(g,T.index,g,T.index+T.segment.length))}return}if(g.nodeType!==Node.ELEMENT_NODE)return;let b=g;if(b.localName==="br"){i.push(`
`);return}if(me.has(b.localName))return;let x=r.get(b);if(x!==void 0&&this.run.slots[x].atomic){if(Array.from(b.getClientRects()).some(a)){i.push(`<x${x}>${X((b.textContent??"").trim()||"•")}</x${x}>`);let T=b.parentNode,C=Array.from(T.childNodes).indexOf(b);d(T,C,T,C+1)}return}let E=i.length;x!==void 0&&i.push(`<x${x}>`);for(let T of Array.from(b.childNodes))p(T);x!==void 0&&(i.slice(E+1).join("").trim()?i.push(`</x${x}>`):i.length=E)};for(let g of this.run.nodes)p(g);let f=i.join("").replace(/\s+/g,g=>g.includes(`
`)?`
`:" ").trim(),m=s.join("").replace(/\s+/g," ").trim();return!c||!Ke(m)?null:{markup:f,slots:this.run.slots,text:m,hint:n,block:t,rect:()=>l.getBoundingClientRect()}}clientRects(){let e=this.run.nodes,t=e[0],n=e[e.length-1];if(!t||!n||!t.isConnected)return[];if(this.rendersInPlace&&this.inserted)return Array.from(this.inserted.getClientRects());let r=document.createRange();return r.setStartBefore(t),r.setEndAfter(n),Array.from(r.getClientRects())}setTranslation(e){this.raw=e;let t=new Set(this.run.slots.map((n,r)=>r));this.tree=Ee(V(e,t),n=>!!this.run.slots[n]?.detached)}renderStatus(e,t,n){if(t.mode!=="dual"||this.renderedMode||this.compact)return;this.removeInserted();let r=document.createElement("yl-t");r.setAttribute("data-state",e),r.style.setProperty("--yl-theme",t.theme),e==="error"&&(r.setAttribute("data-yl-retry",""),r.textContent=n),this.insertAfterRun(r),this.inserted=r}clearStatus(){this.renderedMode||this.removeInserted()}render(e){this.tree&&(this.unrender(),e.mode==="dual"&&!this.compact?(this.renderDual(e),this.renderedMode="dual"):(this.renderReplace(e),this.renderedMode="replace"))}unrender(){this.removeInserted();for(let[e,t]of this.textBackup)e.data===this.written.get(e)&&(e.data=t);this.textBackup.clear(),this.written.clear();for(let e of this.hidden)e.removeAttribute("data-yl-hidden");this.hidden=[],this.unclamped?.removeAttribute("data-yl-unclamp"),this.unclamped=void 0,this.renderedMode=void 0,this.hoverHost=null}isIntact(){for(let e of this.run.nodes)if(!e.isConnected||e.parentNode!==this.run.parent)return!1;for(let[e,t]of this.written)if(e.data!==t)return!1;return!0}applyDualStyle(e){this.renderedMode==="dual"&&this.inserted&&this.decorate(this.inserted,e)}renderDual(e){let t=document.createElement("yl-t");t.setAttribute("lang",e.targetLang),t.setAttribute("dir","auto"),this.decorate(t,e),this.shouldBeInline()&&t.setAttribute("data-inline","");let n=document.createElement("yl-i");n.append(this.buildFragment()),t.append(n),this.insertAfterRun(t),this.inserted=t,this.hoverHost=t;let r=this.parentElement;getComputedStyle(r).webkitLineClamp!=="none"&&getComputedStyle(r).webkitLineClamp!==""&&(r.setAttribute("data-yl-unclamp",""),this.unclamped=r)}decorate(e,t){t.dualStyle==="plain"?e.removeAttribute("data-style"):e.setAttribute("data-style",t.dualStyle);let n=e,r=ei(getComputedStyle(this.parentElement).color);n.style.setProperty("--yl-theme",_e(t.theme,r?ln:De)),r?e.setAttribute("data-tone","dark"):e.removeAttribute("data-tone"),n.style.fontSize=t.fontScale===100?"":`${t.fontScale}%`}shouldBeInline(){let e=this.parentElement,t=getComputedStyle(e);return t.whiteSpace==="nowrap"||t.whiteSpace==="pre"||t.display==="inline"||t.display==="inline-block"?!0:t.display.includes("flex")?!t.flexDirection.startsWith("column"):t.display.includes("grid")}renderReplace(e){let t=this.run.nodes,n=this.tree.some(s=>typeof s=="string"&&s.includes(`
`));if(t.every(s=>s.nodeType===Node.TEXT_NODE)&&!n&&this.run.slots.length===0){let s=this.tree.map(a=>typeof a=="string"?a:"").join("");t.forEach((a,l)=>{let c=a;this.textBackup.set(c,c.data);let d="";l===0&&(d=(/^\s/.test(c.data)?" ":"")+s),c.data=d,this.written.set(c,d)}),this.hoverHost=this.parentElement;return}for(let s of t)if(s.nodeType===Node.TEXT_NODE){let a=s;this.textBackup.set(a,a.data),a.data="",this.written.set(a,"")}else if(s.nodeType===Node.ELEMENT_NODE){let a=s;a.setAttribute("data-yl-hidden",""),Ye.add(a),this.hidden.push(a)}let i=document.createElement("yl-r");i.setAttribute("lang",e.targetLang),i.append(this.buildFragment()),this.insertAfterRun(i),this.inserted=i,this.hoverHost=i}insertAfterRun(e){Ye.add(e);let t=this.run.nodes[this.run.nodes.length-1];t.parentNode?.insertBefore(e,t.nextSibling)}removeInserted(){this.inserted?.remove(),this.inserted=void 0}buildFragment(){let e=document.createDocumentFragment();this.appendNodes(e,this.tree);let t=ce(this.tree);return this.run.slots.forEach((n,r)=>{n.atomic&&!t.has(r)&&e.append(" ",this.cloneSlot(n))}),e}appendNodes(e,t){t.forEach((n,r)=>{if(typeof n=="string"){this.appendText(e,n);return}let i=this.run.slots[n.slot];if(!i)return;if(i.atomic){let a=t[r-1],l=t[r+1];typeof a=="string"&&oi.test(a)&&e.appendChild(document.createTextNode(" ")),e.appendChild(this.cloneSlot(i)),typeof l=="string"&&ri.test(l)&&e.appendChild(document.createTextNode(" "));return}let s=this.cloneShell(i);this.appendNodes(s,n.children),e.appendChild(s)})}appendText(e,t){t.split(`
`).forEach((r,i)=>{i>0&&e.appendChild(document.createElement("br")),r&&e.appendChild(document.createTextNode(r))})}cloneSlot(e){let t=e.el.cloneNode(!0);t.removeAttribute("id"),t.removeAttribute("data-yl-hidden");for(let n of t.querySelectorAll("[id]"))n.removeAttribute("id");return t}cloneShell(e){let t=e.el.cloneNode(!1);return t.removeAttribute("id"),t.removeAttribute("data-yl-hidden"),It.set(t,e.el),t.style?.setProperty("--yl-c",getComputedStyle(e.el).color),t}};var In=`/* Injected into pages and shadow roots. Fonts and colours are inherited on purpose. */

yl-t {
  display: block !important;
  margin: 0.3em 0 0 !important;
  padding: 0;
  font-family: inherit;
  font-weight: inherit;
  line-height: inherit;
  color: inherit;
  white-space: normal !important;
  text-indent: 0;
  letter-spacing: normal;
  overflow-wrap: break-word;
  max-width: 100%;
  float: none !important;
  position: static !important;
}

yl-t[data-inline] {
  display: inline !important;
  margin: 0 0 0 0.5em !important;
  white-space: inherit !important;
}

yl-r {
  display: inline;
  font: inherit;
  color: inherit;
}

/*
 * One colour the reader picks, the same on every page. Its value is set on each translation.
 * The full palette belongs on thin frames only.
 */
/* Copying allowed again, by the reader's choice: text can be selected whatever the page says. */
html[data-yl-unlock] *:not(input):not(textarea) {
  -webkit-user-select: text !important;
  user-select: text !important;
}

yl-t {
  --yl-theme: #1f77f3;
  --yl-pen: 30%;
}

/* See-through colour dims over black: this much more looks the same as it does on white. */
yl-t[data-tone='dark'] {
  --yl-pen: 62%;
}

yl-t[data-style='accent'] {
  color: var(--yl-theme);
}

/* Links stay recognisably links; other coloured text leans to the ink. */
yl-t[data-style='accent'] a[style*='--yl-c'] {
  color: color-mix(in oklab, var(--yl-c) 65%, var(--yl-theme)) !important;
}

yl-t[data-style='accent'] [style*='--yl-c']:not(a) {
  color: color-mix(in oklab, var(--yl-c) 20%, var(--yl-theme)) !important;
}

yl-t[data-style='faded'] {
  opacity: 0.72;
}

yl-t[data-style='underline'] {
  text-decoration: underline dashed 1px var(--yl-theme);
  text-underline-offset: 0.32em;
}

/* A capsule that stops short of the block's ends, so it sits beside the text and not on it. */
yl-t[data-style='bar']:not([data-inline]) {
  position: relative !important;
  padding-left: 0.8em !important;
}

yl-t[data-style='bar']:not([data-inline])::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0.22em;
  bottom: 0.22em;
  width: 3px;
  border-radius: 3px;
  background: linear-gradient(180deg, var(--yl-theme), color-mix(in srgb, var(--yl-theme) 55%, transparent));
}

yl-t[data-style='bar'][data-inline] {
  color: var(--yl-theme);
}

/*
 * A highlighter pen that fades out upward, with no top edge to read as a band. It has to be
 * drawn on an inline box, because that is what follows each line of the text.
 */
yl-i {
  display: inline;
}

yl-t[data-style='highlight'] yl-i {
  background: linear-gradient(to top, color-mix(in srgb, var(--yl-theme) var(--yl-pen), transparent), transparent 78%);
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}

yl-t[data-state='loading'] {
  display: inline-block !important;
  width: 1.5em;
  height: 0.7em;
  margin: 0 0 0 0.4em !important;
  vertical-align: baseline;
  background-image:
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent);
  background-position: 0 50%, 50% 50%, 100% 50%;
  background-repeat: no-repeat;
  background-size: 0.26em 0.26em;
  opacity: 0.7;
  animation: yl-wave 1.05s ease-in-out infinite;
}

yl-t[data-state='error'] {
  font-size: 0.82em;
  color: #c62828;
  cursor: pointer;
  text-decoration: underline;
  text-underline-offset: 0.2em;
}

[data-yl-hidden] {
  display: none !important;
}

[data-yl-unclamp] {
  -webkit-line-clamp: unset !important;
  max-height: none !important;
  overflow: visible !important;
}

@keyframes yl-wave {
  0%,
  100% {
    background-size: 0.42em 0.42em, 0.26em 0.26em, 0.26em 0.26em;
  }
  33% {
    background-size: 0.26em 0.26em, 0.42em 0.42em, 0.26em 0.26em;
  }
  66% {
    background-size: 0.26em 0.26em, 0.26em 0.26em, 0.42em 0.42em;
  }
}

@media (prefers-reduced-motion: reduce) {
  yl-t[data-state='loading'] {
    animation: none;
  }
}
`;var ee=class{constructor(e,t){this.node=e;this.scrollers=t}animations=[];ranges="";movedByY=[];movedByX=[];left=NaN;top=NaN;place(e,t){this.follow();let n=this.node.getRootNode(),r=n instanceof ShadowRoot?n.host.getBoundingClientRect():{left:0,top:0},i=e-r.left,s=t-r.top;for(let a of this.movedByX)i+=a.scrollLeft;for(let a of this.movedByY)s+=a.scrollTop;Math.abs(i-this.left)<.5&&Math.abs(s-this.top)<.5||(this.left=i,this.top=s,this.node.style.left=`${i}px`,this.node.style.top=`${s}px`)}follow(){let e=globalThis.ScrollTimeline;if(!e)return;let t=this.scrollers.map(r=>[r,r.scrollHeight-r.clientHeight,r.scrollWidth-r.clientWidth]),n=t.map(([,r,i])=>`${r},${i}`).join(";");if(n!==this.ranges){this.ranges=n;for(let r of this.animations)r.cancel();this.animations=[],this.movedByY=[],this.movedByX=[];for(let[r,i,s]of t)i>0&&(this.animations.push(this.travel(new e({source:r,axis:"block"}),`translateY(${-i}px)`)),this.movedByY.push(r)),s>0&&(this.animations.push(this.travel(new e({source:r,axis:"inline"}),`translateX(${-s}px)`)),this.movedByX.push(r))}}travel(e,t){return this.node.animate({transform:["translate(0, 0)",t]},{timeline:e,fill:"both",easing:"linear",composite:"add"})}};var Dn=4,te=8,si=.6,ai=.8;function ye(o){let e=[];for(let t=o;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t);(/auto|scroll/.test(n.overflowY)||/auto|scroll/.test(n.overflowX))&&(t.scrollHeight>t.clientHeight+1||t.scrollWidth>t.clientWidth+1)&&e.push({el:t,top:t.scrollTop,left:t.scrollLeft})}return e}function li(o){if(o.scrollHeight<=o.clientHeight+1&&o.scrollWidth<=o.clientWidth+1)return!1;let e=getComputedStyle(o);return/auto|scroll/.test(e.overflowY)||/auto|scroll/.test(e.overflowX)}function _n(o,e){let t=e.getBoundingClientRect();if(o.left>t.left+te||o.right<t.right-te)return!1;let n=Math.max(t.top,0),r=Math.min(t.bottom,innerHeight);return r<=n?!1:Math.min(o.bottom,r)-Math.max(o.top,n)>=(r-n)*ai}function On(o){let e=[];for(let t of Array.from(document.querySelectorAll("body *")))!li(t)||!_n(o,t)||e.some(n=>n.contains(t))||e.push(t);return e}function ci(o,e){if(_n(e,o))return!1;let t=o.getBoundingClientRect();if(e.top>=t.top-te&&e.bottom<=t.bottom+te&&e.left>=t.left-te&&e.right<=t.right+te)return!0;let r=getComputedStyle(o);return/auto|scroll/.test(r.overflowY)&&o.scrollHeight>o.clientHeight+1&&o.clientHeight>=innerHeight*si}var Ze=class{constructor(e){this.ui=e}box;rect;scrollers=[];windowTop=0;windowLeft=0;frameRequest=0;bounds={top:-1/0,bottom:1/0};framePin;over=!1;beyondArea=!1;showPending(e){this.close();let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scrollers=ye(t).filter(i=>ci(i.el,e)),this.windowTop=scrollY,this.windowLeft=scrollX;let n=Se();this.over=n.top>0&&e.top<n.top-1||n.bottom<innerHeight&&e.bottom>n.bottom+1;let r=this.scrollers[0]?.el.getBoundingClientRect();this.beyondArea=!!r&&(e.top<r.top-te||e.bottom>r.bottom+te),this.rect=this.visible(e),this.box=this.ui.addFrame(!0,!0,this.over),this.framePin=new ee(this.box,this.scrollers.map(i=>i.el)),this.reposition(),addEventListener("scroll",this.requestReposition,!0),addEventListener("resize",this.requestReposition)}visible(e){let t=Dn+2,n=this.beyondArea?void 0:this.scrollers[0]?.el.getBoundingClientRect(),r={left:t,right:(document.documentElement.clientWidth||innerWidth)-t,top:Math.max(0,n?.top??0)+t,bottom:Math.min(innerHeight,n?.bottom??1/0)-t},i={...e},s=Math.max(e.left,r.left),a=Math.min(e.right,r.right);a-s>t*2&&Object.assign(i,{left:s,right:a});let l=Math.max(e.top,r.top),c=Math.min(e.bottom,r.bottom);return c-l>t*2&&Object.assign(i,{top:l,bottom:c}),i}settle(e){return e?(this.box&&(this.ui.setFramePending(this.box,!1),this.ui.addToPage(this.box,this.over)),!0):(this.close(),!1)}clip(e,t,n,r){let i=t?.getBoundingClientRect(),s=this.over?{top:-1/0,bottom:1/0}:this.bounds,a=Math.max(0,Math.max(i?.top??-1/0,s.top)-n),l=Math.max(0,r-Math.min(i?.bottom??1/0,s.bottom)),c=Dn,d=u=>u?`${u}px`:`-${c}px`;e.style.clipPath=a||l?`inset(${d(a)} -${c}px ${d(l)} -${c}px)`:""}requestReposition=()=>{this.frameRequest||(this.frameRequest=requestAnimationFrame(this.reposition))};reposition=()=>{this.frameRequest=0,this.bounds=this.ui.settleUnderBars();let e=this.rect;if(!this.box||!e)return;let t=this.windowTop-scrollY,n=this.windowLeft-scrollX;for(let s of this.scrollers)t+=s.top-s.el.scrollTop,n+=s.left-s.el.scrollLeft;let r=e.top+t,i=e.bottom-e.top;this.framePin?.place(U(e.left+n),U(r)),Object.assign(this.box.style,{width:`${U(e.right-e.left)}px`,height:`${U(i)}px`}),this.clip(this.box,this.beyondArea?void 0:this.scrollers[0]?.el,r,r+i)};close(){removeEventListener("scroll",this.requestReposition,!0),removeEventListener("resize",this.requestReposition),cancelAnimationFrame(this.frameRequest),this.frameRequest=0,this.box?.remove(),this.box=void 0,this.framePin=void 0,this.over=!1,this.beyondArea=!1,this.rect=void 0,this.scrollers=[]}get emptyMessage(){return y("marqueeEmpty")}};var di=3e4,Bn=150,ui=30,pi=5e3,$n=4,hi=60,mi=400,fi=300,gi=8,bi="800px 0px",yi=8,vi=3e4,wi=450,xi=2,Ei=3e3,Qe=class{constructor(e,t){this.ui=t;this.settings=e,this.scanner.classifier.setExcludes(e.excludeSelectors),document.addEventListener("click",this.onClick,!0),document.addEventListener("mouseover",this.onMouseOver,!0),document.addEventListener("mouseout",this.onMouseOut,!0)}settings;scanner=new ge;segments=new Set;byNode=new WeakMap;byAnchor=new Map;styledRoots=new WeakSet;watchedRoots=[];pageActive=!1;generation=0;io;mo;queue=[];inFlight=0;flushTimer;dirty=new Set;dirtyTimer;rebuilds=new WeakMap;lastError;errorToastShown=!1;statusTimer;pageLang;hoverTimer;hoverSeg;hoverHosts=new WeakMap;get active(){return this.pageActive}get hasTranslations(){for(let e of this.segments)if(e.isRendered||e.state==="loading"||e.state==="queued")return!0;return!1}get hasPageTranslations(){for(let e of this.segments)if(!this.regionSegs.has(e)&&(e.isRendered||e.state==="loading"||e.state==="queued"))return!0;return!1}setPageLang(e){this.pageLang=e}get display(){let e=this.settings;return{mode:e.mode,dualStyle:e.dualStyle,fontScale:e.fontScale,targetLang:e.targetLang,theme:ue(e.themeColor)}}regionSegs=new Set;displayFor(e){return this.regionSegs.has(e)?{...this.display,mode:"replace"}:this.display}async translateRegion(e){if(!document.body)return 0;await this.scanRoot(document.body);let t=On(e),n=[];for(let r of this.segments)r.state==="done"&&!this.regionSegs.has(r)||!t.some(s=>s.contains(r.parentElement))&&!Ti(r.clientRects(),e)||ke(r.text,this.settings.targetLang)||n.push(r);this.ownWrite(()=>{for(let r of n)this.regionSegs.add(r),r.state==="done"?(r.render(this.displayFor(r)),r.hoverHost&&this.hoverHosts.set(r.hoverHost,r)):r.state==="failed"&&(r.clearStatus(),r.state="idle")});for(let r of n)this.enqueue(r);return this.reportStatus(),n.length}async regionSettled(){for(let e=0;e<di;e+=Bn){if(![...this.regionSegs].some(t=>t.state==="queued"||t.state==="loading"))return;await new Promise(t=>setTimeout(t,Bn))}}restoreRegion(){this.regionSegs.size&&(this.ownWrite(()=>{for(let e of this.regionSegs)e.unrender(),e.clearStatus(),e.state="idle",this.queue=this.queue.filter(t=>t!==e),this.pageActive&&this.enqueue(e)}),this.regionSegs.clear(),this.ui.hideTooltip(),this.pruneIdle(),this.reportStatus())}status(){let e=0,t=0,n=0,r=0;for(let s of this.segments)s.state!=="idle"&&(e++,s.state==="done"||s.state==="same"?t++:s.state==="failed"?n++:r++);let i={active:this.pageActive||this.hasTranslations,mode:this.settings.mode,total:e,done:t,failed:n,pending:r};return this.pageLang&&(i.pageLang=this.pageLang),location.hostname&&(i.host=location.hostname),n>0&&this.lastError&&(i.error=this.lastError),i}reportStatus(){this.statusTimer===void 0&&(this.statusTimer=setTimeout(()=>{this.statusTimer=void 0,j()&&B({type:"status",status:this.status()}).catch(()=>{})},150))}async startPage(){this.pageActive||!document.body||(this.pageActive=!0,this.errorToastShown=!1,this.startObservers(),await this.scanRoot(document.body),this.observeAllEligible(),this.reportStatus())}togglePage(){this.pageActive||this.hasPageTranslations?this.restore():this.startPage()}retire(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.ownWrite(()=>{for(let e of this.segments)e.state==="loading"&&e.clearStatus()})}restore(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.lastError=void 0;for(let e of this.segments)this.dropSegment(e,!0);this.segments.clear(),this.regionSegs.clear(),this.byAnchor.clear(),this.ui.hideTooltip(),this.reportStatus()}setMode(e){this.settings={...this.settings,mode:e},this.rerenderAll(),this.pageActive&&this.observeAllEligible(),this.reportStatus()}retryFailed(){this.errorToastShown=!1,this.lastError=void 0;for(let e of this.segments)e.state==="failed"&&(e.clearStatus(),this.enqueue(e))}applySettings(e){let t=this.settings;if(this.settings=e,e.excludeSelectors!==t.excludeSelectors&&this.scanner.classifier.setExcludes(e.excludeSelectors),(t.targetLang!==e.targetLang||t.sourceLang!==e.sourceLang)&&(this.pageActive||this.hasTranslations)){let r=this.pageActive,i=[...this.segments].filter(s=>s.isRendered);this.generation++,this.queue=[];for(let s of this.segments)s.unrender(),s.clearStatus(),s.state="idle",s.raw=void 0,s.wire=s.markup,s.from="",s.fallback=void 0;if(r)this.observeAllEligible();else for(let s of i)this.enqueue(s);return}t.mode!==e.mode?this.setMode(e.mode):(t.dualStyle!==e.dualStyle||t.fontScale!==e.fontScale||t.themeColor!==e.themeColor)&&this.ownWrite(()=>{for(let r of this.segments)r.applyDualStyle(this.display)})}pruneIdle(){if(!this.pageActive){for(let e of this.segments)if(e.state==="idle"&&!e.isRendered){this.segments.delete(e);for(let t of e.run.nodes)this.byNode.delete(t)}}}hooks={consume:e=>{let t=this.byNode.get(e);return t?.rendersInPlace?t.isIntact()?(this.seen?.add(t),!0):(this.ownWrite(()=>this.dropSegment(t,!0)),this.segments.delete(t),!1):!1},emit:e=>this.register(e),shadowRoot:e=>this.adoptShadowRoot(e)};seen;async scanRoot(e){this.ownWrite(()=>Ht(e)),this.scanner.reset(),this.seen=new Set;let t=this.scanner.scan(e,this.hooks),n=performance.now();for(let r=t.next();!r.done;r=t.next())performance.now()-n>gi&&(await new Promise(i=>setTimeout(i,0)),n=performance.now());this.seen=void 0}register(e){let t=e.nodes[0],n=this.byNode.get(t);if(n&&n.markup===e.markup){this.seen?.add(n);return}n&&(this.ownWrite(()=>this.dropSegment(n,!0)),this.segments.delete(n));let r=new be(e);this.segments.add(r),this.seen?.add(r);for(let i of e.nodes)this.byNode.set(i,r);this.pageActive&&this.observeSegment(r)}observeSegment(e){if(!this.io||e.state!=="idle")return;let t=e.anchor,n=this.byAnchor.get(t);n||(n=new Set,this.byAnchor.set(t,n),this.io.observe(t)),n.add(e)}observeAllEligible(){for(let e of this.segments)this.observeSegment(e)}dropSegment(e,t){t&&(e.unrender(),e.clearStatus()),e.state="idle";for(let r of e.run.nodes)this.byNode.get(r)===e&&this.byNode.delete(r);let n=this.byAnchor.get(e.anchor);n&&(n.delete(e),n.size||(this.byAnchor.delete(e.anchor),this.io?.unobserve(e.anchor)))}adoptShadowRoot(e){if(this.styledRoots.has(e))return;this.styledRoots.add(e);let t=document.createElement("style");t.setAttribute("data-yl",""),t.textContent=In,e.append(t),this.watchedRoots.push(e),this.mo?.observe(e,Dt)}startObservers(){this.io=new IntersectionObserver(this.onIntersect,{rootMargin:bi}),this.mo=new MutationObserver(this.onMutations),document.body&&this.mo.observe(document.body,Dt);for(let e of this.watchedRoots)this.mo.observe(e,Dt)}stopObservers(){this.io?.disconnect(),this.mo?.disconnect(),this.io=void 0,this.mo=void 0}onIntersect=e=>{for(let t of e){if(!t.isIntersecting)continue;let n=this.byAnchor.get(t.target);if(n){for(let r of n)this.enqueue(r);this.byAnchor.delete(t.target)}this.io?.unobserve(t.target)}};ownWrite(e){let t=this.mo?.takeRecords();t?.length&&this.onMutations(t),e(),this.mo?.takeRecords()}onMutations=e=>{for(let t of e){if(Fn(t.target))continue;if(t.type==="childList"){let r=[...Array.from(t.addedNodes),...Array.from(t.removedNodes)];if(r.length&&r.every(Fn))continue}let n=Hn(t.target,this.scanner);n&&this.dirty.add(n)}this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},fi))};async flushDirty(){let e=this.generation,t=[...this.dirty].filter(n=>{for(let r of this.dirty)if(r!==n&&r.contains(n))return!1;return n.isConnected});this.dirty.clear();for(let n of t){if(e!==this.generation||!this.pageActive)return;if(!this.allowRebuild(n)){this.dirty.add(n);continue}let r=[...this.segments].filter(s=>n.contains(s.run.parent));this.ownWrite(()=>Ht(n)),this.scanner.reset(),this.seen=new Set;let i=this.seen;for(let s of this.scanner.scan(n,this.hooks));this.seen=void 0;for(let s of r)i.has(s)||(this.ownWrite(()=>this.dropSegment(s,!0)),this.segments.delete(s))}for(let n of this.segments)n.anchor.isConnected||(this.dropSegment(n,!1),this.segments.delete(n));this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},Ei)),this.reportStatus()}allowRebuild(e){let t=Date.now(),n=this.rebuilds.get(e);return!n||t-n.since>vi?(this.rebuilds.set(e,{n:1,since:t}),!0):(n.n++,n.n<=yi)}enqueue(e,t=!1){if(!(e.state==="done"||e.state==="loading"||e.state==="same")&&!(e.state==="queued"&&!t)){if(ke(e.text,this.settings.targetLang)){e.state="same";return}e.state!=="queued"&&(e.state="queued",t||this.queue.push(e)),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},hi)),this.reportStatus()}}prioritizeQueue(){if(this.queue=this.queue.filter(n=>n.state==="queued"),this.queue.length<2)return;let e=innerHeight,t=new Map;for(let n of this.queue){let r=n.anchor.getBoundingClientRect();t.set(n,r.bottom<0?-r.bottom:r.top>e?r.top-e:0)}this.queue.sort((n,r)=>t.get(n)-t.get(r))}pump(){if(!(this.inFlight>=$n))for(this.prioritizeQueue();this.inFlight<$n&&this.queue.length;){let e=this.settings.sourceLang||this.queue[0].from,t=[],n=[],r=0;for(let i of this.queue)t.length<ui&&(t.length===0||r+i.wire.length<=pi)&&(this.settings.sourceLang||i.from)===e?(t.push(i),r+=i.wire.length):n.push(i);this.queue=n,this.sendBatch(t,e)}}async sendBatch(e,t){let n=this.generation;this.inFlight++;for(let s of e)s.state="loading";let r=setTimeout(()=>{n===this.generation&&this.ownWrite(()=>{for(let s of e)s.state==="loading"&&s.renderStatus("loading",this.displayFor(s),"")})},mi),i;for(let s=0;s<=xi&&!i;s++)try{let a=await B({type:"translate",items:e.map(l=>l.wire),from:t,to:this.settings.targetLang});a?.results?.length===e.length&&(i=a.results)}catch{if(!j())break}if(clearTimeout(r),this.inFlight--,!j()){this.retire();return}n===this.generation&&this.applyResults(e,i),this.pump(),this.reportStatus()}applyResults(e,t){this.ownWrite(()=>{e.forEach((n,r)=>{if(!this.segments.has(n))return;let i=t?.[r]??{ok:!1,code:"network"};if(!i.ok){n.state="failed",this.lastError=i.code,n.clearStatus(),n.renderStatus("error",this.displayFor(n),y("retryInline"));return}if(n.clearStatus(),!this.settings.sourceLang&&!n.from&&Je(i,n.sourceHint(),this.settings.targetLang)){n.fallback=i.text,n.from=n.sourceHint(),n.state="idle",this.enqueue(n);return}let s=n.fallback!==void 0&&this.isUnchanged(n,i.text,void 0)?n.fallback:i.text;if(this.isUnchanged(n,s,i.detected)){if(n.wire===n.markup&&/\s[—–]\s/.test(n.markup)){n.wire=n.markup.replace(/\s[—–]\s/g," - "),n.state="idle",this.enqueue(n);return}n.state="same";return}n.setTranslation(s),n.state="done",n.render(this.displayFor(n)),n.hoverHost&&this.hoverHosts.set(n.hoverHost,n)})}),this.lastError&&!this.errorToastShown&&e.some(n=>n.state==="failed")&&(this.errorToastShown=!0,this.ui.toast(this.ui.errorMessage(this.lastError),{label:y("retry"),run:()=>this.retryFailed()}))}isUnchanged(e,t,n){if(!t.trim())return!0;let r=this.settings.targetLang;return n&&n.split("-")[0]===r.split("-")[0]&&(n===r||!r.startsWith("zh"))?!0:ie(V(t)).trim()===ie(V(e.markup)).trim()}rerenderAll(){this.ownWrite(()=>{for(let e of this.segments)e.state==="done"?(e.render(this.displayFor(e)),e.hoverHost&&this.hoverHosts.set(e.hoverHost,e)):e.state==="failed"&&(e.clearStatus(),e.renderStatus("error",this.displayFor(e),y("retryInline")))})}onClick=e=>{let t=e.composedPath();for(let n of t){if(!(n instanceof Element))continue;if(n.localName==="yl-t"&&n.hasAttribute("data-yl-retry")){e.preventDefault(),e.stopPropagation(),this.retryFailed();return}let r=It.get(n);if(r){if(e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault(),e.stopPropagation(),r.click();return}if(me.has(n.localName))return}};onMouseOver=e=>{if(!this.settings.showOriginalOnHover)return;let t=this.segmentAt(e);if(t===this.hoverSeg||(this.hoverSeg=t,clearTimeout(this.hoverTimer),this.ui.hideTooltip(),!t?.hoverHost))return;let n=t.hoverHost;this.hoverTimer=setTimeout(()=>{t.isRendered&&n.isConnected&&this.ui.showTooltip(ie(V(t.markup)),Si(n))},wi)};onMouseOut=e=>{this.hoverSeg&&!e.relatedTarget&&(this.hoverSeg=void 0,clearTimeout(this.hoverTimer),this.ui.hideTooltip())};segmentAt(e){for(let t of e.composedPath()){if(!(t instanceof Element))continue;let n=this.hoverHosts.get(t);if(n?.rendersInPlace)return n;if(t===document.body)break}}},Dt={childList:!0,characterData:!0,subtree:!0};function Fn(o){let e=o;for(;e;){if(e.nodeType===Node.ELEMENT_NODE&&me.has(e.localName))return!0;e=e.parentNode}return!1}function Si(o){return o.getBoundingClientRect()}function Ti(o,e){for(let t of o){let n=Math.min(t.bottom,e.bottom)-Math.max(t.top,e.top),r=Math.min(t.right,e.right)-Math.max(t.left,e.left),i=t.bottom-t.top;if(i>0&&n>=i/2&&r>=Math.min(24,(t.right-t.left)/2))return!0}return!1}var ki={curl:"bash",bash:"bash",shell:"bash","command line":"bash",命令行:"bash",ruby:"ruby",python:"python",node:"javascript","node.js":"javascript",javascript:"javascript",typescript:"typescript",go:"go",java:"java",php:"php",".net":"csharp","c#":"csharp",html:"html",css:"css",json:"json",yaml:"yaml",sql:"sql"},Wn={js:"javascript",jsx:"jsx",ts:"typescript",tsx:"tsx",py:"python",rb:"ruby",sh:"bash",html:"html",css:"css",json:"json",yml:"yaml",yaml:"yaml",go:"go",java:"java",php:"php",cs:"csharp",sql:"sql",md:"markdown",vue:"vue"};function Un(o){return o.ownerDocument.defaultView?.getComputedStyle(o)??null}function qn(o){return o.getAttribute("aria-hidden")==="true"?!0:Un(o)?.userSelect==="none"}function Mi(o){let e=Un(o)?.display??"";return e==="block"||e==="flex"||e==="grid"||e==="list-item"||e==="table-row"}function jn(o,e){for(let t of Array.from(o.childNodes))if(t.nodeType===3)e.push(t.data);else if(t.nodeType===1){let n=t;if(qn(n))continue;if(n.localName==="br"){e.push(`
`);continue}jn(n,e),Mi(n)&&!(e[e.length-1]??"").endsWith(`
`)&&e.push(`
`)}}function Ci(o){let e=o.localName==="pre"?o:o.querySelector("pre")??o,t=[];return jn(e,t),t.join("").replace(/\n+$/,"")}function Ai(o){let e=[o,...Array.from(o.querySelectorAll("pre,code"))];for(let t of e){let n=/(?:^|\s)(?:language|lang|highlight-source)-([\w+#-]+)/.exec(t.getAttribute("class")??"");if(n?.[1])return n[1].toLowerCase()}return""}function zn(o){let e=o.trim().toLowerCase(),t=/\.([a-z0-9]+)$/.exec(e);return t?.[1]&&Wn[t[1]]?Wn[t[1]]:ki[e]??""}function Ri(o){let e=o.parentElement;for(let t=0;e&&t<4;t++,e=e.parentElement){if(e.querySelectorAll("pre").length>1)return"";for(let n of Array.from(e.querySelectorAll("*"))){if(n.children.length||o.contains(n))continue;let r=zn(n.textContent??"");if(r)return r}}return""}function Ni(o){let e=2;for(let t of o.matchAll(/`+/g))e=Math.max(e,t[0].length);return"`".repeat(e+1)}function Li(o){let e=o.replace(/\s+/g," ").trim();return e?(e.includes("`")?"``":"`")==="``"?`\`\` ${e} \`\``:`\`${e}\``:""}function _t(o,e){let t=/^(\s*)([\s\S]*?)(\s*)$/.exec(e);return t?.[2]?`${t[1]}${o}${t[2]}${o}${t[3]}`:e}function ae(o){let e="";for(let t of Array.from(o.childNodes)){if(t.nodeType===3){e+=t.data.replace(/\s+/g," ");continue}if(t.nodeType!==1)continue;let n=t,r=n.localName;if(r==="br")e+=`  
`;else if(r==="code"||r==="kbd"||r==="samp"||r==="tt")e+=Li(n.textContent??"");else if(r==="strong"||r==="b")e+=_t("**",ae(n));else if(r==="em"||r==="i")e+=_t("*",ae(n));else if(r==="del"||r==="s")e+=_t("~~",ae(n));else if(r==="img"){let i=n.getAttribute("src");i&&(e+=`![${n.getAttribute("alt")??""}](${n.src||i})`)}else if(r==="a"){let i=ae(n).trim(),s=n.href;e+=i&&/^https?:/i.test(s)?`[${i}](${s})`:i}else r!=="svg"&&!qn(n)&&(e+=ae(n))}return e}function Pi(o){let e=0;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&e++;return Math.max(0,e-1)}function Hi(o){let e=o;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&(e=t);return e}function Ii(o){if(o.closest('button,[role="button"],nav,[role="navigation"],[role="tablist"]'))return null;let e=ae(o).replace(/[ \t]+/g," ").trim();if(!e)return null;let t=o.closest("h1,h2,h3,h4,h5,h6");if(t)return{text:`${"#".repeat(Number(t.localName[1]))} ${e.replace(/\s*\n\s*/g," ")}`};let n=o.closest("li");if(n){let r=n.parentElement,i=r?.localName==="ol"?`${Array.from(r.children).indexOf(n)+1}.`:"-";return{text:`${"  ".repeat(Pi(n))}${i} ${e}`,group:Hi(n)}}return o.closest("blockquote")?{text:e.split(`
`).map(r=>`> ${r}`).join(`
`)}:{text:e}}function Di(o){if((o.textContent??"").trim().length>40)return null;let e=o.parentElement;for(let t=0;e&&t<6;t++,e=e.parentElement){if(e.localName==="body"||e.localName==="main"||e.localName==="article")return null;let n=e.querySelectorAll("pre");if(n.length===1)return n[0];if(n.length>1)return null}return null}function _i(o){let e=new Map,t=new Set;for(let{copy:n}of o){let r=n.closest("table");if(!r||t.has(r))continue;t.add(r);let i=Array.from(r.querySelectorAll("tr")).map(a=>Array.from(a.children).map(l=>ae(l).replace(/\s+/g," ").replace(/\|/g,"\\|").trim())).filter(a=>a.some(Boolean));if(!i.length)continue;let s=i.map(a=>`| ${a.join(" | ")} |`);s.splice(1,0,`| ${i[0].map(()=>"---").join(" | ")} |`),e.set(r,s.join(`
`))}return e}function Gn(o){let e=new Map,t=new Set;for(let a of o){if(a.kind==="code")continue;let l=Di(a.copy);if(!l)continue;t.add(a.copy);let c=zn(a.copy.textContent??"");c&&!e.has(l)&&e.set(l,c)}let n=_i(o),r=new Set,i=[];for(let a of o){if(t.has(a.copy))continue;if(a.kind==="code"){let d=Ci(a.copy);if(!d.trim())continue;let u=a.copy.localName==="pre"?a.copy:a.copy.querySelector("pre"),h=u&&(e.get(u)||Ri(u))||Ai(a.copy),p=Ni(d);i.push({text:`${p}${h}
${d}
${p}`});continue}let l=a.copy.closest("table");if(l&&n.has(l)){r.has(l)||i.push({text:n.get(l)}),r.add(l);continue}let c=Ii(a.copy);c&&i.push(c)}let s="";return i.forEach((a,l)=>{l&&(s+=a.group&&a.group===i[l-1].group?`
`:`

`),s+=a.text}),s}var Me=16,Oi=32,Bi=28,$i="data-yl-find",et=class{constructor(e,t,n){this.mirror=e;this.copies=n;this.track.append(this.thumb),t.append(this.track),this.mirror.doc.addEventListener("scroll",this.onScroll,!0),this.track.addEventListener("pointerdown",this.onPointerDown)}track=v("div","scan-track");thumb=v("i","scan-thumb");min=0;max=0;visible=0;origin=0;open=!1;marks=[];active=-1;measure(){let e=1/0,t=-1/0,n=this.mirror.doc.createRange();for(let r of this.copies()){if(!r.isConnected)continue;n.selectNodeContents(r);let i=n.getBoundingClientRect();!i.width&&!i.height||(e=Math.min(e,i.top),t=Math.max(t,i.bottom))}return e===1/0?null:{top:e,bottom:t}}get contentHeight(){let e=this.measure();return e?e.bottom-e.top+Me*2:0}start(e,t){let n=this.mirror.scroller,r=this.measure();if(this.visible=e,this.origin=t,this.open=!0,!n||!r)return;let i=n.scrollTop;this.min=i+r.top-t-Me,this.max=Math.max(this.min,i+r.bottom+Me-t-e),this.scrollTo(Math.max(this.min,Math.min(i,this.max))),this.alignToBlock(),this.paint()}alignToBlock(){let e=this.mirror.doc.createRange(),t=1/0;for(let n of this.copies()){if(!n.isConnected)continue;e.selectNodeContents(n);let r=e.getBoundingClientRect();(r.width||r.height)&&r.bottom>this.origin&&r.top<t&&(t=r.top)}t!==1/0&&this.scrollBy(t-this.origin-Oi)}stop(){this.open=!1,this.clearFind(),this.track.style.display="none"}get extent(){return{from:this.min,to:this.max,visible:this.visible}}get position(){return this.mirror.scroller?.scrollTop??0}moveTo(e){this.scrollTo(e)}scrollBy(e){let t=this.mirror.scroller;t&&this.scrollTo(t.scrollTop+e)}scrollTo(e){let t=this.mirror.scroller;t&&(t.scrollTop=Math.max(this.min,Math.min(e,this.max)))}onScroll=()=>{if(!this.open)return;let e=this.mirror.scroller;e&&((e.scrollTop<this.min-1||e.scrollTop>this.max+1)&&this.scrollTo(e.scrollTop),this.paint())};thumbHeight(){return Math.max(Bi,this.visible*this.visible/(this.max-this.min+this.visible))}paint(){let e=this.mirror.scroller,t=this.max-this.min;if(!e||t<=0){this.track.style.display="none";return}this.track.style.display="";let n=this.thumbHeight();this.thumb.style.height=`${n}px`,this.thumb.style.transform=`translateY(${(e.scrollTop-this.min)/t*(this.visible-n)}px)`}onPointerDown=e=>{e.preventDefault(),this.track.setPointerCapture(e.pointerId);let t=this.track.getBoundingClientRect().top,n=this.thumbHeight(),r=this.max-this.min,i=this.thumb.getBoundingClientRect().top,s=e.target===this.thumb?e.clientY-i:n/2,a=c=>{let d=(c.clientY-t-s)/(this.visible-n);this.scrollTo(this.min+Math.max(0,Math.min(1,d))*r)};a(e);let l=()=>{this.track.removeEventListener("pointermove",a),this.track.removeEventListener("pointerup",l)};this.track.addEventListener("pointermove",a),this.track.addEventListener("pointerup",l)};get hasQuery(){return this.marks.length>0}clearFind(){let e=new Set;for(let t of this.marks){let n=t.parentNode;n&&(t.replaceWith(...Array.from(t.childNodes)),e.add(n))}for(let t of e)t.normalize();this.marks=[],this.active=-1}find(e){this.clearFind();let t=e.trim().toLowerCase();if(!t)return 0;let n=this.mirror.doc;for(let r of this.copies()){if(!r.isConnected)continue;let i=n.createTreeWalker(r,NodeFilter.SHOW_TEXT),s=[];for(let a=i.nextNode();a;a=i.nextNode())s.push(a);for(let a of s)this.markIn(a,t)}return this.step(1),this.marks.length}markIn(e,t){let n=[],r=e;for(let i=r.data.toLowerCase().indexOf(t);i!==-1;i=r.data.toLowerCase().indexOf(t)){let s=r.splitText(i);r=s.splitText(t.length);let a=this.mirror.doc.createElement("mark");a.setAttribute($i,""),s.replaceWith(a),a.append(s),n.push(a)}this.marks.push(...n)}step(e){if(!this.marks.length)return 0;this.marks[this.active]?.removeAttribute("data-active"),this.active=(this.active+e+this.marks.length)%this.marks.length;let t=this.marks[this.active];t.setAttribute("data-active","");let n=t.getBoundingClientRect(),r=n.top-this.origin;return(r<Me||n.bottom-this.origin>this.visible-Me)&&this.scrollBy(r-this.visible/3),this.active+1}};var Qn="[modern-screenshot]",ne=typeof window<"u",Fi=ne&&"Worker"in window,lc=ne&&"atob"in window,cc=ne&&"btoa"in window,$t=ne?window.navigator?.userAgent:"",eo=$t.includes("Chrome"),tt=$t.includes("AppleWebKit")&&!eo,Ft=$t.includes("Firefox"),Wi=o=>o&&"__CONTEXT__"in o,Ui=o=>o.constructor.name==="CSSFontFaceRule",qi=o=>o.constructor.name==="CSSImportRule",ji=o=>o.constructor.name==="CSSLayerBlockRule",Y=o=>o.nodeType===1,Ne=o=>typeof o.className=="object",to=o=>o.tagName==="image",zi=o=>o.tagName==="use",Ce=o=>Y(o)&&typeof o.style<"u"&&!Ne(o),Gi=o=>o.nodeType===8,Ki=o=>o.nodeType===3,we=o=>o.tagName==="IMG",nt=o=>o.tagName==="VIDEO",Xi=o=>o.tagName==="CANVAS",Vi=o=>o.tagName==="TEXTAREA",Yi=o=>o.tagName==="INPUT",Ji=o=>o.tagName==="STYLE",Zi=o=>o.tagName==="SCRIPT",Qi=o=>o.tagName==="SELECT",es=o=>o.tagName==="SLOT",ts=o=>o.tagName==="IFRAME",ns=(...o)=>console.warn(Qn,...o);function os(o){let e=o?.createElement?.("canvas");return e&&(e.height=e.width=1),!!e&&"toDataURL"in e&&!!e.toDataURL("image/webp").includes("image/webp")}var Ot=o=>o.startsWith("data:");function no(o,e){if(o.match(/^[a-z]+:\/\//i))return o;if(ne&&o.match(/^\/\//))return window.location.protocol+o;if(o.match(/^[a-z]+:/i)||!ne)return o;let t=ot().implementation.createHTMLDocument(),n=t.createElement("base"),r=t.createElement("a");return t.head.appendChild(n),t.body.appendChild(r),e&&(n.href=e),r.href=o,r.href}function ot(o){return(o&&Y(o)?o?.ownerDocument:o)??window.document}var rt="http://www.w3.org/2000/svg";function rs(o,e,t){let n=ot(t).createElementNS(rt,"svg");return n.setAttributeNS(null,"width",o.toString()),n.setAttributeNS(null,"height",e.toString()),n.setAttributeNS(null,"viewBox",`0 0 ${o} ${e}`),n}function is(o,e){let t=new XMLSerializer().serializeToString(o);return e&&(t=t.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu,"")),`data:image/svg+xml;charset=utf-8,${encodeURIComponent(t)}`}function ss(o,e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t(r.result),r.onerror=()=>n(r.error),r.onabort=()=>n(new Error(`Failed read blob to ${e}`)),e==="dataUrl"?r.readAsDataURL(o):e==="arrayBuffer"&&r.readAsArrayBuffer(o)})}var as=o=>ss(o,"dataUrl");function ve(o,e){let t=ot(e).createElement("img");return t.decoding="sync",t.loading="eager",t.src=o,t}function Ae(o,e){return new Promise(t=>{let{timeout:n,ownerDocument:r,onError:i,onWarn:s}=e??{},a=typeof o=="string"?ve(o,ot(r)):o,l=null,c=null;function d(){t(a),l&&clearTimeout(l),c?.()}if(n&&(l=setTimeout(d,n)),nt(a)){let u=a.currentSrc||a.src;if(!u)return a.poster?Ae(a.poster,e).then(t):d();if(a.readyState>=2)return d();let h=d,p=f=>{s?.("Failed video load",u,f),i?.(f),d()};c=()=>{a.removeEventListener("loadeddata",h),a.removeEventListener("error",p)},a.addEventListener("loadeddata",h,{once:!0}),a.addEventListener("error",p,{once:!0})}else{let u=to(a)?a.href.baseVal:a.currentSrc||a.src;if(!u)return d();let h=async()=>{if(we(a)&&"decode"in a)try{await a.decode()}catch(f){s?.("Failed to decode image, trying to render anyway",a.dataset.originalSrc||u,f)}d()},p=f=>{s?.("Failed image load",a.dataset.originalSrc||u,f),d()};if(we(a)&&a.complete)return h();c=()=>{a.removeEventListener("load",h),a.removeEventListener("error",p)},a.addEventListener("load",h,{once:!0}),a.addEventListener("error",p,{once:!0})}})}async function ls(o,e){Ce(o)&&(we(o)||nt(o)?await Ae(o,e):await Promise.all(["img","video"].flatMap(t=>Array.from(o.querySelectorAll(t)).map(n=>Ae(n,e)))))}var oo=function(){let e=0,t=()=>`0000${(Math.random()*36**4<<0).toString(36)}`.slice(-4);return()=>(e+=1,`u${t()}${e}`)}();function ro(o){return o?.split(",").map(e=>e.trim().replace(/"|'/g,"").toLowerCase()).filter(Boolean)}var Kn=0;function cs(o){let e=`${Qn}[#${Kn}]`;return Kn++,{time:t=>o&&console.time(`${e} ${t}`),timeEnd:t=>o&&console.timeEnd(`${e} ${t}`),warn:(...t)=>o&&ns(...t)}}function ds(o){return{cache:o?"no-cache":"force-cache"}}async function io(o,e){return Wi(o)?o:Wt(o,{...e,autoDestruct:!0})}async function Wt(o,e){let{scale:t=1,workerUrl:n,workerNumber:r=1}=e||{},i=!!e?.debug,s=e?.features??!0,a=o.ownerDocument??(ne?window.document:void 0),l=o.ownerDocument?.defaultView??(ne?window:void 0),c=new Map,d={width:0,height:0,quality:1,type:"image/png",scale:t,backgroundColor:null,style:null,filter:null,maximumCanvasSize:0,timeout:3e4,progress:null,debug:i,fetch:{requestInit:ds(e?.fetch?.bypassingCache),placeholderImage:"data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",bypassingCache:!1,...e?.fetch},fetchFn:null,font:{},drawImageInterval:100,workerUrl:null,workerNumber:r,onCloneEachNode:null,onCloneNode:null,onEmbedNode:null,onCreateForeignObjectSvg:null,includeStyleProperties:null,autoDestruct:!1,...e,__CONTEXT__:!0,log:cs(i),node:o,ownerDocument:a,ownerWindow:l,dpi:t===1?null:96*t,svgStyleElement:so(a),svgDefsElement:a?.createElementNS(rt,"defs"),svgStyles:new Map,defaultComputedStyles:new Map,workers:[...Array.from({length:Fi&&n&&r?r:0})].map(()=>{try{let p=new Worker(n);return p.onmessage=async f=>{let{url:m,result:g}=f.data;g?c.get(m)?.resolve?.(g):c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},p.onmessageerror=f=>{let{url:m}=f.data;c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},p}catch(p){return d.log.warn("Failed to new Worker",p),null}}).filter(Boolean),fontFamilies:new Map,fontCssTexts:new Map,acceptOfImage:`${[os(a)&&"image/webp","image/svg+xml","image/*","*/*"].filter(Boolean).join(",")};q=0.8`,requests:c,drawImageCount:0,tasks:[],features:s,isEnable:p=>p==="restoreScrollPosition"?typeof s=="boolean"?!1:s[p]??!1:typeof s=="boolean"?s:s[p]??!0,shadowRoots:[]};d.log.time("wait until load"),await ls(o,{timeout:d.timeout,onWarn:d.log.warn}),d.log.timeEnd("wait until load");let{width:u,height:h}=us(o,d);return d.width=u,d.height=h,d}function so(o){if(!o)return;let e=o.createElement("style"),t=e.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);return e.appendChild(t),e}function us(o,e){let{width:t,height:n}=e;if(Y(o)&&(!t||!n)){let r=o.getBoundingClientRect();t=t||r.width||Number(o.getAttribute("width"))||0,n=n||r.height||Number(o.getAttribute("height"))||0}return{width:t,height:n}}async function ps(o,e){let{log:t,timeout:n,drawImageCount:r,drawImageInterval:i}=e;t.time("image to canvas");let s=await Ae(o,{timeout:n,onWarn:e.log.warn}),{canvas:a,context2d:l}=hs(o.ownerDocument,e),c=()=>{try{l?.drawImage(s,0,0,a.width,a.height)}catch(d){e.log.warn("Failed to drawImage",d)}};if(c(),e.isEnable("fixSvgXmlDecode"))for(let d=0;d<r;d++)await new Promise(u=>{setTimeout(()=>{l?.clearRect(0,0,a.width,a.height),c(),u()},d+i)});return e.drawImageCount=0,t.timeEnd("image to canvas"),a}function hs(o,e){let{width:t,height:n,scale:r,backgroundColor:i,maximumCanvasSize:s}=e,a=o.createElement("canvas");a.width=Math.floor(t*r),a.height=Math.floor(n*r),a.style.width=`${t}px`,a.style.height=`${n}px`,s&&(a.width>s||a.height>s)&&(a.width>s&&a.height>s?a.width>a.height?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s):a.width>s?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s));let l=a.getContext("2d");return l&&i&&(l.fillStyle=i,l.fillRect(0,0,a.width,a.height)),{canvas:a,context2d:l}}function ao(o,e){if(o.ownerDocument)try{let i=o.toDataURL();if(i!=="data:,")return ve(i,o.ownerDocument)}catch(i){e.log.warn("Failed to clone canvas",i)}let t=o.cloneNode(!1),n=o.getContext("2d"),r=t.getContext("2d");try{return n&&r&&r.putImageData(n.getImageData(0,0,o.width,o.height),0,0),t}catch(i){e.log.warn("Failed to clone canvas",i)}return t}function ms(o,e){try{if(o?.contentDocument?.documentElement)return Ut(o.contentDocument.documentElement,e)}catch(t){e.log.warn("Failed to clone iframe",t)}return o.cloneNode(!1)}function fs(o){let e=o.cloneNode(!1);return o.currentSrc&&o.currentSrc!==o.src&&(e.src=o.currentSrc,e.srcset=""),e.loading==="lazy"&&(e.loading="eager"),e}async function gs(o,e){if(o.ownerDocument&&!o.currentSrc&&o.poster)return ve(o.poster,o.ownerDocument);let t=o.cloneNode(!1);t.crossOrigin="anonymous",o.currentSrc&&o.currentSrc!==o.src&&(t.src=o.currentSrc);let n=t.ownerDocument;if(n){let r=!0;if(await Ae(t,{onError:()=>r=!1,onWarn:e.log.warn}),!r)return o.poster?ve(o.poster,o.ownerDocument):t;t.currentTime=o.currentTime,await new Promise(s=>{t.addEventListener("seeked",s,{once:!0})});let i=n.createElement("canvas");i.width=o.offsetWidth,i.height=o.offsetHeight;try{let s=i.getContext("2d");s&&s.drawImage(t,0,0,i.width,i.height)}catch(s){return e.log.warn("Failed to clone video",s),o.poster?ve(o.poster,o.ownerDocument):t}return ao(i,e)}return t}function bs(o,e){return Xi(o)?ao(o,e):ts(o)?ms(o,e):we(o)?fs(o):nt(o)?gs(o,e):o.cloneNode(!1)}function ys(o){let e=o.sandbox;if(!e){let{ownerDocument:t}=o;try{t&&(e=t.createElement("iframe"),e.id=`__SANDBOX__${oo()}`,e.width="0",e.height="0",e.style.visibility="hidden",e.style.position="fixed",t.body.appendChild(e),e.srcdoc='<!DOCTYPE html><meta charset="UTF-8"><title></title><body>',o.sandbox=e)}catch(n){o.log.warn("Failed to getSandBox",n)}}return e}var vs=["width","height","-webkit-text-fill-color"],ws=["stroke","fill"];function lo(o,e,t){let{defaultComputedStyles:n}=t,r=o.nodeName.toLowerCase(),i=Ne(o)&&r!=="svg",s=i?ws.map(m=>[m,o.getAttribute(m)]).filter(([,m])=>m!==null):[],a=[i&&"svg",r,s.map((m,g)=>`${m}=${g}`).join(","),e].filter(Boolean).join(":");if(n.has(a))return n.get(a);let c=ys(t)?.contentWindow;if(!c)return new Map;let d=c?.document,u,h;i?(u=d.createElementNS(rt,"svg"),h=u.ownerDocument.createElementNS(u.namespaceURI,r),s.forEach(([m,g])=>{h.setAttributeNS(null,m,g)}),u.appendChild(h)):u=h=d.createElement(r),h.textContent=" ",d.body.appendChild(u);let p=c.getComputedStyle(h,e),f=new Map;for(let m=p.length,g=0;g<m;g++){let b=p.item(g);vs.includes(b)||f.set(b,p.getPropertyValue(b))}return d.body.removeChild(u),n.set(a,f),f}function co(o,e,t){let n=new Map,r=[],i=new Map;if(t)for(let a of t)s(a);else for(let a=o.length,l=0;l<a;l++){let c=o.item(l);s(c)}for(let a=r.length,l=0;l<a;l++)i.get(r[l])?.forEach((c,d)=>n.set(d,c));function s(a){let l=o.getPropertyValue(a),c=o.getPropertyPriority(a),d=a.lastIndexOf("-"),u=d>-1?a.substring(0,d):void 0;if(u){let h=i.get(u);h||(h=new Map,i.set(u,h)),h.set(a,[l,c])}e.get(a)===l&&!c||(u?r.push(u):n.set(a,[l,c]))}return n}function xs(o,e,t,n){let{ownerWindow:r,includeStyleProperties:i,currentParentNodeStyle:s}=n,a=e.style,l=r.getComputedStyle(o),c=lo(o,null,n);s?.forEach((u,h)=>{c.delete(h)});let d=co(l,c,i);d.delete("transition-property"),d.delete("all"),d.delete("d"),d.delete("content"),t&&(d.delete("position"),d.delete("margin-top"),d.delete("margin-right"),d.delete("margin-bottom"),d.delete("margin-left"),d.delete("margin-block-start"),d.delete("margin-block-end"),d.delete("margin-inline-start"),d.delete("margin-inline-end"),d.set("box-sizing",["border-box",""])),d.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text"),eo&&(d.has("font-kerning")||d.set("font-kerning",["normal",""]),(d.get("overflow-x")?.[0]==="hidden"||d.get("overflow-y")?.[0]==="hidden")&&d.get("text-overflow")?.[0]==="ellipsis"&&o.scrollWidth===o.clientWidth&&d.set("text-overflow",["clip",""]));for(let u=a.length,h=0;h<u;h++)a.removeProperty(a.item(h));return d.forEach(([u,h],p)=>{a.setProperty(p,u,h)}),d}function Es(o,e){(Vi(o)||Yi(o)||Qi(o))&&e.setAttribute("value",o.value)}var Ss=["::before","::after"],Ts=["::-webkit-scrollbar","::-webkit-scrollbar-button","::-webkit-scrollbar-thumb","::-webkit-scrollbar-track","::-webkit-scrollbar-track-piece","::-webkit-scrollbar-corner","::-webkit-resizer"];function ks(o,e,t,n,r){let{ownerWindow:i,svgStyleElement:s,svgStyles:a,currentNodeStyle:l}=n;if(!s||!i)return;function c(d){let u=i.getComputedStyle(o,d),h=u.getPropertyValue("content");if(!h||h==="none")return;r?.(h),h=h.replace(/(')|(")|(counter\(.+\))/g,"");let p=[oo()],f=lo(o,d,n);l?.forEach((E,T)=>{f.delete(T)});let m=co(u,f,n.includeStyleProperties);m.delete("content"),m.delete("-webkit-locale"),m.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text");let g=[`content: '${h}';`];if(m.forEach(([E,T],C)=>{g.push(`${C}: ${E}${T?" !important":""};`)}),g.length===1)return;try{e.className=[e.className,...p].join(" ")}catch(E){n.log.warn("Failed to copyPseudoClass",E);return}let b=g.join(`
  `),x=a.get(b);x||(x=[],a.set(b,x)),x.push(`.${p[0]}${d}`)}Ss.forEach(c),t&&Ts.forEach(c)}var Xn=new Set(["symbol"]);async function Vn(o,e,t,n,r){if(Y(t)&&(Ji(t)||Zi(t))||n.filter&&!n.filter(t))return;Xn.has(e.nodeName)||Xn.has(t.nodeName)?n.currentParentNodeStyle=void 0:n.currentParentNodeStyle=n.currentNodeStyle;let i=await Ut(t,n,!1,r);n.isEnable("restoreScrollPosition")&&Ms(o,i),e.appendChild(i)}async function Yn(o,e,t,n){let r=o.firstChild;Y(o)&&o.shadowRoot&&(r=o.shadowRoot?.firstChild,t.shadowRoots.push(o.shadowRoot));for(let i=r;i;i=i.nextSibling)if(!Gi(i))if(Y(i)&&es(i)&&typeof i.assignedNodes=="function"){let s=i.assignedNodes();for(let a=0;a<s.length;a++)await Vn(o,e,s[a],t,n)}else await Vn(o,e,i,t,n)}function Ms(o,e){if(!Ce(o)||!Ce(e))return;let{scrollTop:t,scrollLeft:n}=o;if(!t&&!n)return;let{transform:r}=e.style,i=new DOMMatrix(r),{a:s,b:a,c:l,d:c}=i;i.a=1,i.b=0,i.c=0,i.d=1,i.translateSelf(-n,-t),i.a=s,i.b=a,i.c=l,i.d=c,e.style.transform=i.toString()}function Cs(o,e){let{backgroundColor:t,width:n,height:r,style:i}=e,s=o.style;if(t&&s.setProperty("background-color",t,"important"),n&&s.setProperty("width",`${n}px`,"important"),r&&s.setProperty("height",`${r}px`,"important"),i)for(let a in i)s[a]=i[a]}var As=/^[\w-:]+$/;async function Ut(o,e,t=!1,n){let{ownerDocument:r,ownerWindow:i,fontFamilies:s,onCloneEachNode:a}=e;if(r&&Ki(o))return n&&/\S/.test(o.data)&&n(o.data),r.createTextNode(o.data);if(r&&i&&Y(o)&&(Ce(o)||Ne(o))){let c=await bs(o,e);if(e.isEnable("removeAbnormalAttributes")){let m=c.getAttributeNames();for(let g=m.length,b=0;b<g;b++){let x=m[b];As.test(x)||c.removeAttribute(x)}}let d=e.currentNodeStyle=xs(o,c,t,e);t&&Cs(c,e);let u=!1;if(e.isEnable("copyScrollbar")){let m=[d.get("overflow-x")?.[0],d.get("overflow-y")?.[0]];u=m.includes("scroll")||(m.includes("auto")||m.includes("overlay"))&&(o.scrollHeight>o.clientHeight||o.scrollWidth>o.clientWidth)}let h=d.get("text-transform")?.[0],p=ro(d.get("font-family")?.[0]),f=p?m=>{h==="uppercase"?m=m.toUpperCase():h==="lowercase"?m=m.toLowerCase():h==="capitalize"&&(m=m[0].toUpperCase()+m.substring(1)),p.forEach(g=>{let b=s.get(g);b||s.set(g,b=new Set),m.split("").forEach(x=>b.add(x))})}:void 0;return ks(o,c,u,e,f),Es(o,c),nt(o)||await Yn(o,c,e,f),await a?.(c),c}let l=o.cloneNode(!1);return await Yn(o,l,e),await a?.(l),l}function Rs(o){if(o.ownerDocument=void 0,o.ownerWindow=void 0,o.svgStyleElement=void 0,o.svgDefsElement=void 0,o.svgStyles.clear(),o.defaultComputedStyles.clear(),o.sandbox){try{o.sandbox.remove()}catch(e){o.log.warn("Failed to destroyContext",e)}o.sandbox=void 0}o.workers=[],o.fontFamilies.clear(),o.fontCssTexts.clear(),o.requests.clear(),o.tasks=[],o.shadowRoots=[]}function Ns(o){let{url:e,timeout:t,responseType:n,...r}=o,i=new AbortController,s=t?setTimeout(()=>i.abort(),t):void 0;return fetch(e,{signal:i.signal,...r}).then(a=>{if(!a.ok)throw new Error("Failed fetch, not 2xx response",{cause:a});switch(n){case"arrayBuffer":return a.arrayBuffer();case"dataUrl":return a.blob().then(as);case"text":default:return a.text()}}).finally(()=>clearTimeout(s))}function Re(o,e){let{url:t,requestType:n="text",responseType:r="text",imageDom:i}=e,s=t,{timeout:a,acceptOfImage:l,requests:c,fetchFn:d,fetch:{requestInit:u,bypassingCache:h,placeholderImage:p},font:f,workers:m,fontFamilies:g}=o;n==="image"&&(tt||Ft)&&o.drawImageCount++;let b=c.get(t);if(!b){h&&h instanceof RegExp&&h.test(s)&&(s+=(/\?/.test(s)?"&":"?")+new Date().getTime());let x=n.startsWith("font")&&f&&f.minify,E=new Set;x&&n.split(";")[1].split(",").forEach(D=>{g.has(D)&&g.get(D).forEach(P=>E.add(P))});let T=x&&E.size,C={url:s,timeout:a,responseType:T?"arrayBuffer":r,headers:n==="image"?{accept:l}:void 0,...u};b={type:n,resolve:void 0,reject:void 0,response:null},b.response=(async()=>{if(d&&n==="image"){let $=await d(t);if($)return $}return!tt&&t.startsWith("http")&&m.length?new Promise(($,D)=>{m[c.size&m.length-1].postMessage({rawUrl:t,...C}),b.resolve=$,b.reject=D}):Ns(C)})().catch($=>{if(c.delete(t),n==="image"&&p)return o.log.warn("Failed to fetch image base64, trying to use placeholder image",s),typeof p=="string"?p:p(i);throw $}),c.set(t,b)}return b.response}async function uo(o,e,t,n){if(!po(o))return o;for(let[r,i]of Ls(o,e))try{let s=await Re(t,{url:i,requestType:n?"image":"text",responseType:"dataUrl"});o=o.replace(Ps(r),`$1${s}$3`)}catch(s){t.log.warn("Failed to fetch css data url",r,s)}return o}function po(o){return/url\((['"]?)([^'"]+?)\1\)/.test(o)}var ho=/url\((['"]?)([^'"]+?)\1\)/g;function Ls(o,e){let t=[];return o.replace(ho,(n,r,i)=>(t.push([i,no(i,e)]),n)),t.filter(([n])=>!Ot(n))}function Ps(o){let e=o.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1");return new RegExp(`(url\\(['"]?)(${e})(['"]?\\))`,"g")}var Hs=["background-image","border-image-source","-webkit-border-image","-webkit-mask-image","list-style-image"];function Is(o,e){return Hs.map(t=>{let n=o.getPropertyValue(t);return!n||n==="none"?null:((tt||Ft)&&e.drawImageCount++,uo(n,null,e,!0).then(r=>{!r||n===r||o.setProperty(t,r,o.getPropertyPriority(t))}))}).filter(Boolean)}function Ds(o,e){if(we(o)){let t=o.currentSrc||o.src;if(!Ot(t))return[Re(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.srcset="",o.dataset.originalSrc=t,o.src=n||"")})];(tt||Ft)&&e.drawImageCount++}else if(Ne(o)&&!Ot(o.href.baseVal)){let t=o.href.baseVal;return[Re(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.dataset.originalSrc=t,o.href.baseVal=n||"")})]}return[]}function _s(o,e){let{ownerDocument:t,svgDefsElement:n}=e,r=o.getAttribute("href")??o.getAttribute("xlink:href");if(!r)return[];let[i,s]=r.split("#");if(s){let a=`#${s}`,l=e.shadowRoots.reduce((c,d)=>c??d.querySelector(`svg ${a}`),t?.querySelector(`svg ${a}`));if(i&&o.setAttribute("href",a),n?.querySelector(a))return[];if(l)return n?.appendChild(l.cloneNode(!0)),[];if(i)return[Re(e,{url:i,responseType:"text"}).then(c=>{n?.insertAdjacentHTML("beforeend",c)})]}return[]}function mo(o,e){let{tasks:t}=e;Y(o)&&((we(o)||to(o))&&t.push(...Ds(o,e)),zi(o)&&t.push(..._s(o,e))),Ce(o)&&t.push(...Is(o.style,e)),o.childNodes.forEach(n=>{mo(n,e)})}async function Os(o,e){let{ownerDocument:t,svgStyleElement:n,fontFamilies:r,fontCssTexts:i,tasks:s,font:a}=e;if(!(!t||!n||!r.size))if(a&&a.cssText){let l=Zn(a.cssText,e);n.appendChild(t.createTextNode(`${l}
`))}else{let l=Array.from(t.styleSheets).filter(p=>{try{return"cssRules"in p&&!!p.cssRules.length}catch(f){return e.log.warn(`Error while reading CSS rules from ${p.href}`,f),!1}}),c=t.implementation.createHTMLDocument(""),d=c.createElement("style");c.head.appendChild(d);let u=d.sheet;await Promise.all(l.flatMap(p=>Array.from(p.cssRules).map(async f=>{if(qi(f)){let m=f.href,g="";try{g=await Re(e,{url:m,requestType:"text",responseType:"text"})}catch(x){e.log.warn(`Error fetch remote css import from ${m}`,x)}let b=g.replace(ho,(x,E,T)=>x.replace(T,no(T,m)));for(let x of $s(b))try{u.insertRule(x,u.cssRules.length)}catch(E){e.log.warn("Error inserting rule from remote css import",{rule:x,error:E})}}}))),u.cssRules.length&&l.push(u);let h=[];l.forEach(p=>{Bt(p.cssRules,h)}),h.filter(p=>Ui(p)&&po(p.style.getPropertyValue("src"))&&ro(p.style.getPropertyValue("font-family"))?.some(f=>r.has(f))).forEach(p=>{let f=p,m=i.get(f.cssText);m?n.appendChild(t.createTextNode(`${m}
`)):s.push(uo(f.cssText,f.parentStyleSheet?f.parentStyleSheet.href:null,e).then(g=>{g=Zn(g,e),i.set(f.cssText,g),n.appendChild(t.createTextNode(`${g}
`))}))})}}var Bs=/(\/\*[\s\S]*?\*\/)/g,Jn=/((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;function $s(o){if(o==null)return[];let e=[],t=o.replace(Bs,"");for(;;){let i=Jn.exec(t);if(!i)break;e.push(i[0])}t=t.replace(Jn,"");let n=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,r=new RegExp("((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})","gi");for(;;){let i=n.exec(t);if(i)r.lastIndex=n.lastIndex;else if(i=r.exec(t),i)n.lastIndex=r.lastIndex;else break;e.push(i[0])}return e}var Fs=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,Ws=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function Zn(o,e){let{font:t}=e,n=t?t?.preferredFormat:void 0;return n?o.replace(Ws,r=>{for(;;){let[i,,s]=Fs.exec(r)||[];if(!s)return"";if(s===n)return`src: ${i};`}}):o}function Bt(o,e=[]){for(let t of Array.from(o))ji(t)?e.push(...Bt(t.cssRules)):"cssRules"in t?Bt(t.cssRules,e):e.push(t);return e}var Us=/\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;function qs(o){return Us.test(o.innerHTML)}async function js(o,e){let t=await io(o,e);if(Y(t.node)&&Ne(t.node)&&!qs(t.node))return t.node;let{ownerDocument:n,log:r,tasks:i,svgStyleElement:s,svgDefsElement:a,svgStyles:l,font:c,progress:d,autoDestruct:u,onCloneNode:h,onEmbedNode:p,onCreateForeignObjectSvg:f}=t;r.time("clone node");let m=await Ut(t.node,t,!0);if(s&&n){let T="";l.forEach((C,$)=>{T+=`${C.join(`,
`)} {
  ${$}
}
`}),s.appendChild(n.createTextNode(T))}r.timeEnd("clone node"),await h?.(m),c!==!1&&Y(m)&&(r.time("embed web font"),await Os(m,t),r.timeEnd("embed web font")),r.time("embed node"),mo(m,t);let g=i.length,b=0,x=async()=>{for(;;){let T=i.pop();if(!T)break;try{await T}catch(C){t.log.warn("Failed to run task",C)}d?.(++b,g)}};d?.(b,g),await Promise.all([...Array.from({length:4})].map(x)),r.timeEnd("embed node"),await p?.(m);let E=zs(m,t);return a&&E.insertBefore(a,E.children[0]),s&&E.insertBefore(s,E.children[0]),u&&Rs(t),await f?.(E),E}function zs(o,e){let{width:t,height:n}=e,r=rs(t,n,o.ownerDocument),i=r.ownerDocument.createElementNS(r.namespaceURI,"foreignObject");return i.setAttributeNS(null,"x","0%"),i.setAttributeNS(null,"y","0%"),i.setAttributeNS(null,"width","100%"),i.setAttributeNS(null,"height","100%"),i.append(o),r.appendChild(i),r}async function fo(o,e){let t=await io(o,e),n=await js(t),r=is(n,t.isEnable("removeControlCharacter"));t.autoDestruct||(t.svgStyleElement=so(t.ownerDocument),t.svgDefsElement=t.ownerDocument?.createElementNS(rt,"defs"),t.svgStyles.clear());let i=ve(r,n.ownerDocument);return await ps(i,t)}var go=3e4;async function bo(o){return o.startsWith("data:")?o:await B({type:"asset:fetch",url:o}).catch(()=>null)??!1}async function yo(o,e,t){if(e.height*t>go||e.width*t>go)throw new Error("too large");let n=jt(o),r=await Wt(document.createElement("div"),{scale:t,backgroundColor:n,width:e.width,height:e.height,style:{width:`${o.offsetWidth}px`,height:`${o.scrollHeight}px`,maxHeight:"none",counterReset:Ks(o),overflow:"visible",margin:"0",transformOrigin:"0 0",transform:`translate(${-e.left}px, ${-e.top}px)`},fetchFn:bo,timeout:15e3,filter:Gs(o,e),autoDestruct:!0,includeStyleProperties:Vs(o),features:{fixSvgXmlDecode:!1}});r.node=o;let i=new qt(o.ownerDocument.defaultView??window);r.ownerWindow=i.view,r.onCreateForeignObjectSvg=l=>i.restore(l);let s=await fo(r),a=s.getContext("2d");if(!a)throw new Error("no canvas");if(Ys(a,s))throw new Error("blank");return s}function Gs(o,e){let t=new WeakSet,n,r=o.ownerDocument.defaultView??window,i=o.getBoundingClientRect(),s=o!==o.ownerDocument.body,a=s?o.scrollTop:0,l=s?o.scrollLeft:0,c=e.top,d=e.top+e.height,u=e.left,h=e.left+e.width;return p=>{let f=p.parentNode;if(f&&t.has(f))return!1;if(p.nodeType!==Node.ELEMENT_NODE)return!0;let m=p,g=r.getComputedStyle(m).display;if(g==="none")return!1;if(g.startsWith("inline")||g==="contents"||g.startsWith("table-"))return!0;let b=m.getBoundingClientRect(),x=b.top-i.top+a,E=b.left-i.left+l;return(x+b.height<c||x>d||E+b.width<u||E>h)&&(x>d||!(n??=Xs(o,r)).has(m))&&t.add(m),!0}}function Ks(o){let e=o.ownerDocument.defaultView??window,t=[];for(let n=o;n;n=n.parentElement){let r=e.getComputedStyle(n).counterReset;r&&r!=="none"&&t.unshift(r)}return t.join(" ")||"none"}function Xs(o,e){let t=(r,i)=>{let s=e.getComputedStyle(r,i);return s.counterIncrement!=="none"||s.counterReset!=="none"||s.counterSet!=="none"},n=new WeakSet;for(let r of Array.from(o.querySelectorAll("*")))if(!(!t(r)&&!t(r,"::before")&&!t(r,"::after")))for(let i=r;i&&i!==o&&!n.has(i);i=i.parentElement)n.add(i);return n}var qt=class{kept=[];view;constructor(e){let t=(n,r)=>{let i=e.getComputedStyle(n,r);if(!r||!i.content.includes("counter"))return i;let s=this.keep(i.content);return new Proxy(i,{get:(a,l)=>{if(l==="getPropertyValue")return d=>d==="content"?s:a.getPropertyValue(d);let c=Reflect.get(a,l,a);return typeof c=="function"?c.bind(a):c}})};this.view={getComputedStyle:t}}keep(e){return this.kept.push(e),`YLKEPT${this.kept.length-1}X`}async restore(e){let t=e.querySelector("style");if(!t?.textContent)return;let n=t.textContent.replace(/content: 'YLKEPT(\d+)X';/g,(i,s)=>`content: ${this.kept[Number(s)]};`),r=new Set(Array.from(n.matchAll(/url\("(https?:[^"]+)"\)/g),i=>i[1]));await Promise.all(Array.from(r,async i=>{let s=await bo(i);s&&(n=n.split(i).join(s))})),t.textContent=n}};function jt(o){let e=o.ownerDocument.defaultView??window;for(let t=o;t;t=t.parentElement){let n=e.getComputedStyle(t).backgroundColor;if(n&&n!=="transparent"&&!/rgba(.*, 0)$/.test(n))return n}return"#ffffff"}function Vs(o){let e=(o.ownerDocument.defaultView??window).getComputedStyle(o),t=[];for(let n=0;n<e.length;n++){let r=e.item(n);!r.startsWith("--")&&!/^(animation|transition|view-timeline|scroll-timeline|animation-timeline)/.test(r)&&t.push(r)}return t}function Ys(o,e){let t=Math.max(1,Math.floor(e.height/400)),{data:n}=o.getImageData(0,0,e.width,e.height),[r,i,s]=[n[0],n[1],n[2]];for(let a=0;a<e.height;a+=t)for(let l=0;l<e.width;l+=3){let c=(a*e.width+l)*4;if(n[c]!==r||n[c+1]!==i||n[c+2]!==s)return!1}return!0}var K={margin:12,line:1.5,radius:12,top:18,foot:38};function vo(o,e,t,n){let r=(K.margin+K.line)*n,i=document.createElement("canvas");i.width=o.width+Math.round(r*2),i.height=o.height+Math.round(r*2+(K.top+K.foot)*n);let s=i.getContext("2d");if(!s)throw new Error("no canvas");let{width:a,height:l}=i;s.fillStyle="#ffffff",s.fillRect(0,0,a,l),s.fillStyle=e,s.fillRect(0,0,a,l);let[c=255,d=255,u=255]=s.getImageData(0,0,1,1).data,h=.299*c+.587*d+.114*u<128;return s.save(),s.beginPath(),s.roundRect(r,r,a-r*2,l-r*2,K.radius*n),s.clip(),s.drawImage(o,Math.round(r),Math.round(r+K.top*n)),s.restore(),s.fillStyle=h?"#9aa3ae":"#7c828b",s.font=`${12*n}px -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif`,s.textAlign="center",s.textBaseline="middle",s.fillText(t,a/2,l-r-K.foot/2*n),Js(s,a,l,n),i}function Js(o,e,t,n){let r=(K.margin+K.line/2)*n,i=(K.radius+K.line/2)*n,s={x:e-r,y:t-r},a=e/2,l=[],c=r+i,d=s.y-i;l.push([0,0,e,c,r,0,s.x,0],[a,c,a,d-c,0,c,0,d],[0,d,e,t-d,s.x,0,r,0],[0,c,a,d-c,0,d,0,c]);for(let[u,h,p,f,m,g,b,x]of l){let E=o.createLinearGradient(m,g,b,x);for(let[T,C]of Te)E.addColorStop(Number(T),C);o.save(),o.beginPath(),o.rect(u,h,p,f),o.clip(),o.beginPath(),o.roundRect(r,r,s.x-r,s.y-r,i),o.lineWidth=K.line*n,o.strokeStyle=E,o.stroke(),o.restore()}}function wo(o){let e=new Set;for(let t of o.matchAll(/<x(\d+)>/g))e.add(Number(t[1]));return e}var xo=o=>ie(V(o)).trim();async function Eo(o,e,t){let r=(await B({type:"translate",items:o.map(i=>i.markup),from:e,to:t}))?.results;return!r||r.length!==o.length?o.map(()=>({ok:!1,code:"network"})):(e||await Promise.all(r.map(async(i,s)=>{let a=o[s];if(!i.ok||!Je(i,a.hint,t))return;let c=(await B({type:"translate",items:[a.markup],from:a.hint,to:t}))?.results?.[0];c?.ok&&c.text.trim()&&xo(c.text)!==xo(a.markup)&&(r[s]=c)})),r)}var Zs=200,Qs=700,ea=8,ta=120,na=20,oa=2,ra=360,So=180,Le=16,To=18,zt=39,ia=36,it=8,sa=.25,aa=24,la=260,ca=170,da=120,ua=560,pa=80,ha=3e4,ma=60,fa='img,svg,picture,hr,video,canvas,button,input,select,textarea,yl-r,[role="button"],[role="img"]';function ga(){return new Promise(o=>{let e=setTimeout(o,120);requestAnimationFrame(()=>requestAnimationFrame(()=>{clearTimeout(e),o()}))})}function ko(o){return new Promise((e,t)=>o.toBlob(n=>n?e(n):t(new Error("no image")),"image/png"))}function ba(o){let e=atob(o.slice(o.indexOf(",")+1)),t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return new Blob([t],{type:"image/png"})}function Mo(o){let e=o[0],t=o[o.length-1];if(!e||!t||!e.isConnected||!t.isConnected)return null;let n=document.createRange();return n.setStartBefore(e),n.setEndAfter(t),n.getBoundingClientRect()}function st(o){return getComputedStyle(o).visibility==="visible"}function at(o,e){let t=[],n=!1;for(let r=o;r;r=r.parentElement){let i=e.get(r);if(i!==void 0){n=i;break}t.push(r);let s=getComputedStyle(r).position;if(s==="fixed"||s==="sticky"){n=!0;break}}for(let r of t)e.set(r,n);return n}var lt=class{constructor(e,t,n){this.ui=e;this.settings=t;this.pageTranslated=n}rect;scroller=null;band={top:0,bottom:0};box;card;body;bar;labels=[];mirror;scanner=new ge;entries=[];byCopy=new WeakMap;seenNodes=new WeakSet;seenText=new Map;queue=[];inFlight=0;scanTimer;flushTimer;scanning=!1;rescan=!1;frame=0;backdrop;view;findInput;findCount;closeTimer;exporting=!1;restoreCard;observer;session=0;get running(){return this.rect!==void 0}start(e){this.stop(),this.session++,this.rect=e,this.scanner.classifier.setExcludes(this.settings().excludeSelectors);let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scroller=t?this.findScroller(t):null,this.band={top:this.toContent(e.top),bottom:this.toContent(e.bottom)},this.box=this.ui.addFrame(),Object.assign(this.box.style,{left:`${U(e.left)}px`,top:`${U(e.top)}px`,width:`${U(e.right-e.left)}px`,height:`${U(e.bottom-e.top)}px`}),this.buildBar(e),this.buildCard(e),addEventListener("scroll",this.onScroll,!0),addEventListener("resize",this.syncView),addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutation),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0}),this.scan()}stop(){this.session++,removeEventListener("scroll",this.onScroll,!0),removeEventListener("resize",this.syncView),removeEventListener("keydown",this.onKey,!0),this.observer?.disconnect(),this.observer=void 0,clearTimeout(this.scanTimer),clearTimeout(this.flushTimer),cancelAnimationFrame(this.frame),this.scanTimer=this.flushTimer=void 0,this.frame=0,clearTimeout(this.closeTimer),this.closeTimer=void 0,this.exporting=!1,this.view=this.findInput=this.findCount=void 0,this.mirror?.destroy(),this.mirror=void 0;for(let e of this.entries)e.segment?.unrender();this.box?.remove(),this.ui.dismiss(this.bar),this.ui.dismiss(this.card),this.box=this.bar=this.card=this.body=void 0,this.labels=[],this.rect=void 0,this.scroller=null,this.entries=[],this.byCopy=new WeakMap,this.queue=[],this.seenNodes=new WeakSet,this.seenText.clear(),this.inFlight=0,this.scanning=!1,this.rescan=!1,this.backdrop?.remove(),this.backdrop=void 0,this.restoreCard=void 0}findScroller(e){for(let t=e;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t).overflowY;if((n==="auto"||n==="scroll")&&t.scrollHeight>t.clientHeight+1)return t}return null}get origin(){return this.scroller?this.scroller.getBoundingClientRect().top+this.scroller.clientTop:0}get scrollPos(){return this.scroller?this.scroller.scrollTop:scrollY}atScrollEnd(){let e=this.scroller;if(e)return e.scrollTop+e.clientHeight>=e.scrollHeight-2;let t=document.documentElement;return scrollY+innerHeight>=t.scrollHeight-2}toContent(e){return e-this.origin+this.scrollPos}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.exporting?this.exporting=!1:this.findInput?.value?this.clearFind():this.restoreCard?this.exitImmersive():this.stop())};enterImmersive(){let e=this.card,t=this.view;if(!e||!t||this.restoreCard)return;let n=e.getBoundingClientRect();this.restoreCard={left:e.style.left,top:e.style.top,bottom:e.style.bottom,height:e.style.height};let r=this.ui.addBelow(v("div","scan-backdrop"),e);r.addEventListener("click",()=>this.exitImmersive()),r.addEventListener("wheel",a=>a.preventDefault(),{passive:!1}),this.backdrop=r,e.removeAttribute("data-hidden"),this.mirror?.hidePinned(),this.placeFrame();let i=innerHeight-aa*2,s=Math.min(i,Math.max(la,t.contentHeight+zt));t.start(s-zt,this.mirror?.scrollerTop??0),e.style.top=`${n.top}px`,e.style.bottom="auto",e.style.left=`${n.left}px`,e.style.height=`${n.height}px`,e.offsetHeight,e.classList.add("scan-animate","scan-immersive"),e.style.top=`${Math.round((innerHeight-s)/2)}px`,e.style.left=`${Math.round((innerWidth-n.width)/2)}px`,e.style.height=`${s}px`}exitImmersive(){let e=this.card;!e||!this.restoreCard||this.closeTimer!==void 0||(this.ui.dismiss(this.backdrop),this.backdrop=void 0,e.classList.add("scan-closing"),this.closeTimer=setTimeout(()=>{this.closeTimer=void 0;let t=this.restoreCard;this.restoreCard=void 0,this.clearFind(),this.view?.stop(),e.classList.remove("scan-immersive","scan-animate","scan-closing"),e.setAttribute("data-hidden",""),t&&Object.assign(e.style,t),this.placeFrame(),this.requestSync()},ca))}clearFind(){this.findInput&&(this.findInput.value=""),this.view?.clearFind(),this.paintFind(0,0,!1)}paintFind(e,t,n){this.findCount&&(this.findCount.textContent=t?`${e}/${t}`:n?"0/0":"");let r=this.findInput?.parentElement;r?.toggleAttribute("data-none",n),r?.toggleAttribute("data-found",t>0),r?.toggleAttribute("data-typed",t>0||n)}buildFind(){let e=v("div","scan-find"),t=v("input","scan-find-input");t.type="text",t.placeholder=y("findPlaceholder"),t.spellcheck=!1;let n=v("span","scan-find-count","");e.addEventListener("click",()=>t.focus({preventScroll:!0})),this.findInput=t,this.findCount=n;let r=0,i,s=c=>{r&&this.paintFind(this.view?.step(c)??0,r,!1)};t.addEventListener("input",()=>{clearTimeout(i),i=setTimeout(()=>{r=this.view?.find(t.value)??0,this.paintFind(r?1:0,r,!r&&!!t.value.trim())},da)}),t.addEventListener("keydown",c=>{c.stopPropagation(),c.key==="Enter"&&(c.preventDefault(),s(c.shiftKey?-1:1))});for(let c of["keyup","keypress"])t.addEventListener(c,d=>d.stopPropagation());let a=q("up",y("findPrevious"),()=>s(-1)),l=q("down",y("findNext"),()=>s(1));for(let c of[a,l])c.addEventListener("mousedown",d=>d.preventDefault());return e.append(pe("search"),t,n,a,l),e}onScroll=e=>{if(this.ui.ownsEvent(e))return;if(this.scroller&&e.target!==this.scroller){this.requestSync();return}let t=this.rect;if(!t)return;let n=this.toContent(t.top),r=this.toContent(t.bottom),i=n<this.band.top||r>this.band.bottom;this.band.top=Math.min(this.band.top,n),this.band.bottom=Math.max(this.band.bottom,r);let s=this.atScrollEnd()&&this.band.bottom!==1/0;s&&(this.band.bottom=1/0),(i||s)&&this.scheduleScan(Zs),this.requestSync()};onMutation=()=>this.scheduleScan(Qs);scheduleScan(e){this.scanTimer===void 0&&(this.scanTimer=setTimeout(()=>{this.scanTimer=void 0,this.scan()},e))}isCovered(e){let t=this.rect;if(!t||!e.width||!e.height)return!1;let n=Math.min(e.right,t.right)-Math.max(e.left,t.left),r=t.right-t.left;if(n<e.width*.5&&n<r*.6)return!1;let i=this.toContent(e.top),s=this.toContent(e.bottom);return Math.min(s,this.band.bottom)-Math.max(i,this.band.top)>=(s-i)*.5}async scan(){if(!this.rect)return;if(this.scanning){this.rescan=!0;return}this.scanning=!0;let e=this.session;this.scanner.reset();let t=new Map,n=this.settings().targetLang,r=this.scroller??document.body;if(r){let i={consume:()=>!1,shadowRoot:()=>{},emit:a=>this.considerRun(a,n,t),skipped:a=>this.considerSkipped(a,t),plain:(a,l)=>this.considerPlain(a,l,t)},s=performance.now();for(let a of this.scanner.scan(r,i))if(performance.now()-s>ea){if(await new Promise(l=>setTimeout(l,0)),e!==this.session)return;s=performance.now()}this.revealLeaves(r,t)}this.scanning=!1,this.requestSync(),this.rescan&&(this.rescan=!1,this.scan())}revealLeaves(e,t){for(let n of Array.from(e.querySelectorAll(fa)))this.seenNodes.has(n)||at(n,t)||!st(n)||this.isCovered(n.getBoundingClientRect())&&(this.seenNodes.add(n),this.mirror?.showWhole(n))}alreadyHave(e,t,n){return this.seenNodes.has(e)?!0:!!this.seenText.get(t)?.some(r=>Math.abs(r-n)<ma)}remember(e,t,n){this.seenNodes.add(e);let r=this.seenText.get(t);r?r.push(n):this.seenText.set(t,[n])}considerRun(e,t,n){let r=e.nodes[0];if(this.seenNodes.has(r))return;let i=new be(e),s=i.parentElement;if(at(s,n)||!st(s))return;let a=Mo(e.nodes);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,e.markup,l))return;this.remember(r,e.markup,l);let c=ke(e.text,t),d=this.mirror?.showRun(e.nodes,!c);if(!d)return;let u=this.addEntry("text",a,d);u.segment=i,c?this.setState(u,"kept"):(this.queue.push(u),this.scheduleFlush())}considerSkipped(e,t){if(this.seenNodes.has(e)||at(e,t)||!st(e))return;let n=e.getBoundingClientRect();if(!this.isCovered(n))return;let r=e.textContent??"",i=kn(e)&&!!r.trim(),s=this.toContent(n.top);if(i&&this.alreadyHave(e,r,s))return;i?this.remember(e,r,s):this.seenNodes.add(e);let a=this.mirror?.showWhole(e);if(!a||!i)return;let l=this.addEntry("code",n,a);this.setState(l,"kept")}considerPlain(e,t,n){let r=e[0];if(!r||this.seenNodes.has(r))return;let i=e.map(u=>u.textContent??"").join("").trim();if(!i)return;let s=t.nodeType===Node.ELEMENT_NODE?t:t.host;if(at(s,n)||!st(s))return;let a=Mo(e);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,i,l))return;this.remember(r,i,l);let c=this.mirror?.showRun(e,!1);if(!c)return;let d=this.addEntry("verbatim",a,c);this.setState(d,"kept")}addEntry(e,t,n){let r={kind:e,state:"pending",top:this.toContent(t.top),bottom:this.toContent(t.bottom),left:t.left,right:t.right,copy:n};this.byCopy.set(n,r);let i=this.entries.length;for(;i>0;){let s=this.entries[i-1];if(s.top<r.top||s.top===r.top&&s.left<=r.left)break;i--}return this.entries.splice(i,0,r),this.updateLabel(),r}setState(e,t){e.state=t,this.updateLabel()}buildBar(e){let t=v("div","scan-bar"),n=v("span","grow","");this.labels.push(n),t.append(n,q("expand",y("immersive"),()=>this.enterImmersive()),q("copy",y("copyMarkdown"),()=>this.copyAll()),q("close",y("close"),()=>this.stop()));let r=e.top-ia-it;Object.assign(t.style,{top:`${U(r>=it?r:e.top+it)}px`,right:`${U(Math.max(it,innerWidth-e.right))}px`}),this.bar=this.ui.add(t)}buildCard(e){let t=v("div","scan-card");t.setAttribute("role","log"),t.setAttribute("aria-label",y("marqueeScan")),t.setAttribute("data-hidden","");let n=v("div","scan-head"),r=v("span","grow","");this.labels.push(r),n.append(r,this.buildFind(),q("image",y("copyImage"),()=>this.copyImage()),q("download",y("exportImage"),()=>void this.saveImage()),q("collapse",y("exitImmersive"),()=>this.exitImmersive()),q("copy",y("copyMarkdown"),()=>this.copyAll()),q("close",y("close"),()=>this.stop())),n.addEventListener("wheel",c=>{c.preventDefault(),this.view?.scrollBy(c.deltaY)},{passive:!1});let i=v("div","scan-body");t.append(n,i),this.body=i;let s=e.bottom-e.top+zt,a=innerHeight-e.bottom-Le*2,l=a>=So?Math.min(a,s):Math.round(innerHeight*.42);Object.assign(t.style,{height:`${Math.max(So,l)}px`,bottom:`${Le}px`}),this.card=this.ui.add(t),this.updateLabel(),this.mirror=new Xe(i,this.scroller,()=>{},this.onKey),this.view=new et(this.mirror,i,()=>this.entries.map(c=>c.copy)),this.view.stop(),this.placeFrame()}placeFrame(){let e=this.mirror?.frame,t=this.rect,n=this.body,r=this.card;if(!e||!t||!n||!r)return;let i=(t.right-t.left)*sa,s=t.left,a=t.right;for(let l of this.entries)s=Math.min(s,Math.max(l.left,t.left-i)),a=Math.max(a,Math.min(l.right,t.right+i));if(s=Math.max(0,s-To),a=Math.min(innerWidth,a+To),!this.restoreCard){let l=Math.min(innerWidth-Le*2,Math.max(ra,a-s));r.style.width=`${l}px`,r.style.left=`${Math.max(Le,Math.min(s,innerWidth-l-Le))}px`}if(this.restoreCard){let l=this.mirror?.scrollerTop??0;Object.assign(e.style,{left:`${-s}px`,top:`${-l}px`,width:`${innerWidth}px`,height:`${innerHeight+l}px`});return}Object.assign(e.style,{left:`${-s}px`,top:`${-t.top}px`,width:`${innerWidth}px`,height:`${Math.max(innerHeight,t.top+n.clientHeight)}px`})}paintPending(){this.box&&this.ui.setFramePending(this.box,this.inFlight>0||this.queue.length>0)}scheduleFlush(){this.paintPending(),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},ta))}pump(){for(;this.inFlight<oa&&this.queue.length;)this.send(this.queue.splice(0,na))}async send(e){let t=this.session,n=this.settings();this.inFlight++;let r;try{r=await Eo(e.map(s=>({markup:s.segment.markup,hint:s.segment.sourceHint()})),n.sourceLang,n.targetLang)}catch{r=void 0}if(t!==this.session||!j())return;this.inFlight--;let i;e.forEach((s,a)=>{let l=r?.[a],c=s.segment.run;if(l?.ok&&l.text.trim()){let d=new Set(c.slots.map((u,h)=>h));this.mirror?.setTranslation(s.copy,Ee(V(l.text,d),u=>!!c.slots[u]?.detached),c.slots,wo(c.markup)),this.replaceOnPage(s,l.text,n),this.setState(s,"done")}else this.mirror?.setKept(s.copy),this.setState(s,"failed"),i??=l&&!l.ok?l.code:"network"}),i&&this.ui.toast(this.ui.errorMessage(i)),this.requestSync(),this.pump(),this.paintPending()}replaceOnPage(e,t,n){let r=e.segment;!r||this.pageTranslated()||(r.setTranslation(t),r.render({mode:"replace",dualStyle:"plain",fontScale:100,targetLang:n.targetLang,theme:ue(n.themeColor)}))}updateLabel(){if(!this.labels.length)return;let e=0,t=0;for(let n of this.entries)n.kind==="code"?t++:n.state==="done"&&e++;for(let n of this.labels)n.textContent=y("scanStatus",String(e),String(t))}copyAll(){let e=Gn(this.entries);navigator.clipboard.writeText(e).then(()=>{for(let t of this.labels)t.textContent=y("copied");setTimeout(()=>this.updateLabel(),1200)})}async withPicture(e){let t=this.card;if(!t||!this.restoreCard||this.exporting)return;this.exporting=!0;let n=this.session;t.setAttribute("data-exporting",""),this.clearFind();let r=v("div","scan-making"),i=v("div","scan-making-note");i.append(v("span","scan-making-spin"),v("span","",y("exportingFast"))),r.append(i),this.body?.append(r),await ga();try{let s=await this.drawResult().catch(()=>null)??await this.photographResult();if(!s||n!==this.session)return;let a=this.mirror?.scroller??this.mirror?.doc.body;return await e(vo(s,a?jt(a):"#ffffff",y("pictureMark",y("extName")),devicePixelRatio||1))}catch{this.ui.toast(y("exportFailed"));return}finally{r.remove(),n===this.session&&(this.exporting=!1,t.removeAttribute("data-exporting"),this.updateLabel())}}async drawResult(){let e=this.mirror,t=this.view,n=this.body,r=e?.scroller;if(!e||!t||!n||!r)throw new Error("not ready");let i=r!==e.doc.scrollingElement,s=i?r:e.doc.body,{from:a,to:l,visible:c}=t.extent,d=devicePixelRatio||1,u=n.getBoundingClientRect().left-e.frame.getBoundingClientRect().left,h=s.getBoundingClientRect();return yo(s,{left:u-h.left,top:i?a:a-(h.top+(e.doc.defaultView?.scrollY??0)),width:n.clientWidth,height:l-a+c},d)}async photographResult(){let e=this.view,t=this.body;if(!e||!t)return null;let n=this.session,r=e.position;this.card?.setAttribute("data-photographing","");try{await new Promise(p=>setTimeout(p,340));let{from:i,to:s,visible:a}=e.extent,l=t.getBoundingClientRect(),c=devicePixelRatio||1,d=document.createElement("canvas");d.width=Math.round(l.width*c),d.height=Math.min(Math.round((s-i+a)*c),ha);let u=d.getContext("2d");if(!u)throw new Error("no canvas");let h=Math.ceil(d.height/c/a);for(let p=0;p<h;p++){if(!this.exporting||n!==this.session)return null;for(let b of this.labels)b.textContent=y("exporting",String(p+1),String(h));e.moveTo(i+p*a),await new Promise(b=>setTimeout(b,p?ua:pa));let f=await B({type:"capture:screen"});if(!f)throw new Error("refused");let m=await createImageBitmap(ba(f)),g=m.width/innerWidth;u.drawImage(m,l.left*g,l.top*g,l.width*g,l.height*g,0,Math.round((e.position-i)*c),d.width,Math.round(l.height*c)),m.close()}return d}finally{this.card?.removeAttribute("data-photographing"),n===this.session&&e.moveTo(r)}}async saveImage(){await this.withPicture(async e=>{let t=await ko(e),n=document.createElement("a");n.href=URL.createObjectURL(t),n.download=`yilan-${location.hostname}-${new Date().toISOString().slice(0,10)}.png`,n.click(),setTimeout(()=>URL.revokeObjectURL(n.href),1e4)})}copyImage(){if(!this.restoreCard||this.exporting)return;if(!navigator.clipboard?.write){this.ui.toast(y("copyImageFailed"));return}let e=()=>{},t=()=>{},n=new Promise((i,s)=>{e=i,t=s}),r=navigator.clipboard.write([new ClipboardItem({"image/png":n})]);this.withPicture(async i=>(e(await ko(i)),await r,this.ui.toast(y("copiedImage"),void 0,1800),!0)).then(i=>{i||t(new Error("no picture"))}),r.catch(()=>this.ui.toast(y("copyImageFailed")))}requestSync(){this.frame||(this.frame=requestAnimationFrame(this.syncView))}syncView=()=>{this.frame=0;let e=this.rect;if(!e)return;this.placeFrame();let t=this.toContent(e.top),n=this.toContent(e.bottom),r=this.entries.find(i=>i.bottom>t&&i.top<n);r&&!this.restoreCard&&this.mirror?.alignTo(r.copy,e.top+(r.top-t))}};var xe="http://www.w3.org/2000/svg",pt=8,Gt=5,Xt=16,oe=8,ct=13,dt=8,ya=24,va=22,wa=1.6,xa=2e3,Ea=80,Sa=48,Ta=96,ut=3,ka=1100,Ma=0;function Ca(o){for(let e=o.parentElement;e;e=e.parentElement){let t=getComputedStyle(e).display;if(!t.startsWith("inline")&&t!=="contents")return e}return null}function Co(o){let e=o.commonAncestorContainer,t=new Map,n=document.createRange(),r=i=>{if(!i.data.trim()||!o.intersectsNode(i))return;let s=i===o.startContainer?o.startOffset:0,a=i===o.endContainer?o.endOffset:i.length;n.setStart(i,s),n.setEnd(i,a);let l=Array.from(n.getClientRects()).filter(u=>u.width&&u.height);if(!l.length)return;let c=Ca(i);if(!c)return;let d=t.get(c);d?(d.rects.push(...l),d.end=[i,a]):t.set(c,{el:c,rects:l,start:[i,s],end:[i,a]})};if(e.nodeType===Node.TEXT_NODE)r(e);else{let i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let s=i.nextNode(),a=0;s&&a<xa;s=i.nextNode(),a++)r(s)}return Array.from(t.values())}function Ao(o){return Co(o).map(e=>({el:e.el,members:[e.el],lines:Ro(e.rects)}))}function Ro(o){let e=[];for(let n of o){let r=e.find(i=>Math.min(i.bottom,n.bottom)-Math.max(i.top,n.top)>Math.min(i.bottom-i.top,n.bottom-n.top)/2);r?(r.left=Math.min(r.left,n.left),r.right=Math.max(r.right,n.right),r.top=Math.min(r.top,n.top),r.bottom=Math.max(r.bottom,n.bottom)):e.push({left:n.left,top:n.top,right:n.right,bottom:n.bottom})}return e.sort((n,r)=>n.top-r.top),e.some((n,r)=>r>0&&(n.left>e[r-1].right||n.right<e[r-1].left))?[{left:Math.min(...e.map(n=>n.left)),top:e[0].top,right:Math.max(...e.map(n=>n.right)),bottom:Math.max(...e.map(n=>n.bottom))}]:e}function Aa(o){for(let e=o;e&&e!==document.body;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return!0;return!1}function ht(o){return{left:Math.min(...o.map(e=>e.left)),top:Math.min(...o.map(e=>e.top)),right:Math.max(...o.map(e=>e.right)),bottom:Math.max(...o.map(e=>e.bottom))}}function No(o,e){let t=Math.max(o.left,e.left)-Math.min(o.right,e.right),n=Math.max(o.top,e.top)-Math.min(o.bottom,e.bottom);return t<=0&&n<=Ea||n<=0&&t<=Sa}function Ra(o){let e=o.map(t=>({el:t.el,members:[...t.members],lines:[...t.lines]}));for(let t=!0;t;){t=!1;for(let n=0;n<e.length&&!t;n++)for(let r=n+1;r<e.length&&!t;r++)No(ht(e[n].lines),ht(e[r].lines))&&(e[n].lines.push(...e[r].lines),e[n].members.push(...e[r].members),e.splice(r,1),t=!0)}return e.map(t=>({el:t.el,members:t.members,lines:Ro(t.lines)}))}function ft(o){let e=Ao(o).map(r=>({el:r.el,members:r.members,lines:r.lines.filter(i=>i.top>=0&&i.bottom<=innerHeight&&i.left>=0&&i.right<=innerWidth)})).filter(r=>r.lines.length),t=e.filter(r=>!Aa(r.el)),n=Ra(t.length?t:e);return n.length===1?{tail:n[0]}:null}function Lo(o){let e=[];for(let t of Co(o)){let n=ht(t.rects),r=e[e.length-1],i=!!r&&Math.min(r.box.bottom,n.bottom)>Math.max(r.box.top,n.top)&&n.left-r.box.right<=Ta;if(r&&i){r.range.setEnd(t.end[0],t.end[1]),r.box=ht([r.box,n]);continue}let s=document.createRange();s.setStart(t.start[0],t.start[1]),s.setEnd(t.end[0],t.end[1]),e.push({el:t.el,range:s,newPlace:!!r&&!No(r.box,n),box:n})}return e}function Po(o,e){let t=v("div","source-flash");for(let n of Ao(e).flatMap(r=>r.lines)){let r=v("div","source-flash-line");r.style.left=`${n.left-3}px`,r.style.top=`${n.top-2}px`,r.style.width=`${n.right-n.left+6}px`,r.style.height=`${n.bottom-n.top+4}px`,t.append(r)}o.add(t),setTimeout(()=>t.remove(),ka)}function Na(o){let e=[];for(let t of o){let n=e[e.length-1];(!n||Math.abs(n[0]-t[0])>.5||Math.abs(n[1]-t[1])>.5)&&e.push(t)}return e.filter((t,n)=>{let r=e[(n-1+e.length)%e.length],i=e[(n+1)%e.length];return!(Math.abs(r[0]-t[0])<.5&&Math.abs(i[0]-t[0])<.5)&&!(Math.abs(r[1]-t[1])<.5&&Math.abs(i[1]-t[1])<.5)})}function La(o){let e=o.length,t="";return o.forEach((n,r)=>{let i=o[(r-1+e)%e],s=o[(r+1)%e],a=Math.hypot(i[0]-n[0],i[1]-n[1]),l=Math.hypot(s[0]-n[0],s[1]-n[1]),c=Math.min(Xt,a/2,l/2),d=[n[0]+(i[0]-n[0])/a*c,n[1]+(i[1]-n[1])/a*c],u=[n[0]+(s[0]-n[0])/l*c,n[1]+(s[1]-n[1])/l*c];t+=`${r?"L":"M"}${d[0]} ${d[1]}Q${n[0]} ${n[1]} ${u[0]} ${u[1]}`}),`${t}Z`}function Pa(o){let e=document.createElementNS(xe,"path");e.setAttribute("d",o);let t=e.getTotalLength(),n=Math.max(10,Math.round(t/va)),r=[];for(let i=0;i<n;i++){let s=e.getPointAtLength(i/n*t);r.push([s.x,s.y])}return r.map((i,s)=>{let a=r[(s-1+n)%n],l=r[(s+1)%n],c=l[0]-a[0],d=l[1]-a[1],u=Math.hypot(c,d)||1,h=wa*(Math.sin(s*.9)*.6+Math.sin(s*.37+1.3)*.7);return[i[0]+d/u*-h,i[1]+c/u*h]})}function Kt(o,e,t){let n=o.length,r=s=>o[(s%n+n)%n],i="";for(let s=0;s<t;s++){let a=e+s,[l,c,d,u]=[r(a-1),r(a),r(a+1),r(a+2)];i+=`C${c[0]+(d[0]-l[0])/6} ${c[1]+(d[1]-l[1])/6} ${d[0]-(u[0]-c[0])/6} ${d[1]-(u[1]-c[1])/6} ${d[0]} ${d[1]}`}return i}function Ha(o){let{lines:e}=o,t=e[0],n=e[e.length-1],r=parseFloat(getComputedStyle(o.el).lineHeight),i=t.bottom-t.top,s=Gt+(r>i&&r<i*3?(r-i)/2:0),a=Math.max(ut,t.top-s),l=Math.min(innerHeight-ut,n.bottom+s),c=p=>Math.max(ut,p.left-pt),d=p=>Math.min(innerWidth-ut,p.right+pt),u=[[c(t),a],[d(t),a]],h=(p,f,m)=>(p.bottom+f.top)/2+(m?Gt:-Gt);e.forEach((p,f)=>{let m=e[f+1];if(!m)return;let g=h(p,m,d(p)>d(m));u.push([d(p),g],[d(m),g])}),u.push([d(n),l],[c(n),l]);for(let p=e.length-1;p>0;p--){let f=h(e[p-1],e[p],c(e[p-1])<c(e[p]));u.push([c(e[p]),f],[c(e[p-1]),f])}return{points:Pa(La(Na(u))),top:a,bottom:l,padY:s}}function Ho(o,e,t,n=!0){let{points:r,top:i,bottom:s,padY:a}=Ha(o),l=o.lines[0],c=o.lines[o.lines.length-1],d=s+ct+t<=innerHeight-oe,u=i-ct-t>=oe;if(!n||!d&&!u)return{path:"M"+r[0][0]+" "+r[0][1]+Kt(r,0,r.length)+"Z",left:Math.max(oe,Math.min(l.left,innerWidth-e-oe)),top:Math.max(oe,innerHeight-t-oe)};let h=d,p=h?c:l,f=h?s:i,m=p.left-pt+Xt+dt,g=p.right+pt-Xt-dt,b=h?g-12:m+12,x=g>m?Math.max(m,Math.min(b,g)):(p.left+p.right)/2,E=h?f+ct:f-ct,T=Math.min(ya,e/2),C=Math.max(oe,x-e+T),$=Math.min(innerWidth-e-oe,x-T),D=Math.max(C,Math.min(l.left,$)),P=r.length,z=-1,G=-1;r.forEach((k,O)=>{if(Math.abs(k[1]-f)>=a+6)return;let H=k[0]-x;H>=dt*.6&&(z<0||H<r[z][0]-x)&&(z=O),H<=-dt*.6&&(G<0||H>r[G][0]-x)&&(G=O)});let[S,R]=h?[z,G]:[G,z],L;if(S<0||R<0)L=`M${r[0][0]} ${r[0][1]}${Kt(r,0,P)}Z`;else{let k=(S-R+P)%P||P;L=`M${r[R][0]} ${r[R][1]}${Kt(r,R,k)}L${x} ${E}Z`}return{path:L,left:D,top:h?E-1:E-t+1}}function Io(o,e=!0){let t=document.createElementNS(xe,"svg");t.setAttribute("class","bubble-ring"),t.setAttribute("aria-hidden","true");let n=`yl-ring-${++Ma}`,r=document.createElementNS(xe,"defs"),i=document.createElementNS(xe,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[s,a]of Te){let l=document.createElementNS(xe,"stop");l.setAttribute("offset",s),l.setAttribute("stop-color",a),i.append(l)}r.append(i),t.append(r);for(let s of o){let a=document.createElementNS(xe,"path");a.setAttribute("d",s),e&&a.setAttribute("pathLength","1"),a.setAttribute("stroke",`url(#${n})`),t.append(a)}return t}function Do(o,e,t){let{path:n,left:r,top:i}=Ho(t.tail,e.offsetWidth,e.offsetHeight);e.style.left=`${r}px`,e.style.top=`${i}px`,o.insertBefore(Io([n]),e)}var mt=class{constructor(e,t,n){this.range=t;this.anchor=n.tail.el;let r=this.anchor.getBoundingClientRect();this.first={plan:n,top:r.top,left:r.left};let i=ye(this.anchor).map(s=>s.el);this.area=i[0],e.addToPage(this.node),this.pin=new ee(this.node,i)}node=v("div","source-ring");pin;area;anchor;first;get anchorBox(){return this.anchor.getBoundingClientRect()}retarget(e){this.anchor=e}tailless=!1;detachTail(){this.tailless=!0}setPending(e){this.node.toggleAttribute("data-pending",e)}layout(e,t){let n=this.anchor.getBoundingClientRect(),r=Math.abs(n.top-this.first.top)<1&&Math.abs(n.left-this.first.left)<1,i=ft(this.range)??(r?this.first.plan:null);if(!i)return null;let{path:s,left:a,top:l}=Ho(i.tail,e,t,!this.tailless),c=this.anchorBox,d=Io([s],!1);return d.style.left=`${-c.left}px`,d.style.top=`${-c.top}px`,this.node.replaceChildren(d),this.pin.place(c.left,c.top),{left:a,top:l}}follow(){let e=this.anchorBox;(e.width||e.height)&&this.pin.place(e.left,e.top)}clip(e,t){let n=this.area?.getBoundingClientRect();Oe(this.node,Math.max(e,n?.top??-1/0),Math.min(t,n?.bottom??1/0))}remove(){this.node.remove()}};function Ia(o){return o==="zh-Hans"?"zh-CN":o==="zh-Hant"?"zh-TW":o==="yue"?"zh-HK":o}function Da(o,e){let t=e.toLowerCase(),n=t.split("-")[0],r=a=>{let l=a.lang.toLowerCase().replace("_","-");return l!==t&&l.split("-")[0]!==n?-1:(l===t?2:0)+(a.localService?1:0)},i,s=-1;for(let a of o){let l=r(a);l>s&&(i=a,s=l)}return i}function _a(o,e,t){let n=Intl.Segmenter;if(!n)return Math.min(o.length,e+1);for(let r of new n(t,{granularity:"word"}).segment(o.slice(e)))if(r.segment.trim())return e+r.index+r.segment.length;return o.length}var gt=class{constructor(e,t=n=>new SpeechSynthesisUtterance(n)){this.synth=e;this.create=t}current;callbacks;get reading(){return this.current!==void 0}start(e,t,n){this.stop();let r=Ia(t),i=this.synth.getVoices(),s=Da(i,r);if(i.length&&!s){n.onEnd("noVoice");return}let a=this.create(e);a.lang=r,s&&(a.voice=s),a.onboundary=l=>{a!==this.current||l.name==="sentence"||n.onWord(l.charIndex,l.charLength?l.charIndex+l.charLength:_a(e,l.charIndex,r))},a.onend=()=>this.finish(a),a.onerror=l=>this.finish(a,l.error==="canceled"||l.error==="interrupted"?void 0:"failed"),this.current=a,this.callbacks=n,this.synth.speak(a)}stop(){let e=this.callbacks,t=this.current!==void 0;this.current=void 0,this.callbacks=void 0,t&&(this.synth.cancel(),e?.onEnd())}finish(e,t){if(e!==this.current)return;let n=this.callbacks;this.current=void 0,this.callbacks=void 0,n?.onEnd(t)}};var Ba=5e3,$a='yl-t,yl-r,pre,code,kbd,samp,textarea,input,select,[contenteditable]:not([contenteditable="false"]),.CodeMirror,.cm-editor,.monaco-editor,.ace_editor,.blob-code,.hljs,[role="textbox"],[role="code"]',Fa="yl-t,yl-ui,script,style,noscript,template",Wa=3e3,Ua=4,bt="	";function qa(o){let e=o;for(;e.parentElement&&getComputedStyle(e).display.startsWith("inline");)e=e.parentElement;return e}function ja(o,e){return Math.min(o.bottom,e.bottom)-Math.max(o.top,e.top)>=Math.min(o.height,e.height)/2}function _o(o){let e=o.commonAncestorContainer,t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),n=[""],r,i=0;for(let s=e.nodeType===Node.TEXT_NODE?e:t.nextNode();s;s=t.nextNode()){if(++i>Wa)return"";if(!o.intersectsNode(s))continue;let a=s.parentElement;if(!a||a.closest(Fa))continue;let l=getComputedStyle(a);if(l.visibility!=="visible"||l.userSelect==="none")continue;let c=s.data,d=s===o.startContainer?o.startOffset:0,u=s===o.endContainer?o.endOffset:c.length,h=document.createRange();h.setStart(s,d),h.setEnd(s,u);let p=h.getClientRects(),f=p[0],m=p[p.length-1];if(!f||!m||!f.width)continue;let b=l.whiteSpace.startsWith("pre")||l.whiteSpace==="break-spaces"?c.slice(d,u).replace(/\t/g,"  "):c.slice(d,u).replace(/\s+/g," ");if(!b.trim()&&!r)continue;let x=qa(a);if(r){let T=ja(r.rect,f);r.flow!==x&&!T?n.push(""):r.flow!==x?n[n.length-1]+=bt:T&&f.left-r.rect.right>=Ua&&(n[n.length-1]+=" ")}let E=b.split(`
`);n[n.length-1]+=E[0]??"",n.push(...E.slice(1)),b.trim()&&(r={flow:x,rect:m})}return n.map(s=>s.replace(/ {2,}/g," ").replace(/ *\t[ \t]*/g,bt).replace(/^\t+|\t+$/g,"").trim()).filter(Boolean).join(`
`)}function za(o,e){let t=[...o.matchAll(/[\t\n]/g)].map(r=>r[0]),n=e.split(`
`);return!t.includes(bt)||n.length!==t.length+1?e:n.reduce((r,i,s)=>r+(t[s-1]===bt?" ":`
`)+i)}function Oo(o,e){try{return new Intl.DisplayNames([e],{type:"language"}).of(o)??o}catch{return o}}var Bo=60,Ga=6,Ka=40,Uo=.6;function $o(o){if(!o)return;let e=o.startContainer,t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement,n=ye(t).map(i=>i.el).find(i=>i.clientHeight>=innerHeight*Uo);if(!n)return;let r=n.getBoundingClientRect();return{top:r.top,bottom:r.bottom}}async function Xa(o){let e=NaN,t=0,n=performance.now();for(;t<5&&performance.now()-n<1200;){await new Promise(i=>requestAnimationFrame(i));let r=o.getBoundingClientRect().top;t=r===e?t+1:0,e=r}}function Fo(o,e){return new DOMRect(o,e,0,0)}var yt=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("mouseup",this.onMouseUp),document.addEventListener("mousedown",this.onMouseDown,!0),document.addEventListener("keydown",this.onKeyDown,!0),addEventListener("scroll",this.onScroll,{passive:!0,capture:!0}),addEventListener("resize",this.onResize)}bubble;card;followFrame=0;reader=new gt(speechSynthesis);update(e,t){this.settings=e,this.enabled=t,t||this.closeAll()}translateText(e){let t=getSelection(),n=t&&t.rangeCount?t.getRangeAt(0).cloneRange():void 0,r=n?.getBoundingClientRect();n&&r&&r.width?this.openCard(e,r,{range:n,plan:ft(n),x:r.right,y:r.bottom}):this.openCard(e,new DOMRect(innerWidth/2-240,80,0,0))}isOwnEvent(e){return this.ui.ownsEvent(e)}onMouseDown=e=>{this.isOwnEvent(e)||this.closeAll()};onKeyDown=e=>{e.key==="Escape"&&this.closeAll()};onScroll=e=>{this.isOwnEvent(e)||(this.bubble?.remove(),this.bubble=void 0,this.followFrame||(this.followFrame=requestAnimationFrame(this.followSource)))};onResize=()=>{this.card&&this.placeCard(this.card)};followSource=()=>{this.followFrame=0;let e=this.card;if(!e?.ring)return;e.ring.follow();let t=e.ring.anchorBox;(t.width||t.height)&&e.pin?.place(t.left+e.dx,t.top+e.dy),this.clearOfBars(e)};placeCard(e){if(!e.ring||!e.pin)return;let t=e.ring.anchorBox,n=()=>e.pin?.place(t.left+e.dx,t.top+e.dy);if(t.bottom<0||t.top>innerHeight){n();return}let r=e.ring.layout(e.node.offsetWidth,e.node.offsetHeight);if(!r||e.moved){n();return}e.dx=r.left-t.left,e.dy=r.top-t.top,e.pin.place(r.left,r.top),this.clearOfBars(e)}clearOfBars(e){if(!e.ring)return;let t=this.ui.settleUnderBars(),n=e.area&&e.area.clientHeight>=innerHeight*Uo?e.area.getBoundingClientRect():void 0,r=Math.max(t.top,n?.top??-1/0),i=Math.min(t.bottom,n?.bottom??1/0);Oe(e.node,r,i),e.ring.clip(t.top,t.bottom)}closeCard(e){e.alive=!1,e.menu?.close(),this.card===e&&(this.card=void 0),this.reader.stop(),e.ring?.remove(),this.ui.dismiss(e.node)}onMouseUp=e=>{j()&&(!this.enabled||this.settings.selectionTrigger==="off"||this.isOwnEvent(e)||setTimeout(()=>this.evaluate(e),0))};evaluate(e){let t=getSelection();if(!t||t.isCollapsed||!t.rangeCount)return;let n=t.getRangeAt(0),r=_o(n)||t.toString().trim();if(!r||r.length>Ba||!new RegExp("\\p{L}","u").test(r)||Va(n))return;let i=n.getBoundingClientRect();if(!i.width&&!i.height)return;let s=n.cloneRange(),a=ft(s);if(this.settings.selectionTrigger==="auto"){this.openCard(r,Fo(e.clientX,e.clientY),{range:s,plan:a,x:e.clientX,y:e.clientY});return}this.showBubble(r,e.clientX,e.clientY,s,a)}showBubble(e,t,n,r,i){this.bubble?.remove();let s=v("div","bubble"),a=v("div","bubble-tab"),l=v("button","bubble-action");l.type="button",l.title=y("selectionBubble"),l.setAttribute("aria-label",y("selectionBubble")),l.append(pe("translate"),v("span","",y("selectionAction"))),l.addEventListener("click",()=>{s.remove(),this.bubble=void 0,this.openCard(e,Fo(t,n),{range:r,plan:i,x:t,y:n})}),a.append(l),s.append(a),this.bubble=this.ui.add(s),i?Do(s,a,i):(a.style.left=`${Math.max(8,Math.min(t+6,innerWidth-a.offsetWidth-8))}px`,a.style.top=`${Math.max(8,Math.min(n+10,innerHeight-a.offsetHeight-8))}px`)}glossaryEditor(e,t,n,r){let i=v("div","card-glossary"),s=v("input","card-glossary-input");s.value=e,s.setAttribute("aria-label",y("glossaryTerm"));let a=v("input","card-glossary-input");a.value=t.length<=Bo?t:"",a.placeholder=y("glossaryKeep"),a.setAttribute("aria-label",y("glossaryTranslation"));let l=v("button","card-glossary-save",y("glossarySave"));l.type="button";let c=async()=>{let d=s.value.trim();if(!d)return;let u=(await chrome.storage.sync.get("glossary")).glossary,h=a.value.trim(),p=h?{from:d,to:h,lang:n}:{from:d,to:""},f=(u??[]).filter(m=>!(m.from.toLowerCase()===d.toLowerCase()&&(m.lang??"")===(p.lang??"")));await chrome.storage.sync.set({glossary:[...f,p].slice(-200)}),i.remove(),r(y("glossaryAdded"),1800)};l.addEventListener("click",()=>void c());for(let d of[s,a])d.addEventListener("keydown",u=>{u.key==="Enter"&&c()});return i.append(s,v("span","card-glossary-arrow","→"),a,l),setTimeout(()=>a.focus(),0),i}startDrag(e,t,n){if(n.button!==0)return;n.preventDefault(),t.setPointerCapture(n.pointerId);let r={x:n.clientX,y:n.clientY},i=e.node.getBoundingClientRect(),s={dx:e.dx,dy:e.dy};e.node.toggleAttribute("data-dragging",!0),e.moved||(e.moved=!0,e.ring?.detachTail(),e.ring?.layout(e.node.offsetWidth,e.node.offsetHeight));let a=c=>{let d=Math.max(8,Math.min(i.left+c.clientX-r.x,innerWidth-i.width-8)),u=Math.max(8,Math.min(i.top+c.clientY-r.y,innerHeight-40));if(e.ring&&e.pin){e.dx=s.dx+d-i.left,e.dy=s.dy+u-i.top;let h=e.ring.anchorBox;e.pin.place(h.left+e.dx,h.top+e.dy)}else e.node.style.left=`${d}px`,e.node.style.top=`${u}px`},l=()=>{t.removeEventListener("pointermove",a),t.removeEventListener("pointerup",l),t.removeEventListener("pointercancel",l),e.node.removeAttribute("data-dragging"),this.clearOfBars(e)};t.addEventListener("pointermove",a),t.addEventListener("pointerup",l),t.addEventListener("pointercancel",l)}async jumpTo(e,t){let n=t.el.getBoundingClientRect();if(!(n.top>=0&&n.bottom<=innerHeight)){if(t.el.scrollIntoView({block:"center",behavior:"instant"}),await Xa(t.el),!e.alive)return;e.ring&&(e.ring.retarget(t.el),this.placeCard(e))}Po(this.ui,t.range)}openCard(e,t,n){this.closeAll();let r=this.settings.targetLang,i=v("div","card");i.setAttribute("role","dialog"),i.setAttribute("aria-label",y("selectionBubble"));let s=v("div","card-body"),l=(n?Lo(n.range):[]).map(M=>({segment:M,text:_o(M.range)||M.range.toString().trim()})).filter(M=>new RegExp("\\p{L}","u").test(M.text)),d=(l.length>1&&l.length<=Ka?l:[{segment:void 0,text:e}]).map(M=>{let w=v("div","card-seg"),N=v("div","card-source",M.text);N.title=M.text;let I=v("div","card-result",y("translating"));I.dataset.state="loading",w.append(N,I);let{segment:A}=M;if(A){w.title=y("jumpToSource"),w.dataset.jump="";let F=[0,0];w.addEventListener("mousedown",_=>F=[_.clientX,_.clientY]),w.addEventListener("click",_=>{Math.hypot(_.clientX-F[0],_.clientY-F[1])<4&&this.jumpTo(k,A)})}return s.append(w),{text:M.text,result:I,translated:"",start:0}}),u=en(),h=v("span","grow card-langs"),p=v("span","card-from"),f=v("button","card-lang");f.type="button",f.title=y("targetLang"),f.setAttribute("aria-haspopup","listbox");let m=v("span","");f.append(m,v("i","card-lang-chevron"));let g="",b=()=>{p.textContent=g&&g!==r?`${Oo(g,u)} → `:"",m.textContent=Oo(r,u),h.replaceChildren(p,f)};b();let x,E=(M,w)=>{h.replaceChildren(M),clearTimeout(x),x=setTimeout(b,w)},T="",C=q("copy",y("copy"),()=>{navigator.clipboard.writeText(T).then(()=>E(y("copied"),1200))}),$=(M,w)=>{let N=d.find(W=>W.translated&&M>=W.start&&M<W.start+W.translated.length);if(!N)return;for(let W of d)W!==N&&W.translated&&(W.result.textContent=W.translated);let I=M-N.start,A=Math.min(w-N.start,N.translated.length),F=v("mark","card-word",N.translated.slice(I,A));N.result.replaceChildren(N.translated.slice(0,I),F,N.translated.slice(A));let _=F.offsetTop-s.offsetTop;(_<s.scrollTop||_+F.offsetHeight>s.scrollTop+s.clientHeight)&&(s.scrollTop=_-24)},D=M=>{if(P.toggleAttribute("data-on",M),P.title=M?y("stopSpeaking"):y("speak"),P.setAttribute("aria-label",P.title),P.replaceChildren(pe(M?"stop":"speak")),!M)for(let w of d)w.translated&&(w.result.textContent=w.translated)},P=q("speak",y("speak"),()=>{if(this.reader.reading){this.reader.stop();return}T&&(D(!0),this.reader.start(T,r,{onWord:$,onEnd:M=>{D(!1),M&&E(y(M==="noVoice"?"noVoice":"speakFailed"),2400)}}))}),z=q("close",y("close"),()=>this.closeCard(k)),G=v("div","card-foot"),S=d.length===1&&e.length<=Bo&&e.split(/\s+/).length<=Ga,R=q("glossary",y("addToGlossary"),()=>{i.querySelector(".card-glossary")||(i.insertBefore(this.glossaryEditor(e.trim(),d[0]?.translated??"",r,E),G),this.placeCard(k))});S?G.append(h,R,C,P,z):G.append(h,C,P,z);let L=v("div","card-grip");L.title=y("moveCard"),L.setAttribute("aria-label",y("moveCard")),L.addEventListener("pointerdown",M=>this.startDrag(k,L,M)),i.append(L,s,G);let k={node:i,dx:0,dy:0,alive:!0};if(this.card=k,n?.plan){let M=ye(n.plan.tail.el).map(w=>w.el);k.area=M[0],k.ring=new mt(this.ui,n.range,n.plan),k.ring.setPending(!0),i.dataset.onPage="",this.ui.addToPage(i),k.pin=new ee(i,M),this.placeCard(k)}else this.ui.add(i),this.ui.place(i,t,8,$o(n?.range));let O=0,H=async()=>{let M=++O;try{let w=await B({type:"translate",items:d.map(A=>X(A.text.replace(/\t/g,`
`))),from:this.settings.sourceLang,to:r});if(!k.alive||M!==O)return;d.forEach((A,F)=>{let _=w?.results?.[F];_?.ok?(delete A.result.dataset.state,A.translated=za(A.text,re(_.text)),A.result.textContent=A.translated,_.detected&&(g=_.detected,b())):(A.result.dataset.state="error",A.result.textContent=this.ui.errorMessage(_?.code??"network"))});let N=0,I=d.filter(A=>A.translated);for(let A of I)A.start=N,N+=A.translated.length+2;T=I.map(A=>A.translated).join(`

`)}catch{if(!k.alive||M!==O||!j())return;for(let w of d)w.result.dataset.state="error",w.result.textContent=this.ui.errorMessage("network")}!k.alive||M!==O||(k.ring?.setPending(!1),s.style.overscrollBehavior=s.scrollHeight>s.clientHeight?"contain":"",k.ring?this.placeCard(k):k.moved||this.ui.place(i,t,8,$o(n?.range)))},J=!1;f.addEventListener("pointerdown",()=>J=!!k.menu?.isOpen()),f.addEventListener("click",()=>{if(J){k.menu?.close(),k.menu=void 0;return}k.menu=Fe(this.ui,f.getBoundingClientRect(),r,y("targetLang"),M=>{if(k.menu=void 0,M!==r){r=M,this.reader.stop(),T="";for(let w of d)w.translated="",w.result.dataset.state="loading",w.result.textContent=y("translating");b(),k.ring?.setPending(!0),H()}})}),H()}closeAll(){this.ui.dismiss(this.bubble),this.bubble=void 0,this.card&&this.closeCard(this.card)}};function Va(o){let e=o.commonAncestorContainer;if(Wo(e))return!0;if(e.nodeType===Node.TEXT_NODE)return!1;let t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let n=t.nextNode();n;n=t.nextNode()){if(!o.intersectsNode(n))continue;let r=n,i=n===o.startContainer?o.startOffset:0,s=n===o.endContainer?o.endOffset:r.length;if(r.data.slice(i,s).trim()&&!Wo(n))return!1}return!0}function Wo(o){return!!(o.nodeType===Node.ELEMENT_NODE?o:o.parentElement)?.closest($a)}var qo="__yilan_region_ask__",Go=1500,Ya=2e3,Ko="__yilan_handover__",jo=globalThis;async function Ja(){let o=document.documentElement.lang?.trim();if(o)return o;let e=document.body?.innerText?.slice(0,Go)??"";if(e.trim())try{let n=(await chrome.i18n.detectLanguage(e)).languages?.[0];return n&&n.percentage>=50?n.language:void 0}catch{return}}async function zo(o){let e=document.body?.innerText?.slice(0,Go)??"",t;if(e.trim())try{let r=(await chrome.i18n.detectLanguage(e)).languages?.[0];r&&r.percentage>=50&&(t=r.language)}catch{}return t??=document.documentElement.lang?.trim()||void 0,t!==void 0&&!Mn(t,o)}function Za(o,e){let t=o.toLowerCase().split("-")[0];return e.some(n=>n.toLowerCase()===o.toLowerCase()||n.toLowerCase().split("-")[0]===t)}async function Qa(){let o=await Tt();Qt(S=>B({type:"i18n:messages",locale:S})),await wt(o.uiLang);let e=location.hostname,t=S=>!kt(e,S.neverSites),n=new $e,r=()=>{let S=cn(o.appearance);n.setTheme(_e(ue(o.themeColor),S?an:De),S)};r(),matchMedia("(prefers-color-scheme: dark)").addEventListener("change",r);let i=new Qe(o,n),s=new yt(o,n,t(o)),a=new We(o,n,t(o)),l=new Ze(n),c=new lt(n,()=>o,()=>i.hasPageTranslations),d=new Set,u=(S,R)=>{let L=0;for(let k of Array.from(document.querySelectorAll("iframe"))){let O=k.getBoundingClientRect(),H={left:S.left-O.left-k.clientLeft,top:S.top-O.top-k.clientTop,right:S.right-O.left-k.clientLeft,bottom:S.bottom-O.top-k.clientTop};H.right<=0||H.bottom<=0||H.left>=O.width||H.top>=O.height||(k.contentWindow?.postMessage({[qo]:!0,rect:H,token:R},"*"),L++)}return L},h=async S=>{let R=window===window.top;R&&l.showPending(S);let L=await i.translateRegion(S);return L&&await i.regionSettled(),R?l.settle(L>0):L>0};addEventListener("message",S=>{let R=S.data;if(!R||typeof R!="object"||typeof R.token!="string"||!(qo in R)||S.source!==parent||!d.has(R.token)||!R.rect)return;let{left:L,top:k,right:O,bottom:H}=R.rect;[L,k,O,H].every(Number.isFinite)&&(u({left:L,top:k,right:O,bottom:H},R.token),h({left:L,top:k,right:O,bottom:H}))});let p=()=>{l.close(),i.restoreRegion(),c.stop()},f=()=>{p(),B({type:"region:closeAll"}).catch(()=>{})},m=!1,g=S=>{S.key!=="Escape"||!m||(S.preventDefault(),S.stopPropagation(),m=!1,removeEventListener("keydown",g,!0),f())},b=new je(n),x=S=>{if(window!==top){B({type:"marquee:request",mode:S}).catch(()=>{});return}f(),focus(),b.begin(R=>{if(S==="scan"){c.start(R);return}m=!0,addEventListener("keydown",g,!0);let L=crypto.randomUUID();(async()=>{await B({type:"region:arm",token:L}).catch(()=>{}),await new Promise(H=>setTimeout(H,50));let k=u(R,L);!await h(R)&&!k&&n.toast(l.emptyMessage)})()})},E=!1,T=!1,C=()=>{E||(E=!0,clearInterval($),m=!1,removeEventListener("keydown",g,!0),b.cancel(),p(),i.retire(),s.update(o,!1),a.update(o,!1))},$=setInterval(()=>{j()||C()},Ya);addEventListener(Ko,()=>{j()||(T=!0,C())});let D=y("refreshAfterUpdate");return En(()=>o.shortcuts,S=>{if(!j()){C(),T||n.toast(D);return}S==="marquee"?x("cover"):S==="sweep"?x("scan"):B({type:"shortcut:page",action:S}).catch(()=>{})}),dn(S=>{!o.autoTranslate&&S.autoTranslate&&t(S)&&zo(S.targetLang).then(R=>R?i.startPage():void 0),S.uiLang!==o.uiLang&&wt(S.uiLang),o=S,r(),i.applySettings(S),s.update(S,t(S)),a.update(S,t(S))}),{handle:(S,R)=>{switch(S.type){case"page:translate":f(),i.startPage();break;case"page:restore":f(),i.restore();break;case"page:toggle":f(),i.togglePage();break;case"page:retry":i.retryFailed();break;case"page:status":R(i.status());return;case"mode:toggle":{let L=o.mode==="dual"?"replace":"dual";o={...o,mode:L},i.setMode(L),window===top&&chrome.storage.sync.set({mode:L});break}case"marquee:start":x(S.mode??"cover");break;case"region:arm":d.add(S.token),setTimeout(()=>d.delete(S.token),5e3);break;case"region:close":p();break;case"selection:translate":s.translateText(S.text);break}R(!0)},afterReady:async()=>{let S=await Ja();i.setPageLang(S),(t(o)&&(kt(e,o.alwaysSites)||S!==void 0&&Za(S,o.alwaysLangs)||o.autoTranslate&&await zo(o.targetLang))||await B({type:"tab:hello"}).catch(()=>!1))&&await i.startPage()}}}function el(){if(document.contentType!=="text/html"&&document.contentType!=="application/xhtml+xml"||Nn()||jo.__yilanAlive?.())return;jo.__yilanAlive=j,dispatchEvent(new Event(Ko));let o=Qa();chrome.runtime.onMessage.addListener((e,t,n)=>(o.then(({handle:r})=>r(e,n)),!0)),o.then(({afterReady:e})=>e())}el();})();
