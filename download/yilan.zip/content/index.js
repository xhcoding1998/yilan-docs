"use strict";(()=>{function re(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}var Ar={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" "};function ve(o){return o.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi,(e,t)=>{if(t[0]==="#"){let n=t[1]==="x"||t[1]==="X"?parseInt(t.slice(2),16):parseInt(t.slice(1),10);return!Number.isFinite(n)||n<0||n>1114111?e:String.fromCodePoint(n)}return Ar[t.toLowerCase()]??e})}var jt=/<\s*(\/?)\s*x\s*(\d{1,4})\s*>/gi;function ie(o,e){let t=[],n=[],r=new Set,i=l=>{let c=n.length?n[n.length-1].children:t,d=c[c.length-1];typeof l=="string"&&typeof d=="string"?c[c.length-1]=d+l:c.push(l)},s=[],a=0;jt.lastIndex=0;for(let l=jt.exec(o);l;l=jt.exec(o)){if(l.index>a){let u=ve(o.slice(a,l.index));u&&i(u)}a=l.index+l[0].length;let c=l[1]==="/",d=Number(l[2]);if(c){let u=s.lastIndexOf(d);if(u!==-1){s.splice(u,1);continue}let p=n.map(h=>h.slot).lastIndexOf(d);p!==-1&&(n.length=p)}else{if(r.has(d)||e&&!e.has(d)){s.push(d);continue}r.add(d);let u={slot:d,children:[]};i(u),n.push(u)}}if(a<o.length){let l=ve(o.slice(a));l&&i(l)}return t}function _e(o,e){let t=[];for(let n of o){if(typeof n=="string"){t.push(n);continue}let r=t[t.length-1];typeof r=="string"&&e(n.slot)&&(t[t.length-1]=r.replace(/\s*\n\s*$/," ")),t.push({slot:n.slot,children:_e(n.children,e)})}return t}function we(o){return o.map(e=>typeof e=="string"?e:we(e.children)).join("")}function Te(o,e=new Set){for(let t of o)typeof t!="string"&&(e.add(t.slot),Te(t.children,e));return e}function Y(){try{return!!chrome.runtime?.id}catch{return!1}}async function N(o){return await chrome.runtime.sendMessage(o)}var Mn=[{code:"zh_CN",name:"简体中文",bcp47:"zh-CN"},{code:"zh_TW",name:"繁體中文",bcp47:"zh-TW"},{code:"en",name:"English",bcp47:"en"},{code:"ja",name:"日本語",bcp47:"ja"},{code:"ko",name:"한국어",bcp47:"ko"},{code:"es",name:"Español",bcp47:"es"},{code:"fr",name:"Français",bcp47:"fr"},{code:"de",name:"Deutsch",bcp47:"de"}];var ke=null;function Cn(o){return Mn.some(e=>e.code===o)}var An=async o=>{let e=await fetch(chrome.runtime.getURL(`_locales/${o}/messages.json`));return e.ok?await e.json():null};function Rn(o){An=o}async function Rr(o){if(!Cn(o))return null;try{return await An(o)}catch{return null}}async function zt(o){if(!Cn(o)){ke=null;return}if(ke?.code===o)return;let e=await Rr(o);ke=e?{code:o,messages:e}:null}function Ln(){if(ke)return Mn.find(o=>o.code===ke.code)?.bcp47??"en";try{return chrome.i18n.getUILanguage()}catch{return"en"}}function Lr(o,e){let t=n=>n.replace(/\$(\d)/g,(r,i)=>e[Number(i)-1]??"");return o.message.replace(/\$([A-Za-z0-9_@]+)\$/g,(n,r)=>{let i=o.placeholders?.[r.toLowerCase()];return i?t(i.content):n}).replace(/\$\$/g,"$")}function b(o,...e){let t=ke?.messages[o];if(t)return Lr(t,e);try{return chrome.i18n.getMessage(o,e)||o}catch{return o}}var nt=["togglePage","toggleMode","marquee","sweep"],tt={togglePage:["Shift","Space","KeyT"],toggleMode:["Shift","Space","KeyD"],marquee:["Shift","Space","KeyS"],sweep:["Shift","Space","KeyX"]},Nr={togglePage:["Alt","Shift","KeyY"],toggleMode:["Alt","Shift","KeyD"]};function Nn(o){let e={...tt,...o};for(let t of nt){let n=Nr[t];n&&Kt(e[t],n)&&(e[t]=tt[t])}return e}var Gt=["Ctrl","Alt","Shift","Meta"];function Pn(o){return/^(Control|Alt|Shift|Meta|OS)(Left|Right)?$/.test(o)}function Hn(o){let e={Ctrl:o.ctrlKey,Alt:o.altKey,Shift:o.shiftKey,Meta:o.metaKey};return Gt.filter(t=>e[t])}function In(o){let e=t=>Gt.includes(t);return{mods:Gt.filter(t=>o.includes(t)),keys:o.filter(t=>!e(t))}}function Kt(o,e){return o.length>0&&o.length===e.length&&o.every(t=>e.includes(t))}var rt="#ffffff",On="#1f2329",_n="#14171c";function Bn(o){return o==="dark"?!0:o==="light"?!1:matchMedia("(prefers-color-scheme: dark)").matches}function Xt(o){let e=parseInt(o.slice(1),16),t=n=>{let r=n/255;return r<=.03928?r/12.92:((r+.055)/1.055)**2.4};return .2126*t(e>>16&255)+.7152*t(e>>8&255)+.0722*t(e&255)}function ot(o,e){let[t,n]=[Xt(o),Xt(e)].sort((r,i)=>i-r);return(t+.05)/(n+.05)}function it(o,e,t=4){if(ot(o,e)>=t)return o;let n=parseInt(o.slice(1),16),[r,i,s]=[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255],a=Math.max(r,i,s),l=Math.min(r,i,s),c=a-l,d=0;c&&(a===r?d=((i-s)/c+6)%6:a===i?d=(s-r)/c+2:d=(r-i)/c+4),d*=60;let u=(a+l)/2,p=c?c/(1-Math.abs(2*u-1)):0,h=m=>{let f=p*Math.min(m,1-m),v=w=>{let E=(w+d/30)%12;return Math.round(255*(m-f*Math.max(-1,Math.min(E-3,9-E,1)))).toString(16).padStart(2,"0")};return`#${v(0)}${v(8)}${v(4)}`},g=Xt(e)<.2?.01:-.01;for(let m=u;m>=0&&m<=1;m+=g){let f=h(m);if(ot(f,e)>=t)return f}return g>0?"#ffffff":"#000000"}var Dn=[{id:"blue",color:"#1f77f3",name:"themeBlue"},{id:"red",color:"#ea303f",name:"themeRed"},{id:"orange",color:"#d45105",name:"themeOrange"},{id:"amber",color:"#a27304",name:"themeAmber"},{id:"green",color:"#108d4f",name:"themeGreen"},{id:"teal",color:"#0f8a86",name:"themeTeal"},{id:"violet",color:"#8561f2",name:"themeViolet"},{id:"pink",color:"#e72486",name:"themePink"}];function Me(o){return/^#[0-9a-f]{6}$/i.test(o)?o:(Dn.find(e=>e.id===o)??Dn[0]).color}var Pr={uiLang:"auto",targetLang:"zh-Hans",sourceLang:"",mode:"dual",dualStyle:"highlight",themeColor:"blue",appearance:"auto",shortcuts:tt,fontScale:100,selectionTrigger:"icon",showOriginalOnHover:!0,unlockCopy:!1,inputTranslate:!1,inputLang:"en",glossary:[],autoTranslate:!1,alwaysSites:[],neverSites:[],alwaysLangs:[],excludeSelectors:"",cacheDays:7};function Hr(o){let e=o.toLowerCase();return e==="zh-tw"||e==="zh-hk"||e==="zh-mo"||e.startsWith("zh-hant")?"zh-Hant":e.startsWith("zh")?"zh-Hans":e.split("-")[0]??"en"}async function Vt(){let o=await chrome.storage.sync.get(null),e={...Pr,...o,shortcuts:Nn(o.shortcuts)};return o.cacheDays===void 0&&o.persistentCache===!1&&(e.cacheDays=0),o.targetLang||(e.targetLang=Ir()),e}function Ir(){let o=Hr(chrome.i18n.getUILanguage());return Dr.has(o)?o:"en"}function Fn(o){chrome.storage.onChanged.addListener((e,t)=>{t==="sync"&&Vt().then(o)})}function Yt(o,e){return e.some(t=>o===t||o.endsWith(`.${t}`))}var xe=[{code:"zh-Hans",name:"简体中文"},{code:"zh-Hant",name:"繁體中文"},{code:"yue",name:"粵語"},{code:"en",name:"English"},{code:"ja",name:"日本語"},{code:"ko",name:"한국어"},{code:"fr",name:"Français"},{code:"de",name:"Deutsch"},{code:"es",name:"Español"},{code:"pt",name:"Português"},{code:"it",name:"Italiano"},{code:"ru",name:"Русский"},{code:"uk",name:"Українська"},{code:"pl",name:"Polski"},{code:"nl",name:"Nederlands"},{code:"tr",name:"Türkçe"},{code:"ar",name:"العربية"},{code:"hi",name:"हिन्दी"},{code:"vi",name:"Tiếng Việt"},{code:"th",name:"ไทย"},{code:"id",name:"Bahasa Indonesia"}],$n={"zh-Hans":"chinese simplified 简体 中文 汉语 jianti zhongwen","zh-Hant":"chinese traditional 繁体 繁體 中文 fanti zhongwen",yue:"cantonese 粤语 广东话 yueyu guangdonghua",en:"english 英语 英文 yingyu yingwen",ja:"japanese 日语 日文 riyu riwen",ko:"korean 韩语 韩文 朝鲜语 hanyu hanwen",fr:"french 法语 法文 fayu",de:"german 德语 德文 deyu",es:"spanish 西班牙语 xibanya",pt:"portuguese 葡萄牙语 putaoya",it:"italian 意大利语 yidali",ru:"russian 俄语 俄文 eyu",uk:"ukrainian 乌克兰语 wukelan",pl:"polish 波兰语 bolan",nl:"dutch 荷兰语 helan",tr:"turkish 土耳其语 tuerqi",ar:"arabic 阿拉伯语 alabo",hi:"hindi 印地语 yindi",vi:"vietnamese 越南语 yuenan",th:"thai 泰语 taiyu",id:"indonesian 印尼语 印度尼西亚语 yinni"},Dr=new Set(xe.map(o=>o.code));var Un="__yilanFrame";var st=new Map,Wn=!1;function at(){Wn||window.top!==window||(Wn=!0,addEventListener("message",o=>{let e=o.data?.[Un];if(typeof e!="string")return;let t=Array.from(document.querySelectorAll("iframe")).find(n=>n.contentWindow===o.source);t&&(st.set(e,t),setTimeout(()=>st.delete(e),1e4))}))}function lt(o){try{window.top?.postMessage({[Un]:o},"*")}catch{}}async function Be(o){let e=st.get(o);for(let t=0;t<10&&!e;t++)await new Promise(n=>setTimeout(n,30)),e=st.get(o);return e}function Fe(o,e){let t=o.getBoundingClientRect(),n=t.left+o.clientLeft,r=t.top+o.clientTop;return{left:e.left+n,right:e.right+n,top:e.top+r,bottom:e.bottom+r}}function $e(o){return{left:o.left,top:o.top,right:o.right,bottom:o.bottom}}function We(o){let e=o;return!!e&&[e.left,e.top,e.right,e.bottom].every(Number.isFinite)}var Or=[.1,.35,.65,.9];function _r(o){for(let e=o;e&&e!==document.body&&e!==document.documentElement;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return e;return null}function Br(o){let e=null;for(let t=o;t&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t),r=parseInt(n.zIndex,10);n.position!=="static"&&!Number.isNaN(r)&&(e=r)}return e}function qn(o){let e=new Set;for(let t of Or)for(let n of document.elementsFromPoint(innerWidth*t,o)){if(n.localName==="yl-ui")continue;let r=_r(n);r&&r.getBoundingClientRect().height<innerHeight*.45&&e.add(r);break}return Array.from(e)}function Ue(){let o=new Set,e=0;for(let r=0;r<2;r++)for(let i of qn(e+2))o.add(i),e=Math.max(e,i.getBoundingClientRect().bottom);let t=innerHeight;for(let r of qn(t-2))o.add(r),t=Math.min(t,r.getBoundingClientRect().top);let n=null;for(let r of o){let i=Br(r);if(i===null)return{top:e,bottom:t,stacking:null};n=n===null?i:Math.min(n,i)}return{top:e,bottom:t,stacking:n}}function ct(o,e,t){if(e<=0&&t>=innerHeight){o.style.clipPath="";return}let n=o.getBoundingClientRect(),r=i=>Number.isFinite(i)?i:-9999;o.style.clipPath=`inset(${r(e-n.top)}px -9999px ${r(n.bottom-t)}px -9999px)`}var dt=`/* Thin gradient edges in the full palette on clean, light surfaces. */
:host {
  --ink: #000000;
  --paper: #ffffff;
  --muted: #666b73;
  --line: rgba(20, 30, 50, 0.1);
  --hover: color-mix(in srgb, var(--yl-theme) 8%, var(--paper));
  --shadow: 0 8px 28px rgba(20, 40, 80, 0.13), 0 1px 3px rgba(20, 40, 80, 0.08);
  --ease: cubic-bezier(0.2, 0.8, 0.2, 1);
  --spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  --edge: linear-gradient(115deg, #4da2ff, #55db9c 35%, #ffd731 62%, #fb4903 85%, #5c4ade);
  --yl-theme: #1f77f3;
  --yl-on-theme: #ffffff;
  --sky: color-mix(in srgb, var(--yl-theme) 13%, var(--paper));
  --glass: rgba(255, 255, 255, 0.7);
  --error: #c43a02;
}

:host([data-appearance='dark']) {
  --ink: #eef0f3;
  --paper: #1f2329;
  --muted: #9aa3ae;
  --line: rgba(255, 255, 255, 0.1);
  --hover: color-mix(in srgb, var(--yl-theme) 12%, var(--paper));
  --shadow: 0 8px 28px rgba(0, 0, 0, 0.28), 0 1px 3px rgba(0, 0, 0, 0.2);
  --sky: color-mix(in srgb, var(--yl-theme) 14%, var(--paper));
  --glass: rgba(255, 255, 255, 0.1);
  --error: #ff8a5c;
}

* {
  box-sizing: border-box;
}

.layer {
  position: fixed;
  font: 400 13px/1.45 Inter, 'Segoe UI', system-ui, -apple-system, 'Microsoft YaHei', sans-serif;
  color: var(--ink);
  pointer-events: auto;
}

/* ---- selection ------------------------------------------------------------ */

/* Holds nothing itself: its parts are placed on the screen. */
.bubble {
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

.bubble-ring {
  position: absolute;
  top: 0;
  left: 0;
  width: 1px;
  height: 1px;
  overflow: visible;
  pointer-events: none;
}

.bubble-ring path {
  fill: none;
  stroke-width: 2;
  stroke-linejoin: round;
  filter: drop-shadow(0 1px 3px rgba(20, 40, 80, 0.18));
}

/* Drawn once, as the selection is made. It stays as it is when the card takes the button's place. */
.bubble .bubble-ring path {
  stroke-dasharray: 1;
  animation: ring-draw 0.34s var(--ease);
}

/* The bar holding the actions, which the bubble's tail points at. */
.bubble-tab {
  position: absolute;
  display: inline-flex;
  gap: 2px;
  padding: 3px;
  border-radius: 11px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  pointer-events: auto;
  animation: fade-in 0.18s var(--ease) 0.14s both;
}

@keyframes ring-draw {
  from {
    stroke-dashoffset: 1;
  }
}

.bubble-action {
  height: 28px;
  padding: 0 11px 0 8px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 0;
  border-radius: 8px;
  background: var(--yl-theme);
  color: var(--yl-on-theme);
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  transition: filter 0.15s, transform 0.15s var(--spring);
}

.bubble-action svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.bubble-action:hover {
  filter: brightness(1.1);
}

.bubble-action:active {
  transform: scale(0.96);
}

.card {
  width: 480px;
  max-width: calc(100vw - 16px);
  overflow: hidden;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  animation: enter 0.22s var(--ease);
}

/* Fades in without moving: while it rose into place, it could not be measured for where it is. */
.card[data-on-page] {
  z-index: 1;
  animation-name: fade-in;
}

/* The ring round the text, while its card is open. */
.source-ring {
  width: 1px;
  height: 1px;
  pointer-events: none;
}

/* Translating: dotted, and whole once the translation is in. */
.source-ring[data-pending] path {
  stroke-width: 2.6;
  stroke-linecap: round;
  stroke-dasharray: 0 7px;
}

/* Where the card is held to move it: a short bar across its top. */
.card-grip {
  height: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: grab;
  touch-action: none;
}

.card-grip::before {
  content: '';
  width: 34px;
  height: 4px;
  border-radius: 2px;
  background: var(--line);
  transition: background-color 0.15s, width 0.15s var(--ease);
}

.card-grip:hover::before,
.card[data-dragging] .card-grip::before {
  width: 42px;
  background: color-mix(in srgb, var(--yl-theme) 55%, var(--line));
}

.card[data-dragging] {
  user-select: none;
}

.card[data-dragging] .card-grip {
  cursor: grabbing;
}

.card-grip + .card-body {
  padding-top: 2px;
}

.card-body {
  max-height: 320px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba(20, 30, 50, 0.18) transparent;
  padding: 12px 14px 10px;
}

.card-source {
  /* All of it, as it was selected: it is read out as well. */
  margin-bottom: 10px;
  color: var(--muted);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  user-select: text;
}

.card-result {
  padding-top: 10px;
  border-top: 1px solid var(--line);
  font-size: 14px;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  user-select: text;
}

/* The sentence being read: underlined, the word in it lit where the voice says which. */
.card-sentence {
  color: var(--ink);
  text-decoration: underline;
  text-decoration-color: color-mix(in srgb, var(--yl-theme, #1f77f3) 55%, transparent);
  text-decoration-thickness: 2px;
  text-underline-offset: 3px;
  text-decoration-skip-ink: none;
}

/* In a card of several parts, each line has its own speaker, there when the line is pointed at. */
.card-line {
  position: relative;
  padding-right: 24px;
}

.card-say.icon-btn {
  position: absolute;
  top: -4px;
  right: -4px;
  width: 24px;
  height: 24px;
  opacity: 0;
  transition: opacity 0.15s, background-color 0.15s, color 0.15s;
}

.card-line > .card-result + .card-say {
  top: 6px;
}

.card-seg[data-jump] .card-line > .card-result + .card-say {
  top: -4px;
}

.card-line:hover > .card-say:not(:disabled),
.card-say[data-on],
.card-say:focus-visible {
  opacity: 1;
}

.card-say svg {
  width: 13px;
  height: 13px;
}

/* An English word: its phonetics, British and American, each one a press to hear it. */
.card-phon {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin: -4px 0 10px;
}

.card-seg[data-jump] .card-phon {
  margin: 0 0 6px;
}

.card-accent {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 8px 0 7px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: transparent;
  color: var(--ink);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
  transition: background-color 0.15s, color 0.15s, border-color 0.15s;
}

.card-accent:hover {
  background: var(--hover);
}

.card-accent[data-on] {
  border-color: color-mix(in srgb, var(--yl-theme, #1f77f3) 40%, transparent);
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 12%, transparent);
  color: var(--yl-theme, #1f77f3);
}

.card-accent-name {
  color: var(--muted);
  font-size: 11px;
}

.card-accent[data-on] .card-accent-name {
  color: inherit;
}

.card-accent-ipa {
  font-family: 'Lucida Sans Unicode', 'Segoe UI', 'Arial Unicode MS', sans-serif;
}

.card-accent svg {
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0.7;
}

/* The word being read. */
.card-word {
  border-radius: 3px;
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 26%, transparent);
  color: inherit;
}

/* Reading: the button stays lit, and a stop square replaces the speaker. */
.icon-btn[data-on],
.icon-btn[data-on]:hover {
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 14%, transparent);
  color: var(--yl-theme, #1f77f3);
}

.icon-btn[data-on] svg {
  fill: currentColor;
}

/* Between parts, one thin line, drawn apart from the part so its rounded corners do not bend it. */
.card-seg {
  position: relative;
}

.card-seg + .card-seg {
  margin-top: 11px;
}

.card-seg + .card-seg::before {
  content: '';
  position: absolute;
  top: -6px;
  left: 6px;
  right: 6px;
  border-top: 1px solid var(--line);
}

.card-seg[data-jump] .card-source {
  margin-bottom: 4px;
}

.card-seg[data-jump] .card-result {
  padding-top: 0;
  border-top: 0;
}


.card-seg[data-jump] {
  margin-left: -6px;
  margin-right: -6px;
  padding: 4px 6px;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.15s;
}

.card-seg[data-jump]:hover {
  background-color: var(--hover);
}

/* Shows where a part of the card came from, for a moment. */
.source-flash {
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

.source-flash-line {
  position: absolute;
  border-radius: 4px;
  background: color-mix(in srgb, var(--yl-theme) 32%, transparent);
  animation: flash-out 1.1s var(--ease) forwards;
}

@keyframes flash-out {
  0%,
  45% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}

.card-result[data-state='loading'] {
  color: var(--muted);
}

.card-result[data-state='error'] {
  color: var(--error);
}

/* Adding to the glossary, in the card itself. */
.card-glossary {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 14px;
  border-top: 1px solid var(--line);
}

.card-glossary-input {
  flex: 1;
  min-width: 0;
  height: 28px;
  padding: 0 8px;
  border-radius: 7px;
  border: 1px solid var(--line);
  background: var(--paper);
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  outline: none;
}

.card-glossary-input:focus {
  border-color: var(--yl-theme);
}

.card-glossary-arrow {
  color: var(--muted);
}

.card-glossary-save {
  height: 28px;
  padding: 0 12px;
  border: 0;
  border-radius: 7px;
  background: var(--yl-theme);
  color: var(--yl-on-theme);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}

/* The translation of a field, before anything in it changes. */
.write-pop {
  position: relative;
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  overflow: hidden;
  animation: fade-in 0.16s var(--ease);
}

/* In the corner, over the text's padding: no row of its own. */
.write-close {
  position: absolute;
  top: 4px;
  right: 4px;
}

.write-foot .grow {
  flex: 1;
}

.write-lang {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: var(--sky);
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}

.write-lang:hover {
  background: color-mix(in srgb, var(--yl-theme) 20%, var(--paper));
}

/* Part of the field or all of it. */
.write-scope {
  display: inline-flex;
  height: 30px;
  padding: 2px;
  border-radius: 8px;
  background: var(--sky);
}

.write-scope button {
  padding: 0 9px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--muted);
  font: inherit;
  font-size: 12.5px;
  white-space: nowrap;
  cursor: pointer;
}

.write-scope button:hover {
  color: var(--ink);
}

.write-scope button[aria-checked='true'] {
  background: var(--paper);
  color: var(--ink);
  font-weight: 500;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
}

.write-scope button:focus-visible {
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);
}

.write-chevron {
  width: 6px;
  height: 6px;
  margin-top: -3px;
  border-right: 1.5px solid currentColor;
  border-bottom: 1.5px solid currentColor;
  transform: rotate(45deg);
  opacity: 0.6;
}

.write-result {
  max-height: 220px;
  overflow-y: auto;
  padding: 12px 38px 12px 14px;
  font-size: 14px;
  line-height: 1.55;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  user-select: text;
}

/* The translation put back into the writer's language, to check it says what they meant. */
.write-back {
  display: flex;
  gap: 8px;
  margin: -4px 14px 10px;
  padding: 7px 10px;
  border-radius: 8px;
  background: var(--sky);
  color: var(--muted);
  font-size: 12.5px;
  line-height: 1.5;
}

.write-back[hidden] {
  display: none;
}

.write-back-label {
  flex: none;
  color: var(--yl-theme);
  font-weight: 600;
}

.write-back-text {
  min-width: 0;
  overflow-wrap: anywhere;
  white-space: pre-wrap;
  color: var(--ink);
}

.write-back[data-loading] .write-back-text {
  color: var(--muted);
}

.write-result:focus {
  outline: none;
}

.write-result[data-state='loading'] {
  color: var(--muted);
}

.write-result[data-state='error'] {
  color: var(--error);
}

.write-foot {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 10px 10px;
  border-top: 1px solid var(--line);
}

.write-copy,
.write-replace {
  height: 30px;
  padding: 0 14px;
  border-radius: 8px;
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}

.write-copy {
  border: 1px solid var(--line);
  background: var(--paper);
  color: var(--ink);
}

.write-copy:hover {
  background: var(--hover);
}

.write-replace {
  border: 0;
  background: var(--yl-theme);
  color: var(--yl-on-theme);
  font-weight: 500;
}

.write-replace:focus-visible,
.write-copy:focus-visible,
.write-lang:focus-visible {
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);
  outline-offset: 1px;
}

/* After copying: done in the theme colour, or failed in red, for a moment. */
.write-copy[data-done],
.icon-btn[data-done] {
  color: var(--yl-theme);
}

.write-copy[data-failed],
.icon-btn[data-failed] {
  color: var(--error);
}

.write-copy:disabled,
.write-replace:disabled {
  opacity: 0.5;
  cursor: default;
}

.lang-menu-item[data-current]::after {
  content: '✓';
  float: right;
  color: var(--yl-theme);
}

/* Which language to write in, this once. */
.lang-menu {
  width: 240px;
  display: flex;
  flex-direction: column;
  padding: 6px;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  animation: fade-in 0.14s var(--ease);
}

.lang-menu-search {
  height: 32px;
  margin-bottom: 4px;
  padding: 0 10px;
  border-radius: 8px;
  border: 1px solid var(--line);
  background: var(--paper);
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  outline: none;
}

.lang-menu-search:focus {
  border-color: var(--yl-theme);
}

.lang-menu-list {
  max-height: 228px;
  overflow-y: auto;
  scrollbar-width: thin;
}

.lang-menu-item {
  display: block;
  width: 100%;
  padding: 6px 10px;
  border: 0;
  border-radius: 7px;
  background: transparent;
  color: var(--ink);
  font: inherit;
  font-size: 13px;
  text-align: left;
  cursor: pointer;
}

.lang-menu-item:hover,
.lang-menu-item[data-active] {
  background: var(--hover);
}

.lang-menu-item[data-active] {
  color: var(--yl-theme);
  font-weight: 500;
}

.lang-menu-empty {
  padding: 10px;
  color: var(--muted);
  font-size: 13px;
}

/* While a field is being translated. */
.input-busy {
  padding: 3px 9px;
  border-radius: 999px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  font-size: 12px;
  color: var(--muted);
  pointer-events: none;
  animation: fade-in 0.15s var(--ease);
}

.card-foot {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px 6px 4px 14px;
  border-top: 1px solid var(--line);
  color: var(--muted);
  font-size: 12px;
}

.card-foot .grow {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* "English → 简体中文": the language translated into can be changed for this card. */
.card-langs {
  display: flex;
  align-items: center;
}

.card-from {
  flex: none;
}

.card-lang {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  height: 22px;
  margin-left: -2px;
  padding: 0 6px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--ink);
  font: inherit;
  font-weight: 500;
  cursor: pointer;
}

/* Alone in the foot, its text lines up where the label's did. */
.card-from:empty + .card-lang {
  margin-left: -6px;
}

.card-lang span {
  overflow: hidden;
  text-overflow: ellipsis;
}

.card-lang:hover,
.card-lang[aria-expanded='true'] {
  background: var(--sky);
}

.card-lang:focus-visible {
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);
}

.card-lang-chevron {
  flex: none;
  width: 5px;
  height: 5px;
  margin-top: -3px;
  border-right: 1.5px solid currentColor;
  border-bottom: 1.5px solid currentColor;
  transform: rotate(45deg);
  opacity: 0.55;
}

.icon-btn {
  width: 28px;
  height: 28px;
  padding: 0;
  display: grid;
  place-items: center;
  flex: none;
  border: 0;
  border-radius: 7px;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  transition: background-color 0.15s, color 0.15s, transform 0.15s var(--spring);
}

.icon-btn:hover {
  background: var(--hover);
  color: var(--ink);
}

.icon-btn:active {
  transform: scale(0.9);
}

.icon-btn svg {
  width: 15px;
  height: 15px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.tooltip {
  max-width: 420px;
  padding: 7px 10px;
  border-radius: 8px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  overflow-wrap: anywhere;
  pointer-events: none;
  animation: enter 0.16s var(--ease);
}

.toast {
  left: 50%;
  bottom: 28px;
  translate: -50% 0;
  max-width: min(480px, calc(100vw - 32px));
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 9px 14px;
  border-radius: 10px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  animation: rise 0.22s var(--ease);
}

.toast button {
  flex: none;
  padding: 0;
  border: 0;
  background: none;
  color: var(--ink);
  font: inherit;
  font-weight: 500;
  text-decoration: underline;
  cursor: pointer;
}

/* ---- frame ---------------------------------------------------------------- */

.region-box {
  border-radius: 10px;
  pointer-events: none;
}

/* Drawn as a stroke, so all four sides have one width at any screen scale. */
.flow-ring {
  position: absolute;
  overflow: visible;
  pointer-events: none;
}

.flow-line {
  fill: none;
}

/* Waiting for the translation: the frame breathes. */
.region-box[data-pending] .flow-ring {
  animation: frame-wait 0.9s ease-in-out infinite alternate;
}

/* ---- scan card ------------------------------------------------------------ */

.scan-card {
  display: flex;
  flex-direction: column;
  max-width: calc(100vw - 16px);
  overflow: hidden;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
}

.scan-immersive {
  animation: enter 0.24s var(--ease);
}

/* What scrolls passes under the head, which stands clear of it. */
.scan-immersive .scan-head {
  position: relative;
  z-index: 1;
  box-shadow: 0 1px 0 var(--line), 0 6px 12px -8px rgba(20, 30, 50, 0.35);
}

.scan-card[data-exporting] {
  pointer-events: none;
}

/* While the picture is made. Turning needs nothing from the page, which is busy drawing. */
.scan-making {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: grid;
  place-items: center;
  background: color-mix(in srgb, var(--paper) 62%, transparent);
  animation: fade-in 0.16s var(--ease);
}

.scan-making-note {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border-radius: 10px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  color: var(--ink);
  font-size: 13px;
}

.scan-making-spin {
  width: 14px;
  height: 14px;
  border-radius: 50%;
  border: 2px solid color-mix(in srgb, var(--yl-theme) 22%, transparent);
  border-top-color: var(--yl-theme);
  animation: making-turn 0.7s linear infinite;
}

@keyframes making-turn {
  to {
    transform: rotate(360deg);
  }
}

/* Being photographed, the slow way: nothing on the result that is not the result, and square
   and flat, or every screen brings its rounded corners and shadow into the joins. */
.scan-card[data-photographing] .scan-track,
.scan-card[data-photographing] .scan-making {
  visibility: hidden;
}

.scan-card[data-photographing] {
  border-radius: 0;
  background: var(--paper);
  box-shadow: none;
}

.scan-card[data-photographing] .scan-head {
  box-shadow: none;
}

.scan-closing {
  animation: leave 0.17s var(--ease) forwards !important;
  pointer-events: none;
}

.scan-track {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 12px;
  cursor: pointer;
  touch-action: none;
}

.scan-thumb {
  position: absolute;
  top: 0;
  right: 3px;
  width: 6px;
  border-radius: 3px;
  background: rgba(20, 30, 50, 0.26);
  transition: background-color 0.15s, width 0.15s var(--ease);
}

.scan-track:hover .scan-thumb {
  width: 8px;
  background: rgba(20, 30, 50, 0.42);
}

/* Small until there is something to say. */
.scan-find {
  flex: none;
  display: flex;
  align-items: center;
  gap: 5px;
  width: 148px;
  height: 26px;
  margin: 0 6px 0 10px;
  padding: 0 4px 0 8px;
  border: 1px solid var(--line);
  border-radius: 7px;
  background: var(--paper);
  color: var(--muted);
  cursor: text;
  transition: width 0.2s var(--ease), border-color 0.15s;
}

.scan-find:focus-within {
  border-color: var(--yl-theme);
}

.scan-find[data-typed] {
  width: 214px;
}

.scan-find > svg {
  flex: none;
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.scan-find-input {
  flex: 1;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: 0;
  outline: 0;
  background: none;
  color: var(--ink);
  font: inherit;
  font-size: 12px;
  user-select: text;
}

.scan-find-input::placeholder {
  color: var(--muted);
}

.scan-find-count {
  flex: none;
  display: none;
  font-size: 11px;
  font-variant-numeric: tabular-nums;
}

.scan-find .icon-btn {
  display: none;
  width: 20px;
  height: 20px;
  border-radius: 5px;
}

.scan-find .icon-btn svg {
  width: 13px;
  height: 13px;
}

.scan-find[data-typed] .scan-find-count,
.scan-find[data-found] .icon-btn {
  display: grid;
}

.scan-find[data-typed] .scan-find-count {
  display: block;
}

.scan-find[data-none] .scan-find-count {
  color: var(--error);
}

.scan-animate {
  transition: top 0.3s var(--ease), left 0.3s var(--ease), height 0.3s var(--ease), bottom 0.3s var(--ease);
}

.scan-backdrop {
  inset: 0;
  /* The page shows only through small holes in a veil, with its colour taken down: tidy on
     any page and with any theme colour. The same recipe as element-plus.org's navigation. */
  background-image: radial-gradient(transparent 1px, var(--paper) 1px);
  background-size: 4px 4px;
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(1.7);
  -webkit-backdrop-filter: var(--veil);
  backdrop-filter: var(--veil);
  animation: fade-in 0.28s var(--ease);
}

/* A light page through a dark veil is a harsh grid unless the page comes down to its level. */
:host([data-appearance='dark']) .scan-backdrop {
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(0.4);
}

/* Only ever seen at full screen. */
.scan-card[data-hidden] {
  visibility: hidden;
  pointer-events: none;
}

.scan-bar {
  display: flex;
  align-items: center;
  gap: 2px;
  height: 36px;
  padding: 0 4px 0 12px;
  border: 1.5px solid transparent;
  border-radius: 10px;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  font-size: 12px;
  white-space: nowrap;
  animation: enter 0.2s var(--ease);
}

.scan-bar .grow {
  margin-right: 8px;
}

.scan-head {
  cursor: default;
}

.scan-grip {
  position: absolute;
  z-index: 2;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  cursor: ns-resize;
  touch-action: none;
}

.scan-head {
  flex: none;
  display: flex;
  align-items: center;
  gap: 2px;
  height: 36px;
  padding: 0 6px 0 14px;
  background: var(--sky);
  color: var(--ink);
  font-size: 12px;
  user-select: none;
}

.scan-head .icon-btn {
  color: var(--ink);
}

.scan-head .icon-btn:hover {
  background: var(--glass);
}

.scan-head .grow {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Shows a copy of the page, whose text assumes the page's own background. */
.scan-body {
  background: #fff;
  position: relative;
  flex: 1;
  min-height: 0;
  overflow: hidden;
}

.scan-body iframe {
  position: absolute;
  border: 0;
  background: transparent;
}

/* ---- marquee -------------------------------------------------------------- */

.marquee-shade {
  inset: 0;
  cursor: crosshair;
  background: rgba(20, 40, 80, 0.05);
  touch-action: none;
  user-select: none;
  animation: fade-in 0.15s var(--ease);
}

.marquee-hint {
  left: 50%;
  top: 16px;
  translate: -50% 0;
  padding: 6px 12px;
  border-radius: 8px;
  border: 1.5px solid transparent;
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;
  box-shadow: var(--shadow);
  white-space: nowrap;
  pointer-events: none;
  animation: rise 0.2s var(--ease);
}

.leaving {
  animation: leave 0.16s var(--ease) forwards !important;
  pointer-events: none;
}

@keyframes frame-wait {
  to {
    opacity: 0.5;
  }
}

@keyframes enter {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.985);
  }
}

@keyframes leave {
  to {
    opacity: 0;
    transform: translateY(4px) scale(0.985);
  }
}

@keyframes pop {
  from {
    opacity: 0;
    transform: scale(0.7);
  }
}

@keyframes rise {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}

@keyframes fade-in {
  from {
    opacity: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
`;async function jn(o,e){try{return await navigator.clipboard.writeText(o),!0}catch{}let t=document.createElement("textarea");t.value=o,t.setAttribute("readonly",""),t.setAttribute("aria-hidden","true"),t.style.cssText="position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;";let n=document.activeElement;(e??document.body??document.documentElement).appendChild(t);let r=!1;try{t.focus(),t.select(),r=document.execCommand("copy")}catch{r=!1}return t.remove(),n?.focus?.({preventScroll:!0}),r}var le="http://www.w3.org/2000/svg",$r=2,Wr=3,Ur=12,qe=[["0","#4da2ff"],["0.35","#55db9c"],["0.62","#ffd731"],["0.85","#fb4903"],["1","#5c4ade"]],qr=0,Jt=2147483646;function Zt(o){for(let e of["keydown","keyup","keypress"])o.addEventListener(e,t=>t.stopPropagation())}function G(o){let e=devicePixelRatio||1;return Math.round(o*e)/e}var jr={copy:["M9 9h10v11H9z","M5 15V4h10"],speak:["M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z","M15.5 9a4 4 0 0 1 0 6","M18 6.5a8 8 0 0 1 0 11"],speakSource:["M3 9.5v5h3L10 18v-12L6 9.5z","M13.5 17.5l3.25-10 3.25 10","M14.6 14.2h4.3"],close:["M6 6l12 12","M18 6L6 18"],stop:["M7 7h10v10H7z"],check:["M5 12.5l4.5 4.5L19 7.5"],expand:["M4 9V4h5","M20 9V4h-5","M4 15v5h5","M20 15v5h-5"],collapse:["M9 4v5H4","M15 4v5h5","M9 20v-5H4","M15 20v-5h5"],search:["M11 5a6 6 0 1 1 0 12a6 6 0 0 1 0-12z","M15.5 15.5L20 20"],up:["M6 15l6-6 6 6"],down:["M6 9l6 6 6-6"],image:["M4 5h16v14H4z","M4 16l5-5 4 4 3-3 4 4","M15.5 8.5h.01"],download:["M12 4v11","M7.5 11L12 15.5 16.5 11","M5 19.5h14"],glossary:["M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z","M5 19.5A1.5 1.5 0 0 0 6.5 21H19","M12 7.5v6","M9 10.5h6"],translate:["M4 5h7","M9 3v2c0 4.418-2.239 8-5 8","M5 9c0 2.144 2.952 3.908 6.7 4","M12 20l4-9 4 9","M19.1 18h-6.2"]};function ce(o){let e=document.createElementNS(le,"svg");e.setAttribute("viewBox","0 0 24 24");for(let t of jr[o]){let n=document.createElementNS(le,"path");n.setAttribute("d",t),e.append(n)}return e}function y(o,e,t){let n=document.createElement(o);return n.className=e,t!==void 0&&(n.textContent=t),n}var zr=1400;function Ee(o,e){let t=Number(o.dataset.copyTimer);t&&clearTimeout(t);let n=o.classList.contains("icon-btn");o.dataset.restoreTitle??=o.title,n?o.dataset.restoreIcon??=o.innerHTML:o.dataset.restoreText??=o.textContent??"",o.toggleAttribute("data-done",e),o.toggleAttribute("data-failed",!e),o.title=b(e?"copied":"copyFailed"),n?o.replaceChildren(ce(e?"check":"close")):o.textContent=b(e?"copied":"copyFailedShort"),o.dataset.copyTimer=String(setTimeout(()=>{o.removeAttribute("data-done"),o.removeAttribute("data-failed"),o.title=o.dataset.restoreTitle??"",n?o.innerHTML=o.dataset.restoreIcon??"":o.textContent=o.dataset.restoreText??"",delete o.dataset.restoreTitle,delete o.dataset.restoreIcon,delete o.dataset.restoreText,delete o.dataset.copyTimer},zr))}function K(o,e,t){let n=y("button","icon-btn");return n.type="button",n.title=e,n.setAttribute("aria-label",e),n.append(ce(o)),n.addEventListener("click",t),n}var ut=class{host;root;toastEl;toastTimer;theme;dark=!1;pageHost;pageRoot;overHost;overRoot;tooltipEl;setTheme(e,t){this.theme=e,this.dark=t;for(let n of[this.host,this.pageHost,this.overHost])n&&this.paint(n)}settleUnderBars(){let e=Ue(),t=e.stacking!==null&&e.stacking>1;return this.pageHost&&(this.pageHost.style.zIndex=String(t?e.stacking-1:Jt)),t?{top:-1/0,bottom:1/0}:{top:e.top>0?e.top:-1/0,bottom:e.bottom<innerHeight?e.bottom:1/0}}paint(e){this.theme&&(e.style.setProperty("--yl-theme",this.theme),e.style.setProperty("--yl-on-theme",ot("#ffffff",this.theme)>=3?"#ffffff":"#14161b")),e.dataset.appearance=this.dark?"dark":"light"}get hostElement(){return this.host}isHost(e){return!!e&&(e===this.host||e===this.pageHost||e===this.overHost)}ownsEvent(e){return e.composedPath().some(t=>t===this.host||t===this.pageHost||t===this.overHost)}ensurePage(){if(this.pageRoot&&this.pageHost?.isConnected)return this.pageRoot;this.pageHost=document.createElement("yl-ui"),this.pageHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${Jt};`,this.paint(this.pageHost),Zt(this.pageHost),this.pageRoot=this.pageHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=dt,this.pageRoot.append(e),document.documentElement.append(this.pageHost),this.pageRoot}ensureOver(){if(this.overRoot&&this.overHost?.isConnected)return this.overRoot;this.overHost=document.createElement("yl-ui"),this.overHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${Jt};`,this.paint(this.overHost),Zt(this.overHost),this.overRoot=this.overHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=dt,this.overRoot.append(e),document.documentElement.append(this.overHost),this.overRoot}addToPage(e,t=!1){return e.classList.add("layer"),e.style.position="absolute",(t?this.ensureOver():this.ensurePage()).append(e),e}ensure(){if(this.root&&this.host?.isConnected)return this.root;this.host=document.createElement("yl-ui"),this.host.style.cssText="all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",this.paint(this.host),Zt(this.host),this.root=this.host.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=dt,this.root.append(e),this.host.setAttribute("popover","manual"),document.documentElement.append(this.host),this.raise(),this.root}raise(){let e=this.host;if(!e)return;let t;try{t=Array.from(document.querySelectorAll(":modal")).filter(r=>r!==e).pop()}catch{t=void 0}let n=t??document.documentElement;if(e.parentNode!==n&&n.append(e),"showPopover"in e)try{if(e.matches(":popover-open")){if(!Array.from(document.querySelectorAll(":modal, :popover-open")).some(s=>s!==e))return;e.hidePopover()}e.showPopover()}catch{}}add(e){e.classList.add("layer");let t=this.ensure();return this.raise(),t.append(e),e}copy(e){return jn(e,this.ensure())}addBelow(e,t){return e.classList.add("layer"),t.parentNode?.insertBefore(e,t),e}place(e,t,n=8,r){let{left:i,top:s}=this.spot(e,t,n,r);e.style.left=`${i}px`,e.style.top=`${s}px`}spot(e,t,n=8,r){let i=e.offsetWidth,s=e.offsetHeight,a=Ue(),l=Math.max(a.top,r?.top??0)+8,c=Math.min(a.bottom,r?.bottom??innerHeight)-8,d=Math.max(8,Math.min(t.left,innerWidth-i-8)),u=t.bottom+n;return u+s>c&&(u=t.top-s-n),{left:d,top:Math.max(l,Math.min(u,c-s))}}ring(e){let t=document.createElementNS(le,"svg");t.setAttribute("class","flow-ring"),t.setAttribute("aria-hidden","true");let n=`yl-edge-${++qr}`,r=document.createElementNS(le,"defs"),i=document.createElementNS(le,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[u,p]of qe){let h=document.createElementNS(le,"stop");h.setAttribute("offset",u),h.setAttribute("stop-color",p),i.append(h)}if(!matchMedia("(prefers-reduced-motion: reduce)").matches){let u=document.createElementNS(le,"animateTransform");u.setAttribute("attributeName","gradientTransform"),u.setAttribute("type","rotate"),u.setAttribute("from","0 0.5 0.5"),u.setAttribute("to","360 0.5 0.5"),u.setAttribute("dur","6s"),u.setAttribute("repeatCount","indefinite"),i.append(u)}r.append(i);let s=Math.max(1/(devicePixelRatio||1),G($r)),a=G(Wr);t.style.left=t.style.top=`${-a}px`,t.style.width=`calc(100% + ${a*2}px)`,t.style.height=`calc(100% + ${a*2}px)`;let c=(u=>{let p=document.createElementNS(le,"rect");return p.setAttribute("class",u),p.setAttribute("x",String(s/2)),p.setAttribute("y",String(s/2)),p.setAttribute("stroke-width",String(s)),p.setAttribute("rx",String(Ur)),p})("flow-line");c.setAttribute("stroke",`url(#${n})`),t.append(r,c),e.append(t);let d=()=>{let u=e.getBoundingClientRect(),p=Math.max(0,u.width+a*2-s),h=Math.max(0,u.height+a*2-s);c.setAttribute("width",String(p)),c.setAttribute("height",String(h))};new ResizeObserver(d).observe(e),d()}addFrame(e=!1,t=!1,n=!1){let r=y("div","region-box");return e&&(r.dataset.pending=""),t?this.addToPage(r,n):this.add(r),this.ring(r),r}setFramePending(e,t){t?e.dataset.pending="":delete e.dataset.pending}dismiss(e){if(!e)return;e.classList.add("leaving");let t=()=>e.remove();e.addEventListener("animationend",t,{once:!0}),setTimeout(t,220)}toast(e,t,n=5e3){this.dismiss(this.toastEl),clearTimeout(this.toastTimer);let r=y("div","toast");if(r.setAttribute("role","status"),r.append(y("span","",e)),t){let i=y("button","",t.label);i.type="button",i.addEventListener("click",()=>{r.remove(),t.run()}),r.append(i)}this.toastEl=this.add(r),this.toastTimer=setTimeout(()=>this.dismiss(r),n)}showTooltip(e,t){this.hideTooltip();let n=y("div","tooltip",e);this.tooltipEl=this.add(n),this.place(n,t,6)}hideTooltip(){this.dismiss(this.tooltipEl),this.tooltipEl=void 0}errorMessage(e){return b(`error_${e}`)||b("error_unavailable")}};var Qt=8,zn=o=>xe.find(e=>e.code===o)?.name??o;function pt(o,e,t,n,r){let i=y("div","lang-menu");i.setAttribute("role","dialog"),i.setAttribute("aria-label",n);let s=y("input","lang-menu-search");s.placeholder=b("searchLanguage");let a=y("div","lang-menu-list");a.setAttribute("role","listbox"),i.append(s,a),o.add(i);let l=[],c=Math.max(0,xe.findIndex(E=>E.code===t)),d=()=>{let E=s.value.trim().toLowerCase(),T=R=>!E||zn(R).toLowerCase().includes(E)||R.toLowerCase().startsWith(E)||($n[R]??"").includes(E);l=xe.map(R=>R.code).filter(T),c=Math.min(c,Math.max(0,l.length-1)),a.replaceChildren(...l.map((R,D)=>{let _=y("button","lang-menu-item",zn(R));return _.type="button",_.toggleAttribute("data-active",D===c),_.toggleAttribute("data-current",R===t),_.addEventListener("mousedown",W=>W.preventDefault()),_.addEventListener("click",()=>m(R)),_})),l.length||a.append(y("div","lang-menu-empty",b("noLanguage"))),a.children[c]?.scrollIntoView({block:"nearest"})},u=!1,p=()=>u=!0,h=()=>{u=!1,setTimeout(()=>{u||g()})};i.addEventListener("pointerdown",p),addEventListener("pointerdown",h,!0);let g=()=>{removeEventListener("pointerdown",h,!0),i.remove()},m=E=>{g(),r(E)};s.addEventListener("input",()=>{c=0,d()}),s.addEventListener("keydown",E=>{E.key==="ArrowDown"||E.key==="ArrowUp"?(E.preventDefault(),c=(c+(E.key==="ArrowDown"?1:-1)+l.length)%Math.max(1,l.length),d()):E.key==="Enter"?(E.preventDefault(),l[c]&&m(l[c])):E.key==="Escape"&&(E.preventDefault(),E.stopPropagation(),g())}),d();let f=i.offsetHeight,v=i.offsetWidth,w=innerHeight-e.bottom-Qt;return i.style.left=`${Math.max(Qt,Math.min(e.left,innerWidth-v-Qt))}px`,i.style.top=`${w>=f||w>=e.top?e.bottom+4:e.top-f-4}px`,s.focus(),{close:g,isOpen:()=>i.isConnected}}var Gn=700,Kn=3,Gr=5e3,Kr=new Set(["","text","search"]),de=8,Xr=300,Vr=360,Yr=460,Jr=o=>xe.find(e=>e.code===o)?.name??o;function Zr(o){if(o instanceof HTMLTextAreaElement)return o.readOnly||o.disabled?null:o;if(o instanceof HTMLInputElement)return!Kr.has(o.type.toLowerCase())||o.readOnly||o.disabled?null:o;if(o instanceof HTMLElement&&o.isContentEditable){let e=o;for(;e.parentElement?.isContentEditable;)e=e.parentElement;return e}return null}function Ce(o){return o instanceof HTMLInputElement||o instanceof HTMLTextAreaElement}function Xn(o){return(Ce(o)?o.value:o.innerText??"").replace(/[\s ]+$/,"")}function Vn(o){return!!o.trim()&&o.length<=Gr&&new RegExp("\\p{L}","u").test(o)}function Jn(o){let e=getSelection();e?.removeAllRanges(),e?.addRange(o)}function en(o,e,t){let n=o.value.slice(e,t);return{text:n,select(){let r=e;return o.value.slice(e,t)!==n&&(r=o.value.indexOf(n),r<0)?!1:(o.focus(),o.setSelectionRange(r,r+n.length),!0)}}}function tn(o,e){return{text:e.toString(),select(){return!o.contains(e.commonAncestorContainer)||!e.toString().trim()?!1:(o.focus(),Jn(e.cloneRange()),!0)}}}function Qr(o){if(Ce(o))return{...en(o,0,o.value.length),text:Xn(o)};let e=document.createRange();return e.selectNodeContents(o),{...tn(o,e),text:Xn(o)}}function Zn(o,e,t){for(;e<t&&/\s/.test(o[e]);)e++;for(;t>e&&/\s/.test(o[t-1]);)t--;return[e,t]}function Qn(o){if(Ce(o)){let{selectionStart:n,selectionEnd:r}=o;if(n===null||r===null||n===r)return null;let[i,s]=Zn(o.value,n,r);return i<s?en(o,i,s):null}let e=getSelection();if(!e?.rangeCount||e.isCollapsed)return null;let t=e.getRangeAt(0);return!o.contains(t.commonAncestorContainer)||!t.toString().trim()?null:tn(o,t.cloneRange())}function ei(o){return Qn(o)!==null}function ti(o){if(Ce(o)){let n=o.selectionStart;if(n===null)return null;let r=o.value,i=r.lastIndexOf(`
`,n-1)+1,s=r.indexOf(`
`,n),[a,l]=Zn(r,i,s<0?r.length:s);return a<l?en(o,a,l):null}let e=getSelection();if(!e?.rangeCount)return null;let t=e.getRangeAt(0).startContainer;if(!o.contains(t))return null;for(;t&&t!==o;t=t.parentNode){if(!(t instanceof HTMLElement))continue;let n=getComputedStyle(t).display;if(n.startsWith("inline")||n==="contents")continue;if(!t.innerText.trim())return null;let r=document.createRange();return r.selectNodeContents(t),tn(o,r)}return null}function Yn(o,e){if(!document.execCommand("insertText",!1,e))if(Ce(o))o.setRangeText(e,o.selectionStart??0,o.selectionEnd??o.value.length,"end"),o.dispatchEvent(new Event("input",{bubbles:!0}));else{let t=getSelection()?.getRangeAt(0);t?.deleteContents(),t?.insertNode(document.createTextNode(e))}}function ni(o,e){if(Ce(o)){if(o.selectionStart===null)return;let s=o.selectionStart,a=o.value.slice(Math.max(0,s-e),s);a.length===e&&!a.trim()&&(o.setSelectionRange(s-e,s),document.execCommand("delete")||o.setRangeText("",s-e,s,"end"));return}let t=getSelection();if(!t?.rangeCount||!t.isCollapsed)return;let{startContainer:n,startOffset:r}=t.getRangeAt(0);if(!(n instanceof Text)||r<e||!/^[  ]+$/.test(n.data.slice(r-e,r)))return;let i=document.createRange();i.setStart(n,r-e),i.setEnd(n,r),Jn(i),document.execCommand("delete")}var ht=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("keydown",this.onKeyDown,!0),at()}presses=[];preview;menu;update(e,t){this.settings=e,this.enabled=t,this.active||this.preview?.close(!1)}get active(){return this.enabled&&this.settings.inputTranslate&&Y()}onKeyDown=e=>{if(!this.active||this.preview||this.remote)return;if(e.key!==" "||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||e.repeat){this.release(),this.presses=[];return}let t=Zr(e.composedPath()[0]??e.target);if(this.held&&this.held.field!==t&&this.release(),!t)return;let n=performance.now();this.presses=[...this.presses.filter(i=>n-i<Gn),n];let r=this.presses.length>=Kn;if(r&&(this.presses=[]),this.held||ei(t)){if(e.preventDefault(),r){this.forget(),this.openPreview(t);return}let i=(this.held?.count??0)+1;this.forget(),this.held={field:t,count:i,timer:setTimeout(()=>this.release(),Gn)},document.addEventListener("pointerdown",this.release,!0);return}r&&(e.preventDefault(),ni(t,Kn-1),this.openPreview(t))};held;forget(){this.held&&(clearTimeout(this.held.timer),this.held=void 0,document.removeEventListener("pointerdown",this.release,!0))}release=()=>{let e=this.held;e&&(this.forget(),document.activeElement!==e.field&&!e.field.contains(document.activeElement)&&e.field.focus(),Yn(e.field," ".repeat(e.count)))};openPreview(e){let t=Qr(e);if(!Vn(t.text))return;let n=Qn(e),r=n??ti(e);r&&(!Vn(r.text)||r.text.trim()===t.text.trim())&&(r=null);let i={part:r,all:t},s={rect:$e(e.getBoundingClientRect()),all:t.text,part:r?.text??null,picked:!!n,lang:this.settings.inputLang},a={replace:(l,c)=>{i[l]?.select()?Yn(e,c):e.focus()},close:l=>{l&&e.focus()}};window.top===window?this.showPreview(s,a):this.showAbove(s,a)}remote;async showAbove(e,t){let n=crypto.randomUUID();lt(n);let r=!1;try{r=await N({type:"input:show",key:n,request:e})===!0}catch{r=!1}if(!r){this.showPreview(e,t);return}this.remote={key:n,actions:t},document.addEventListener("pointerdown",this.dismissRemote,!0)}dismissRemote=()=>{let e=this.remote;e&&(this.endRemote(),N({type:"input:dismiss",key:e.key}).catch(()=>{}))};endRemote(){document.removeEventListener("pointerdown",this.dismissRemote,!0),this.remote=void 0}remoteDone(e){let t=this.remote;if(!t||t.key!==e.key)return;this.endRemote();let n=e;n.action==="replace"?(n.scope==="part"||n.scope==="all")&&typeof n.text=="string"&&t.actions.replace(n.scope,n.text):t.actions.close(n.refocus===!0)}async showForFrame(e,t,n){if(window.top!==window||!this.active||!We(t?.rect)||typeof t.all!="string")return!1;let r=await Be(e);if(!r)return!1;let i=Fe(r,t.rect),s=a=>void N({type:"input:done",key:e,frameId:n,...a}).catch(()=>{});return this.showPreview({rect:i,all:t.all,part:typeof t.part=="string"?t.part:null,picked:t.picked===!0,lang:String(t.lang||this.settings.inputLang)},{replace:(a,l)=>s({action:"replace",scope:a,text:l}),close:a=>s({action:"close",refocus:a})},e),!0}dismissForFrame(e){this.preview?.key===e&&this.preview.close(!1,!1)}showPreview(e,t,n){let r={part:e.part,all:e.all},i=e.part,s=e.picked,a=i?"part":"all";this.preview?.close(!1);let l=y("div","write-pop");l.setAttribute("role","dialog"),l.setAttribute("aria-label",b("sectionInput"));let c=y("button","write-lang");c.type="button",c.title=b("inputOtherLanguage"),c.setAttribute("aria-haspopup","listbox");let d=y("span","","");c.append(d,y("i","write-chevron"));let u=K("close",b("close"),()=>fe(!0));u.classList.add("write-close");let p=y("div","write-result",b("translating"));p.dataset.state="loading",p.tabIndex=-1;let h=y("div","write-foot"),g=y("button","write-copy",b("copy"));g.type="button";let m=y("button","write-replace",b("writeReplace"));m.type="button",h.append(c);let f=new Map;if(i){let k=y("div","write-scope");k.setAttribute("role","radiogroup");for(let[j,V]of[["part",b(s?"writeScopePicked":"writeScopeLine")],["all",b("writeScopeAll")]]){let z=y("button","",V);z.type="button",z.setAttribute("role","radio"),z.addEventListener("click",()=>{a!==j&&(a=j,v(),M(W))}),f.set(j,z),k.append(z)}h.append(k)}let v=()=>{for(let[k,j]of f)j.setAttribute("aria-checked",String(k===a))};v(),h.append(y("span","grow"),g,m);let w=y("div","write-back");w.hidden=!0,w.title=b("writeBackHint");let E=y("span","write-back-text");w.append(y("span","write-back-label",b("writeBack")),E),l.append(u,p,w,h),this.ui.add(l);let T=new Map,R=new Map,D="",_=()=>(r[a]??"").trim(),W=e.lang,X="",J=0,x=!1,M=async k=>{W=k,d.textContent=Jr(k);let j=++J,V=`${a} ${k}`,z=_(),oe=T.get(V);if(oe!==void 0){P(oe),this.preview?.node===l&&B(V,oe,k,j);return}X="",w.hidden=!0,p.dataset.state="loading",p.textContent=b("translating"),m.setAttribute("aria-busy","true"),g.disabled=!0,te();try{let ae=await N({type:"translate",items:[re(z)],from:"",to:k});if(j!==J||this.preview?.node!==l)return;let ee=ae?.results?.[0];if(ee?.ok){let L=ve(ee.text);T.set(V,L),ee.detected&&(D=ee.detected),P(L),this.preview?.node===l&&B(V,L,k,j)}else F(this.ui.errorMessage(ee?.code??"network"))}catch{j===J&&Y()&&F(this.ui.errorMessage("network"))}},P=k=>{if(X=k,delete p.dataset.state,p.textContent=k,m.removeAttribute("aria-busy"),g.disabled=!1,x){O();return}te(),m.focus()},B=async(k,j,V,z)=>{let oe=ee=>ee.toLowerCase().split("-")[0];if(!D||oe(D)===oe(V)){w.hidden=!0,te();return}let ae=R.get(k);if(w.hidden=!1,w.toggleAttribute("data-loading",ae===void 0),E.textContent=ae??b("translating"),te(),ae===void 0){try{let ee=await N({type:"translate",items:[re(j)],from:V,to:D});if(z!==J||this.preview?.node!==l)return;let L=ee?.results?.[0];if(L?.ok){let be=ve(L.text);R.set(k,be),w.removeAttribute("data-loading"),E.textContent=be}else w.hidden=!0}catch{z===J&&(w.hidden=!0)}te()}},F=k=>{w.hidden=!0,x=!1,m.removeAttribute("aria-busy"),p.dataset.state="error",p.textContent=k,te()},O=()=>{let k=X;fe(!1,!1),t.replace(a,k)},te=()=>{let k=e.rect,V=Math.min(Yr,Math.max(i?Vr:Xr,k.right-k.left),innerWidth-de*2);l.style.width=`${V}px`;let z=l.offsetHeight,oe=k.top-z-de,ae=oe>=de?oe:Math.min(k.bottom+de,innerHeight-z-de);l.style.left=`${Math.max(de,Math.min(k.left,innerWidth-V-de))}px`,l.style.top=`${Math.max(de,ae)}px`},fe=(k,j=!0)=>{++J,document.removeEventListener("pointerdown",ge,!0),this.menu?.close(),this.menu=void 0,l.remove(),this.preview?.node===l&&(this.preview=void 0),j&&t.close(k)},ge=k=>{this.ui.ownsEvent(k)||fe(!1)};m.addEventListener("click",()=>{X?O():p.dataset.state==="loading"&&(x=!0)}),g.addEventListener("click",()=>{X&&this.ui.copy(X).then(k=>Ee(g,k))}),c.addEventListener("click",()=>{this.menu?.close(),this.menu=pt(this.ui,c.getBoundingClientRect(),W,b("inputLang"),k=>void M(k))}),l.addEventListener("keydown",k=>{if(k.key==="Escape"){k.preventDefault(),fe(!0);return}if(!(k.ctrlKey||k.metaKey)||k.altKey||k.shiftKey)return;let j=k.key.toLowerCase();if(j==="a")k.preventDefault(),getSelection()?.selectAllChildren(p);else if(j==="c"&&X){let V=getSelection()?.toString()??"";(!V.trim()||!X.includes(V.trim()))&&(k.preventDefault(),this.ui.copy(X).then(z=>Ee(g,z)))}}),document.addEventListener("pointerdown",ge,!0),this.preview={node:l,close:fe,key:n},te(),m.focus(),M(W)}};function eo(o,e){let t=new Set,n=r=>{let i=r.composedPath()[0];return i instanceof Element?i.localName==="yl-ui"?!0:i.matches("input,textarea,select")||!!i.closest('[contenteditable]:not([contenteditable="false"]),[role="textbox"]'):!1};window.addEventListener("keydown",r=>{if(Pn(r.code))return;t.add(r.code);let i=Hn(r);if(n(r)&&!i.some(c=>c!=="Shift"))return;let s=[...i,...t],a=o();for(let c of nt){let d=a[c];if(Kt(d,s)){r.preventDefault(),r.stopPropagation(),r.repeat||e(c);return}}nt.some(c=>{let{mods:d,keys:u}=In(a[c]);return u.length>1&&u.includes(r.code)&&d.length===i.length&&d.every(p=>i.includes(p))})&&(r.preventDefault(),r.stopPropagation())},!0),window.addEventListener("keyup",r=>t.delete(r.code),!0),window.addEventListener("blur",()=>t.clear())}var to=8,mt=36,ft=18,gt=class{constructor(e){this.ui=e}shade;box;hint;start;pointer={x:0,y:0};raf=0;onDone;get running(){return this.shade!==void 0}begin(e){this.running||(this.onDone=e,this.shade=this.ui.add(y("div","marquee-shade")),this.hint=this.ui.add(y("div","marquee-hint",b("marqueeHint"))),this.shade.addEventListener("pointerdown",this.onDown),this.shade.addEventListener("pointermove",this.onMove),this.shade.addEventListener("pointerup",this.onUp),this.shade.addEventListener("wheel",this.onWheel,{passive:!1}),addEventListener("keydown",this.onKey,!0),addEventListener("scroll",this.draw,!0),addEventListener("blur",this.cancel))}cancel=()=>this.end();end(){cancelAnimationFrame(this.raf),this.raf=0,removeEventListener("keydown",this.onKey,!0),removeEventListener("scroll",this.draw,!0),removeEventListener("blur",this.cancel),this.shade?.remove(),this.box?.remove(),this.hint?.remove(),this.shade=this.box=this.hint=void 0,this.start=void 0}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.end())};onDown=e=>{e.button===0&&(e.preventDefault(),this.shade.setPointerCapture(e.pointerId),this.start={x:e.clientX+scrollX,y:e.clientY+scrollY},this.pointer={x:e.clientX,y:e.clientY},this.box=this.ui.addFrame(),this.hint?.remove(),this.hint=void 0,this.draw(),this.raf=requestAnimationFrame(this.edgeScroll))};onMove=e=>{this.start&&(this.pointer={x:e.clientX,y:e.clientY},this.draw())};onUp=()=>{if(!this.start)return;let e=this.currentRect();this.end(),e.right-e.left>=to&&e.bottom-e.top>=to&&this.onDone?.(e)};onWheel=e=>{e.preventDefault(),this.scrollTarget().scrollBy(e.deltaX,e.deltaY)};scrollTarget(){let e=document.elementsFromPoint(this.pointer.x,this.pointer.y);for(let t of e)if(!this.ui.isHost(t)){for(let n=t;n&&n!==document.documentElement;n=n.parentElement){let r=getComputedStyle(n).overflowY;if((r==="auto"||r==="scroll")&&n.scrollHeight>n.clientHeight)return n}break}return window}edgeScroll=()=>{if(!this.start)return;let{x:e,y:t}=this.pointer,n=t<mt?-ft:t>innerHeight-mt?ft:0,r=e<mt?-ft:e>innerWidth-mt?ft:0;(r||n)&&window.scrollBy(r,n),this.raf=requestAnimationFrame(this.edgeScroll)};currentRect(){let e=this.start.x-scrollX,t=this.start.y-scrollY;return{left:Math.min(e,this.pointer.x),top:Math.min(t,this.pointer.y),right:Math.max(e,this.pointer.x),bottom:Math.max(t,this.pointer.y)}}draw=()=>{if(!this.start||!this.box)return;let e=this.currentRect();Object.assign(this.box.style,{left:`${G(e.left)}px`,top:`${G(e.top)}px`,width:`${G(e.right-e.left)}px`,height:`${G(e.bottom-e.top)}px`})}};var Ae=new Set(["yl-t","yl-r","yl-ui"]),oi=new Set(["script","style","noscript","template","head","meta","link","title","base","datalist","area","map","param","source","track","rp"]),ri=new Set(["pre","textarea","input","select","option","optgroup","canvas","video","audio","iframe","frame","frameset","object","embed","applet","listing","xmp","plaintext"]),ii=new Set(["code","kbd","samp","var","tt","img","picture","svg","math","ruby","wbr"]),si=new Set(["CodeMirror","cm-editor","cm-content","cm-line","monaco-editor","monaco-diff-editor","ace_editor","hljs","prism-code","shiki","astro-code","xterm","blob-code","blob-code-inner","blob-wrapper","blob-num","react-code-lines","react-code-text","react-file-line","react-syntax-highlighter","syntaxhighlighter","code-block","codeblock","code-toolbar","sourceCode","gist-file","gist-data","d2h-wrapper","d2h-file-wrapper","mw-highlight","rouge-table","rouge-code","linenums","line-numbers","lineno","hljs-ln","katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),ai=new Set(["highlight","highlighter-rouge","codehilite","code","prism","terminal","gist","source","snippet","example"]),li=["language-","lang-","highlight-source-","highlight-text-","brush:"],ci=new Set(["code","textbox","searchbox","combobox","math","img","slider","spinbutton"]),di=/^\s*"?'?(monospace|ui-monospace|consolas|menlo|monaco|courier|courier new|lucida console|lucida sans typewriter|sfmono-regular|sf mono|fira code|fira mono|source code pro|jetbrains mono|roboto mono|ibm plex mono|dejavu sans mono|liberation mono|cascadia code|cascadia mono|ubuntu mono|hack|inconsolata)\b/i,ui='nav,button,[role="navigation"],[role="menu"],[role="menubar"],[role="tablist"],[role="toolbar"],[role="button"],[role="menuitem"],[role="tab"]';function nn(o){return di.test(o)}function no(o){let e=o.classList;for(let t=0;t<e.length;t++){let n=e[t];if(si.has(n)||(ai.has(n)||li.some(r=>n.startsWith(r)))&&pi(o))return!0}return!1}function pi(o){for(let e of Array.from(o.children)){let t=e.localName;if(t==="pre"||t==="code"||t==="table"||e.firstElementChild?.localName==="pre")return!0}return!1}var hi=/^(material-icons(-[\w-]+)?|material-symbols(-[\w-]+)?|mdi|mdi-[\w-]+|fa|fas|far|fab|fal|fa-[\w-]+|bi|bi-[\w-]+|glyphicon|glyphicon-[\w-]+|iconfont|anticon|anticon-[\w-]+)$/;function mi(o){if(o.childElementCount>0)return!1;let e=(o.textContent??"").trim();if(e.length>40||/\s/.test(e))return!1;let t=o.classList;for(let n=0;n<t.length;n++)if(hi.test(t[n]))return!0;return o.getAttribute("aria-hidden")==="true"&&/^[a-z0-9_]+$/.test(e)}function fi(o){if(o.getAttribute("translate")==="no")return!0;let e=o.getAttribute("contenteditable");if(e!==null&&e!=="false")return!0;let t=o.getAttribute("role");return!!(t&&ci.has(t))}var bt=class{excludeSelector=null;setExcludes(e){let t=e.split(`
`).map(n=>n.trim()).filter(n=>n&&wi(n));this.excludeSelector=t.length?t.join(","):null}classify(e){let t=e.localName;if(t==="br")return"br";if(Ae.has(t))return"own";if(oi.has(t))return"hidden";let n=getComputedStyle(e);if(ri.has(t))return n.display==="none"?"hidden":"skip";if(n.display==="none"||n.visibility==="hidden"||n.visibility==="collapse")return"collapsed";if(n.position==="absolute"&&parseFloat(n.width)<=1&&parseFloat(n.height)<=1)return"hidden";let r=yi(n.display);if(ii.has(t)||mi(e)||fi(e)||no(e)||this.isExcluded(e))return r?"atomic":"skip";if(nn(n.fontFamily)){let i=e.parentElement,s=i?nn(getComputedStyle(i).fontFamily):!1;if(r&&!s)return"atomic";if(!r&&n.whiteSpace.startsWith("pre"))return"skip"}return t==="button"||e.getAttribute("role")==="button"||e.localName.includes("-")&&vi(e)?"block":r?"inline":"block"}isExcluded(e){return this.excludeSelector!==null&&e.matches(this.excludeSelector)}},gi=new Set(["katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),bi=new Set(["pre","code","samp","kbd","listing","xmp","plaintext"]);function oo(o){if(bi.has(o.localName)||o.querySelector("pre"))return!0;let e=o.classList;for(let n=0;n<e.length;n++){let r=e[n];if(gi.has(r))return!1}if(no(o))return!0;let t=getComputedStyle(o);return nn(t.fontFamily)&&t.whiteSpace.startsWith("pre")}function yt(o){return o.matches(ui)}function ro(o,e){let t=n=>{let r=n.toLowerCase(),i=r.split("-")[0];return i!=="zh"&&i!=="yue"?i:/hant|-tw|-hk|-mo/.test(r)||i==="yue"?"zh-hant":"zh-hans"};return t(o)===t(e)}function yi(o){return o==="inline"||o==="inline-block"||o==="inline-flex"||o==="inline-grid"||o===""||o==="ruby"}function Re(o){if(o.shadowRoot)return o.shadowRoot;if(!o.localName.includes("-"))return null;try{return chrome.dom?.openOrClosedShadowRoot?.(o)??null}catch{return null}}function vi(o){return Re(o)!==null}function wi(o){try{return document.createDocumentFragment().querySelector(o),!0}catch{return!1}}function vt(o){let e=o.trim();return!new RegExp("\\p{L}","u").test(e)||/^(https?:\/\/|www\.)\S+$/i.test(e)||/^\S+@\S+\.\S+$/.test(e)?!1:!xi(e)}function xi(o){let e=o.replace(/^[("'“‘[]+|[.,:;!?)"'”’\]]+$/g,"");return/^[\w$.:/\\#()<>=\-[\]{}]+$/.test(e)?/\w_\w|\w\.\w|\(\)|::|^--|\w=|\w[/\\]\w|^[#$.]\w/.test(e):!1}var Ei=/[這個們來時會對說為學國還過發現點開關與實體後經機於從無見長問間電動應當將麼樣邊裡寫話讀請]/,Si=/[这个们来时会对说为学国还过发现点开关与实体后经机于从无见长问间电动应当将么样边里写话读请]/;function je(o,e){let t=o.match(new RegExp("\\p{L}","gu"));if(!t)return!1;let n=i=>(o.match(i)?.length??0)/t.length,r=e.split("-")[0];return r==="zh"?/[぀-ヿ]/.test(o)||n(new RegExp("\\p{Script=Han}","gu"))<.6?!1:e==="zh-Hant"?!Si.test(o):!Ei.test(o):r==="ja"?n(/[぀-ヿ]/g)>.2:r==="ko"?n(new RegExp("\\p{Script=Hangul}","gu"))>.5:!1}var Ti=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,ki=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,ao="data-yl-mirror",io=new Set(["script","noscript","iframe","frame","object","embed","meta","title","base","style","link","yl-ui","yl-t","yl-r"]),Mi=["class","style","open","hidden"],so=`
*, *::before, *::after { visibility: hidden !important; transition: none !important; animation: none !important; }
html, body { visibility: visible !important; scroll-behavior: auto !important; overscroll-behavior: contain; }

* { scrollbar-color: transparent transparent !important; }
html { overflow-x: hidden !important; }
[data-yl-pinned], [data-yl-pinned] *, [data-yl-pinned]::before, [data-yl-pinned]::after { visibility: hidden !important; background: none !important; box-shadow: none !important; border-color: transparent !important; }
mark[data-yl-find] { background: rgba(255, 215, 49, 0.6) !important; color: inherit !important; border-radius: 2px; }
mark[data-yl-find][data-active] { background: #ff9632 !important; }
[data-yl-box] { visibility: visible !important; }
[data-yl-box]::before, [data-yl-box]::after { visibility: visible !important; }
yl-m { display: contents !important; }
yl-m, yl-m *, yl-m *::before, yl-m *::after,
[data-yl-all], [data-yl-all] *, [data-yl-all]::before, [data-yl-all]::after,
[data-yl-all] *::before, [data-yl-all] *::after { visibility: visible !important; }
yl-m[data-pending] > * , yl-m[data-pending] { opacity: 0.45; }
[data-yl-hidden] { display: none !important; }
`;function lo(){try{return!!window.frameElement?.hasAttribute(ao)}catch{return!1}}var wt=class{constructor(e,t,n,r){this.sourceScroller=t;this.onClick=n;this.onKey=r;this.frame=document.createElement("iframe"),this.frame.setAttribute(ao,""),this.frame.setAttribute("sandbox","allow-same-origin"),this.frame.setAttribute("tabindex","-1"),e.append(this.frame),this.build()}frame;doc;map=new WeakMap;observer;build(){let e=this.frame.contentDocument;if(!e)throw new Error("mirror frame has no document");this.doc=e;let t=e.importNode(document.documentElement,!0),n=[];this.pair(document.documentElement,t,n);for(let r of n)r.remove();e.replaceChild(t,e.documentElement),this.addStyles(t),e.addEventListener("click",this.handleClick,!0),e.addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutations),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:Mi}),this.copyScroll()}pair(e,t,n){if(this.map.set(e,t),t.nodeType===Node.ELEMENT_NODE){let s=t;if(io.has(s.localName)){n.push(s);return}this.clean(s);let a=Re(e);a&&this.copyShadow(a,s,n)}let r=e.childNodes,i=t.childNodes;for(let s=0;s<r.length;s++){let a=r[s],l=i[s];a&&l&&this.pair(a,l,n)}}copyShadow(e,t,n){let r;try{r=t.attachShadow({mode:"open"})}catch{return}let i=this.doc.createElement("style");i.textContent=so,r.append(i);for(let s of Array.from(e.childNodes)){let a=this.doc.importNode(s,!0);r.append(a),!(s.nodeType===Node.ELEMENT_NODE&&s.localName==="style")&&this.pair(s,a,n)}}clean(e){for(let n of Array.from(e.attributes))n.name.toLowerCase().startsWith("on")&&e.removeAttribute(n.name);let t=e.localName;(t==="video"||t==="audio")&&(e.removeAttribute("autoplay"),e.removeAttribute("src")),t==="img"&&e.removeAttribute("loading")}addStyles(e){let t=e.querySelector("head");t||(t=this.doc.createElement("head"),e.prepend(t));let n=(i,s)=>{let a=this.doc.createElement("style");s&&(a.media=s),a.textContent=Array.from(i,l=>l.cssText).join(`
`),t.append(a)};for(let i of Array.from(document.styleSheets)){let s=i.ownerNode;if(s&&s.closest("yl-ui"))continue;let a=null;try{a=i.cssRules}catch{}if(a)n(a,i.media.mediaText||void 0);else if(i.href){let l=this.doc.createElement("link");l.rel="stylesheet",l.href=i.href,i.media.mediaText&&(l.media=i.media.mediaText);let c=s?.getAttribute("crossorigin");c!=null&&l.setAttribute("crossorigin",c),t.append(l)}}try{for(let i of Array.from(document.adoptedStyleSheets??[]))n(i.cssRules)}catch{}let r=this.doc.createElement("style");r.textContent=so,t.append(r)}onMutations=e=>{for(let t of e){if(t.type==="attributes"){let r=this.map.get(t.target),i=t.attributeName;if(!r||!i)continue;let s=t.target.getAttribute(i);s===null?r.removeAttribute(i):r.setAttribute(i,s);continue}let n=this.map.get(t.target);if(n)for(let r of Array.from(t.addedNodes)){if(this.map.has(r)||r.nodeType===Node.ELEMENT_NODE&&io.has(r.localName))continue;let i=this.doc.importNode(r,!0),s=[];this.pair(r,i,s);for(let l of s)l.remove();let a=r.nextSibling?this.map.get(r.nextSibling):null;n.insertBefore(i,a&&a.parentNode===n?a:null)}}};handleClick=e=>{let t=e.target;if(!t||t.nodeType!==Node.ELEMENT_NODE)return;let n=t,r=n.closest("a[href]");if(e.preventDefault(),r&&/^https?:/i.test(r.href)){window.open(r.href,"_blank","noopener");return}this.onClick(n,e)};revealBoxes(e){for(let t=e;t&&t.nodeType===Node.ELEMENT_NODE;t=t.parentNode){let n=t;if(n.hasAttribute("data-yl-box"))return;n.setAttribute("data-yl-box","")}}showRun(e,t){let n=e.map(s=>this.map.get(s)).filter(s=>!!s&&!!s.parentNode),r=n[0];if(!r?.parentNode)return null;let i=this.doc.createElement("yl-m");t&&i.setAttribute("data-pending",""),r.parentNode.insertBefore(i,r);for(let s of n)i.append(s);return this.revealBoxes(i.parentNode),i}showWhole(e){let t=this.map.get(e);return t?(t.setAttribute("data-yl-all",""),this.revealBoxes(t.parentNode),t):null}setTranslation(e,t,n,r){let i=this.doc.createDocumentFragment();this.append(i,t,n);let s=Te(t);for(let a of r){let l=n[a];if(l?.atomic&&!s.has(a)){let c=this.copyAtomic(l);c&&i.append(this.doc.createTextNode(" "),c)}}e.replaceChildren(i),e.removeAttribute("data-pending")}setKept(e){e.removeAttribute("data-pending")}copyAtomic(e){let t=this.map.get(e.el);return t?t.cloneNode(!0):this.doc.importNode(e.el,!0)}append(e,t,n){t.forEach((r,i)=>{if(typeof r=="string"){r.split(`
`).forEach((c,d)=>{d>0&&e.appendChild(this.doc.createElement("br")),c&&e.appendChild(this.doc.createTextNode(c))});return}let s=n[r.slot];if(!s)return;if(s.atomic){let c=t[i-1],d=t[i+1];typeof c=="string"&&Ti.test(c)&&e.appendChild(this.doc.createTextNode(" "));let u=this.copyAtomic(s);u&&e.appendChild(u),typeof d=="string"&&ki.test(d)&&e.appendChild(this.doc.createTextNode(" "));return}let a=this.map.get(s.el),l=a?a.cloneNode(!1):this.doc.importNode(s.el,!1);this.append(l,r.children,n),e.appendChild(l)})}get scroller(){return this.sourceScroller?this.map.get(this.sourceScroller)??null:this.doc.scrollingElement}copyScroll(){let e=this.scroller;e&&(e.scrollTop=this.sourceScroller?this.sourceScroller.scrollTop:scrollY)}get scrollerTop(){let e=this.scroller;return!e||e===this.doc.scrollingElement?0:Math.max(0,e.getBoundingClientRect().top)}alignTo(e,t){let n=this.scroller;if(!n)return;let r=this.doc.createRange();r.selectNodeContents(e);let i=r.getBoundingClientRect();if(!i.width&&!i.height)return;let s=i.top-t;Math.abs(s)>.5&&(n.scrollTop+=s)}hidePinned(){for(let e of Array.from(this.doc.querySelectorAll("body *"))){let t=this.frame.contentWindow?.getComputedStyle(e).position;(t==="fixed"||t==="sticky")&&e.setAttribute("data-yl-pinned","")}}textOf(e){return e.textContent??""}destroy(){this.observer?.disconnect(),this.observer=void 0,this.frame.remove()}};var Ci=new Set(["a","b","strong","i","em","u","s","del","ins","mark","sub","sup","abbr","cite","q","small","big","font","dfn","strike","label"]),Ai=["fontWeight","fontStyle","color","backgroundColor","textDecorationLine","fontSize","fontFamily"];function Ri(o){let e=o.parentElement;if(!e)return!0;let t=getComputedStyle(o),n=getComputedStyle(e);return t.display!=="inline"?!0:Ai.some(r=>t[r]!==n[r])}var co=4;function on(o){return o==="inline-block"||o==="inline-flex"||o==="inline-grid"}function Li(o){let e=getComputedStyle(o);return on(e.display)?!0:parseFloat(e.marginLeft)>=co||parseFloat(e.marginRight)>=co}function Ni(o){let e=[];for(let n of o)if(n.nodeType===Node.TEXT_NODE)e.push(n);else if(n.nodeType===Node.ELEMENT_NODE){let r=document.createTreeWalker(n,NodeFilter.SHOW_TEXT);for(let i=r.nextNode();i;i=r.nextNode())e.push(i)}let t=[];for(let n=e.length-1;n>=0;n--){let r=e[n];if(xt(r.data)||t.some(s=>s.contains(r)))continue;let i=Pi(r,o);if(!i)break;t.unshift(i)}return new Set(t)}function Pi(o,e){let t=null;for(let n=o.parentElement;n;n=n.parentElement){if(e.includes(n))return t;on(getComputedStyle(n).display)&&(t=n)}return null}function xt(o){return!/[^ \t\r\n\f]/.test(o)}var Le=class{classifier=new bt;kinds=new WeakMap;blockDescendant=new WeakMap;reset(){this.kinds=new WeakMap,this.blockDescendant=new WeakMap}kindOf(e){let t=this.kinds.get(e);return t===void 0&&(t=this.classifier.classify(e),this.kinds.set(e,t)),t}*scan(e,t,n=!1){let r=[],i=0,s=()=>{if(r.length){let a=this.buildRun(r,e,n);a?t.emit(a):t.plain?.(r,e)}r=[],i=0};for(let a of Array.from(e.childNodes)){if(t.consume(a)){s();continue}if(a.nodeType===Node.TEXT_NODE){let d=xt(a.data);d||(i=0),(!d||r.length)&&r.push(a);continue}if(a.nodeType!==Node.ELEMENT_NODE)continue;let l=a;switch(this.kindOf(l)){case"own":case"hidden":break;case"collapsed":yield*this.scan(l,t,n||yt(l));break;case"skip":s(),t.skipped?.(l);break;case"br":r.length&&r.push(l),++i>=2&&s();break;case"atomic":i=0,r.push(l);break;case"inline":this.isolatedInlineBlock(l,e)||this.hasBlockDescendant(l)?(s(),yield*this.scan(l,t,n||yt(l))):(i=0,r.push(l));break;case"block":{s();let d=n||yt(l);yield*this.scan(l,t,d);let u=Re(l);u&&(t.shadowRoot(u),yield*this.scan(u,t,d)),yield;break}}}if(s(),e.nodeType===Node.ELEMENT_NODE&&!Hi(e)){let a=Re(e);a&&(t.shadowRoot(a),yield*this.scan(a,t,n))}}isolatedInlineBlock(e,t){if(!on(getComputedStyle(e).display))return!1;for(let n of Array.from(t.childNodes))if(n.nodeType===Node.TEXT_NODE&&!xt(n.data))return!1;return!0}hasBlockDescendant(e){let t=this.blockDescendant.get(e);if(t!==void 0)return t;let n=!1;for(let r of Array.from(e.children)){let i=this.kindOf(r);if(i==="block"||i==="skip"||i==="inline"&&this.hasBlockDescendant(r)){n=!0;break}}return this.blockDescendant.set(e,n),n}buildRun(e,t,n){let r=[],i=t.nodeType===Node.ELEMENT_NODE?t:t.host,s=getComputedStyle(i).whiteSpace,a=s==="pre-line"||s==="pre-wrap"||s==="pre"||s==="break-spaces",l=[],c=[],d=Ni(e);for(let h of e)this.serialize(h,a,r,c,l,d);for(let h of d){c.push(`
`);let g=r.length;this.serialize(h,a,r,c,l);let m=r[g];m&&(m.detached=!0)}let u=uo(l.join(""));if(!vt(u))return null;let p=e.slice();for(;p.length>1;){let h=p[p.length-1];if(!(h.nodeType===Node.TEXT_NODE?xt(h.data):h.localName==="br"))break;p.pop()}return{nodes:p,parent:t,markup:uo(c.join("")),slots:r,text:u,compact:n}}serialize(e,t,n,r,i,s){if(s?.has(e))return;if(e.nodeType===Node.TEXT_NODE){let p=e.data,h=t?p.replace(/[ \t\r\f]+/g," "):p.replace(/[ \t\r\n\f]+/g," ");r.push(re(h)),i.push(h);return}if(e.nodeType!==Node.ELEMENT_NODE)return;let a=e,l=this.kindOf(a);if(l==="br"){r.push(`
`),i.push(`
`);return}if(l==="hidden"||l==="collapsed"||l==="own"||l==="skip")return;if(l==="atomic"){let p=n.length;n.push({el:a,atomic:!0});let h=(a.textContent??"").replace(/\s+/g," ").trim()||a.getAttribute("alt")||"•";r.push(`<x${p}>${re(h)}</x${p}>`);return}let c=Ci.has(a.localName)||Ri(a),d=c?n.length:-1,u=Li(a);u&&(r.push(" "),i.push(" ")),c&&(n.push({el:a,atomic:!1}),r.push(`<x${d}>`));for(let p of Array.from(a.childNodes))this.serialize(p,t,n,r,i,s);c&&r.push(`</x${d}>`),u&&(r.push(" "),i.push(" "))}};function Hi(o){return o.localName.includes("-")}function uo(o){return o.replace(/ *\n */g,`
`).replace(/ {2,}/g," ").trim()}function po(o,e){let t=o.nodeType===Node.ELEMENT_NODE?o:o.parentNode;for(;t;){if(t.nodeType===Node.DOCUMENT_FRAGMENT_NODE)return t;if(t.nodeType!==Node.ELEMENT_NODE)return null;let n=t,r=e.kindOf(n);if(r==="block"||r==="collapsed"||n===document.body)return n;if(r==="skip"||r==="hidden")return null;t=n.parentNode}return null}var Et=new WeakSet;function rn(o){for(let e of Array.from(o.querySelectorAll("yl-t,yl-r")))Et.has(e)||e.remove();for(let e of Array.from(o.querySelectorAll("[data-yl-hidden]")))Et.has(e)||e.removeAttribute("data-yl-hidden")}var Ii=.98;function Di(o){let e=/^rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(o);return e?.2126*Number(e[1])+.7152*Number(e[2])+.0722*Number(e[3])>140:!1}function St(o,e,t){if(!e||!o.detected||o.score===void 0||o.score>=Ii)return!1;let n=o.detected.split("-")[0];return n!==e&&n!==t.split("-")[0]}var sn=new WeakMap,Oi=24,_i=new Set(["en","fr","de","es","pt","it","nl","pl","tr","vi","id"]),Bi=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,Fi=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,Ne=class{constructor(e){this.run=e;this.wire=e.markup}state="idle";raw;wire;from="";fallback;hoverHost=null;tree;renderedMode;inserted;textBackup=new Map;written=new Map;hidden=[];unclamped;get markup(){return this.run.markup}get text(){return this.run.text}get compact(){return this.run.compact}get isRendered(){return this.renderedMode!==void 0}get rendersInPlace(){return this.renderedMode==="replace"}get anchor(){let e=this.parentElement;for(let t of this.run.nodes)if(t.nodeType===Node.ELEMENT_NODE){e=t;break}for(;e.parentElement&&getComputedStyle(e).display==="contents";)e=e.parentElement;return e}get parentElement(){let e=this.run.parent;return e.nodeType===Node.ELEMENT_NODE?e:e.host}sourceHint(){if(this.text.length>Oi||/[^\p{Script=Latin}\P{L}]/u.test(this.text))return"";let t=this.parentElement.closest("[lang]")?.getAttribute("lang")?.split("-")[0]?.toLowerCase()??"";return _i.has(t)?t:""}regionContent(e){let t=this.parentElement,n=this.sourceHint();if(this.rendersInPlace){let f=this.hoverHost;return{markup:this.markup,slots:this.run.slots,text:this.text,hint:n,block:t,rect:()=>f?.getBoundingClientRect()??null}}let r=new Map(this.run.slots.map((f,v)=>[f.el,v])),i=[],s=[],a=f=>{let v=f.left+f.width/2,w=f.top+f.height/2;return f.width>0&&v>=e.left&&v<=e.right&&w>=e.top&&w<=e.bottom},l=document.createRange(),c=!1,d=(f,v,w,E)=>{c||(l.setStart(f,v),c=!0),l.setEnd(w,E)},u=new Intl.Segmenter(void 0,{granularity:"word"}),p=document.createRange(),h=f=>{if(f.nodeType===Node.TEXT_NODE){for(let T of u.segment(f.data)){if(!T.isWordLike&&!/\S/.test(T.segment)){i.push(" "),s.push(" ");continue}p.setStart(f,T.index),p.setEnd(f,T.index+T.segment.length),a(p.getBoundingClientRect())&&(i.push(re(T.segment)),s.push(T.segment),d(f,T.index,f,T.index+T.segment.length))}return}if(f.nodeType!==Node.ELEMENT_NODE)return;let v=f;if(v.localName==="br"){i.push(`
`);return}if(Ae.has(v.localName))return;let w=r.get(v);if(w!==void 0&&this.run.slots[w].atomic){if(Array.from(v.getClientRects()).some(a)){i.push(`<x${w}>${re((v.textContent??"").trim()||"•")}</x${w}>`);let T=v.parentNode,R=Array.from(T.childNodes).indexOf(v);d(T,R,T,R+1)}return}let E=i.length;w!==void 0&&i.push(`<x${w}>`);for(let T of Array.from(v.childNodes))h(T);w!==void 0&&(i.slice(E+1).join("").trim()?i.push(`</x${w}>`):i.length=E)};for(let f of this.run.nodes)h(f);let g=i.join("").replace(/\s+/g,f=>f.includes(`
`)?`
`:" ").trim(),m=s.join("").replace(/\s+/g," ").trim();return!c||!vt(m)?null:{markup:g,slots:this.run.slots,text:m,hint:n,block:t,rect:()=>l.getBoundingClientRect()}}clientRects(){let e=this.run.nodes,t=e[0],n=e[e.length-1];if(!t||!n||!t.isConnected)return[];if(this.rendersInPlace&&this.inserted)return Array.from(this.inserted.getClientRects());let r=document.createRange();return r.setStartBefore(t),r.setEndAfter(n),Array.from(r.getClientRects())}setTranslation(e){this.raw=e;let t=new Set(this.run.slots.map((n,r)=>r));this.tree=_e(ie(e,t),n=>!!this.run.slots[n]?.detached)}renderStatus(e,t,n){if(t.mode!=="dual"||this.renderedMode||this.compact)return;this.removeInserted();let r=document.createElement("yl-t");r.setAttribute("data-state",e),r.style.setProperty("--yl-theme",t.theme),e==="error"&&(r.setAttribute("data-yl-retry",""),r.textContent=n),this.insertAfterRun(r),this.inserted=r}clearStatus(){this.renderedMode||this.removeInserted()}render(e){this.tree&&(this.unrender(),e.mode==="dual"&&!this.compact?(this.renderDual(e),this.renderedMode="dual"):(this.renderReplace(e),this.renderedMode="replace"))}unrender(){this.removeInserted();for(let[e,t]of this.textBackup)e.data===this.written.get(e)&&(e.data=t);this.textBackup.clear(),this.written.clear();for(let e of this.hidden)e.removeAttribute("data-yl-hidden");this.hidden=[],this.unclamped?.removeAttribute("data-yl-unclamp"),this.unclamped=void 0,this.renderedMode=void 0,this.hoverHost=null}isIntact(){for(let e of this.run.nodes)if(!e.isConnected||e.parentNode!==this.run.parent)return!1;for(let[e,t]of this.written)if(e.data!==t)return!1;return!0}applyDualStyle(e){this.renderedMode==="dual"&&this.inserted&&this.decorate(this.inserted,e)}renderDual(e){let t=document.createElement("yl-t");t.setAttribute("lang",e.targetLang),t.setAttribute("dir","auto"),this.decorate(t,e),this.shouldBeInline()&&t.setAttribute("data-inline","");let n=document.createElement("yl-i");n.append(this.buildFragment()),t.append(n),this.insertAfterRun(t),this.inserted=t,this.hoverHost=t;let r=this.parentElement;getComputedStyle(r).webkitLineClamp!=="none"&&getComputedStyle(r).webkitLineClamp!==""&&(r.setAttribute("data-yl-unclamp",""),this.unclamped=r)}decorate(e,t){t.dualStyle==="plain"?e.removeAttribute("data-style"):e.setAttribute("data-style",t.dualStyle);let n=e,r=Di(getComputedStyle(this.parentElement).color);n.style.setProperty("--yl-theme",it(t.theme,r?_n:rt)),r?e.setAttribute("data-tone","dark"):e.removeAttribute("data-tone"),n.style.fontSize=t.fontScale===100?"":`${t.fontScale}%`}shouldBeInline(){let e=this.parentElement,t=getComputedStyle(e);return t.whiteSpace==="nowrap"||t.whiteSpace==="pre"||t.display==="inline"||t.display==="inline-block"?!0:t.display.includes("flex")?!t.flexDirection.startsWith("column"):t.display.includes("grid")}renderReplace(e){let t=this.run.nodes,n=this.tree.some(s=>typeof s=="string"&&s.includes(`
`));if(t.every(s=>s.nodeType===Node.TEXT_NODE)&&!n&&this.run.slots.length===0){let s=this.tree.map(a=>typeof a=="string"?a:"").join("");t.forEach((a,l)=>{let c=a;this.textBackup.set(c,c.data);let d="";l===0&&(d=(/^\s/.test(c.data)?" ":"")+s),c.data=d,this.written.set(c,d)}),this.hoverHost=this.parentElement;return}for(let s of t)if(s.nodeType===Node.TEXT_NODE){let a=s;this.textBackup.set(a,a.data),a.data="",this.written.set(a,"")}else if(s.nodeType===Node.ELEMENT_NODE){let a=s;a.setAttribute("data-yl-hidden",""),Et.add(a),this.hidden.push(a)}let i=document.createElement("yl-r");i.setAttribute("lang",e.targetLang),i.append(this.buildFragment()),this.insertAfterRun(i),this.inserted=i,this.hoverHost=i}insertAfterRun(e){Et.add(e);let t=this.run.nodes[this.run.nodes.length-1];t.parentNode?.insertBefore(e,t.nextSibling)}removeInserted(){this.inserted?.remove(),this.inserted=void 0}buildFragment(){let e=document.createDocumentFragment();this.appendNodes(e,this.tree);let t=Te(this.tree);return this.run.slots.forEach((n,r)=>{n.atomic&&!t.has(r)&&e.append(" ",this.cloneSlot(n))}),e}appendNodes(e,t){t.forEach((n,r)=>{if(typeof n=="string"){this.appendText(e,n);return}let i=this.run.slots[n.slot];if(!i)return;if(i.atomic){let a=t[r-1],l=t[r+1];typeof a=="string"&&Bi.test(a)&&e.appendChild(document.createTextNode(" ")),e.appendChild(this.cloneSlot(i)),typeof l=="string"&&Fi.test(l)&&e.appendChild(document.createTextNode(" "));return}let s=this.cloneShell(i);this.appendNodes(s,n.children),e.appendChild(s)})}appendText(e,t){t.split(`
`).forEach((r,i)=>{i>0&&e.appendChild(document.createElement("br")),r&&e.appendChild(document.createTextNode(r))})}cloneSlot(e){let t=e.el.cloneNode(!0);t.removeAttribute("id"),t.removeAttribute("data-yl-hidden");for(let n of t.querySelectorAll("[id]"))n.removeAttribute("id");return t}cloneShell(e){let t=e.el.cloneNode(!1);return t.removeAttribute("id"),t.removeAttribute("data-yl-hidden"),sn.set(t,e.el),t.style?.setProperty("--yl-c",getComputedStyle(e.el).color),t}};var ho=`/* Injected into pages and shadow roots. Fonts and colours are inherited on purpose. */

yl-t {
  display: block !important;
  margin: 0.3em 0 0 !important;
  padding: 0;
  font-family: inherit;
  font-weight: inherit;
  line-height: inherit;
  color: inherit;
  white-space: normal !important;
  text-indent: 0;
  letter-spacing: normal;
  overflow-wrap: break-word;
  max-width: 100%;
  float: none !important;
  position: static !important;
}

yl-t[data-inline] {
  display: inline !important;
  margin: 0 0 0 0.5em !important;
  white-space: inherit !important;
}

yl-r {
  display: inline;
  font: inherit;
  color: inherit;
}

/*
 * One colour the reader picks, the same on every page. Its value is set on each translation.
 * The full palette belongs on thin frames only.
 */
/* Copying allowed again, by the reader's choice: text can be selected whatever the page says. */
html[data-yl-unlock] *:not(input):not(textarea) {
  -webkit-user-select: text !important;
  user-select: text !important;
}

yl-t {
  --yl-theme: #1f77f3;
  --yl-pen: 30%;
}

/* See-through colour dims over black: this much more looks the same as it does on white. */
yl-t[data-tone='dark'] {
  --yl-pen: 62%;
}

yl-t[data-style='accent'] {
  color: var(--yl-theme);
}

/* Links stay recognisably links; other coloured text leans to the ink. */
yl-t[data-style='accent'] a[style*='--yl-c'] {
  color: color-mix(in oklab, var(--yl-c) 65%, var(--yl-theme)) !important;
}

yl-t[data-style='accent'] [style*='--yl-c']:not(a) {
  color: color-mix(in oklab, var(--yl-c) 20%, var(--yl-theme)) !important;
}

yl-t[data-style='faded'] {
  opacity: 0.72;
}

yl-t[data-style='underline'] {
  text-decoration: underline dashed 1px var(--yl-theme);
  text-underline-offset: 0.32em;
}

/* A capsule that stops short of the block's ends, so it sits beside the text and not on it. */
yl-t[data-style='bar']:not([data-inline]) {
  position: relative !important;
  padding-left: 0.8em !important;
}

yl-t[data-style='bar']:not([data-inline])::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0.22em;
  bottom: 0.22em;
  width: 3px;
  border-radius: 3px;
  background: linear-gradient(180deg, var(--yl-theme), color-mix(in srgb, var(--yl-theme) 55%, transparent));
}

yl-t[data-style='bar'][data-inline] {
  color: var(--yl-theme);
}

/*
 * A highlighter pen that fades out upward, with no top edge to read as a band. It has to be
 * drawn on an inline box, because that is what follows each line of the text.
 */
yl-i {
  display: inline;
}

yl-t[data-style='highlight'] yl-i {
  background: linear-gradient(to top, color-mix(in srgb, var(--yl-theme) var(--yl-pen), transparent), transparent 78%);
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}

yl-t[data-state='loading'] {
  display: inline-block !important;
  width: 1.5em;
  height: 0.7em;
  margin: 0 0 0 0.4em !important;
  vertical-align: baseline;
  background-image:
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent);
  background-position: 0 50%, 50% 50%, 100% 50%;
  background-repeat: no-repeat;
  background-size: 0.26em 0.26em;
  opacity: 0.7;
  animation: yl-wave 1.05s ease-in-out infinite;
}

yl-t[data-state='error'] {
  font-size: 0.82em;
  color: #c62828;
  cursor: pointer;
  text-decoration: underline;
  text-underline-offset: 0.2em;
}

[data-yl-hidden] {
  display: none !important;
}

[data-yl-unclamp] {
  -webkit-line-clamp: unset !important;
  max-height: none !important;
  overflow: visible !important;
}

@keyframes yl-wave {
  0%,
  100% {
    background-size: 0.42em 0.42em, 0.26em 0.26em, 0.26em 0.26em;
  }
  33% {
    background-size: 0.26em 0.26em, 0.42em 0.42em, 0.26em 0.26em;
  }
  66% {
    background-size: 0.26em 0.26em, 0.26em 0.26em, 0.42em 0.42em;
  }
}

@media (prefers-reduced-motion: reduce) {
  yl-t[data-state='loading'] {
    animation: none;
  }
}
`;var ue=class{constructor(e,t){this.node=e;this.scrollers=t}animations=[];ranges="";movedByY=[];movedByX=[];left=NaN;top=NaN;place(e,t){this.follow();let n=this.node.getRootNode(),r=n instanceof ShadowRoot?n.host.getBoundingClientRect():{left:0,top:0},i=e-r.left,s=t-r.top;for(let a of this.movedByX)i+=a.scrollLeft;for(let a of this.movedByY)s+=a.scrollTop;Math.abs(i-this.left)<.5&&Math.abs(s-this.top)<.5||(this.left=i,this.top=s,this.node.style.left=`${i}px`,this.node.style.top=`${s}px`)}follow(){let e=globalThis.ScrollTimeline;if(!e)return;let t=this.scrollers.map(r=>[r,r.scrollHeight-r.clientHeight,r.scrollWidth-r.clientWidth]),n=t.map(([,r,i])=>`${r},${i}`).join(";");if(n!==this.ranges){this.ranges=n;for(let r of this.animations)r.cancel();this.animations=[],this.movedByY=[],this.movedByX=[];for(let[r,i,s]of t)i>0&&(this.animations.push(this.travel(new e({source:r,axis:"block"}),`translateY(${-i}px)`)),this.movedByY.push(r)),s>0&&(this.animations.push(this.travel(new e({source:r,axis:"inline"}),`translateX(${-s}px)`)),this.movedByX.push(r))}}travel(e,t){return this.node.animate({transform:["translate(0, 0)",t]},{timeline:e,fill:"both",easing:"linear",composite:"add"})}};var mo=4,pe=8,Wi=.6,Ui=.8;function Pe(o){let e=[];for(let t=o;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t);(/auto|scroll/.test(n.overflowY)||/auto|scroll/.test(n.overflowX))&&(t.scrollHeight>t.clientHeight+1||t.scrollWidth>t.clientWidth+1)&&e.push({el:t,top:t.scrollTop,left:t.scrollLeft})}return e}function qi(o){if(o.scrollHeight<=o.clientHeight+1&&o.scrollWidth<=o.clientWidth+1)return!1;let e=getComputedStyle(o);return/auto|scroll/.test(e.overflowY)||/auto|scroll/.test(e.overflowX)}function fo(o,e){let t=e.getBoundingClientRect();if(o.left>t.left+pe||o.right<t.right-pe)return!1;let n=Math.max(t.top,0),r=Math.min(t.bottom,innerHeight);return r<=n?!1:Math.min(o.bottom,r)-Math.max(o.top,n)>=(r-n)*Ui}function go(o){let e=[];for(let t of Array.from(document.querySelectorAll("body *")))!qi(t)||!fo(o,t)||e.some(n=>n.contains(t))||e.push(t);return e}function ji(o,e){if(fo(e,o))return!1;let t=o.getBoundingClientRect();if(e.top>=t.top-pe&&e.bottom<=t.bottom+pe&&e.left>=t.left-pe&&e.right<=t.right+pe)return!0;let r=getComputedStyle(o);return/auto|scroll/.test(r.overflowY)&&o.scrollHeight>o.clientHeight+1&&o.clientHeight>=innerHeight*Wi}var Tt=class{constructor(e){this.ui=e}box;rect;scrollers=[];windowTop=0;windowLeft=0;frameRequest=0;bounds={top:-1/0,bottom:1/0};framePin;over=!1;beyondArea=!1;showPending(e){this.close();let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scrollers=Pe(t).filter(i=>ji(i.el,e)),this.windowTop=scrollY,this.windowLeft=scrollX;let n=Ue();this.over=n.top>0&&e.top<n.top-1||n.bottom<innerHeight&&e.bottom>n.bottom+1;let r=this.scrollers[0]?.el.getBoundingClientRect();this.beyondArea=!!r&&(e.top<r.top-pe||e.bottom>r.bottom+pe),this.rect=this.visible(e),this.box=this.ui.addFrame(!0,!0,this.over),this.framePin=new ue(this.box,this.scrollers.map(i=>i.el)),this.reposition(),addEventListener("scroll",this.requestReposition,!0),addEventListener("resize",this.requestReposition)}visible(e){let t=mo+2,n=this.beyondArea?void 0:this.scrollers[0]?.el.getBoundingClientRect(),r={left:t,right:(document.documentElement.clientWidth||innerWidth)-t,top:Math.max(0,n?.top??0)+t,bottom:Math.min(innerHeight,n?.bottom??1/0)-t},i={...e},s=Math.max(e.left,r.left),a=Math.min(e.right,r.right);a-s>t*2&&Object.assign(i,{left:s,right:a});let l=Math.max(e.top,r.top),c=Math.min(e.bottom,r.bottom);return c-l>t*2&&Object.assign(i,{top:l,bottom:c}),i}settle(e){return e?(this.box&&(this.ui.setFramePending(this.box,!1),this.ui.addToPage(this.box,this.over)),!0):(this.close(),!1)}clip(e,t,n,r){let i=t?.getBoundingClientRect(),s=this.over?{top:-1/0,bottom:1/0}:this.bounds,a=Math.max(0,Math.max(i?.top??-1/0,s.top)-n),l=Math.max(0,r-Math.min(i?.bottom??1/0,s.bottom)),c=mo,d=u=>u?`${u}px`:`-${c}px`;e.style.clipPath=a||l?`inset(${d(a)} -${c}px ${d(l)} -${c}px)`:""}requestReposition=()=>{this.frameRequest||(this.frameRequest=requestAnimationFrame(this.reposition))};reposition=()=>{this.frameRequest=0,this.bounds=this.ui.settleUnderBars();let e=this.rect;if(!this.box||!e)return;let t=this.windowTop-scrollY,n=this.windowLeft-scrollX;for(let s of this.scrollers)t+=s.top-s.el.scrollTop,n+=s.left-s.el.scrollLeft;let r=e.top+t,i=e.bottom-e.top;this.framePin?.place(G(e.left+n),G(r)),Object.assign(this.box.style,{width:`${G(e.right-e.left)}px`,height:`${G(i)}px`}),this.clip(this.box,this.beyondArea?void 0:this.scrollers[0]?.el,r,r+i)};close(){removeEventListener("scroll",this.requestReposition,!0),removeEventListener("resize",this.requestReposition),cancelAnimationFrame(this.frameRequest),this.frameRequest=0,this.box?.remove(),this.box=void 0,this.framePin=void 0,this.over=!1,this.beyondArea=!1,this.rect=void 0,this.scrollers=[]}get emptyMessage(){return b("marqueeEmpty")}};var zi=3e4,bo=150,Gi=30,Ki=5e3,yo=4,Xi=60,Vi=400,Yi=300,Ji=8,Zi="800px 0px",Qi=8,es=3e4,ts=450,ns=2,os=3e3,kt=class{constructor(e,t){this.ui=t;this.settings=e,this.scanner.classifier.setExcludes(e.excludeSelectors),document.addEventListener("click",this.onClick,!0),document.addEventListener("mouseover",this.onMouseOver,!0),document.addEventListener("mouseout",this.onMouseOut,!0)}settings;scanner=new Le;segments=new Set;byNode=new WeakMap;byAnchor=new Map;styledRoots=new WeakSet;watchedRoots=[];pageActive=!1;generation=0;io;mo;queue=[];inFlight=0;flushTimer;dirty=new Set;dirtyTimer;rebuilds=new WeakMap;lastError;errorToastShown=!1;statusTimer;pageLang;hoverTimer;hoverSeg;hoverHosts=new WeakMap;get active(){return this.pageActive}get hasTranslations(){for(let e of this.segments)if(e.isRendered||e.state==="loading"||e.state==="queued")return!0;return!1}get hasPageTranslations(){for(let e of this.segments)if(!this.regionSegs.has(e)&&(e.isRendered||e.state==="loading"||e.state==="queued"))return!0;return!1}setPageLang(e){this.pageLang=e}get display(){let e=this.settings;return{mode:e.mode,dualStyle:e.dualStyle,fontScale:e.fontScale,targetLang:e.targetLang,theme:Me(e.themeColor)}}regionSegs=new Set;displayFor(e){return this.regionSegs.has(e)?{...this.display,mode:"replace"}:this.display}async translateRegion(e){if(!document.body)return 0;await this.scanRoot(document.body);let t=go(e),n=[];for(let r of this.segments)r.state==="done"&&!this.regionSegs.has(r)||!t.some(s=>s.contains(r.parentElement))&&!is(r.clientRects(),e)||je(r.text,this.settings.targetLang)||n.push(r);this.ownWrite(()=>{for(let r of n)this.regionSegs.add(r),r.state==="done"?(r.render(this.displayFor(r)),r.hoverHost&&this.hoverHosts.set(r.hoverHost,r)):r.state==="failed"&&(r.clearStatus(),r.state="idle")});for(let r of n)this.enqueue(r);return this.reportStatus(),n.length}async regionSettled(){for(let e=0;e<zi;e+=bo){if(![...this.regionSegs].some(t=>t.state==="queued"||t.state==="loading"))return;await new Promise(t=>setTimeout(t,bo))}}restoreRegion(){this.regionSegs.size&&(this.ownWrite(()=>{for(let e of this.regionSegs)e.unrender(),e.clearStatus(),e.state="idle",this.queue=this.queue.filter(t=>t!==e),this.pageActive&&this.enqueue(e)}),this.regionSegs.clear(),this.ui.hideTooltip(),this.pruneIdle(),this.reportStatus())}status(){let e=0,t=0,n=0,r=0;for(let s of this.segments)s.state!=="idle"&&(e++,s.state==="done"||s.state==="same"?t++:s.state==="failed"?n++:r++);let i={active:this.pageActive||this.hasTranslations,mode:this.settings.mode,total:e,done:t,failed:n,pending:r};return this.pageLang&&(i.pageLang=this.pageLang),location.hostname&&(i.host=location.hostname),n>0&&this.lastError&&(i.error=this.lastError),i}reportStatus(){this.statusTimer===void 0&&(this.statusTimer=setTimeout(()=>{this.statusTimer=void 0,Y()&&N({type:"status",status:this.status()}).catch(()=>{})},150))}async startPage(){this.pageActive||!document.body||(this.pageActive=!0,this.errorToastShown=!1,this.startObservers(),await this.scanRoot(document.body),this.observeAllEligible(),this.reportStatus())}togglePage(){this.pageActive||this.hasPageTranslations?this.restore():this.startPage()}retire(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.ownWrite(()=>{for(let e of this.segments)e.state==="loading"&&e.clearStatus()})}restore(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.lastError=void 0;for(let e of this.segments)this.dropSegment(e,!0);this.segments.clear(),this.regionSegs.clear(),this.byAnchor.clear(),this.ui.hideTooltip(),this.reportStatus()}setMode(e){this.settings={...this.settings,mode:e},this.rerenderAll(),this.pageActive&&this.observeAllEligible(),this.reportStatus()}retryFailed(){this.errorToastShown=!1,this.lastError=void 0;for(let e of this.segments)e.state==="failed"&&(e.clearStatus(),this.enqueue(e))}applySettings(e){let t=this.settings;if(this.settings=e,e.excludeSelectors!==t.excludeSelectors&&this.scanner.classifier.setExcludes(e.excludeSelectors),e.showOriginalOnHover||(clearTimeout(this.hoverTimer),this.hoverSeg=void 0,this.ui.hideTooltip()),(t.targetLang!==e.targetLang||t.sourceLang!==e.sourceLang)&&(this.pageActive||this.hasTranslations)){let r=this.pageActive,i=[...this.segments].filter(s=>s.isRendered);this.generation++,this.queue=[];for(let s of this.segments)s.unrender(),s.clearStatus(),s.state="idle",s.raw=void 0,s.wire=s.markup,s.from="",s.fallback=void 0;if(r)this.observeAllEligible();else for(let s of i)this.enqueue(s);return}t.mode!==e.mode?this.setMode(e.mode):(t.dualStyle!==e.dualStyle||t.fontScale!==e.fontScale||t.themeColor!==e.themeColor)&&this.ownWrite(()=>{for(let r of this.segments)r.applyDualStyle(this.display)})}pruneIdle(){if(!this.pageActive){for(let e of this.segments)if(e.state==="idle"&&!e.isRendered){this.segments.delete(e);for(let t of e.run.nodes)this.byNode.delete(t)}}}hooks={consume:e=>{let t=this.byNode.get(e);return t?.rendersInPlace?t.isIntact()?(this.seen?.add(t),!0):(this.ownWrite(()=>this.dropSegment(t,!0)),this.segments.delete(t),!1):!1},emit:e=>this.register(e),shadowRoot:e=>this.adoptShadowRoot(e)};seen;async scanRoot(e){this.ownWrite(()=>rn(e)),this.scanner.reset(),this.seen=new Set;let t=this.scanner.scan(e,this.hooks),n=performance.now();for(let r=t.next();!r.done;r=t.next())performance.now()-n>Ji&&(await new Promise(i=>setTimeout(i,0)),n=performance.now());this.seen=void 0}register(e){let t=e.nodes[0],n=this.byNode.get(t);if(n&&n.markup===e.markup){this.seen?.add(n);return}n&&(this.ownWrite(()=>this.dropSegment(n,!0)),this.segments.delete(n));let r=new Ne(e);this.segments.add(r),this.seen?.add(r);for(let i of e.nodes)this.byNode.set(i,r);this.pageActive&&this.observeSegment(r)}observeSegment(e){if(!this.io||e.state!=="idle")return;let t=e.anchor,n=this.byAnchor.get(t);n||(n=new Set,this.byAnchor.set(t,n),this.io.observe(t)),n.add(e)}observeAllEligible(){for(let e of this.segments)this.observeSegment(e)}dropSegment(e,t){t&&(e.unrender(),e.clearStatus()),e.state="idle";for(let r of e.run.nodes)this.byNode.get(r)===e&&this.byNode.delete(r);let n=this.byAnchor.get(e.anchor);n&&(n.delete(e),n.size||(this.byAnchor.delete(e.anchor),this.io?.unobserve(e.anchor)))}adoptShadowRoot(e){if(this.styledRoots.has(e))return;this.styledRoots.add(e);let t=document.createElement("style");t.setAttribute("data-yl",""),t.textContent=ho,e.append(t),this.watchedRoots.push(e),this.mo?.observe(e,an)}startObservers(){this.io=new IntersectionObserver(this.onIntersect,{rootMargin:Zi}),this.mo=new MutationObserver(this.onMutations),document.body&&this.mo.observe(document.body,an);for(let e of this.watchedRoots)this.mo.observe(e,an)}stopObservers(){this.io?.disconnect(),this.mo?.disconnect(),this.io=void 0,this.mo=void 0}onIntersect=e=>{for(let t of e){if(!t.isIntersecting)continue;let n=this.byAnchor.get(t.target);if(n){for(let r of n)this.enqueue(r);this.byAnchor.delete(t.target)}this.io?.unobserve(t.target)}};ownWrite(e){let t=this.mo?.takeRecords();t?.length&&this.onMutations(t),e(),this.mo?.takeRecords()}onMutations=e=>{for(let t of e){if(vo(t.target))continue;if(t.type==="childList"){let r=[...Array.from(t.addedNodes),...Array.from(t.removedNodes)];if(r.length&&r.every(vo))continue}let n=po(t.target,this.scanner);n&&this.dirty.add(n)}this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},Yi))};async flushDirty(){let e=this.generation,t=[...this.dirty].filter(n=>{for(let r of this.dirty)if(r!==n&&r.contains(n))return!1;return n.isConnected});this.dirty.clear();for(let n of t){if(e!==this.generation||!this.pageActive)return;if(!this.allowRebuild(n)){this.dirty.add(n);continue}let r=[...this.segments].filter(s=>n.contains(s.run.parent));this.ownWrite(()=>rn(n)),this.scanner.reset(),this.seen=new Set;let i=this.seen;for(let s of this.scanner.scan(n,this.hooks));this.seen=void 0;for(let s of r)i.has(s)||(this.ownWrite(()=>this.dropSegment(s,!0)),this.segments.delete(s))}for(let n of this.segments)n.anchor.isConnected||(this.dropSegment(n,!1),this.segments.delete(n));this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},os)),this.reportStatus()}allowRebuild(e){let t=Date.now(),n=this.rebuilds.get(e);return!n||t-n.since>es?(this.rebuilds.set(e,{n:1,since:t}),!0):(n.n++,n.n<=Qi)}enqueue(e,t=!1){if(!(e.state==="done"||e.state==="loading"||e.state==="same")&&!(e.state==="queued"&&!t)){if(je(e.text,this.settings.targetLang)){e.state="same";return}e.state!=="queued"&&(e.state="queued",t||this.queue.push(e)),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},Xi)),this.reportStatus()}}prioritizeQueue(){if(this.queue=this.queue.filter(n=>n.state==="queued"),this.queue.length<2)return;let e=innerHeight,t=new Map;for(let n of this.queue){let r=n.anchor.getBoundingClientRect();t.set(n,r.bottom<0?-r.bottom:r.top>e?r.top-e:0)}this.queue.sort((n,r)=>t.get(n)-t.get(r))}pump(){if(!(this.inFlight>=yo))for(this.prioritizeQueue();this.inFlight<yo&&this.queue.length;){let e=this.settings.sourceLang||this.queue[0].from,t=[],n=[],r=0;for(let i of this.queue)t.length<Gi&&(t.length===0||r+i.wire.length<=Ki)&&(this.settings.sourceLang||i.from)===e?(t.push(i),r+=i.wire.length):n.push(i);this.queue=n,this.sendBatch(t,e)}}async sendBatch(e,t){let n=this.generation;this.inFlight++;for(let s of e)s.state="loading";let r=setTimeout(()=>{n===this.generation&&this.ownWrite(()=>{for(let s of e)s.state==="loading"&&s.renderStatus("loading",this.displayFor(s),"")})},Vi),i;for(let s=0;s<=ns&&!i;s++)try{let a=await N({type:"translate",items:e.map(l=>l.wire),from:t,to:this.settings.targetLang});a?.results?.length===e.length&&(i=a.results)}catch{if(!Y())break}if(clearTimeout(r),this.inFlight--,!Y()){this.retire();return}n===this.generation&&this.applyResults(e,i),this.pump(),this.reportStatus()}applyResults(e,t){this.ownWrite(()=>{e.forEach((n,r)=>{if(!this.segments.has(n))return;let i=t?.[r]??{ok:!1,code:"network"};if(!i.ok){n.state="failed",this.lastError=i.code,n.clearStatus(),n.renderStatus("error",this.displayFor(n),b("retryInline"));return}if(n.clearStatus(),!this.settings.sourceLang&&!n.from&&St(i,n.sourceHint(),this.settings.targetLang)){n.fallback=i.text,n.from=n.sourceHint(),n.state="idle",this.enqueue(n);return}let s=n.fallback!==void 0&&this.isUnchanged(n,i.text,void 0)?n.fallback:i.text;if(this.isUnchanged(n,s,i.detected)){if(n.wire===n.markup&&/\s[—–]\s/.test(n.markup)){n.wire=n.markup.replace(/\s[—–]\s/g," - "),n.state="idle",this.enqueue(n);return}n.state="same";return}n.setTranslation(s),n.state="done",n.render(this.displayFor(n)),n.hoverHost&&this.hoverHosts.set(n.hoverHost,n)})}),this.lastError&&!this.errorToastShown&&e.some(n=>n.state==="failed")&&(this.errorToastShown=!0,this.ui.toast(this.ui.errorMessage(this.lastError),{label:b("retry"),run:()=>this.retryFailed()}))}isUnchanged(e,t,n){if(!t.trim())return!0;let r=this.settings.targetLang;return n&&n.split("-")[0]===r.split("-")[0]&&(n===r||!r.startsWith("zh"))?!0:we(ie(t)).trim()===we(ie(e.markup)).trim()}rerenderAll(){this.ownWrite(()=>{for(let e of this.segments)e.state==="done"?(e.render(this.displayFor(e)),e.hoverHost&&this.hoverHosts.set(e.hoverHost,e)):e.state==="failed"&&(e.clearStatus(),e.renderStatus("error",this.displayFor(e),b("retryInline")))})}onClick=e=>{let t=e.composedPath();for(let n of t){if(!(n instanceof Element))continue;if(n.localName==="yl-t"&&n.hasAttribute("data-yl-retry")){e.preventDefault(),e.stopPropagation(),this.retryFailed();return}let r=sn.get(n);if(r){if(e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault(),e.stopPropagation(),r.click();return}if(Ae.has(n.localName))return}};onMouseOver=e=>{if(!this.settings.showOriginalOnHover)return;let t=this.segmentAt(e);if(t===this.hoverSeg||(this.hoverSeg=t,clearTimeout(this.hoverTimer),this.ui.hideTooltip(),!t?.hoverHost))return;let n=t.hoverHost;this.hoverTimer=setTimeout(()=>{t.isRendered&&n.isConnected&&this.ui.showTooltip(we(ie(t.markup)),rs(n))},ts)};onMouseOut=e=>{this.hoverSeg&&!e.relatedTarget&&(this.hoverSeg=void 0,clearTimeout(this.hoverTimer),this.ui.hideTooltip())};segmentAt(e){for(let t of e.composedPath()){if(!(t instanceof Element))continue;let n=this.hoverHosts.get(t);if(n?.rendersInPlace)return n;if(t===document.body)break}}},an={childList:!0,characterData:!0,subtree:!0};function vo(o){let e=o;for(;e;){if(e.nodeType===Node.ELEMENT_NODE&&Ae.has(e.localName))return!0;e=e.parentNode}return!1}function rs(o){return o.getBoundingClientRect()}function is(o,e){for(let t of o){let n=Math.min(t.bottom,e.bottom)-Math.max(t.top,e.top),r=Math.min(t.right,e.right)-Math.max(t.left,e.left),i=t.bottom-t.top;if(i>0&&n>=i/2&&r>=Math.min(24,(t.right-t.left)/2))return!0}return!1}var ss={curl:"bash",bash:"bash",shell:"bash","command line":"bash",命令行:"bash",ruby:"ruby",python:"python",node:"javascript","node.js":"javascript",javascript:"javascript",typescript:"typescript",go:"go",java:"java",php:"php",".net":"csharp","c#":"csharp",html:"html",css:"css",json:"json",yaml:"yaml",sql:"sql"},wo={js:"javascript",jsx:"jsx",ts:"typescript",tsx:"tsx",py:"python",rb:"ruby",sh:"bash",html:"html",css:"css",json:"json",yml:"yaml",yaml:"yaml",go:"go",java:"java",php:"php",cs:"csharp",sql:"sql",md:"markdown",vue:"vue"};function xo(o){return o.ownerDocument.defaultView?.getComputedStyle(o)??null}function Eo(o){return o.getAttribute("aria-hidden")==="true"?!0:xo(o)?.userSelect==="none"}function as(o){let e=xo(o)?.display??"";return e==="block"||e==="flex"||e==="grid"||e==="list-item"||e==="table-row"}function So(o,e){for(let t of Array.from(o.childNodes))if(t.nodeType===3)e.push(t.data);else if(t.nodeType===1){let n=t;if(Eo(n))continue;if(n.localName==="br"){e.push(`
`);continue}So(n,e),as(n)&&!(e[e.length-1]??"").endsWith(`
`)&&e.push(`
`)}}function ls(o){let e=o.localName==="pre"?o:o.querySelector("pre")??o,t=[];return So(e,t),t.join("").replace(/\n+$/,"")}function cs(o){let e=[o,...Array.from(o.querySelectorAll("pre,code"))];for(let t of e){let n=/(?:^|\s)(?:language|lang|highlight-source)-([\w+#-]+)/.exec(t.getAttribute("class")??"");if(n?.[1])return n[1].toLowerCase()}return""}function To(o){let e=o.trim().toLowerCase(),t=/\.([a-z0-9]+)$/.exec(e);return t?.[1]&&wo[t[1]]?wo[t[1]]:ss[e]??""}function ds(o){let e=o.parentElement;for(let t=0;e&&t<4;t++,e=e.parentElement){if(e.querySelectorAll("pre").length>1)return"";for(let n of Array.from(e.querySelectorAll("*"))){if(n.children.length||o.contains(n))continue;let r=To(n.textContent??"");if(r)return r}}return""}function us(o){let e=2;for(let t of o.matchAll(/`+/g))e=Math.max(e,t[0].length);return"`".repeat(e+1)}function ps(o){let e=o.replace(/\s+/g," ").trim();return e?(e.includes("`")?"``":"`")==="``"?`\`\` ${e} \`\``:`\`${e}\``:""}function ln(o,e){let t=/^(\s*)([\s\S]*?)(\s*)$/.exec(e);return t?.[2]?`${t[1]}${o}${t[2]}${o}${t[3]}`:e}function Se(o){let e="";for(let t of Array.from(o.childNodes)){if(t.nodeType===3){e+=t.data.replace(/\s+/g," ");continue}if(t.nodeType!==1)continue;let n=t,r=n.localName;if(r==="br")e+=`  
`;else if(r==="code"||r==="kbd"||r==="samp"||r==="tt")e+=ps(n.textContent??"");else if(r==="strong"||r==="b")e+=ln("**",Se(n));else if(r==="em"||r==="i")e+=ln("*",Se(n));else if(r==="del"||r==="s")e+=ln("~~",Se(n));else if(r==="img"){let i=n.getAttribute("src");i&&(e+=`![${n.getAttribute("alt")??""}](${n.src||i})`)}else if(r==="a"){let i=Se(n).trim(),s=n.href;e+=i&&/^https?:/i.test(s)?`[${i}](${s})`:i}else r!=="svg"&&!Eo(n)&&(e+=Se(n))}return e}function hs(o){let e=0;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&e++;return Math.max(0,e-1)}function ms(o){let e=o;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&(e=t);return e}function fs(o){if(o.closest('button,[role="button"],nav,[role="navigation"],[role="tablist"]'))return null;let e=Se(o).replace(/[ \t]+/g," ").trim();if(!e)return null;let t=o.closest("h1,h2,h3,h4,h5,h6");if(t)return{text:`${"#".repeat(Number(t.localName[1]))} ${e.replace(/\s*\n\s*/g," ")}`};let n=o.closest("li");if(n){let r=n.parentElement,i=r?.localName==="ol"?`${Array.from(r.children).indexOf(n)+1}.`:"-";return{text:`${"  ".repeat(hs(n))}${i} ${e}`,group:ms(n)}}return o.closest("blockquote")?{text:e.split(`
`).map(r=>`> ${r}`).join(`
`)}:{text:e}}function gs(o){if((o.textContent??"").trim().length>40)return null;let e=o.parentElement;for(let t=0;e&&t<6;t++,e=e.parentElement){if(e.localName==="body"||e.localName==="main"||e.localName==="article")return null;let n=e.querySelectorAll("pre");if(n.length===1)return n[0];if(n.length>1)return null}return null}function bs(o){let e=new Map,t=new Set;for(let{copy:n}of o){let r=n.closest("table");if(!r||t.has(r))continue;t.add(r);let i=Array.from(r.querySelectorAll("tr")).map(a=>Array.from(a.children).map(l=>Se(l).replace(/\s+/g," ").replace(/\|/g,"\\|").trim())).filter(a=>a.some(Boolean));if(!i.length)continue;let s=i.map(a=>`| ${a.join(" | ")} |`);s.splice(1,0,`| ${i[0].map(()=>"---").join(" | ")} |`),e.set(r,s.join(`
`))}return e}function ko(o){let e=new Map,t=new Set;for(let a of o){if(a.kind==="code")continue;let l=gs(a.copy);if(!l)continue;t.add(a.copy);let c=To(a.copy.textContent??"");c&&!e.has(l)&&e.set(l,c)}let n=bs(o),r=new Set,i=[];for(let a of o){if(t.has(a.copy))continue;if(a.kind==="code"){let d=ls(a.copy);if(!d.trim())continue;let u=a.copy.localName==="pre"?a.copy:a.copy.querySelector("pre"),p=u&&(e.get(u)||ds(u))||cs(a.copy),h=us(d);i.push({text:`${h}${p}
${d}
${h}`});continue}let l=a.copy.closest("table");if(l&&n.has(l)){r.has(l)||i.push({text:n.get(l)}),r.add(l);continue}let c=fs(a.copy);c&&i.push(c)}let s="";return i.forEach((a,l)=>{l&&(s+=a.group&&a.group===i[l-1].group?`
`:`

`),s+=a.text}),s}var ze=16,ys=32,vs=28,ws="data-yl-find",Mt=class{constructor(e,t,n){this.mirror=e;this.copies=n;this.track.append(this.thumb),t.append(this.track),this.mirror.doc.addEventListener("scroll",this.onScroll,!0),this.track.addEventListener("pointerdown",this.onPointerDown)}track=y("div","scan-track");thumb=y("i","scan-thumb");min=0;max=0;visible=0;origin=0;open=!1;marks=[];active=-1;measure(){let e=1/0,t=-1/0,n=this.mirror.doc.createRange();for(let r of this.copies()){if(!r.isConnected)continue;n.selectNodeContents(r);let i=n.getBoundingClientRect();!i.width&&!i.height||(e=Math.min(e,i.top),t=Math.max(t,i.bottom))}return e===1/0?null:{top:e,bottom:t}}get contentHeight(){let e=this.measure();return e?e.bottom-e.top+ze*2:0}start(e,t){let n=this.mirror.scroller,r=this.measure();if(this.visible=e,this.origin=t,this.open=!0,!n||!r)return;let i=n.scrollTop;this.min=i+r.top-t-ze,this.max=Math.max(this.min,i+r.bottom+ze-t-e),this.scrollTo(Math.max(this.min,Math.min(i,this.max))),this.alignToBlock(),this.paint()}alignToBlock(){let e=this.mirror.doc.createRange(),t=1/0;for(let n of this.copies()){if(!n.isConnected)continue;e.selectNodeContents(n);let r=e.getBoundingClientRect();(r.width||r.height)&&r.bottom>this.origin&&r.top<t&&(t=r.top)}t!==1/0&&this.scrollBy(t-this.origin-ys)}stop(){this.open=!1,this.clearFind(),this.track.style.display="none"}get extent(){return{from:this.min,to:this.max,visible:this.visible}}get position(){return this.mirror.scroller?.scrollTop??0}moveTo(e){this.scrollTo(e)}scrollBy(e){let t=this.mirror.scroller;t&&this.scrollTo(t.scrollTop+e)}scrollTo(e){let t=this.mirror.scroller;t&&(t.scrollTop=Math.max(this.min,Math.min(e,this.max)))}onScroll=()=>{if(!this.open)return;let e=this.mirror.scroller;e&&((e.scrollTop<this.min-1||e.scrollTop>this.max+1)&&this.scrollTo(e.scrollTop),this.paint())};thumbHeight(){return Math.max(vs,this.visible*this.visible/(this.max-this.min+this.visible))}paint(){let e=this.mirror.scroller,t=this.max-this.min;if(!e||t<=0){this.track.style.display="none";return}this.track.style.display="";let n=this.thumbHeight();this.thumb.style.height=`${n}px`,this.thumb.style.transform=`translateY(${(e.scrollTop-this.min)/t*(this.visible-n)}px)`}onPointerDown=e=>{e.preventDefault(),this.track.setPointerCapture(e.pointerId);let t=this.track.getBoundingClientRect().top,n=this.thumbHeight(),r=this.max-this.min,i=this.thumb.getBoundingClientRect().top,s=e.target===this.thumb?e.clientY-i:n/2,a=c=>{let d=(c.clientY-t-s)/(this.visible-n);this.scrollTo(this.min+Math.max(0,Math.min(1,d))*r)};a(e);let l=()=>{this.track.removeEventListener("pointermove",a),this.track.removeEventListener("pointerup",l)};this.track.addEventListener("pointermove",a),this.track.addEventListener("pointerup",l)};get hasQuery(){return this.marks.length>0}clearFind(){let e=new Set;for(let t of this.marks){let n=t.parentNode;n&&(t.replaceWith(...Array.from(t.childNodes)),e.add(n))}for(let t of e)t.normalize();this.marks=[],this.active=-1}find(e){this.clearFind();let t=e.trim().toLowerCase();if(!t)return 0;let n=this.mirror.doc;for(let r of this.copies()){if(!r.isConnected)continue;let i=n.createTreeWalker(r,NodeFilter.SHOW_TEXT),s=[];for(let a=i.nextNode();a;a=i.nextNode())s.push(a);for(let a of s)this.markIn(a,t)}return this.step(1),this.marks.length}markIn(e,t){let n=[],r=e;for(let i=r.data.toLowerCase().indexOf(t);i!==-1;i=r.data.toLowerCase().indexOf(t)){let s=r.splitText(i);r=s.splitText(t.length);let a=this.mirror.doc.createElement("mark");a.setAttribute(ws,""),s.replaceWith(a),a.append(s),n.push(a)}this.marks.push(...n)}step(e){if(!this.marks.length)return 0;this.marks[this.active]?.removeAttribute("data-active"),this.active=(this.active+e+this.marks.length)%this.marks.length;let t=this.marks[this.active];t.setAttribute("data-active","");let n=t.getBoundingClientRect(),r=n.top-this.origin;return(r<ze||n.bottom-this.origin>this.visible-ze)&&this.scrollBy(r-this.visible/3),this.active+1}};var Po="[modern-screenshot]",he=typeof window<"u",xs=he&&"Worker"in window,Yc=he&&"atob"in window,Jc=he&&"btoa"in window,un=he?window.navigator?.userAgent:"",Ho=un.includes("Chrome"),Ct=un.includes("AppleWebKit")&&!Ho,pn=un.includes("Firefox"),Es=o=>o&&"__CONTEXT__"in o,Ss=o=>o.constructor.name==="CSSFontFaceRule",Ts=o=>o.constructor.name==="CSSImportRule",ks=o=>o.constructor.name==="CSSLayerBlockRule",se=o=>o.nodeType===1,Ve=o=>typeof o.className=="object",Io=o=>o.tagName==="image",Ms=o=>o.tagName==="use",Ge=o=>se(o)&&typeof o.style<"u"&&!Ve(o),Cs=o=>o.nodeType===8,As=o=>o.nodeType===3,Ie=o=>o.tagName==="IMG",At=o=>o.tagName==="VIDEO",Rs=o=>o.tagName==="CANVAS",Ls=o=>o.tagName==="TEXTAREA",Ns=o=>o.tagName==="INPUT",Ps=o=>o.tagName==="STYLE",Hs=o=>o.tagName==="SCRIPT",Is=o=>o.tagName==="SELECT",Ds=o=>o.tagName==="SLOT",Os=o=>o.tagName==="IFRAME",_s=(...o)=>console.warn(Po,...o);function Bs(o){let e=o?.createElement?.("canvas");return e&&(e.height=e.width=1),!!e&&"toDataURL"in e&&!!e.toDataURL("image/webp").includes("image/webp")}var cn=o=>o.startsWith("data:");function Do(o,e){if(o.match(/^[a-z]+:\/\//i))return o;if(he&&o.match(/^\/\//))return window.location.protocol+o;if(o.match(/^[a-z]+:/i)||!he)return o;let t=Rt().implementation.createHTMLDocument(),n=t.createElement("base"),r=t.createElement("a");return t.head.appendChild(n),t.body.appendChild(r),e&&(n.href=e),r.href=o,r.href}function Rt(o){return(o&&se(o)?o?.ownerDocument:o)??window.document}var Lt="http://www.w3.org/2000/svg";function Fs(o,e,t){let n=Rt(t).createElementNS(Lt,"svg");return n.setAttributeNS(null,"width",o.toString()),n.setAttributeNS(null,"height",e.toString()),n.setAttributeNS(null,"viewBox",`0 0 ${o} ${e}`),n}function $s(o,e){let t=new XMLSerializer().serializeToString(o);return e&&(t=t.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu,"")),`data:image/svg+xml;charset=utf-8,${encodeURIComponent(t)}`}function Ws(o,e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t(r.result),r.onerror=()=>n(r.error),r.onabort=()=>n(new Error(`Failed read blob to ${e}`)),e==="dataUrl"?r.readAsDataURL(o):e==="arrayBuffer"&&r.readAsArrayBuffer(o)})}var Us=o=>Ws(o,"dataUrl");function He(o,e){let t=Rt(e).createElement("img");return t.decoding="sync",t.loading="eager",t.src=o,t}function Ke(o,e){return new Promise(t=>{let{timeout:n,ownerDocument:r,onError:i,onWarn:s}=e??{},a=typeof o=="string"?He(o,Rt(r)):o,l=null,c=null;function d(){t(a),l&&clearTimeout(l),c?.()}if(n&&(l=setTimeout(d,n)),At(a)){let u=a.currentSrc||a.src;if(!u)return a.poster?Ke(a.poster,e).then(t):d();if(a.readyState>=2)return d();let p=d,h=g=>{s?.("Failed video load",u,g),i?.(g),d()};c=()=>{a.removeEventListener("loadeddata",p),a.removeEventListener("error",h)},a.addEventListener("loadeddata",p,{once:!0}),a.addEventListener("error",h,{once:!0})}else{let u=Io(a)?a.href.baseVal:a.currentSrc||a.src;if(!u)return d();let p=async()=>{if(Ie(a)&&"decode"in a)try{await a.decode()}catch(g){s?.("Failed to decode image, trying to render anyway",a.dataset.originalSrc||u,g)}d()},h=g=>{s?.("Failed image load",a.dataset.originalSrc||u,g),d()};if(Ie(a)&&a.complete)return p();c=()=>{a.removeEventListener("load",p),a.removeEventListener("error",h)},a.addEventListener("load",p,{once:!0}),a.addEventListener("error",h,{once:!0})}})}async function qs(o,e){Ge(o)&&(Ie(o)||At(o)?await Ke(o,e):await Promise.all(["img","video"].flatMap(t=>Array.from(o.querySelectorAll(t)).map(n=>Ke(n,e)))))}var Oo=function(){let e=0,t=()=>`0000${(Math.random()*36**4<<0).toString(36)}`.slice(-4);return()=>(e+=1,`u${t()}${e}`)}();function _o(o){return o?.split(",").map(e=>e.trim().replace(/"|'/g,"").toLowerCase()).filter(Boolean)}var Mo=0;function js(o){let e=`${Po}[#${Mo}]`;return Mo++,{time:t=>o&&console.time(`${e} ${t}`),timeEnd:t=>o&&console.timeEnd(`${e} ${t}`),warn:(...t)=>o&&_s(...t)}}function zs(o){return{cache:o?"no-cache":"force-cache"}}async function Bo(o,e){return Es(o)?o:hn(o,{...e,autoDestruct:!0})}async function hn(o,e){let{scale:t=1,workerUrl:n,workerNumber:r=1}=e||{},i=!!e?.debug,s=e?.features??!0,a=o.ownerDocument??(he?window.document:void 0),l=o.ownerDocument?.defaultView??(he?window:void 0),c=new Map,d={width:0,height:0,quality:1,type:"image/png",scale:t,backgroundColor:null,style:null,filter:null,maximumCanvasSize:0,timeout:3e4,progress:null,debug:i,fetch:{requestInit:zs(e?.fetch?.bypassingCache),placeholderImage:"data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",bypassingCache:!1,...e?.fetch},fetchFn:null,font:{},drawImageInterval:100,workerUrl:null,workerNumber:r,onCloneEachNode:null,onCloneNode:null,onEmbedNode:null,onCreateForeignObjectSvg:null,includeStyleProperties:null,autoDestruct:!1,...e,__CONTEXT__:!0,log:js(i),node:o,ownerDocument:a,ownerWindow:l,dpi:t===1?null:96*t,svgStyleElement:Fo(a),svgDefsElement:a?.createElementNS(Lt,"defs"),svgStyles:new Map,defaultComputedStyles:new Map,workers:[...Array.from({length:xs&&n&&r?r:0})].map(()=>{try{let h=new Worker(n);return h.onmessage=async g=>{let{url:m,result:f}=g.data;f?c.get(m)?.resolve?.(f):c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},h.onmessageerror=g=>{let{url:m}=g.data;c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},h}catch(h){return d.log.warn("Failed to new Worker",h),null}}).filter(Boolean),fontFamilies:new Map,fontCssTexts:new Map,acceptOfImage:`${[Bs(a)&&"image/webp","image/svg+xml","image/*","*/*"].filter(Boolean).join(",")};q=0.8`,requests:c,drawImageCount:0,tasks:[],features:s,isEnable:h=>h==="restoreScrollPosition"?typeof s=="boolean"?!1:s[h]??!1:typeof s=="boolean"?s:s[h]??!0,shadowRoots:[]};d.log.time("wait until load"),await qs(o,{timeout:d.timeout,onWarn:d.log.warn}),d.log.timeEnd("wait until load");let{width:u,height:p}=Gs(o,d);return d.width=u,d.height=p,d}function Fo(o){if(!o)return;let e=o.createElement("style"),t=e.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);return e.appendChild(t),e}function Gs(o,e){let{width:t,height:n}=e;if(se(o)&&(!t||!n)){let r=o.getBoundingClientRect();t=t||r.width||Number(o.getAttribute("width"))||0,n=n||r.height||Number(o.getAttribute("height"))||0}return{width:t,height:n}}async function Ks(o,e){let{log:t,timeout:n,drawImageCount:r,drawImageInterval:i}=e;t.time("image to canvas");let s=await Ke(o,{timeout:n,onWarn:e.log.warn}),{canvas:a,context2d:l}=Xs(o.ownerDocument,e),c=()=>{try{l?.drawImage(s,0,0,a.width,a.height)}catch(d){e.log.warn("Failed to drawImage",d)}};if(c(),e.isEnable("fixSvgXmlDecode"))for(let d=0;d<r;d++)await new Promise(u=>{setTimeout(()=>{l?.clearRect(0,0,a.width,a.height),c(),u()},d+i)});return e.drawImageCount=0,t.timeEnd("image to canvas"),a}function Xs(o,e){let{width:t,height:n,scale:r,backgroundColor:i,maximumCanvasSize:s}=e,a=o.createElement("canvas");a.width=Math.floor(t*r),a.height=Math.floor(n*r),a.style.width=`${t}px`,a.style.height=`${n}px`,s&&(a.width>s||a.height>s)&&(a.width>s&&a.height>s?a.width>a.height?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s):a.width>s?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s));let l=a.getContext("2d");return l&&i&&(l.fillStyle=i,l.fillRect(0,0,a.width,a.height)),{canvas:a,context2d:l}}function $o(o,e){if(o.ownerDocument)try{let i=o.toDataURL();if(i!=="data:,")return He(i,o.ownerDocument)}catch(i){e.log.warn("Failed to clone canvas",i)}let t=o.cloneNode(!1),n=o.getContext("2d"),r=t.getContext("2d");try{return n&&r&&r.putImageData(n.getImageData(0,0,o.width,o.height),0,0),t}catch(i){e.log.warn("Failed to clone canvas",i)}return t}function Vs(o,e){try{if(o?.contentDocument?.documentElement)return mn(o.contentDocument.documentElement,e)}catch(t){e.log.warn("Failed to clone iframe",t)}return o.cloneNode(!1)}function Ys(o){let e=o.cloneNode(!1);return o.currentSrc&&o.currentSrc!==o.src&&(e.src=o.currentSrc,e.srcset=""),e.loading==="lazy"&&(e.loading="eager"),e}async function Js(o,e){if(o.ownerDocument&&!o.currentSrc&&o.poster)return He(o.poster,o.ownerDocument);let t=o.cloneNode(!1);t.crossOrigin="anonymous",o.currentSrc&&o.currentSrc!==o.src&&(t.src=o.currentSrc);let n=t.ownerDocument;if(n){let r=!0;if(await Ke(t,{onError:()=>r=!1,onWarn:e.log.warn}),!r)return o.poster?He(o.poster,o.ownerDocument):t;t.currentTime=o.currentTime,await new Promise(s=>{t.addEventListener("seeked",s,{once:!0})});let i=n.createElement("canvas");i.width=o.offsetWidth,i.height=o.offsetHeight;try{let s=i.getContext("2d");s&&s.drawImage(t,0,0,i.width,i.height)}catch(s){return e.log.warn("Failed to clone video",s),o.poster?He(o.poster,o.ownerDocument):t}return $o(i,e)}return t}function Zs(o,e){return Rs(o)?$o(o,e):Os(o)?Vs(o,e):Ie(o)?Ys(o):At(o)?Js(o,e):o.cloneNode(!1)}function Qs(o){let e=o.sandbox;if(!e){let{ownerDocument:t}=o;try{t&&(e=t.createElement("iframe"),e.id=`__SANDBOX__${Oo()}`,e.width="0",e.height="0",e.style.visibility="hidden",e.style.position="fixed",t.body.appendChild(e),e.srcdoc='<!DOCTYPE html><meta charset="UTF-8"><title></title><body>',o.sandbox=e)}catch(n){o.log.warn("Failed to getSandBox",n)}}return e}var ea=["width","height","-webkit-text-fill-color"],ta=["stroke","fill"];function Wo(o,e,t){let{defaultComputedStyles:n}=t,r=o.nodeName.toLowerCase(),i=Ve(o)&&r!=="svg",s=i?ta.map(m=>[m,o.getAttribute(m)]).filter(([,m])=>m!==null):[],a=[i&&"svg",r,s.map((m,f)=>`${m}=${f}`).join(","),e].filter(Boolean).join(":");if(n.has(a))return n.get(a);let c=Qs(t)?.contentWindow;if(!c)return new Map;let d=c?.document,u,p;i?(u=d.createElementNS(Lt,"svg"),p=u.ownerDocument.createElementNS(u.namespaceURI,r),s.forEach(([m,f])=>{p.setAttributeNS(null,m,f)}),u.appendChild(p)):u=p=d.createElement(r),p.textContent=" ",d.body.appendChild(u);let h=c.getComputedStyle(p,e),g=new Map;for(let m=h.length,f=0;f<m;f++){let v=h.item(f);ea.includes(v)||g.set(v,h.getPropertyValue(v))}return d.body.removeChild(u),n.set(a,g),g}function Uo(o,e,t){let n=new Map,r=[],i=new Map;if(t)for(let a of t)s(a);else for(let a=o.length,l=0;l<a;l++){let c=o.item(l);s(c)}for(let a=r.length,l=0;l<a;l++)i.get(r[l])?.forEach((c,d)=>n.set(d,c));function s(a){let l=o.getPropertyValue(a),c=o.getPropertyPriority(a),d=a.lastIndexOf("-"),u=d>-1?a.substring(0,d):void 0;if(u){let p=i.get(u);p||(p=new Map,i.set(u,p)),p.set(a,[l,c])}e.get(a)===l&&!c||(u?r.push(u):n.set(a,[l,c]))}return n}function na(o,e,t,n){let{ownerWindow:r,includeStyleProperties:i,currentParentNodeStyle:s}=n,a=e.style,l=r.getComputedStyle(o),c=Wo(o,null,n);s?.forEach((u,p)=>{c.delete(p)});let d=Uo(l,c,i);d.delete("transition-property"),d.delete("all"),d.delete("d"),d.delete("content"),t&&(d.delete("position"),d.delete("margin-top"),d.delete("margin-right"),d.delete("margin-bottom"),d.delete("margin-left"),d.delete("margin-block-start"),d.delete("margin-block-end"),d.delete("margin-inline-start"),d.delete("margin-inline-end"),d.set("box-sizing",["border-box",""])),d.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text"),Ho&&(d.has("font-kerning")||d.set("font-kerning",["normal",""]),(d.get("overflow-x")?.[0]==="hidden"||d.get("overflow-y")?.[0]==="hidden")&&d.get("text-overflow")?.[0]==="ellipsis"&&o.scrollWidth===o.clientWidth&&d.set("text-overflow",["clip",""]));for(let u=a.length,p=0;p<u;p++)a.removeProperty(a.item(p));return d.forEach(([u,p],h)=>{a.setProperty(h,u,p)}),d}function oa(o,e){(Ls(o)||Ns(o)||Is(o))&&e.setAttribute("value",o.value)}var ra=["::before","::after"],ia=["::-webkit-scrollbar","::-webkit-scrollbar-button","::-webkit-scrollbar-thumb","::-webkit-scrollbar-track","::-webkit-scrollbar-track-piece","::-webkit-scrollbar-corner","::-webkit-resizer"];function sa(o,e,t,n,r){let{ownerWindow:i,svgStyleElement:s,svgStyles:a,currentNodeStyle:l}=n;if(!s||!i)return;function c(d){let u=i.getComputedStyle(o,d),p=u.getPropertyValue("content");if(!p||p==="none")return;r?.(p),p=p.replace(/(')|(")|(counter\(.+\))/g,"");let h=[Oo()],g=Wo(o,d,n);l?.forEach((E,T)=>{g.delete(T)});let m=Uo(u,g,n.includeStyleProperties);m.delete("content"),m.delete("-webkit-locale"),m.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text");let f=[`content: '${p}';`];if(m.forEach(([E,T],R)=>{f.push(`${R}: ${E}${T?" !important":""};`)}),f.length===1)return;try{e.className=[e.className,...h].join(" ")}catch(E){n.log.warn("Failed to copyPseudoClass",E);return}let v=f.join(`
  `),w=a.get(v);w||(w=[],a.set(v,w)),w.push(`.${h[0]}${d}`)}ra.forEach(c),t&&ia.forEach(c)}var Co=new Set(["symbol"]);async function Ao(o,e,t,n,r){if(se(t)&&(Ps(t)||Hs(t))||n.filter&&!n.filter(t))return;Co.has(e.nodeName)||Co.has(t.nodeName)?n.currentParentNodeStyle=void 0:n.currentParentNodeStyle=n.currentNodeStyle;let i=await mn(t,n,!1,r);n.isEnable("restoreScrollPosition")&&aa(o,i),e.appendChild(i)}async function Ro(o,e,t,n){let r=o.firstChild;se(o)&&o.shadowRoot&&(r=o.shadowRoot?.firstChild,t.shadowRoots.push(o.shadowRoot));for(let i=r;i;i=i.nextSibling)if(!Cs(i))if(se(i)&&Ds(i)&&typeof i.assignedNodes=="function"){let s=i.assignedNodes();for(let a=0;a<s.length;a++)await Ao(o,e,s[a],t,n)}else await Ao(o,e,i,t,n)}function aa(o,e){if(!Ge(o)||!Ge(e))return;let{scrollTop:t,scrollLeft:n}=o;if(!t&&!n)return;let{transform:r}=e.style,i=new DOMMatrix(r),{a:s,b:a,c:l,d:c}=i;i.a=1,i.b=0,i.c=0,i.d=1,i.translateSelf(-n,-t),i.a=s,i.b=a,i.c=l,i.d=c,e.style.transform=i.toString()}function la(o,e){let{backgroundColor:t,width:n,height:r,style:i}=e,s=o.style;if(t&&s.setProperty("background-color",t,"important"),n&&s.setProperty("width",`${n}px`,"important"),r&&s.setProperty("height",`${r}px`,"important"),i)for(let a in i)s[a]=i[a]}var ca=/^[\w-:]+$/;async function mn(o,e,t=!1,n){let{ownerDocument:r,ownerWindow:i,fontFamilies:s,onCloneEachNode:a}=e;if(r&&As(o))return n&&/\S/.test(o.data)&&n(o.data),r.createTextNode(o.data);if(r&&i&&se(o)&&(Ge(o)||Ve(o))){let c=await Zs(o,e);if(e.isEnable("removeAbnormalAttributes")){let m=c.getAttributeNames();for(let f=m.length,v=0;v<f;v++){let w=m[v];ca.test(w)||c.removeAttribute(w)}}let d=e.currentNodeStyle=na(o,c,t,e);t&&la(c,e);let u=!1;if(e.isEnable("copyScrollbar")){let m=[d.get("overflow-x")?.[0],d.get("overflow-y")?.[0]];u=m.includes("scroll")||(m.includes("auto")||m.includes("overlay"))&&(o.scrollHeight>o.clientHeight||o.scrollWidth>o.clientWidth)}let p=d.get("text-transform")?.[0],h=_o(d.get("font-family")?.[0]),g=h?m=>{p==="uppercase"?m=m.toUpperCase():p==="lowercase"?m=m.toLowerCase():p==="capitalize"&&(m=m[0].toUpperCase()+m.substring(1)),h.forEach(f=>{let v=s.get(f);v||s.set(f,v=new Set),m.split("").forEach(w=>v.add(w))})}:void 0;return sa(o,c,u,e,g),oa(o,c),At(o)||await Ro(o,c,e,g),await a?.(c),c}let l=o.cloneNode(!1);return await Ro(o,l,e),await a?.(l),l}function da(o){if(o.ownerDocument=void 0,o.ownerWindow=void 0,o.svgStyleElement=void 0,o.svgDefsElement=void 0,o.svgStyles.clear(),o.defaultComputedStyles.clear(),o.sandbox){try{o.sandbox.remove()}catch(e){o.log.warn("Failed to destroyContext",e)}o.sandbox=void 0}o.workers=[],o.fontFamilies.clear(),o.fontCssTexts.clear(),o.requests.clear(),o.tasks=[],o.shadowRoots=[]}function ua(o){let{url:e,timeout:t,responseType:n,...r}=o,i=new AbortController,s=t?setTimeout(()=>i.abort(),t):void 0;return fetch(e,{signal:i.signal,...r}).then(a=>{if(!a.ok)throw new Error("Failed fetch, not 2xx response",{cause:a});switch(n){case"arrayBuffer":return a.arrayBuffer();case"dataUrl":return a.blob().then(Us);case"text":default:return a.text()}}).finally(()=>clearTimeout(s))}function Xe(o,e){let{url:t,requestType:n="text",responseType:r="text",imageDom:i}=e,s=t,{timeout:a,acceptOfImage:l,requests:c,fetchFn:d,fetch:{requestInit:u,bypassingCache:p,placeholderImage:h},font:g,workers:m,fontFamilies:f}=o;n==="image"&&(Ct||pn)&&o.drawImageCount++;let v=c.get(t);if(!v){p&&p instanceof RegExp&&p.test(s)&&(s+=(/\?/.test(s)?"&":"?")+new Date().getTime());let w=n.startsWith("font")&&g&&g.minify,E=new Set;w&&n.split(";")[1].split(",").forEach(_=>{f.has(_)&&f.get(_).forEach(W=>E.add(W))});let T=w&&E.size,R={url:s,timeout:a,responseType:T?"arrayBuffer":r,headers:n==="image"?{accept:l}:void 0,...u};v={type:n,resolve:void 0,reject:void 0,response:null},v.response=(async()=>{if(d&&n==="image"){let D=await d(t);if(D)return D}return!Ct&&t.startsWith("http")&&m.length?new Promise((D,_)=>{m[c.size&m.length-1].postMessage({rawUrl:t,...R}),v.resolve=D,v.reject=_}):ua(R)})().catch(D=>{if(c.delete(t),n==="image"&&h)return o.log.warn("Failed to fetch image base64, trying to use placeholder image",s),typeof h=="string"?h:h(i);throw D}),c.set(t,v)}return v.response}async function qo(o,e,t,n){if(!jo(o))return o;for(let[r,i]of pa(o,e))try{let s=await Xe(t,{url:i,requestType:n?"image":"text",responseType:"dataUrl"});o=o.replace(ha(r),`$1${s}$3`)}catch(s){t.log.warn("Failed to fetch css data url",r,s)}return o}function jo(o){return/url\((['"]?)([^'"]+?)\1\)/.test(o)}var zo=/url\((['"]?)([^'"]+?)\1\)/g;function pa(o,e){let t=[];return o.replace(zo,(n,r,i)=>(t.push([i,Do(i,e)]),n)),t.filter(([n])=>!cn(n))}function ha(o){let e=o.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1");return new RegExp(`(url\\(['"]?)(${e})(['"]?\\))`,"g")}var ma=["background-image","border-image-source","-webkit-border-image","-webkit-mask-image","list-style-image"];function fa(o,e){return ma.map(t=>{let n=o.getPropertyValue(t);return!n||n==="none"?null:((Ct||pn)&&e.drawImageCount++,qo(n,null,e,!0).then(r=>{!r||n===r||o.setProperty(t,r,o.getPropertyPriority(t))}))}).filter(Boolean)}function ga(o,e){if(Ie(o)){let t=o.currentSrc||o.src;if(!cn(t))return[Xe(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.srcset="",o.dataset.originalSrc=t,o.src=n||"")})];(Ct||pn)&&e.drawImageCount++}else if(Ve(o)&&!cn(o.href.baseVal)){let t=o.href.baseVal;return[Xe(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.dataset.originalSrc=t,o.href.baseVal=n||"")})]}return[]}function ba(o,e){let{ownerDocument:t,svgDefsElement:n}=e,r=o.getAttribute("href")??o.getAttribute("xlink:href");if(!r)return[];let[i,s]=r.split("#");if(s){let a=`#${s}`,l=e.shadowRoots.reduce((c,d)=>c??d.querySelector(`svg ${a}`),t?.querySelector(`svg ${a}`));if(i&&o.setAttribute("href",a),n?.querySelector(a))return[];if(l)return n?.appendChild(l.cloneNode(!0)),[];if(i)return[Xe(e,{url:i,responseType:"text"}).then(c=>{n?.insertAdjacentHTML("beforeend",c)})]}return[]}function Go(o,e){let{tasks:t}=e;se(o)&&((Ie(o)||Io(o))&&t.push(...ga(o,e)),Ms(o)&&t.push(...ba(o,e))),Ge(o)&&t.push(...fa(o.style,e)),o.childNodes.forEach(n=>{Go(n,e)})}async function ya(o,e){let{ownerDocument:t,svgStyleElement:n,fontFamilies:r,fontCssTexts:i,tasks:s,font:a}=e;if(!(!t||!n||!r.size))if(a&&a.cssText){let l=No(a.cssText,e);n.appendChild(t.createTextNode(`${l}
`))}else{let l=Array.from(t.styleSheets).filter(h=>{try{return"cssRules"in h&&!!h.cssRules.length}catch(g){return e.log.warn(`Error while reading CSS rules from ${h.href}`,g),!1}}),c=t.implementation.createHTMLDocument(""),d=c.createElement("style");c.head.appendChild(d);let u=d.sheet;await Promise.all(l.flatMap(h=>Array.from(h.cssRules).map(async g=>{if(Ts(g)){let m=g.href,f="";try{f=await Xe(e,{url:m,requestType:"text",responseType:"text"})}catch(w){e.log.warn(`Error fetch remote css import from ${m}`,w)}let v=f.replace(zo,(w,E,T)=>w.replace(T,Do(T,m)));for(let w of wa(v))try{u.insertRule(w,u.cssRules.length)}catch(E){e.log.warn("Error inserting rule from remote css import",{rule:w,error:E})}}}))),u.cssRules.length&&l.push(u);let p=[];l.forEach(h=>{dn(h.cssRules,p)}),p.filter(h=>Ss(h)&&jo(h.style.getPropertyValue("src"))&&_o(h.style.getPropertyValue("font-family"))?.some(g=>r.has(g))).forEach(h=>{let g=h,m=i.get(g.cssText);m?n.appendChild(t.createTextNode(`${m}
`)):s.push(qo(g.cssText,g.parentStyleSheet?g.parentStyleSheet.href:null,e).then(f=>{f=No(f,e),i.set(g.cssText,f),n.appendChild(t.createTextNode(`${f}
`))}))})}}var va=/(\/\*[\s\S]*?\*\/)/g,Lo=/((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;function wa(o){if(o==null)return[];let e=[],t=o.replace(va,"");for(;;){let i=Lo.exec(t);if(!i)break;e.push(i[0])}t=t.replace(Lo,"");let n=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,r=new RegExp("((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})","gi");for(;;){let i=n.exec(t);if(i)r.lastIndex=n.lastIndex;else if(i=r.exec(t),i)n.lastIndex=r.lastIndex;else break;e.push(i[0])}return e}var xa=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,Ea=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function No(o,e){let{font:t}=e,n=t?t?.preferredFormat:void 0;return n?o.replace(Ea,r=>{for(;;){let[i,,s]=xa.exec(r)||[];if(!s)return"";if(s===n)return`src: ${i};`}}):o}function dn(o,e=[]){for(let t of Array.from(o))ks(t)?e.push(...dn(t.cssRules)):"cssRules"in t?dn(t.cssRules,e):e.push(t);return e}var Sa=/\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;function Ta(o){return Sa.test(o.innerHTML)}async function ka(o,e){let t=await Bo(o,e);if(se(t.node)&&Ve(t.node)&&!Ta(t.node))return t.node;let{ownerDocument:n,log:r,tasks:i,svgStyleElement:s,svgDefsElement:a,svgStyles:l,font:c,progress:d,autoDestruct:u,onCloneNode:p,onEmbedNode:h,onCreateForeignObjectSvg:g}=t;r.time("clone node");let m=await mn(t.node,t,!0);if(s&&n){let T="";l.forEach((R,D)=>{T+=`${R.join(`,
`)} {
  ${D}
}
`}),s.appendChild(n.createTextNode(T))}r.timeEnd("clone node"),await p?.(m),c!==!1&&se(m)&&(r.time("embed web font"),await ya(m,t),r.timeEnd("embed web font")),r.time("embed node"),Go(m,t);let f=i.length,v=0,w=async()=>{for(;;){let T=i.pop();if(!T)break;try{await T}catch(R){t.log.warn("Failed to run task",R)}d?.(++v,f)}};d?.(v,f),await Promise.all([...Array.from({length:4})].map(w)),r.timeEnd("embed node"),await h?.(m);let E=Ma(m,t);return a&&E.insertBefore(a,E.children[0]),s&&E.insertBefore(s,E.children[0]),u&&da(t),await g?.(E),E}function Ma(o,e){let{width:t,height:n}=e,r=Fs(t,n,o.ownerDocument),i=r.ownerDocument.createElementNS(r.namespaceURI,"foreignObject");return i.setAttributeNS(null,"x","0%"),i.setAttributeNS(null,"y","0%"),i.setAttributeNS(null,"width","100%"),i.setAttributeNS(null,"height","100%"),i.append(o),r.appendChild(i),r}async function Ko(o,e){let t=await Bo(o,e),n=await ka(t),r=$s(n,t.isEnable("removeControlCharacter"));t.autoDestruct||(t.svgStyleElement=Fo(t.ownerDocument),t.svgDefsElement=t.ownerDocument?.createElementNS(Lt,"defs"),t.svgStyles.clear());let i=He(r,n.ownerDocument);return await Ks(i,t)}var Xo=3e4;async function Vo(o){return o.startsWith("data:")?o:await N({type:"asset:fetch",url:o}).catch(()=>null)??!1}async function Yo(o,e,t){if(e.height*t>Xo||e.width*t>Xo)throw new Error("too large");let n=gn(o),r=await hn(document.createElement("div"),{scale:t,backgroundColor:n,width:e.width,height:e.height,style:{width:`${o.offsetWidth}px`,height:`${o.scrollHeight}px`,maxHeight:"none",counterReset:Aa(o),overflow:"visible",margin:"0",transformOrigin:"0 0",transform:`translate(${-e.left}px, ${-e.top}px)`},fetchFn:Vo,timeout:15e3,filter:Ca(o,e),autoDestruct:!0,includeStyleProperties:La(o),features:{fixSvgXmlDecode:!1}});r.node=o;let i=new fn(o.ownerDocument.defaultView??window);r.ownerWindow=i.view,r.onCreateForeignObjectSvg=l=>i.restore(l);let s=await Ko(r),a=s.getContext("2d");if(!a)throw new Error("no canvas");if(Na(a,s))throw new Error("blank");return s}function Ca(o,e){let t=new WeakSet,n,r=o.ownerDocument.defaultView??window,i=o.getBoundingClientRect(),s=o!==o.ownerDocument.body,a=s?o.scrollTop:0,l=s?o.scrollLeft:0,c=e.top,d=e.top+e.height,u=e.left,p=e.left+e.width;return h=>{let g=h.parentNode;if(g&&t.has(g))return!1;if(h.nodeType!==Node.ELEMENT_NODE)return!0;let m=h,f=r.getComputedStyle(m).display;if(f==="none")return!1;if(f.startsWith("inline")||f==="contents"||f.startsWith("table-"))return!0;let v=m.getBoundingClientRect(),w=v.top-i.top+a,E=v.left-i.left+l;return(w+v.height<c||w>d||E+v.width<u||E>p)&&(w>d||!(n??=Ra(o,r)).has(m))&&t.add(m),!0}}function Aa(o){let e=o.ownerDocument.defaultView??window,t=[];for(let n=o;n;n=n.parentElement){let r=e.getComputedStyle(n).counterReset;r&&r!=="none"&&t.unshift(r)}return t.join(" ")||"none"}function Ra(o,e){let t=(r,i)=>{let s=e.getComputedStyle(r,i);return s.counterIncrement!=="none"||s.counterReset!=="none"||s.counterSet!=="none"},n=new WeakSet;for(let r of Array.from(o.querySelectorAll("*")))if(!(!t(r)&&!t(r,"::before")&&!t(r,"::after")))for(let i=r;i&&i!==o&&!n.has(i);i=i.parentElement)n.add(i);return n}var fn=class{kept=[];view;constructor(e){let t=(n,r)=>{let i=e.getComputedStyle(n,r);if(!r||!i.content.includes("counter"))return i;let s=this.keep(i.content);return new Proxy(i,{get:(a,l)=>{if(l==="getPropertyValue")return d=>d==="content"?s:a.getPropertyValue(d);let c=Reflect.get(a,l,a);return typeof c=="function"?c.bind(a):c}})};this.view={getComputedStyle:t}}keep(e){return this.kept.push(e),`YLKEPT${this.kept.length-1}X`}async restore(e){let t=e.querySelector("style");if(!t?.textContent)return;let n=t.textContent.replace(/content: 'YLKEPT(\d+)X';/g,(i,s)=>`content: ${this.kept[Number(s)]};`),r=new Set(Array.from(n.matchAll(/url\("(https?:[^"]+)"\)/g),i=>i[1]));await Promise.all(Array.from(r,async i=>{let s=await Vo(i);s&&(n=n.split(i).join(s))})),t.textContent=n}};function gn(o){let e=o.ownerDocument.defaultView??window;for(let t=o;t;t=t.parentElement){let n=e.getComputedStyle(t).backgroundColor;if(n&&n!=="transparent"&&!/rgba(.*, 0)$/.test(n))return n}return"#ffffff"}function La(o){let e=(o.ownerDocument.defaultView??window).getComputedStyle(o),t=[];for(let n=0;n<e.length;n++){let r=e.item(n);!r.startsWith("--")&&!/^(animation|transition|view-timeline|scroll-timeline|animation-timeline)/.test(r)&&t.push(r)}return t}function Na(o,e){let t=Math.max(1,Math.floor(e.height/400)),{data:n}=o.getImageData(0,0,e.width,e.height),[r,i,s]=[n[0],n[1],n[2]];for(let a=0;a<e.height;a+=t)for(let l=0;l<e.width;l+=3){let c=(a*e.width+l)*4;if(n[c]!==r||n[c+1]!==i||n[c+2]!==s)return!1}return!0}var ne={margin:12,line:1.5,radius:12,top:18,foot:38};function Jo(o,e,t,n){let r=(ne.margin+ne.line)*n,i=document.createElement("canvas");i.width=o.width+Math.round(r*2),i.height=o.height+Math.round(r*2+(ne.top+ne.foot)*n);let s=i.getContext("2d");if(!s)throw new Error("no canvas");let{width:a,height:l}=i;s.fillStyle="#ffffff",s.fillRect(0,0,a,l),s.fillStyle=e,s.fillRect(0,0,a,l);let[c=255,d=255,u=255]=s.getImageData(0,0,1,1).data,p=.299*c+.587*d+.114*u<128;return s.save(),s.beginPath(),s.roundRect(r,r,a-r*2,l-r*2,ne.radius*n),s.clip(),s.drawImage(o,Math.round(r),Math.round(r+ne.top*n)),s.restore(),s.fillStyle=p?"#9aa3ae":"#7c828b",s.font=`${12*n}px -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif`,s.textAlign="center",s.textBaseline="middle",s.fillText(t,a/2,l-r-ne.foot/2*n),Pa(s,a,l,n),i}function Pa(o,e,t,n){let r=(ne.margin+ne.line/2)*n,i=(ne.radius+ne.line/2)*n,s={x:e-r,y:t-r},a=e/2,l=[],c=r+i,d=s.y-i;l.push([0,0,e,c,r,0,s.x,0],[a,c,a,d-c,0,c,0,d],[0,d,e,t-d,s.x,0,r,0],[0,c,a,d-c,0,d,0,c]);for(let[u,p,h,g,m,f,v,w]of l){let E=o.createLinearGradient(m,f,v,w);for(let[T,R]of qe)E.addColorStop(Number(T),R);o.save(),o.beginPath(),o.rect(u,p,h,g),o.clip(),o.beginPath(),o.roundRect(r,r,s.x-r,s.y-r,i),o.lineWidth=ne.line*n,o.strokeStyle=E,o.stroke(),o.restore()}}function Zo(o){let e=new Set;for(let t of o.matchAll(/<x(\d+)>/g))e.add(Number(t[1]));return e}var Qo=o=>we(ie(o)).trim();async function er(o,e,t){let r=(await N({type:"translate",items:o.map(i=>i.markup),from:e,to:t}))?.results;return!r||r.length!==o.length?o.map(()=>({ok:!1,code:"network"})):(e||await Promise.all(r.map(async(i,s)=>{let a=o[s];if(!i.ok||!St(i,a.hint,t))return;let c=(await N({type:"translate",items:[a.markup],from:a.hint,to:t}))?.results?.[0];c?.ok&&c.text.trim()&&Qo(c.text)!==Qo(a.markup)&&(r[s]=c)})),r)}var Ha=200,Ia=700,Da=8,Oa=120,_a=20,Ba=2,Fa=360,tr=180,Ye=16,nr=18,bn=39,$a=36,Nt=8,Wa=.25,Ua=24,qa=260,ja=170,za=120,Ga=560,Ka=80,Xa=3e4,Va=60,Ya='img,svg,picture,hr,video,canvas,button,input,select,textarea,yl-r,[role="button"],[role="img"]';function Ja(){return new Promise(o=>{let e=setTimeout(o,120);requestAnimationFrame(()=>requestAnimationFrame(()=>{clearTimeout(e),o()}))})}function or(o){return new Promise((e,t)=>o.toBlob(n=>n?e(n):t(new Error("no image")),"image/png"))}function Za(o){let e=atob(o.slice(o.indexOf(",")+1)),t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return new Blob([t],{type:"image/png"})}function rr(o){let e=o[0],t=o[o.length-1];if(!e||!t||!e.isConnected||!t.isConnected)return null;let n=document.createRange();return n.setStartBefore(e),n.setEndAfter(t),n.getBoundingClientRect()}function Pt(o){return getComputedStyle(o).visibility==="visible"}function Ht(o,e){let t=[],n=!1;for(let r=o;r;r=r.parentElement){let i=e.get(r);if(i!==void 0){n=i;break}t.push(r);let s=getComputedStyle(r).position;if(s==="fixed"||s==="sticky"){n=!0;break}}for(let r of t)e.set(r,n);return n}var It=class{constructor(e,t,n){this.ui=e;this.settings=t;this.pageTranslated=n}rect;scroller=null;band={top:0,bottom:0};box;card;body;bar;labels=[];mirror;scanner=new Le;entries=[];byCopy=new WeakMap;seenNodes=new WeakSet;seenText=new Map;queue=[];inFlight=0;scanTimer;flushTimer;scanning=!1;rescan=!1;frame=0;backdrop;view;findInput;findCount;closeTimer;exporting=!1;restoreCard;observer;session=0;get running(){return this.rect!==void 0}start(e){this.stop(),this.session++,this.rect=e,this.scanner.classifier.setExcludes(this.settings().excludeSelectors);let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scroller=t?this.findScroller(t):null,this.band={top:this.toContent(e.top),bottom:this.toContent(e.bottom)},this.box=this.ui.addFrame(),Object.assign(this.box.style,{left:`${G(e.left)}px`,top:`${G(e.top)}px`,width:`${G(e.right-e.left)}px`,height:`${G(e.bottom-e.top)}px`}),this.buildBar(e),this.buildCard(e),addEventListener("scroll",this.onScroll,!0),addEventListener("resize",this.syncView),addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutation),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0}),this.scan()}stop(){this.session++,removeEventListener("scroll",this.onScroll,!0),removeEventListener("resize",this.syncView),removeEventListener("keydown",this.onKey,!0),this.observer?.disconnect(),this.observer=void 0,clearTimeout(this.scanTimer),clearTimeout(this.flushTimer),cancelAnimationFrame(this.frame),this.scanTimer=this.flushTimer=void 0,this.frame=0,clearTimeout(this.closeTimer),this.closeTimer=void 0,this.exporting=!1,this.view=this.findInput=this.findCount=void 0,this.mirror?.destroy(),this.mirror=void 0;for(let e of this.entries)e.segment?.unrender();this.box?.remove(),this.ui.dismiss(this.bar),this.ui.dismiss(this.card),this.box=this.bar=this.card=this.body=void 0,this.labels=[],this.rect=void 0,this.scroller=null,this.entries=[],this.byCopy=new WeakMap,this.queue=[],this.seenNodes=new WeakSet,this.seenText.clear(),this.inFlight=0,this.scanning=!1,this.rescan=!1,this.backdrop?.remove(),this.backdrop=void 0,this.restoreCard=void 0}findScroller(e){for(let t=e;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t).overflowY;if((n==="auto"||n==="scroll")&&t.scrollHeight>t.clientHeight+1)return t}return null}get origin(){return this.scroller?this.scroller.getBoundingClientRect().top+this.scroller.clientTop:0}get scrollPos(){return this.scroller?this.scroller.scrollTop:scrollY}atScrollEnd(){let e=this.scroller;if(e)return e.scrollTop+e.clientHeight>=e.scrollHeight-2;let t=document.documentElement;return scrollY+innerHeight>=t.scrollHeight-2}toContent(e){return e-this.origin+this.scrollPos}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.exporting?this.exporting=!1:this.findInput?.value?this.clearFind():this.restoreCard?this.exitImmersive():this.stop())};enterImmersive(){let e=this.card,t=this.view;if(!e||!t||this.restoreCard)return;let n=e.getBoundingClientRect();this.restoreCard={left:e.style.left,top:e.style.top,bottom:e.style.bottom,height:e.style.height};let r=this.ui.addBelow(y("div","scan-backdrop"),e);r.addEventListener("click",()=>this.exitImmersive()),r.addEventListener("wheel",a=>a.preventDefault(),{passive:!1}),this.backdrop=r,e.removeAttribute("data-hidden"),this.mirror?.hidePinned(),this.placeFrame();let i=innerHeight-Ua*2,s=Math.min(i,Math.max(qa,t.contentHeight+bn));t.start(s-bn,this.mirror?.scrollerTop??0),e.style.top=`${n.top}px`,e.style.bottom="auto",e.style.left=`${n.left}px`,e.style.height=`${n.height}px`,e.offsetHeight,e.classList.add("scan-animate","scan-immersive"),e.style.top=`${Math.round((innerHeight-s)/2)}px`,e.style.left=`${Math.round((innerWidth-n.width)/2)}px`,e.style.height=`${s}px`}exitImmersive(){let e=this.card;!e||!this.restoreCard||this.closeTimer!==void 0||(this.ui.dismiss(this.backdrop),this.backdrop=void 0,e.classList.add("scan-closing"),this.closeTimer=setTimeout(()=>{this.closeTimer=void 0;let t=this.restoreCard;this.restoreCard=void 0,this.clearFind(),this.view?.stop(),e.classList.remove("scan-immersive","scan-animate","scan-closing"),e.setAttribute("data-hidden",""),t&&Object.assign(e.style,t),this.placeFrame(),this.requestSync()},ja))}clearFind(){this.findInput&&(this.findInput.value=""),this.view?.clearFind(),this.paintFind(0,0,!1)}paintFind(e,t,n){this.findCount&&(this.findCount.textContent=t?`${e}/${t}`:n?"0/0":"");let r=this.findInput?.parentElement;r?.toggleAttribute("data-none",n),r?.toggleAttribute("data-found",t>0),r?.toggleAttribute("data-typed",t>0||n)}buildFind(){let e=y("div","scan-find"),t=y("input","scan-find-input");t.type="text",t.placeholder=b("findPlaceholder"),t.spellcheck=!1;let n=y("span","scan-find-count","");e.addEventListener("click",()=>t.focus({preventScroll:!0})),this.findInput=t,this.findCount=n;let r=0,i,s=c=>{r&&this.paintFind(this.view?.step(c)??0,r,!1)};t.addEventListener("input",()=>{clearTimeout(i),i=setTimeout(()=>{r=this.view?.find(t.value)??0,this.paintFind(r?1:0,r,!r&&!!t.value.trim())},za)}),t.addEventListener("keydown",c=>{c.stopPropagation(),c.key==="Enter"&&(c.preventDefault(),s(c.shiftKey?-1:1))});for(let c of["keyup","keypress"])t.addEventListener(c,d=>d.stopPropagation());let a=K("up",b("findPrevious"),()=>s(-1)),l=K("down",b("findNext"),()=>s(1));for(let c of[a,l])c.addEventListener("mousedown",d=>d.preventDefault());return e.append(ce("search"),t,n,a,l),e}onScroll=e=>{if(this.ui.ownsEvent(e))return;if(this.scroller&&e.target!==this.scroller){this.requestSync();return}let t=this.rect;if(!t)return;let n=this.toContent(t.top),r=this.toContent(t.bottom),i=n<this.band.top||r>this.band.bottom;this.band.top=Math.min(this.band.top,n),this.band.bottom=Math.max(this.band.bottom,r);let s=this.atScrollEnd()&&this.band.bottom!==1/0;s&&(this.band.bottom=1/0),(i||s)&&this.scheduleScan(Ha),this.requestSync()};onMutation=()=>this.scheduleScan(Ia);scheduleScan(e){this.scanTimer===void 0&&(this.scanTimer=setTimeout(()=>{this.scanTimer=void 0,this.scan()},e))}isCovered(e){let t=this.rect;if(!t||!e.width||!e.height)return!1;let n=Math.min(e.right,t.right)-Math.max(e.left,t.left),r=t.right-t.left;if(n<e.width*.5&&n<r*.6)return!1;let i=this.toContent(e.top),s=this.toContent(e.bottom);return Math.min(s,this.band.bottom)-Math.max(i,this.band.top)>=(s-i)*.5}async scan(){if(!this.rect)return;if(this.scanning){this.rescan=!0;return}this.scanning=!0;let e=this.session;this.scanner.reset();let t=new Map,n=this.settings().targetLang,r=this.scroller??document.body;if(r){let i={consume:()=>!1,shadowRoot:()=>{},emit:a=>this.considerRun(a,n,t),skipped:a=>this.considerSkipped(a,t),plain:(a,l)=>this.considerPlain(a,l,t)},s=performance.now();for(let a of this.scanner.scan(r,i))if(performance.now()-s>Da){if(await new Promise(l=>setTimeout(l,0)),e!==this.session)return;s=performance.now()}this.revealLeaves(r,t)}this.scanning=!1,this.requestSync(),this.rescan&&(this.rescan=!1,this.scan())}revealLeaves(e,t){for(let n of Array.from(e.querySelectorAll(Ya)))this.seenNodes.has(n)||Ht(n,t)||!Pt(n)||this.isCovered(n.getBoundingClientRect())&&(this.seenNodes.add(n),this.mirror?.showWhole(n))}alreadyHave(e,t,n){return this.seenNodes.has(e)?!0:!!this.seenText.get(t)?.some(r=>Math.abs(r-n)<Va)}remember(e,t,n){this.seenNodes.add(e);let r=this.seenText.get(t);r?r.push(n):this.seenText.set(t,[n])}considerRun(e,t,n){let r=e.nodes[0];if(this.seenNodes.has(r))return;let i=new Ne(e),s=i.parentElement;if(Ht(s,n)||!Pt(s))return;let a=rr(e.nodes);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,e.markup,l))return;this.remember(r,e.markup,l);let c=je(e.text,t),d=this.mirror?.showRun(e.nodes,!c);if(!d)return;let u=this.addEntry("text",a,d);u.segment=i,c?this.setState(u,"kept"):(this.queue.push(u),this.scheduleFlush())}considerSkipped(e,t){if(this.seenNodes.has(e)||Ht(e,t)||!Pt(e))return;let n=e.getBoundingClientRect();if(!this.isCovered(n))return;let r=e.textContent??"",i=oo(e)&&!!r.trim(),s=this.toContent(n.top);if(i&&this.alreadyHave(e,r,s))return;i?this.remember(e,r,s):this.seenNodes.add(e);let a=this.mirror?.showWhole(e);if(!a||!i)return;let l=this.addEntry("code",n,a);this.setState(l,"kept")}considerPlain(e,t,n){let r=e[0];if(!r||this.seenNodes.has(r))return;let i=e.map(u=>u.textContent??"").join("").trim();if(!i)return;let s=t.nodeType===Node.ELEMENT_NODE?t:t.host;if(Ht(s,n)||!Pt(s))return;let a=rr(e);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,i,l))return;this.remember(r,i,l);let c=this.mirror?.showRun(e,!1);if(!c)return;let d=this.addEntry("verbatim",a,c);this.setState(d,"kept")}addEntry(e,t,n){let r={kind:e,state:"pending",top:this.toContent(t.top),bottom:this.toContent(t.bottom),left:t.left,right:t.right,copy:n};this.byCopy.set(n,r);let i=this.entries.length;for(;i>0;){let s=this.entries[i-1];if(s.top<r.top||s.top===r.top&&s.left<=r.left)break;i--}return this.entries.splice(i,0,r),this.updateLabel(),r}setState(e,t){e.state=t,this.updateLabel()}buildBar(e){let t=y("div","scan-bar"),n=y("span","grow","");this.labels.push(n),t.append(n,K("expand",b("immersive"),()=>this.enterImmersive()),this.copyButton(),K("close",b("close"),()=>this.stop()));let r=e.top-$a-Nt;Object.assign(t.style,{top:`${G(r>=Nt?r:e.top+Nt)}px`,right:`${G(Math.max(Nt,innerWidth-e.right))}px`}),this.bar=this.ui.add(t)}buildCard(e){let t=y("div","scan-card");t.setAttribute("role","log"),t.setAttribute("aria-label",b("marqueeScan")),t.setAttribute("data-hidden","");let n=y("div","scan-head"),r=y("span","grow","");this.labels.push(r),n.append(r,this.buildFind(),K("image",b("copyImage"),()=>this.copyImage()),K("download",b("exportImage"),()=>void this.saveImage()),K("collapse",b("exitImmersive"),()=>this.exitImmersive()),this.copyButton(),K("close",b("close"),()=>this.stop())),n.addEventListener("wheel",c=>{c.preventDefault(),this.view?.scrollBy(c.deltaY)},{passive:!1});let i=y("div","scan-body");t.append(n,i),this.body=i;let s=e.bottom-e.top+bn,a=innerHeight-e.bottom-Ye*2,l=a>=tr?Math.min(a,s):Math.round(innerHeight*.42);Object.assign(t.style,{height:`${Math.max(tr,l)}px`,bottom:`${Ye}px`}),this.card=this.ui.add(t),this.updateLabel(),this.mirror=new wt(i,this.scroller,()=>{},this.onKey),this.view=new Mt(this.mirror,i,()=>this.entries.map(c=>c.copy)),this.view.stop(),this.placeFrame()}placeFrame(){let e=this.mirror?.frame,t=this.rect,n=this.body,r=this.card;if(!e||!t||!n||!r)return;let i=(t.right-t.left)*Wa,s=t.left,a=t.right;for(let l of this.entries)s=Math.min(s,Math.max(l.left,t.left-i)),a=Math.max(a,Math.min(l.right,t.right+i));if(s=Math.max(0,s-nr),a=Math.min(innerWidth,a+nr),!this.restoreCard){let l=Math.min(innerWidth-Ye*2,Math.max(Fa,a-s));r.style.width=`${l}px`,r.style.left=`${Math.max(Ye,Math.min(s,innerWidth-l-Ye))}px`}if(this.restoreCard){let l=this.mirror?.scrollerTop??0;Object.assign(e.style,{left:`${-s}px`,top:`${-l}px`,width:`${innerWidth}px`,height:`${innerHeight+l}px`});return}Object.assign(e.style,{left:`${-s}px`,top:`${-t.top}px`,width:`${innerWidth}px`,height:`${Math.max(innerHeight,t.top+n.clientHeight)}px`})}paintPending(){this.box&&this.ui.setFramePending(this.box,this.inFlight>0||this.queue.length>0)}scheduleFlush(){this.paintPending(),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},Oa))}pump(){for(;this.inFlight<Ba&&this.queue.length;)this.send(this.queue.splice(0,_a))}async send(e){let t=this.session,n=this.settings();this.inFlight++;let r;try{r=await er(e.map(s=>({markup:s.segment.markup,hint:s.segment.sourceHint()})),n.sourceLang,n.targetLang)}catch{r=void 0}if(t!==this.session||!Y())return;this.inFlight--;let i;e.forEach((s,a)=>{let l=r?.[a],c=s.segment.run;if(l?.ok&&l.text.trim()){let d=new Set(c.slots.map((u,p)=>p));this.mirror?.setTranslation(s.copy,_e(ie(l.text,d),u=>!!c.slots[u]?.detached),c.slots,Zo(c.markup)),this.replaceOnPage(s,l.text,n),this.setState(s,"done")}else this.mirror?.setKept(s.copy),this.setState(s,"failed"),i??=l&&!l.ok?l.code:"network"}),i&&this.ui.toast(this.ui.errorMessage(i)),this.requestSync(),this.pump(),this.paintPending()}replaceOnPage(e,t,n){let r=e.segment;!r||this.pageTranslated()||(r.setTranslation(t),r.render({mode:"replace",dualStyle:"plain",fontScale:100,targetLang:n.targetLang,theme:Me(n.themeColor)}))}updateLabel(){if(!this.labels.length)return;let e=0,t=0;for(let n of this.entries)n.kind==="code"?t++:n.state==="done"&&e++;for(let n of this.labels)n.textContent=b("scanStatus",String(e),String(t))}copyButton(){let e=K("copy",b("copyMarkdown"),()=>this.copyAll(e));return e}copyAll(e){let t=ko(this.entries);this.ui.copy(t).then(n=>{e&&Ee(e,n);for(let r of this.labels)r.textContent=b(n?"copied":"copyFailed");setTimeout(()=>this.updateLabel(),n?1200:2400)})}async withPicture(e){let t=this.card;if(!t||!this.restoreCard||this.exporting)return;this.exporting=!0;let n=this.session;t.setAttribute("data-exporting",""),this.clearFind();let r=y("div","scan-making"),i=y("div","scan-making-note");i.append(y("span","scan-making-spin"),y("span","",b("exportingFast"))),r.append(i),this.body?.append(r),await Ja();try{let s=await this.drawResult().catch(()=>null)??await this.photographResult();if(!s||n!==this.session)return;let a=this.mirror?.scroller??this.mirror?.doc.body;return await e(Jo(s,a?gn(a):"#ffffff",b("pictureMark",b("extName")),devicePixelRatio||1))}catch{this.ui.toast(b("exportFailed"));return}finally{r.remove(),n===this.session&&(this.exporting=!1,t.removeAttribute("data-exporting"),this.updateLabel())}}async drawResult(){let e=this.mirror,t=this.view,n=this.body,r=e?.scroller;if(!e||!t||!n||!r)throw new Error("not ready");let i=r!==e.doc.scrollingElement,s=i?r:e.doc.body,{from:a,to:l,visible:c}=t.extent,d=devicePixelRatio||1,u=n.getBoundingClientRect().left-e.frame.getBoundingClientRect().left,p=s.getBoundingClientRect();return Yo(s,{left:u-p.left,top:i?a:a-(p.top+(e.doc.defaultView?.scrollY??0)),width:n.clientWidth,height:l-a+c},d)}async photographResult(){let e=this.view,t=this.body;if(!e||!t)return null;let n=this.session,r=e.position;this.card?.setAttribute("data-photographing","");try{await new Promise(h=>setTimeout(h,340));let{from:i,to:s,visible:a}=e.extent,l=t.getBoundingClientRect(),c=devicePixelRatio||1,d=document.createElement("canvas");d.width=Math.round(l.width*c),d.height=Math.min(Math.round((s-i+a)*c),Xa);let u=d.getContext("2d");if(!u)throw new Error("no canvas");let p=Math.ceil(d.height/c/a);for(let h=0;h<p;h++){if(!this.exporting||n!==this.session)return null;for(let v of this.labels)v.textContent=b("exporting",String(h+1),String(p));e.moveTo(i+h*a),await new Promise(v=>setTimeout(v,h?Ga:Ka));let g=await N({type:"capture:screen"});if(!g)throw new Error("refused");let m=await createImageBitmap(Za(g)),f=m.width/innerWidth;u.drawImage(m,l.left*f,l.top*f,l.width*f,l.height*f,0,Math.round((e.position-i)*c),d.width,Math.round(l.height*c)),m.close()}return d}finally{this.card?.removeAttribute("data-photographing"),n===this.session&&e.moveTo(r)}}async saveImage(){await this.withPicture(async e=>{let t=await or(e),n=document.createElement("a");n.href=URL.createObjectURL(t),n.download=`yilan-${location.hostname}-${new Date().toISOString().slice(0,10)}.png`,n.click(),setTimeout(()=>URL.revokeObjectURL(n.href),1e4)})}copyImage(){if(!this.restoreCard||this.exporting)return;if(!navigator.clipboard?.write){this.ui.toast(b("copyImageFailed"));return}let e=()=>{},t=()=>{},n=new Promise((i,s)=>{e=i,t=s}),r=navigator.clipboard.write([new ClipboardItem({"image/png":n})]);this.withPicture(async i=>(e(await or(i)),await r,this.ui.toast(b("copiedImage"),void 0,1800),!0)).then(i=>{i||t(new Error("no picture"))}),r.catch(()=>this.ui.toast(b("copyImageFailed")))}requestSync(){this.frame||(this.frame=requestAnimationFrame(this.syncView))}syncView=()=>{this.frame=0;let e=this.rect;if(!e)return;this.placeFrame();let t=this.toContent(e.top),n=this.toContent(e.bottom),r=this.entries.find(i=>i.bottom>t&&i.top<n);r&&!this.restoreCard&&this.mirror?.alignTo(r.copy,e.top+(r.top-t))}};var De="http://www.w3.org/2000/svg",Bt=8,yn=5,wn=16,me=8,Dt=13,Ot=8,Qa=24,el=22,tl=1.6,nl=2e3,ol=80,rl=48,il=96,_t=3,sl=1100,al=0;function ll(o){for(let e=o.parentElement;e;e=e.parentElement){let t=getComputedStyle(e).display;if(!t.startsWith("inline")&&t!=="contents")return e}return null}function ir(o){let e=o.commonAncestorContainer,t=new Map,n=document.createRange(),r=i=>{if(!i.data.trim()||!o.intersectsNode(i))return;let s=i===o.startContainer?o.startOffset:0,a=i===o.endContainer?o.endOffset:i.length;n.setStart(i,s),n.setEnd(i,a);let l=Array.from(n.getClientRects()).filter(u=>u.width&&u.height);if(!l.length)return;let c=ll(i);if(!c)return;let d=t.get(c);d?(d.rects.push(...l),d.end=[i,a]):t.set(c,{el:c,rects:l,start:[i,s],end:[i,a]})};if(e.nodeType===Node.TEXT_NODE)r(e);else{let i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let s=i.nextNode(),a=0;s&&a<nl;s=i.nextNode(),a++)r(s)}return Array.from(t.values())}function sr(o){return ir(o).map(e=>({el:e.el,members:[e.el],lines:ar(e.rects)}))}function ar(o){let e=[];for(let n of o){let r=e.find(i=>Math.min(i.bottom,n.bottom)-Math.max(i.top,n.top)>Math.min(i.bottom-i.top,n.bottom-n.top)/2);r?(r.left=Math.min(r.left,n.left),r.right=Math.max(r.right,n.right),r.top=Math.min(r.top,n.top),r.bottom=Math.max(r.bottom,n.bottom)):e.push({left:n.left,top:n.top,right:n.right,bottom:n.bottom})}return e.sort((n,r)=>n.top-r.top),e.some((n,r)=>r>0&&(n.left>e[r-1].right||n.right<e[r-1].left))?[{left:Math.min(...e.map(n=>n.left)),top:e[0].top,right:Math.max(...e.map(n=>n.right)),bottom:Math.max(...e.map(n=>n.bottom))}]:e}function cl(o){for(let e=o;e&&e!==document.body;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return!0;return!1}function Ft(o){return{left:Math.min(...o.map(e=>e.left)),top:Math.min(...o.map(e=>e.top)),right:Math.max(...o.map(e=>e.right)),bottom:Math.max(...o.map(e=>e.bottom))}}function lr(o,e){let t=Math.max(o.left,e.left)-Math.min(o.right,e.right),n=Math.max(o.top,e.top)-Math.min(o.bottom,e.bottom);return t<=0&&n<=ol||n<=0&&t<=rl}function dl(o){let e=o.map(t=>({el:t.el,members:[...t.members],lines:[...t.lines]}));for(let t=!0;t;){t=!1;for(let n=0;n<e.length&&!t;n++)for(let r=n+1;r<e.length&&!t;r++)lr(Ft(e[n].lines),Ft(e[r].lines))&&(e[n].lines.push(...e[r].lines),e[n].members.push(...e[r].members),e.splice(r,1),t=!0)}return e.map(t=>({el:t.el,members:t.members,lines:ar(t.lines)}))}function $t(o){let e=sr(o).map(r=>({el:r.el,members:r.members,lines:r.lines.filter(i=>i.top>=0&&i.bottom<=innerHeight&&i.left>=0&&i.right<=innerWidth)})).filter(r=>r.lines.length),t=e.filter(r=>!cl(r.el)),n=dl(t.length?t:e);return n.length===1?{tail:n[0]}:null}function cr(o){let e=[];for(let t of ir(o)){let n=Ft(t.rects),r=e[e.length-1],i=!!r&&Math.min(r.box.bottom,n.bottom)>Math.max(r.box.top,n.top)&&n.left-r.box.right<=il;if(r&&i){r.range.setEnd(t.end[0],t.end[1]),r.box=Ft([r.box,n]);continue}let s=document.createRange();s.setStart(t.start[0],t.start[1]),s.setEnd(t.end[0],t.end[1]),e.push({el:t.el,range:s,newPlace:!!r&&!lr(r.box,n),box:n})}return e}function xn(o,e){let t=y("div","source-flash");for(let n of sr(e).flatMap(r=>r.lines)){let r=y("div","source-flash-line");r.style.left=`${n.left-3}px`,r.style.top=`${n.top-2}px`,r.style.width=`${n.right-n.left+6}px`,r.style.height=`${n.bottom-n.top+4}px`,t.append(r)}o.add(t),setTimeout(()=>t.remove(),sl)}function ul(o){let e=[];for(let t of o){let n=e[e.length-1];(!n||Math.abs(n[0]-t[0])>.5||Math.abs(n[1]-t[1])>.5)&&e.push(t)}return e.filter((t,n)=>{let r=e[(n-1+e.length)%e.length],i=e[(n+1)%e.length];return!(Math.abs(r[0]-t[0])<.5&&Math.abs(i[0]-t[0])<.5)&&!(Math.abs(r[1]-t[1])<.5&&Math.abs(i[1]-t[1])<.5)})}function pl(o){let e=o.length,t="";return o.forEach((n,r)=>{let i=o[(r-1+e)%e],s=o[(r+1)%e],a=Math.hypot(i[0]-n[0],i[1]-n[1]),l=Math.hypot(s[0]-n[0],s[1]-n[1]),c=Math.min(wn,a/2,l/2),d=[n[0]+(i[0]-n[0])/a*c,n[1]+(i[1]-n[1])/a*c],u=[n[0]+(s[0]-n[0])/l*c,n[1]+(s[1]-n[1])/l*c];t+=`${r?"L":"M"}${d[0]} ${d[1]}Q${n[0]} ${n[1]} ${u[0]} ${u[1]}`}),`${t}Z`}function hl(o){let e=document.createElementNS(De,"path");e.setAttribute("d",o);let t=e.getTotalLength(),n=Math.max(10,Math.round(t/el)),r=[];for(let i=0;i<n;i++){let s=e.getPointAtLength(i/n*t);r.push([s.x,s.y])}return r.map((i,s)=>{let a=r[(s-1+n)%n],l=r[(s+1)%n],c=l[0]-a[0],d=l[1]-a[1],u=Math.hypot(c,d)||1,p=tl*(Math.sin(s*.9)*.6+Math.sin(s*.37+1.3)*.7);return[i[0]+d/u*-p,i[1]+c/u*p]})}function vn(o,e,t){let n=o.length,r=s=>o[(s%n+n)%n],i="";for(let s=0;s<t;s++){let a=e+s,[l,c,d,u]=[r(a-1),r(a),r(a+1),r(a+2)];i+=`C${c[0]+(d[0]-l[0])/6} ${c[1]+(d[1]-l[1])/6} ${d[0]-(u[0]-c[0])/6} ${d[1]-(u[1]-c[1])/6} ${d[0]} ${d[1]}`}return i}function ml(o){let{lines:e}=o,t=e[0],n=e[e.length-1],r=parseFloat(getComputedStyle(o.el).lineHeight),i=t.bottom-t.top,s=yn+(r>i&&r<i*3?(r-i)/2:0),a=Math.max(_t,t.top-s),l=Math.min(innerHeight-_t,n.bottom+s),c=h=>Math.max(_t,h.left-Bt),d=h=>Math.min(innerWidth-_t,h.right+Bt),u=[[c(t),a],[d(t),a]],p=(h,g,m)=>(h.bottom+g.top)/2+(m?yn:-yn);e.forEach((h,g)=>{let m=e[g+1];if(!m)return;let f=p(h,m,d(h)>d(m));u.push([d(h),f],[d(m),f])}),u.push([d(n),l],[c(n),l]);for(let h=e.length-1;h>0;h--){let g=p(e[h-1],e[h],c(e[h-1])<c(e[h]));u.push([c(e[h]),g],[c(e[h-1]),g])}return{points:hl(pl(ul(u))),top:a,bottom:l,padY:s}}function dr(o,e,t,n=!0){let{points:r,top:i,bottom:s,padY:a}=ml(o),l=o.lines[0],c=o.lines[o.lines.length-1],d=s+Dt+t<=innerHeight-me,u=i-Dt-t>=me;if(!n||!d&&!u)return{path:"M"+r[0][0]+" "+r[0][1]+vn(r,0,r.length)+"Z",left:Math.max(me,Math.min(l.left,innerWidth-e-me)),top:Math.max(me,innerHeight-t-me)};let p=d,h=p?c:l,g=p?s:i,m=h.left-Bt+wn+Ot,f=h.right+Bt-wn-Ot,v=p?f-12:m+12,w=f>m?Math.max(m,Math.min(v,f)):(h.left+h.right)/2,E=p?g+Dt:g-Dt,T=Math.min(Qa,e/2),R=Math.max(me,w-e+T),D=Math.min(innerWidth-e-me,w-T),_=Math.max(R,Math.min(l.left,D)),W=r.length,X=-1,J=-1;r.forEach((B,F)=>{if(Math.abs(B[1]-g)>=a+6)return;let O=B[0]-w;O>=Ot*.6&&(X<0||O<r[X][0]-w)&&(X=F),O<=-Ot*.6&&(J<0||O>r[J][0]-w)&&(J=F)});let[x,M]=p?[X,J]:[J,X],P;if(x<0||M<0)P=`M${r[0][0]} ${r[0][1]}${vn(r,0,W)}Z`;else{let B=(x-M+W)%W||W;P=`M${r[M][0]} ${r[M][1]}${vn(r,M,B)}L${w} ${E}Z`}return{path:P,left:_,top:p?E-1:E-t+1}}function ur(o,e=!0){let t=document.createElementNS(De,"svg");t.setAttribute("class","bubble-ring"),t.setAttribute("aria-hidden","true");let n=`yl-ring-${++al}`,r=document.createElementNS(De,"defs"),i=document.createElementNS(De,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[s,a]of qe){let l=document.createElementNS(De,"stop");l.setAttribute("offset",s),l.setAttribute("stop-color",a),i.append(l)}r.append(i),t.append(r);for(let s of o){let a=document.createElementNS(De,"path");a.setAttribute("d",s),e&&a.setAttribute("pathLength","1"),a.setAttribute("stroke",`url(#${n})`),t.append(a)}return t}function pr(o,e,t){let{path:n,left:r,top:i}=dr(t.tail,e.offsetWidth,e.offsetHeight);e.style.left=`${r}px`,e.style.top=`${i}px`,o.insertBefore(ur([n]),e)}var Je=class{constructor(e,t,n){this.range=t;this.anchor=n.tail.el;let r=this.anchor.getBoundingClientRect();this.first={plan:n,top:r.top,left:r.left};let i=Pe(this.anchor).map(s=>s.el);this.area=i[0],e.addToPage(this.node),this.pin=new ue(this.node,i)}node=y("div","source-ring");pin;area;anchor;first;get anchorBox(){return this.anchor.getBoundingClientRect()}retarget(e){this.anchor=e}tailless=!1;detachTail(){this.tailless=!0}setPending(e){this.node.toggleAttribute("data-pending",e)}layout(e,t){let n=this.anchor.getBoundingClientRect(),r=Math.abs(n.top-this.first.top)<1&&Math.abs(n.left-this.first.left)<1,i=$t(this.range)??(r?this.first.plan:null);if(!i)return null;let{path:s,left:a,top:l}=dr(i.tail,e,t,!this.tailless),c=this.anchorBox,d=ur([s],!1);return d.style.left=`${-c.left}px`,d.style.top=`${-c.top}px`,this.node.replaceChildren(d),this.pin.place(c.left,c.top),{left:a,top:l}}follow(){let e=this.anchorBox;(e.width||e.height)&&this.pin.place(e.left,e.top)}clip(e,t){let n=this.area?.getBoundingClientRect();ct(this.node,Math.max(e,n?.top??-1/0),Math.min(t,n?.bottom??1/0))}remove(){this.node.remove()}};function fl(o){return o==="zh-Hans"?"zh-CN":o==="zh-Hant"?"zh-TW":o==="yue"?"zh-HK":o}function gl(o,e){let t=e.toLowerCase(),n=t.split("-")[0],r=a=>{let l=a.lang.toLowerCase().replace("_","-");return l!==t&&l.split("-")[0]!==n?-1:(l===t?2:0)+(a.localService?1:0)},i,s=-1;for(let a of o){let l=r(a);l>s&&(i=a,s=l)}return i}function bl(o,e,t){let n=Intl.Segmenter;if(!n)return Math.min(o.length,e+1);for(let r of new n(t,{granularity:"word"}).segment(o.slice(e)))if(r.segment.trim())return e+r.index+r.segment.length;return o.length}function yl(o,e){let t=[],n=Intl.Segmenter,r=n?[...new n(e||void 0,{granularity:"sentence"}).segment(o)].map(i=>({start:i.index,text:i.segment})):[{start:0,text:o}];for(let i of r){let s=0;for(let a of i.text.split(/(\n+)/)){let l=a.length-a.trimStart().length,c=a.trim();c&&t.push({start:i.start+s+l,text:c}),s+=a.length}}return t}var Wt=class{constructor(e,t=n=>new SpeechSynthesisUtterance(n)){this.synth=e;this.create=t}current;callbacks;get reading(){return this.current!==void 0}start(e,t,n){this.stop();let r=fl(t),i=this.synth.getVoices(),s=gl(i,r);if(i.length&&!s){n.onEnd("noVoice");return}let a=yl(e,r);if(!a.length){n.onEnd();return}let l={};this.current=l,this.callbacks=n,a.forEach((c,d)=>{let u=this.create(c.text);u.lang=r,s&&(u.voice=s),u.onstart=()=>{l===this.current&&n.onSentence?.(c.start,c.start+c.text.length)},u.onboundary=p=>{if(l!==this.current||p.name==="sentence")return;let h=p.charLength?p.charIndex+p.charLength:bl(c.text,p.charIndex,r);n.onWord(c.start+p.charIndex,c.start+h)},d===a.length-1&&(u.onend=()=>this.finish(l)),u.onerror=p=>this.finish(l,p.error==="canceled"||p.error==="interrupted"?void 0:"failed"),this.synth.speak(u)})}stop(){let e=this.callbacks,t=this.current!==void 0;this.current=void 0,this.callbacks=void 0,t&&(this.synth.cancel(),e?.onEnd())}finish(e,t){if(e!==this.current)return;let n=this.callbacks;this.current=void 0,this.callbacks=void 0,t&&this.synth.cancel(),n?.onEnd(t)}};var hr,Ze,Qe,En=new Map;function vl(o,e){let t=En.get(e);return t||(t=(async()=>{let n=await N({type:"asset:fetch",url:e});if(!n)return null;let r=atob(n.slice(n.indexOf(",")+1)),i=new Uint8Array(r.length);for(let s=0;s<r.length;s++)i[s]=r.charCodeAt(s);return await o.decodeAudioData(i.buffer)})().catch(()=>null),En.set(e,t),t.then(n=>n||En.delete(e))),t}function Oe(){let o=Qe;Qe=void 0;try{Ze?.stop()}catch{}Ze=void 0,o?.()}async function mr(o,e){Oe(),hr??=new AudioContext;let t=hr;t.state==="suspended"&&t.resume();let n=await vl(t,o);if(!n)return!1;Oe();let r=t.createBufferSource();return r.buffer=n,r.connect(t.destination),Ze=r,Qe=e,r.onended=()=>{if(Ze!==r)return;Ze=void 0;let i=Qe;Qe=void 0,i?.()},r.start(),!0}var xl=5e3,El='yl-t,yl-r,pre,code,kbd,samp,textarea,input,select,[contenteditable]:not([contenteditable="false"]),.CodeMirror,.cm-editor,.monaco-editor,.ace_editor,.blob-code,.hljs,[role="textbox"],[role="code"]',Sl="yl-t,yl-ui,script,style,noscript,template",Tl=3e3,kl=4,Ut="	";function Ml(o){let e=o;for(;e.parentElement&&getComputedStyle(e).display.startsWith("inline");)e=e.parentElement;return e}function Cl(o,e){return Math.min(o.bottom,e.bottom)-Math.max(o.top,e.top)>=Math.min(o.height,e.height)/2}function fr(o){let e=o.commonAncestorContainer,t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),n=[""],r,i=0;for(let s=e.nodeType===Node.TEXT_NODE?e:t.nextNode();s;s=t.nextNode()){if(++i>Tl)return"";if(!o.intersectsNode(s))continue;let a=s.parentElement;if(!a||a.closest(Sl))continue;let l=getComputedStyle(a);if(l.visibility!=="visible"||l.userSelect==="none")continue;let c=s.data,d=s===o.startContainer?o.startOffset:0,u=s===o.endContainer?o.endOffset:c.length,p=document.createRange();p.setStart(s,d),p.setEnd(s,u);let h=p.getClientRects(),g=h[0],m=h[h.length-1];if(!g||!m||!g.width)continue;let v=l.whiteSpace.startsWith("pre")||l.whiteSpace==="break-spaces"?c.slice(d,u).replace(/\t/g,"  "):c.slice(d,u).replace(/\s+/g," ");if(!v.trim()&&!r)continue;let w=Ml(a);if(r){let T=Cl(r.rect,g);r.flow!==w&&!T?n.push(""):r.flow!==w?n[n.length-1]+=Ut:T&&g.left-r.rect.right>=kl&&(n[n.length-1]+=" ")}let E=v.split(`
`);n[n.length-1]+=E[0]??"",n.push(...E.slice(1)),v.trim()&&(r={flow:w,rect:m})}return n.map(s=>s.replace(/ {2,}/g," ").replace(/ *\t[ \t]*/g,Ut).replace(/^\t+|\t+$/g,"").trim()).filter(Boolean).join(`
`)}function Al(o,e){let t=[...o.matchAll(/[\t\n]/g)].map(r=>r[0]),n=e.split(`
`);return!t.includes(Ut)||n.length!==t.length+1?e:n.reduce((r,i,s)=>r+(t[s-1]===Ut?" ":`
`)+i)}function gr(o,e){try{return new Intl.DisplayNames([e],{type:"language"}).of(o)??o}catch{return o}}var br=60,Rl=6,Ll=40,Er=.6,Nl=/^[A-Za-z]+(?:['’-][A-Za-z]+)*$/,Pl=32;function yr(o){if(!o)return;let e=o.startContainer,t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement,n=Pe(t).map(i=>i.el).find(i=>i.clientHeight>=innerHeight*Er);if(!n)return;let r=n.getBoundingClientRect();return{top:r.top,bottom:r.bottom}}async function vr(o){let e=NaN,t=0,n=performance.now();for(;t<5&&performance.now()-n<1200;){await new Promise(i=>requestAnimationFrame(i));let r=o.getBoundingClientRect().top;t=r===e?t+1:0,e=r}}function wr(o,e){return new DOMRect(o,e,0,0)}var qt=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("mouseup",this.onMouseUp),document.addEventListener("mousedown",this.onMouseDown,!0),document.addEventListener("keydown",this.onKeyDown,!0),addEventListener("scroll",this.onScroll,{passive:!0,capture:!0}),addEventListener("resize",this.onResize),at()}bubble;card;remote;followFrame=0;reader=new Wt(speechSynthesis);update(e,t){this.settings=e,this.enabled=t,t||this.closeAll()}translateText(e){let t=getSelection(),n=t&&t.rangeCount?t.getRangeAt(0).cloneRange():void 0,r=n?.getBoundingClientRect();n&&r&&r.width?this.openCard(e,r,{range:n,plan:$t(n),x:r.right,y:r.bottom}):this.openCard(e,new DOMRect(innerWidth/2-240,80,0,0))}isOwnEvent(e){return this.ui.ownsEvent(e)}onMouseDown=e=>{this.isOwnEvent(e)||this.closeAll()};onKeyDown=e=>{e.key==="Escape"&&this.closeAll()};onScroll=e=>{if(this.isOwnEvent(e))return;this.bubble?.remove(),this.bubble=void 0,this.followFrame||(this.followFrame=requestAnimationFrame(this.followSource));let t=this.remote;t&&!t.moveFrame&&(t.moveFrame=requestAnimationFrame(()=>{if(t.moveFrame=0,this.remote!==t)return;let n=t.ring?.anchorBox;n&&(n.width||n.height)&&N({type:"card:move",key:t.key,anchor:$e(n)}).catch(()=>{})}))};onResize=()=>{this.card&&this.placeCard(this.card)};followSource=()=>{this.followFrame=0;let e=this.card;if(!e?.ring)return;e.ring.follow();let t=e.ring.anchorBox;(t.width||t.height)&&e.pin?.place(t.left+e.dx,t.top+e.dy),this.clearOfBars(e)};placeCard(e){if(!e.ring||!e.pin)return;let t=e.ring.anchorBox,n=()=>e.pin?.place(t.left+e.dx,t.top+e.dy);if(t.bottom<0||t.top>innerHeight){n();return}let r=e.ring.layout(e.node.offsetWidth,e.node.offsetHeight);if(!r||e.moved){n();return}e.dx=r.left-t.left,e.dy=r.top-t.top,e.pin.place(r.left,r.top),this.clearOfBars(e)}clearOfBars(e){if(!e.ring)return;let t=this.ui.settleUnderBars(),n=e.area&&e.area.clientHeight>=innerHeight*Er?e.area.getBoundingClientRect():void 0,r=Math.max(t.top,n?.top??-1/0),i=Math.min(t.bottom,n?.bottom??1/0);ct(e.node,r,i),e.ring.clip(t.top,t.bottom)}closeCard(e,t=!0){e.alive&&(e.alive=!1,e.menu?.close(),this.card===e&&(this.card=void 0),this.reader.stop(),Oe(),e.ring?.remove(),this.ui.dismiss(e.node),t&&e.onClose?.())}onMouseUp=e=>{Y()&&(!this.enabled||this.settings.selectionTrigger==="off"||this.isOwnEvent(e)||setTimeout(()=>this.evaluate(e),0))};evaluate(e){let t=getSelection();if(!t||t.isCollapsed||!t.rangeCount)return;let n=t.getRangeAt(0),r=fr(n)||t.toString().trim();if(!r||r.length>xl||!new RegExp("\\p{L}","u").test(r)||Hl(n))return;let i=n.getBoundingClientRect();if(!i.width&&!i.height)return;let s=n.cloneRange(),a=$t(s);if(this.settings.selectionTrigger==="auto"){this.openCard(r,wr(e.clientX,e.clientY),{range:s,plan:a,x:e.clientX,y:e.clientY});return}this.showBubble(r,e.clientX,e.clientY,s,a)}showBubble(e,t,n,r,i){this.bubble?.remove();let s=y("div","bubble"),a=y("div","bubble-tab"),l=y("button","bubble-action");l.type="button",l.title=b("selectionBubble"),l.setAttribute("aria-label",b("selectionBubble")),l.append(ce("translate"),y("span","",b("selectionAction"))),l.addEventListener("click",()=>{s.remove(),this.bubble=void 0,this.openCard(e,wr(t,n),{range:r,plan:i,x:t,y:n})}),a.append(l),s.append(a),this.bubble=this.ui.add(s),i?pr(s,a,i):(a.style.left=`${Math.max(8,Math.min(t+6,innerWidth-a.offsetWidth-8))}px`,a.style.top=`${Math.max(8,Math.min(n+10,innerHeight-a.offsetHeight-8))}px`)}glossaryEditor(e,t,n,r){let i=y("div","card-glossary"),s=y("input","card-glossary-input");s.value=e,s.setAttribute("aria-label",b("glossaryTerm"));let a=y("input","card-glossary-input");a.value=t.length<=br?t:"",a.placeholder=b("glossaryKeep"),a.setAttribute("aria-label",b("glossaryTranslation"));let l=y("button","card-glossary-save",b("glossarySave"));l.type="button";let c=async()=>{let d=s.value.trim();if(!d)return;let u=(await chrome.storage.sync.get("glossary")).glossary,p=a.value.trim(),h=p?{from:d,to:p,lang:n}:{from:d,to:""},g=(u??[]).filter(m=>!(m.from.toLowerCase()===d.toLowerCase()&&(m.lang??"")===(h.lang??"")));await chrome.storage.sync.set({glossary:[...g,h].slice(-200)}),i.remove(),r(b("glossaryAdded"),1800)};l.addEventListener("click",()=>void c());for(let d of[s,a])d.addEventListener("keydown",u=>{u.key==="Enter"&&c()});return i.append(s,y("span","card-glossary-arrow","→"),a,l),setTimeout(()=>a.focus(),0),i}startDrag(e,t,n){if(n.button!==0)return;n.preventDefault(),t.setPointerCapture(n.pointerId);let r={x:n.clientX,y:n.clientY},i=e.node.getBoundingClientRect(),s={dx:e.dx,dy:e.dy};e.node.toggleAttribute("data-dragging",!0),e.moved||(e.moved=!0,e.ring?.detachTail(),e.ring?.layout(e.node.offsetWidth,e.node.offsetHeight));let a=c=>{let d=Math.max(8,Math.min(i.left+c.clientX-r.x,innerWidth-i.width-8)),u=Math.max(8,Math.min(i.top+c.clientY-r.y,innerHeight-40));if(e.ring&&e.pin){e.dx=s.dx+d-i.left,e.dy=s.dy+u-i.top;let p=e.ring.anchorBox;e.pin.place(p.left+e.dx,p.top+e.dy)}else e.node.style.left=`${d}px`,e.node.style.top=`${u}px`},l=()=>{t.removeEventListener("pointermove",a),t.removeEventListener("pointerup",l),t.removeEventListener("pointercancel",l),e.node.removeAttribute("data-dragging"),this.clearOfBars(e)};t.addEventListener("pointermove",a),t.addEventListener("pointerup",l),t.addEventListener("pointercancel",l)}async jumpTo(e,t){let n=t.el.getBoundingClientRect();if(!(n.top>=0&&n.bottom<=innerHeight)){if(t.el.scrollIntoView({block:"center",behavior:"instant"}),await vr(t.el),!e.alive)return;e.ring&&(e.ring.retarget(t.el),this.placeCard(e))}xn(this.ui,t.range)}openCard(e,t,n){this.closeAll();let i=(n?cr(n.range):[]).map(c=>({segment:c,text:fr(c.range)||c.range.toString().trim()})).filter(c=>new RegExp("\\p{L}","u").test(c.text)),a=i.length>1&&i.length<=Ll?i:[{text:e}],l={text:e,anchor:t,around:n,parts:a.map(({segment:c,text:d})=>({text:d,onJump:c?u=>void this.jumpTo(u,c):void 0}))};window.top!==window?this.openAbove(l,a.map(c=>c.segment)):this.renderCard(l)}async openAbove(e,t){let n=crypto.randomUUID();lt(n);let r=e.around?.plan,i=r&&e.around?new Je(this.ui,e.around.range,r):void 0;i&&(i.detachTail(),i.layout(0,0),i.setPending(!0));let s={key:n,ring:i,segments:t,moveFrame:0};this.remote=s;let a=i?.anchorBox??e.anchor,l={texts:e.parts.map(d=>d.text),term:e.text,anchor:$e(a),jumps:t.some(Boolean)},c=!1;try{c=await N({type:"card:show",key:n,request:l})===!0}catch{c=!1}this.remote!==s||c||(this.endRemote(!1),this.renderCard(e))}endRemote(e){let t=this.remote;t&&(this.remote=void 0,cancelAnimationFrame(t.moveFrame),t.ring?.remove(),e&&N({type:"card:dismiss",key:t.key}).catch(()=>{}))}cardNews(e){let t=this.remote;if(!t||t.key!==e.key)return;let n=e;if(n.action==="closed")this.endRemote(!1);else if(n.action==="pending")t.ring?.setPending(!0);else if(n.action==="done")t.ring?.setPending(!1);else if(n.action==="jump"){let r=t.segments[n.index];r&&this.jumpInFrame(t,r)}}async jumpInFrame(e,t){let n=t.el.getBoundingClientRect();if(n.top<0||n.bottom>innerHeight){if(t.el.scrollIntoView({block:"center",behavior:"instant"}),await vr(t.el),this.remote!==e)return;e.ring?.retarget(t.el),e.ring?.layout(0,0)}xn(this.ui,t.range)}async showCardForFrame(e,t,n){if(window.top!==window||!We(t?.anchor)||!Array.isArray(t.texts)||!t.texts.length||!t.texts.every(a=>typeof a=="string"))return!1;let r=await Be(e);if(!r)return!1;let i=Fe(r,t.anchor),s=a=>void N({type:"card:news",key:e,frameId:n,...a}).catch(()=>{});return this.closeAll(),this.renderCard({text:typeof t.term=="string"?t.term:t.texts.join(" "),anchor:new DOMRect(i.left,i.top,i.right-i.left,i.bottom-i.top),parts:t.texts.map((a,l)=>({text:a,onJump:t.jumps?()=>s({action:"jump",index:l}):void 0})),key:e,onPending:a=>s({action:a?"pending":"done"}),onClose:()=>s({action:"closed"})}),!0}dismissForFrame(e){this.card?.key===e&&this.closeCard(this.card,!1)}moveForFrame(e,t){let n=this.card;n?.key!==e||n.moved||!We(t)||Be(e).then(r=>{if(!r||this.card!==n)return;let i=Fe(r,t);n.anchor=new DOMRect(i.left,i.top,i.right-i.left,i.bottom-i.top),this.ui.place(n.node,n.anchor,8)})}renderCard(e){let{text:t,anchor:n,around:r}=e,i=this.settings.targetLang,s=y("div","card");s.setAttribute("role","dialog"),s.setAttribute("aria-label",b("selectionBubble"));let a=y("div","card-body"),l=e.parts.length>1,c=(S,C)=>{let U=y("div","card-line"),A=K("speak",C,()=>{});return A.classList.add("card-say"),A.dataset.label=C,A.dataset.icon="speak",A.addEventListener("mousedown",q=>q.stopPropagation()),A.addEventListener("click",q=>q.stopPropagation()),U.append(S,A),{line:U,b:A}},d=e.parts.map(S=>{let C=y("div","card-seg"),U=y("div","card-source",S.text),A=y("div","card-result",b("translating"));A.dataset.state="loading";let q,$;if(l){let H=c(U,b("speakSource")),Z=c(A,b("speak"));q=H.b,$=Z.b,Z.b.disabled=!0,C.append(H.line,Z.line)}else C.append(U,A);let{onJump:I}=S;if(I){C.title=b("jumpToSource"),C.dataset.jump="";let H=[0,0];C.addEventListener("mousedown",Z=>H=[Z.clientX,Z.clientY]),C.addEventListener("click",Z=>{Math.hypot(Z.clientX-H[0],Z.clientY-H[1])<4&&I(L)})}return a.append(C),{text:S.text,source:U,result:A,translated:"",saySource:q,sayResult:$}}),u=Ln(),p=y("span","grow card-langs"),h=y("span","card-from"),g=y("button","card-lang");g.type="button",g.title=b("targetLang"),g.setAttribute("aria-haspopup","listbox");let m=y("span","");g.append(m,y("i","card-lang-chevron"));let f="",v=()=>{h.textContent=f&&f!==i?`${gr(f,u)} → `:"",m.textContent=gr(i,u),p.replaceChildren(h,g)};v();let w,E=(S,C)=>{p.replaceChildren(S),clearTimeout(w),w=setTimeout(v,C)},T="",R=K("copy",b("copy"),()=>{T&&this.ui.copy(T).then(S=>{Ee(R,S),E(b(S?"copied":"copyFailed"),S?1200:2400)})}),D=[],_,W,X=S=>{S.node.textContent=S.text,delete S.node.dataset.reading},J=()=>{let S=W?.[0]??_?.[0];if(S===void 0)return;let C=D.find(Q=>S>=Q.start&&S<Q.start+Q.text.length);if(!C)return;for(let Q of D)Q!==C&&(Q.node.textContent=Q.text);let U=C.text,A=Q=>Q&&[Math.max(0,Q[0]-C.start),Math.min(U.length,Q[1]-C.start)],q=A(W),[$,I]=A(_)??q,H=y("span","card-sentence"),Z=H;if(q&&q[0]>=$&&q[1]<=I){let Q=y("mark","card-word",U.slice(q[0],q[1]));H.append(U.slice($,q[0]),Q,U.slice(q[1],I)),Z=Q}else H.append(U.slice($,I));C.node.replaceChildren(U.slice(0,$),H,U.slice(I));let ye=Z.offsetTop-a.offsetTop;(ye<a.scrollTop||ye+Z.offsetHeight>a.scrollTop+a.clientHeight)&&(a.scrollTop=ye-24)},x=(S,C)=>{S.toggleAttribute("data-on",C),S.title=C?b("stopSpeaking"):S.dataset.label??"",S.setAttribute("aria-label",S.title),S.replaceChildren(ce(C?"stop":S.dataset.icon??"speak"))},M,P=(S,C,U)=>{Oe();let A=M===S;if(this.reader.stop(),A)return;let q=0,$=C.filter(I=>I.text.trim()).map(I=>{let H={...I,start:q};return q+=I.text.length+2,H});if(!(!$.length||!U)){D=$,_=W=void 0,M=S;for(let I of $)I.node.dataset.reading="";x(S,!0),this.reader.start($.map(I=>I.text).join(`

`),U,{onSentence:(I,H)=>{_=[I,H],W=void 0,J()},onWord:(I,H)=>{W=[I,H],J()},onEnd:I=>{x(S,!1),$.forEach(X),M===S&&(M=void 0,D=[],_=W=void 0),I&&E(b(I==="noVoice"?"noVoice":"speakFailed"),2400)}})}},B=()=>f||(this.settings.sourceLang!=="auto"?this.settings.sourceLang:""),F=K("speak",b("speak"),()=>P(F,d.filter(S=>S.translated).map(S=>({node:S.result,text:S.translated})),i));F.dataset.label=b("speak"),F.dataset.icon="speak";let O=K("speakSource",b("speakSource"),()=>P(O,d.map(S=>({node:S.source,text:S.text})),B()));O.dataset.label=b("speakSource"),O.dataset.icon="speakSource";for(let S of d)S.saySource?.addEventListener("click",()=>P(S.saySource,[{node:S.source,text:S.text}],B())),S.sayResult?.addEventListener("click",()=>{S.translated&&P(S.sayResult,[{node:S.result,text:S.translated}],i)});let te=d.length===1?t.trim():"",fe=te.length<=Pl&&Nl.test(te),ge,k=S=>{if(!L.alive||ge||!d[0])return;ge=y("div","card-phon");let C=[["uk",b("accentUK"),"en-GB"],["us",b("accentUS"),"en-US"]];for(let[U,A,q]of C){let $=S?.[U],I=$?.ipa??S?.ipa,H=y("button","card-accent");H.type="button",H.title=`${A} ${I??""}`.trim(),H.append(y("span","card-accent-name",A)),I&&H.append(y("span","card-accent-ipa",I)),H.append(ce("speak"));let Z=()=>H.removeAttribute("data-on");H.addEventListener("mousedown",ye=>ye.stopPropagation()),H.addEventListener("click",ye=>{ye.stopPropagation();let Q=H.hasAttribute("data-on");if(this.reader.stop(),Oe(),Q)return;H.setAttribute("data-on","");let kn=()=>this.reader.start(te,q,{onWord:()=>{},onEnd:et=>{Z(),et&&E(b(et==="noVoice"?"noVoice":"speakFailed"),2400)}});if(!$)return kn();mr($.audio,Z).then(et=>{!et&&H.hasAttribute("data-on")&&kn()})}),ge.append(H)}d[0].source.after(ge),L.ring&&this.placeCard(L)},j=fe?N({type:"dict:word",word:te}).catch(()=>null):void 0,V=K("close",b("close"),()=>this.closeCard(L)),z=y("div","card-foot"),oe=d.length===1&&t.length<=br&&t.split(/\s+/).length<=Rl,ae=K("glossary",b("addToGlossary"),()=>{s.querySelector(".card-glossary")||(s.insertBefore(this.glossaryEditor(t.trim(),d[0]?.translated??"",i,E),z),this.placeCard(L))});oe?z.append(p,ae,R,O,F,V):z.append(p,R,O,F,V);let ee=y("div","card-grip");ee.title=b("moveCard"),ee.setAttribute("aria-label",b("moveCard")),ee.addEventListener("pointerdown",S=>this.startDrag(L,ee,S)),s.append(ee,a,z);let L={node:s,dx:0,dy:0,alive:!0,key:e.key,onClose:e.onClose,anchor:n};if(this.card=L,r?.plan){let S=Pe(r.plan.tail.el).map(C=>C.el);L.area=S[0],L.ring=new Je(this.ui,r.range,r.plan),L.ring.setPending(!0),s.dataset.onPage="",this.ui.addToPage(s),L.pin=new ue(s,S),this.placeCard(L)}else this.ui.add(s),this.ui.place(s,n,8,yr(r?.range));let be=0,Sn=async()=>{let S=++be;try{let C=await N({type:"translate",items:d.map(A=>re(A.text.replace(/\t/g,`
`))),from:this.settings.sourceLang,to:i});if(!L.alive||S!==be)return;d.forEach((A,q)=>{let $=C?.results?.[q];$?.ok?(delete A.result.dataset.state,A.translated=Al(A.text,ve($.text)),A.result.textContent=A.translated,$.detected&&(f=$.detected,v())):(A.result.dataset.state="error",A.result.textContent=this.ui.errorMessage($?.code??"network"))});let U=d.filter(A=>A.translated);for(let A of U)A.sayResult&&(A.sayResult.disabled=!1);T=U.map(A=>A.translated).join(`

`),j&&(!f||f==="en")&&j.then(k)}catch{if(!L.alive||S!==be||!Y())return;for(let C of d)C.result.dataset.state="error",C.result.textContent=this.ui.errorMessage("network")}!L.alive||S!==be||(L.ring?.setPending(!1),e.onPending?.(!1),a.style.overscrollBehavior=a.scrollHeight>a.clientHeight?"contain":"",L.ring?this.placeCard(L):L.moved||this.ui.place(s,n,8,yr(r?.range)))},Tn=!1;g.addEventListener("pointerdown",()=>Tn=!!L.menu?.isOpen()),g.addEventListener("click",()=>{if(Tn){L.menu?.close(),L.menu=void 0;return}L.menu=pt(this.ui,g.getBoundingClientRect(),i,b("targetLang"),S=>{if(L.menu=void 0,S!==i){i=S,this.reader.stop(),T="";for(let C of d)C.translated="",C.sayResult&&(C.sayResult.disabled=!0),C.result.dataset.state="loading",C.result.textContent=b("translating");v(),L.ring?.setPending(!0),e.onPending?.(!0),Sn()}})}),e.onPending?.(!0),Sn()}closeAll(){this.ui.dismiss(this.bubble),this.bubble=void 0,this.card&&this.closeCard(this.card),this.endRemote(!0)}};function Hl(o){let e=o.commonAncestorContainer;if(xr(e))return!0;if(e.nodeType===Node.TEXT_NODE)return!1;let t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let n=t.nextNode();n;n=t.nextNode()){if(!o.intersectsNode(n))continue;let r=n,i=n===o.startContainer?o.startOffset:0,s=n===o.endContainer?o.endOffset:r.length;if(r.data.slice(i,s).trim()&&!xr(n))return!1}return!0}function xr(o){return!!(o.nodeType===Node.ELEMENT_NODE?o:o.parentElement)?.closest(El)}var Sr="__yilan_region_ask__",Mr=1500,Il=2e3,Cr="__yilan_handover__",Tr=globalThis;async function Dl(){let o=document.documentElement.lang?.trim();if(o)return o;let e=document.body?.innerText?.slice(0,Mr)??"";if(e.trim())try{let n=(await chrome.i18n.detectLanguage(e)).languages?.[0];return n&&n.percentage>=50?n.language:void 0}catch{return}}async function kr(o){let e=document.body?.innerText?.slice(0,Mr)??"",t;if(e.trim())try{let r=(await chrome.i18n.detectLanguage(e)).languages?.[0];r&&r.percentage>=50&&(t=r.language)}catch{}return t??=document.documentElement.lang?.trim()||void 0,t!==void 0&&!ro(t,o)}function Ol(o,e){let t=o.toLowerCase().split("-")[0];return e.some(n=>n.toLowerCase()===o.toLowerCase()||n.toLowerCase().split("-")[0]===t)}async function _l(){let o=await Vt();Rn(x=>N({type:"i18n:messages",locale:x})),await zt(o.uiLang);let e=location.hostname,t=x=>!Yt(e,x.neverSites),n=new ut,r=()=>{let x=Bn(o.appearance);n.setTheme(it(Me(o.themeColor),x?On:rt),x)};r(),matchMedia("(prefers-color-scheme: dark)").addEventListener("change",r);let i=new kt(o,n),s=new qt(o,n,t(o)),a=new ht(o,n,t(o)),l=new Tt(n),c=new It(n,()=>o,()=>i.hasPageTranslations),d=new Set,u=(x,M)=>{let P=0;for(let B of Array.from(document.querySelectorAll("iframe"))){let F=B.getBoundingClientRect(),O={left:x.left-F.left-B.clientLeft,top:x.top-F.top-B.clientTop,right:x.right-F.left-B.clientLeft,bottom:x.bottom-F.top-B.clientTop};O.right<=0||O.bottom<=0||O.left>=F.width||O.top>=F.height||(B.contentWindow?.postMessage({[Sr]:!0,rect:O,token:M},"*"),P++)}return P},p=async x=>{let M=window===window.top;M&&l.showPending(x);let P=await i.translateRegion(x);return P&&await i.regionSettled(),M?l.settle(P>0):P>0};addEventListener("message",x=>{let M=x.data;if(!M||typeof M!="object"||typeof M.token!="string"||!(Sr in M)||x.source!==parent||!d.has(M.token)||!M.rect)return;let{left:P,top:B,right:F,bottom:O}=M.rect;[P,B,F,O].every(Number.isFinite)&&(u({left:P,top:B,right:F,bottom:O},M.token),p({left:P,top:B,right:F,bottom:O}))});let h=()=>{l.close(),i.restoreRegion(),c.stop()},g=()=>{h(),N({type:"region:closeAll"}).catch(()=>{})},m=!1,f=x=>{x.key!=="Escape"||!m||(x.preventDefault(),x.stopPropagation(),m=!1,removeEventListener("keydown",f,!0),g())},v=new gt(n),w=x=>{if(window!==top){N({type:"marquee:request",mode:x}).catch(()=>{});return}g(),focus(),v.begin(M=>{if(x==="scan"){c.start(M);return}m=!0,addEventListener("keydown",f,!0);let P=crypto.randomUUID();(async()=>{await N({type:"region:arm",token:P}).catch(()=>{}),await new Promise(O=>setTimeout(O,50));let B=u(M,P);!await p(M)&&!B&&n.toast(l.emptyMessage)})()})},E=!1,T=!1,R=()=>{E||(E=!0,clearInterval(D),m=!1,removeEventListener("keydown",f,!0),v.cancel(),h(),i.retire(),s.update(o,!1),a.update(o,!1))},D=setInterval(()=>{Y()||R()},Il);addEventListener(Cr,()=>{Y()||(T=!0,R())});let _=b("refreshAfterUpdate");return eo(()=>o.shortcuts,x=>{if(!Y()){R(),T||n.toast(_);return}x==="marquee"?w("cover"):x==="sweep"?w("scan"):N({type:"shortcut:page",action:x}).catch(()=>{})}),Fn(x=>{!o.autoTranslate&&x.autoTranslate&&t(x)&&kr(x.targetLang).then(M=>M?i.startPage():void 0),x.uiLang!==o.uiLang&&zt(x.uiLang),o=x,r(),i.applySettings(x),s.update(x,t(x)),a.update(x,t(x))}),{handle:(x,M)=>{switch(x.type){case"page:translate":g(),i.startPage();break;case"page:restore":g(),i.restore();break;case"page:toggle":g(),i.togglePage();break;case"page:retry":i.retryFailed();break;case"page:status":M(i.status());return;case"mode:toggle":{let P=o.mode==="dual"?"replace":"dual";o={...o,mode:P},i.setMode(P),window===top&&chrome.storage.sync.set({mode:P});break}case"marquee:start":w(x.mode??"cover");break;case"region:arm":d.add(x.token),setTimeout(()=>d.delete(x.token),5e3);break;case"region:close":h();break;case"selection:translate":s.translateText(x.text);break;case"input:show":a.showForFrame(x.key,x.request,x.frameId).then(M,()=>M(!1));return;case"input:done":a.remoteDone(x);break;case"input:dismiss":a.dismissForFrame(x.key);break;case"card:show":s.showCardForFrame(x.key,x.request,x.frameId).then(M,()=>M(!1));return;case"card:news":s.cardNews(x);break;case"card:dismiss":s.dismissForFrame(x.key);break;case"card:move":s.moveForFrame(x.key,x.anchor);break}M(!0)},afterReady:async()=>{let x=await Dl();i.setPageLang(x),(t(o)&&(Yt(e,o.alwaysSites)||x!==void 0&&Ol(x,o.alwaysLangs)||o.autoTranslate&&await kr(o.targetLang))||await N({type:"tab:hello"}).catch(()=>!1))&&await i.startPage()}}}function Bl(){if(document.contentType!=="text/html"&&document.contentType!=="application/xhtml+xml"||lo()||Tr.__yilanAlive?.())return;Tr.__yilanAlive=Y,dispatchEvent(new Event(Cr));let o=_l();chrome.runtime.onMessage.addListener((e,t,n)=>(o.then(({handle:r})=>r(e,n)),!0)),o.then(({afterReady:e})=>e())}Bl();})();
