"use strict";(()=>{function K(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}var Go={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" "};function ae(o){return o.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi,(e,t)=>{if(t[0]==="#"){let n=t[1]==="x"||t[1]==="X"?parseInt(t.slice(2),16):parseInt(t.slice(1),10);return!Number.isFinite(n)||n<0||n>1114111?e:String.fromCodePoint(n)}return Go[t.toLowerCase()]??e})}var yt=/<\s*(\/?)\s*x\s*(\d{1,4})\s*>/gi;function X(o,e){let t=[],n=[],r=new Set,i=l=>{let c=n.length?n[n.length-1].children:t,d=c[c.length-1];typeof l=="string"&&typeof d=="string"?c[c.length-1]=d+l:c.push(l)},s=[],a=0;yt.lastIndex=0;for(let l=yt.exec(o);l;l=yt.exec(o)){if(l.index>a){let u=ae(o.slice(a,l.index));u&&i(u)}a=l.index+l[0].length;let c=l[1]==="/",d=Number(l[2]);if(c){let u=s.lastIndexOf(d);if(u!==-1){s.splice(u,1);continue}let h=n.map(p=>p.slot).lastIndexOf(d);h!==-1&&(n.length=h)}else{if(r.has(d)||e&&!e.has(d)){s.push(d);continue}r.add(d);let u={slot:d,children:[]};i(u),n.push(u)}}if(a<o.length){let l=ae(o.slice(a));l&&i(l)}return t}function xe(o,e){let t=[];for(let n of o){if(typeof n=="string"){t.push(n);continue}let r=t[t.length-1];typeof r=="string"&&e(n.slot)&&(t[t.length-1]=r.replace(/\s*\n\s*$/," ")),t.push({slot:n.slot,children:xe(n.children,e)})}return t}function re(o){return o.map(e=>typeof e=="string"?e:re(e.children)).join("")}function le(o,e=new Set){for(let t of o)typeof t!="string"&&(e.add(t.slot),le(t.children,e));return e}function F(){try{return!!chrome.runtime?.id}catch{return!1}}async function _(o){return await chrome.runtime.sendMessage(o)}var Xt=[{code:"zh_CN",name:"简体中文",bcp47:"zh-CN"},{code:"zh_TW",name:"繁體中文",bcp47:"zh-TW"},{code:"en",name:"English",bcp47:"en"},{code:"ja",name:"日本語",bcp47:"ja"},{code:"ko",name:"한국어",bcp47:"ko"},{code:"es",name:"Español",bcp47:"es"},{code:"fr",name:"Français",bcp47:"fr"},{code:"de",name:"Deutsch",bcp47:"de"}];var ce=null;function Vt(o){return Xt.some(e=>e.code===o)}var Yt=async o=>{let e=await fetch(chrome.runtime.getURL(`_locales/${o}/messages.json`));return e.ok?await e.json():null};function Jt(o){Yt=o}async function Ko(o){if(!Vt(o))return null;try{return await Yt(o)}catch{return null}}async function vt(o){if(!Vt(o)){ce=null;return}if(ce?.code===o)return;let e=await Ko(o);ce=e?{code:o,messages:e}:null}function Zt(){if(ce)return Xt.find(o=>o.code===ce.code)?.bcp47??"en";try{return chrome.i18n.getUILanguage()}catch{return"en"}}function Xo(o,e){let t=n=>n.replace(/\$(\d)/g,(r,i)=>e[Number(i)-1]??"");return o.message.replace(/\$([A-Za-z0-9_@]+)\$/g,(n,r)=>{let i=o.placeholders?.[r.toLowerCase()];return i?t(i.content):n}).replace(/\$\$/g,"$")}function v(o,...e){let t=ce?.messages[o];if(t)return Xo(t,e);try{return chrome.i18n.getMessage(o,e)||o}catch{return o}}var Pe=["togglePage","toggleMode","marquee","sweep"],Le={togglePage:["Shift","Space","KeyT"],toggleMode:["Shift","Space","KeyD"],marquee:["Shift","Space","KeyS"],sweep:["Shift","Space","KeyX"]},Vo={togglePage:["Alt","Shift","KeyY"],toggleMode:["Alt","Shift","KeyD"]};function Qt(o){let e={...Le,...o};for(let t of Pe){let n=Vo[t];n&&xt(e[t],n)&&(e[t]=Le[t])}return e}var wt=["Ctrl","Alt","Shift","Meta"];function en(o){return/^(Control|Alt|Shift|Meta|OS)(Left|Right)?$/.test(o)}function tn(o){let e={Ctrl:o.ctrlKey,Alt:o.altKey,Shift:o.shiftKey,Meta:o.metaKey};return wt.filter(t=>e[t])}function nn(o){let e=t=>wt.includes(t);return{mods:wt.filter(t=>o.includes(t)),keys:o.filter(t=>!e(t))}}function xt(o,e){return o.length>0&&o.length===e.length&&o.every(t=>e.includes(t))}var Ie="#ffffff",rn="#1f2329",sn="#14171c";function an(o){return o==="dark"?!0:o==="light"?!1:matchMedia("(prefers-color-scheme: dark)").matches}function Et(o){let e=parseInt(o.slice(1),16),t=n=>{let r=n/255;return r<=.03928?r/12.92:((r+.055)/1.055)**2.4};return .2126*t(e>>16&255)+.7152*t(e>>8&255)+.0722*t(e&255)}function He(o,e){let[t,n]=[Et(o),Et(e)].sort((r,i)=>i-r);return(t+.05)/(n+.05)}function De(o,e,t=4){if(He(o,e)>=t)return o;let n=parseInt(o.slice(1),16),[r,i,s]=[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255],a=Math.max(r,i,s),l=Math.min(r,i,s),c=a-l,d=0;c&&(a===r?d=((i-s)/c+6)%6:a===i?d=(s-r)/c+2:d=(r-i)/c+4),d*=60;let u=(a+l)/2,h=c?c/(1-Math.abs(2*u-1)):0,p=m=>{let g=h*Math.min(m,1-m),y=E=>{let x=(E+d/30)%12;return Math.round(255*(m-g*Math.max(-1,Math.min(x-3,9-x,1)))).toString(16).padStart(2,"0")};return`#${y(0)}${y(8)}${y(4)}`},f=Et(e)<.2?.01:-.01;for(let m=u;m>=0&&m<=1;m+=f){let g=p(m);if(He(g,e)>=t)return g}return f>0?"#ffffff":"#000000"}var on=[{id:"blue",color:"#1f77f3",name:"themeBlue"},{id:"red",color:"#ea303f",name:"themeRed"},{id:"orange",color:"#d45105",name:"themeOrange"},{id:"amber",color:"#a27304",name:"themeAmber"},{id:"green",color:"#108d4f",name:"themeGreen"},{id:"teal",color:"#0f8a86",name:"themeTeal"},{id:"violet",color:"#8561f2",name:"themeViolet"},{id:"pink",color:"#e72486",name:"themePink"}];function de(o){return/^#[0-9a-f]{6}$/i.test(o)?o:(on.find(e=>e.id===o)??on[0]).color}var Yo={uiLang:"auto",targetLang:"zh-Hans",sourceLang:"",mode:"dual",dualStyle:"highlight",themeColor:"blue",appearance:"auto",shortcuts:Le,fontScale:100,selectionTrigger:"icon",showOriginalOnHover:!0,unlockCopy:!1,inputTranslate:!1,inputLang:"en",glossary:[],autoTranslate:!1,alwaysSites:[],neverSites:[],alwaysLangs:[],excludeSelectors:"",cacheDays:7};function Jo(o){let e=o.toLowerCase();return e==="zh-tw"||e==="zh-hk"||e==="zh-mo"||e.startsWith("zh-hant")?"zh-Hant":e.startsWith("zh")?"zh-Hans":e.split("-")[0]??"en"}async function St(){let o=await chrome.storage.sync.get(null),e={...Yo,...o,shortcuts:Qt(o.shortcuts)};return o.cacheDays===void 0&&o.persistentCache===!1&&(e.cacheDays=0),o.targetLang||(e.targetLang=Zo()),e}function Zo(){let o=Jo(chrome.i18n.getUILanguage());return Qo.has(o)?o:"en"}function ln(o){chrome.storage.onChanged.addListener((e,t)=>{t==="sync"&&St().then(o)})}function Tt(o,e){return e.some(t=>o===t||o.endsWith(`.${t}`))}var ie=[{code:"zh-Hans",name:"简体中文"},{code:"zh-Hant",name:"繁體中文"},{code:"yue",name:"粵語"},{code:"en",name:"English"},{code:"ja",name:"日本語"},{code:"ko",name:"한국어"},{code:"fr",name:"Français"},{code:"de",name:"Deutsch"},{code:"es",name:"Español"},{code:"pt",name:"Português"},{code:"it",name:"Italiano"},{code:"ru",name:"Русский"},{code:"uk",name:"Українська"},{code:"pl",name:"Polski"},{code:"nl",name:"Nederlands"},{code:"tr",name:"Türkçe"},{code:"ar",name:"العربية"},{code:"hi",name:"हिन्दी"},{code:"vi",name:"Tiếng Việt"},{code:"th",name:"ไทย"},{code:"id",name:"Bahasa Indonesia"}],cn={"zh-Hans":"chinese simplified 简体 中文 汉语 jianti zhongwen","zh-Hant":"chinese traditional 繁体 繁體 中文 fanti zhongwen",yue:"cantonese 粤语 广东话 yueyu guangdonghua",en:"english 英语 英文 yingyu yingwen",ja:"japanese 日语 日文 riyu riwen",ko:"korean 韩语 韩文 朝鲜语 hanyu hanwen",fr:"french 法语 法文 fayu",de:"german 德语 德文 deyu",es:"spanish 西班牙语 xibanya",pt:"portuguese 葡萄牙语 putaoya",it:"italian 意大利语 yidali",ru:"russian 俄语 俄文 eyu",uk:"ukrainian 乌克兰语 wukelan",pl:"polish 波兰语 bolan",nl:"dutch 荷兰语 helan",tr:"turkish 土耳其语 tuerqi",ar:"arabic 阿拉伯语 alabo",hi:"hindi 印地语 yindi",vi:"vietnamese 越南语 yuenan",th:"thai 泰语 taiyu",id:"indonesian 印尼语 印度尼西亚语 yinni"},Qo=new Set(ie.map(o=>o.code));var er=[.1,.35,.65,.9];function tr(o){for(let e=o;e&&e!==document.body&&e!==document.documentElement;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return e;return null}function nr(o){let e=null;for(let t=o;t&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t),r=parseInt(n.zIndex,10);n.position!=="static"&&!Number.isNaN(r)&&(e=r)}return e}function dn(o){let e=new Set;for(let t of er)for(let n of document.elementsFromPoint(innerWidth*t,o)){if(n.localName==="yl-ui")continue;let r=tr(n);r&&r.getBoundingClientRect().height<innerHeight*.45&&e.add(r);break}return Array.from(e)}function Ee(){let o=new Set,e=0;for(let r=0;r<2;r++)for(let i of dn(e+2))o.add(i),e=Math.max(e,i.getBoundingClientRect().bottom);let t=innerHeight;for(let r of dn(t-2))o.add(r),t=Math.min(t,r.getBoundingClientRect().top);let n=null;for(let r of o){let i=nr(r);if(i===null)return{top:e,bottom:t,stacking:null};n=n===null?i:Math.min(n,i)}return{top:e,bottom:t,stacking:n}}function _e(o,e,t){if(e<=0&&t>=innerHeight){o.style.clipPath="";return}let n=o.getBoundingClientRect(),r=i=>Number.isFinite(i)?i:-9999;o.style.clipPath=`inset(${r(e-n.top)}px -9999px ${r(n.bottom-t)}px -9999px)`}var Oe=`/* Thin gradient edges in the full palette on clean, light surfaces. */\r
:host {\r
  --ink: #000000;\r
  --paper: #ffffff;\r
  --muted: #666b73;\r
  --line: rgba(20, 30, 50, 0.1);\r
  --hover: color-mix(in srgb, var(--yl-theme) 8%, var(--paper));\r
  --shadow: 0 8px 28px rgba(20, 40, 80, 0.13), 0 1px 3px rgba(20, 40, 80, 0.08);\r
  --ease: cubic-bezier(0.2, 0.8, 0.2, 1);\r
  --spring: cubic-bezier(0.34, 1.56, 0.64, 1);\r
  --edge: linear-gradient(115deg, #4da2ff, #55db9c 35%, #ffd731 62%, #fb4903 85%, #5c4ade);\r
  --yl-theme: #1f77f3;\r
  --yl-on-theme: #ffffff;\r
  --sky: color-mix(in srgb, var(--yl-theme) 13%, var(--paper));\r
  --glass: rgba(255, 255, 255, 0.7);\r
  --error: #c43a02;\r
}\r
\r
:host([data-appearance='dark']) {\r
  --ink: #eef0f3;\r
  --paper: #1f2329;\r
  --muted: #9aa3ae;\r
  --line: rgba(255, 255, 255, 0.1);\r
  --hover: color-mix(in srgb, var(--yl-theme) 12%, var(--paper));\r
  --shadow: 0 8px 28px rgba(0, 0, 0, 0.28), 0 1px 3px rgba(0, 0, 0, 0.2);\r
  --sky: color-mix(in srgb, var(--yl-theme) 14%, var(--paper));\r
  --glass: rgba(255, 255, 255, 0.1);\r
  --error: #ff8a5c;\r
}\r
\r
* {\r
  box-sizing: border-box;\r
}\r
\r
.layer {\r
  position: fixed;\r
  font: 400 13px/1.45 Inter, 'Segoe UI', system-ui, -apple-system, 'Microsoft YaHei', sans-serif;\r
  color: var(--ink);\r
  pointer-events: auto;\r
}\r
\r
/* ---- selection ------------------------------------------------------------ */\r
\r
/* Holds nothing itself: its parts are placed on the screen. */\r
.bubble {\r
  top: 0;\r
  left: 0;\r
  width: 0;\r
  height: 0;\r
  pointer-events: none;\r
}\r
\r
.bubble-ring {\r
  position: absolute;\r
  top: 0;\r
  left: 0;\r
  width: 1px;\r
  height: 1px;\r
  overflow: visible;\r
  pointer-events: none;\r
}\r
\r
.bubble-ring path {\r
  fill: none;\r
  stroke-width: 2;\r
  stroke-linejoin: round;\r
  filter: drop-shadow(0 1px 3px rgba(20, 40, 80, 0.18));\r
}\r
\r
/* Drawn once, as the selection is made. It stays as it is when the card takes the button's place. */\r
.bubble .bubble-ring path {\r
  stroke-dasharray: 1;\r
  animation: ring-draw 0.34s var(--ease);\r
}\r
\r
/* The bar holding the actions, which the bubble's tail points at. */\r
.bubble-tab {\r
  position: absolute;\r
  display: inline-flex;\r
  gap: 2px;\r
  padding: 3px;\r
  border-radius: 11px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  pointer-events: auto;\r
  animation: fade-in 0.18s var(--ease) 0.14s both;\r
}\r
\r
@keyframes ring-draw {\r
  from {\r
    stroke-dashoffset: 1;\r
  }\r
}\r
\r
.bubble-action {\r
  height: 28px;\r
  padding: 0 11px 0 8px;\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 5px;\r
  border: 0;\r
  border-radius: 8px;\r
  background: var(--yl-theme);\r
  color: var(--yl-on-theme);\r
  font-size: 13px;\r
  font-weight: 500;\r
  white-space: nowrap;\r
  cursor: pointer;\r
  transition: filter 0.15s, transform 0.15s var(--spring);\r
}\r
\r
.bubble-action svg {\r
  width: 16px;\r
  height: 16px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.bubble-action:hover {\r
  filter: brightness(1.1);\r
}\r
\r
.bubble-action:active {\r
  transform: scale(0.96);\r
}\r
\r
.card {\r
  width: 480px;\r
  max-width: calc(100vw - 16px);\r
  overflow: hidden;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  animation: enter 0.22s var(--ease);\r
}\r
\r
/* Fades in without moving: while it rose into place, it could not be measured for where it is. */\r
.card[data-on-page] {\r
  z-index: 1;\r
  animation-name: fade-in;\r
}\r
\r
/* The ring round the text, while its card is open. */\r
.source-ring {\r
  width: 1px;\r
  height: 1px;\r
  pointer-events: none;\r
}\r
\r
/* Translating: dotted, and whole once the translation is in. */\r
.source-ring[data-pending] path {\r
  stroke-width: 2.6;\r
  stroke-linecap: round;\r
  stroke-dasharray: 0 7px;\r
}\r
\r
/* Where the card is held to move it: a short bar across its top. */\r
.card-grip {\r
  height: 14px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  cursor: grab;\r
  touch-action: none;\r
}\r
\r
.card-grip::before {\r
  content: '';\r
  width: 34px;\r
  height: 4px;\r
  border-radius: 2px;\r
  background: var(--line);\r
  transition: background-color 0.15s, width 0.15s var(--ease);\r
}\r
\r
.card-grip:hover::before,\r
.card[data-dragging] .card-grip::before {\r
  width: 42px;\r
  background: color-mix(in srgb, var(--yl-theme) 55%, var(--line));\r
}\r
\r
.card[data-dragging] {\r
  user-select: none;\r
}\r
\r
.card[data-dragging] .card-grip {\r
  cursor: grabbing;\r
}\r
\r
.card-grip + .card-body {\r
  padding-top: 2px;\r
}\r
\r
.card-body {\r
  max-height: 320px;\r
  overflow-y: auto;\r
  scrollbar-width: thin;\r
  scrollbar-color: rgba(20, 30, 50, 0.18) transparent;\r
  padding: 12px 14px 10px;\r
}\r
\r
.card-source {\r
  /* No padding or border here: a clamped box shows its next line through its own padding. */\r
  margin-bottom: 10px;\r
  color: var(--muted);\r
  display: -webkit-box;\r
  -webkit-box-orient: vertical;\r
  -webkit-line-clamp: 2;\r
  overflow: hidden;\r
  overflow-wrap: anywhere;\r
}\r
\r
.card-result {\r
  padding-top: 10px;\r
  border-top: 1px solid var(--line);\r
  font-size: 14px;\r
  white-space: pre-wrap;\r
  overflow-wrap: anywhere;\r
  user-select: text;\r
}\r
\r
/* The word being read. */\r
.card-word {\r
  border-radius: 3px;\r
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 26%, transparent);\r
  color: inherit;\r
}\r
\r
/* Reading: the button stays lit, and a stop square replaces the speaker. */\r
.icon-btn[data-on],\r
.icon-btn[data-on]:hover {\r
  background: color-mix(in srgb, var(--yl-theme, #1f77f3) 14%, transparent);\r
  color: var(--yl-theme, #1f77f3);\r
}\r
\r
.icon-btn[data-on] svg {\r
  fill: currentColor;\r
}\r
\r
/* Between parts, one thin line, drawn apart from the part so its rounded corners do not bend it. */\r
.card-seg {\r
  position: relative;\r
}\r
\r
.card-seg + .card-seg {\r
  margin-top: 11px;\r
}\r
\r
.card-seg + .card-seg::before {\r
  content: '';\r
  position: absolute;\r
  top: -6px;\r
  left: 6px;\r
  right: 6px;\r
  border-top: 1px solid var(--line);\r
}\r
\r
.card-seg[data-jump] .card-source {\r
  margin-bottom: 4px;\r
}\r
\r
.card-seg[data-jump] .card-result {\r
  padding-top: 0;\r
  border-top: 0;\r
}\r
\r
\r
.card-seg[data-jump] {\r
  margin-left: -6px;\r
  margin-right: -6px;\r
  padding: 4px 6px;\r
  border-radius: 8px;\r
  cursor: pointer;\r
  transition: background-color 0.15s;\r
}\r
\r
.card-seg[data-jump]:hover {\r
  background-color: var(--hover);\r
}\r
\r
/* Shows where a part of the card came from, for a moment. */\r
.source-flash {\r
  top: 0;\r
  left: 0;\r
  width: 0;\r
  height: 0;\r
  pointer-events: none;\r
}\r
\r
.source-flash-line {\r
  position: absolute;\r
  border-radius: 4px;\r
  background: color-mix(in srgb, var(--yl-theme) 32%, transparent);\r
  animation: flash-out 1.1s var(--ease) forwards;\r
}\r
\r
@keyframes flash-out {\r
  0%,\r
  45% {\r
    opacity: 1;\r
  }\r
  100% {\r
    opacity: 0;\r
  }\r
}\r
\r
.card-result[data-state='loading'] {\r
  color: var(--muted);\r
}\r
\r
.card-result[data-state='error'] {\r
  color: var(--error);\r
}\r
\r
/* Adding to the glossary, in the card itself. */\r
.card-glossary {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  padding: 8px 14px;\r
  border-top: 1px solid var(--line);\r
}\r
\r
.card-glossary-input {\r
  flex: 1;\r
  min-width: 0;\r
  height: 28px;\r
  padding: 0 8px;\r
  border-radius: 7px;\r
  border: 1px solid var(--line);\r
  background: var(--paper);\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  outline: none;\r
}\r
\r
.card-glossary-input:focus {\r
  border-color: var(--yl-theme);\r
}\r
\r
.card-glossary-arrow {\r
  color: var(--muted);\r
}\r
\r
.card-glossary-save {\r
  height: 28px;\r
  padding: 0 12px;\r
  border: 0;\r
  border-radius: 7px;\r
  background: var(--yl-theme);\r
  color: var(--yl-on-theme);\r
  font: inherit;\r
  font-size: 13px;\r
  font-weight: 500;\r
  cursor: pointer;\r
}\r
\r
/* The translation of a field, before anything in it changes. */\r
.write-pop {\r
  position: relative;\r
  display: flex;\r
  flex-direction: column;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  overflow: hidden;\r
  animation: fade-in 0.16s var(--ease);\r
}\r
\r
/* In the corner, over the text's padding: no row of its own. */\r
.write-close {\r
  position: absolute;\r
  top: 4px;\r
  right: 4px;\r
}\r
\r
.write-foot .grow {\r
  flex: 1;\r
}\r
\r
.write-lang {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 6px;\r
  height: 30px;\r
  padding: 0 10px;\r
  border: 0;\r
  border-radius: 8px;\r
  background: var(--sky);\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  font-weight: 500;\r
  cursor: pointer;\r
}\r
\r
.write-lang:hover {\r
  background: color-mix(in srgb, var(--yl-theme) 20%, var(--paper));\r
}\r
\r
/* Part of the field or all of it. */\r
.write-scope {\r
  display: inline-flex;\r
  height: 30px;\r
  padding: 2px;\r
  border-radius: 8px;\r
  background: var(--sky);\r
}\r
\r
.write-scope button {\r
  padding: 0 9px;\r
  border: 0;\r
  border-radius: 6px;\r
  background: transparent;\r
  color: var(--muted);\r
  font: inherit;\r
  font-size: 12.5px;\r
  white-space: nowrap;\r
  cursor: pointer;\r
}\r
\r
.write-scope button:hover {\r
  color: var(--ink);\r
}\r
\r
.write-scope button[aria-checked='true'] {\r
  background: var(--paper);\r
  color: var(--ink);\r
  font-weight: 500;\r
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);\r
}\r
\r
.write-scope button:focus-visible {\r
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);\r
}\r
\r
.write-chevron {\r
  width: 6px;\r
  height: 6px;\r
  margin-top: -3px;\r
  border-right: 1.5px solid currentColor;\r
  border-bottom: 1.5px solid currentColor;\r
  transform: rotate(45deg);\r
  opacity: 0.6;\r
}\r
\r
.write-result {\r
  max-height: 220px;\r
  overflow-y: auto;\r
  padding: 12px 38px 12px 14px;\r
  font-size: 14px;\r
  line-height: 1.55;\r
  white-space: pre-wrap;\r
  overflow-wrap: anywhere;\r
  user-select: text;\r
}\r
\r
.write-result:focus {\r
  outline: none;\r
}\r
\r
.write-result[data-state='loading'] {\r
  color: var(--muted);\r
}\r
\r
.write-result[data-state='error'] {\r
  color: var(--error);\r
}\r
\r
.write-foot {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  padding: 8px 10px 10px;\r
  border-top: 1px solid var(--line);\r
}\r
\r
.write-copy,\r
.write-replace {\r
  height: 30px;\r
  padding: 0 14px;\r
  border-radius: 8px;\r
  font: inherit;\r
  font-size: 13px;\r
  cursor: pointer;\r
}\r
\r
.write-copy {\r
  border: 1px solid var(--line);\r
  background: var(--paper);\r
  color: var(--ink);\r
}\r
\r
.write-copy:hover {\r
  background: var(--hover);\r
}\r
\r
.write-replace {\r
  border: 0;\r
  background: var(--yl-theme);\r
  color: var(--yl-on-theme);\r
  font-weight: 500;\r
}\r
\r
.write-replace:focus-visible,\r
.write-copy:focus-visible,\r
.write-lang:focus-visible {\r
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);\r
  outline-offset: 1px;\r
}\r
\r
.write-copy:disabled,\r
.write-replace:disabled {\r
  opacity: 0.5;\r
  cursor: default;\r
}\r
\r
.lang-menu-item[data-current]::after {\r
  content: '✓';\r
  float: right;\r
  color: var(--yl-theme);\r
}\r
\r
/* Which language to write in, this once. */\r
.lang-menu {\r
  width: 240px;\r
  display: flex;\r
  flex-direction: column;\r
  padding: 6px;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  animation: fade-in 0.14s var(--ease);\r
}\r
\r
.lang-menu-search {\r
  height: 32px;\r
  margin-bottom: 4px;\r
  padding: 0 10px;\r
  border-radius: 8px;\r
  border: 1px solid var(--line);\r
  background: var(--paper);\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  outline: none;\r
}\r
\r
.lang-menu-search:focus {\r
  border-color: var(--yl-theme);\r
}\r
\r
.lang-menu-list {\r
  max-height: 228px;\r
  overflow-y: auto;\r
  scrollbar-width: thin;\r
}\r
\r
.lang-menu-item {\r
  display: block;\r
  width: 100%;\r
  padding: 6px 10px;\r
  border: 0;\r
  border-radius: 7px;\r
  background: transparent;\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 13px;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
\r
.lang-menu-item:hover,\r
.lang-menu-item[data-active] {\r
  background: var(--hover);\r
}\r
\r
.lang-menu-item[data-active] {\r
  color: var(--yl-theme);\r
  font-weight: 500;\r
}\r
\r
.lang-menu-empty {\r
  padding: 10px;\r
  color: var(--muted);\r
  font-size: 13px;\r
}\r
\r
/* While a field is being translated. */\r
.input-busy {\r
  padding: 3px 9px;\r
  border-radius: 999px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  font-size: 12px;\r
  color: var(--muted);\r
  pointer-events: none;\r
  animation: fade-in 0.15s var(--ease);\r
}\r
\r
.card-foot {\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  padding: 4px 6px 4px 14px;\r
  border-top: 1px solid var(--line);\r
  color: var(--muted);\r
  font-size: 12px;\r
}\r
\r
.card-foot .grow {\r
  flex: 1;\r
  min-width: 0;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
/* "English → 简体中文": the language translated into can be changed for this card. */\r
.card-langs {\r
  display: flex;\r
  align-items: center;\r
}\r
\r
.card-from {\r
  flex: none;\r
}\r
\r
.card-lang {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 5px;\r
  min-width: 0;\r
  height: 22px;\r
  margin-left: -2px;\r
  padding: 0 6px;\r
  border: 0;\r
  border-radius: 6px;\r
  background: transparent;\r
  color: var(--ink);\r
  font: inherit;\r
  font-weight: 500;\r
  cursor: pointer;\r
}\r
\r
/* Alone in the foot, its text lines up where the label's did. */\r
.card-from:empty + .card-lang {\r
  margin-left: -6px;\r
}\r
\r
.card-lang span {\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
.card-lang:hover,\r
.card-lang[aria-expanded='true'] {\r
  background: var(--sky);\r
}\r
\r
.card-lang:focus-visible {\r
  outline: 2px solid color-mix(in srgb, var(--yl-theme) 45%, transparent);\r
}\r
\r
.card-lang-chevron {\r
  flex: none;\r
  width: 5px;\r
  height: 5px;\r
  margin-top: -3px;\r
  border-right: 1.5px solid currentColor;\r
  border-bottom: 1.5px solid currentColor;\r
  transform: rotate(45deg);\r
  opacity: 0.55;\r
}\r
\r
.icon-btn {\r
  width: 28px;\r
  height: 28px;\r
  padding: 0;\r
  display: grid;\r
  place-items: center;\r
  flex: none;\r
  border: 0;\r
  border-radius: 7px;\r
  background: transparent;\r
  color: var(--muted);\r
  cursor: pointer;\r
  transition: background-color 0.15s, color 0.15s, transform 0.15s var(--spring);\r
}\r
\r
.icon-btn:hover {\r
  background: var(--hover);\r
  color: var(--ink);\r
}\r
\r
.icon-btn:active {\r
  transform: scale(0.9);\r
}\r
\r
.icon-btn svg {\r
  width: 15px;\r
  height: 15px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 1.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.tooltip {\r
  max-width: 420px;\r
  padding: 7px 10px;\r
  border-radius: 8px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  overflow-wrap: anywhere;\r
  pointer-events: none;\r
  animation: enter 0.16s var(--ease);\r
}\r
\r
.toast {\r
  left: 50%;\r
  bottom: 28px;\r
  translate: -50% 0;\r
  max-width: min(480px, calc(100vw - 32px));\r
  display: flex;\r
  align-items: center;\r
  gap: 12px;\r
  padding: 9px 14px;\r
  border-radius: 10px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  animation: rise 0.22s var(--ease);\r
}\r
\r
.toast button {\r
  flex: none;\r
  padding: 0;\r
  border: 0;\r
  background: none;\r
  color: var(--ink);\r
  font: inherit;\r
  font-weight: 500;\r
  text-decoration: underline;\r
  cursor: pointer;\r
}\r
\r
/* ---- frame ---------------------------------------------------------------- */\r
\r
.region-box {\r
  border-radius: 10px;\r
  pointer-events: none;\r
}\r
\r
/* Drawn as a stroke, so all four sides have one width at any screen scale. */\r
.flow-ring {\r
  position: absolute;\r
  overflow: visible;\r
  pointer-events: none;\r
}\r
\r
.flow-line {\r
  fill: none;\r
}\r
\r
/* Waiting for the translation: the frame breathes. */\r
.region-box[data-pending] .flow-ring {\r
  animation: frame-wait 0.9s ease-in-out infinite alternate;\r
}\r
\r
/* ---- scan card ------------------------------------------------------------ */\r
\r
.scan-card {\r
  display: flex;\r
  flex-direction: column;\r
  max-width: calc(100vw - 16px);\r
  overflow: hidden;\r
  border-radius: 12px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
}\r
\r
.scan-immersive {\r
  animation: enter 0.24s var(--ease);\r
}\r
\r
/* What scrolls passes under the head, which stands clear of it. */\r
.scan-immersive .scan-head {\r
  position: relative;\r
  z-index: 1;\r
  box-shadow: 0 1px 0 var(--line), 0 6px 12px -8px rgba(20, 30, 50, 0.35);\r
}\r
\r
.scan-card[data-exporting] {\r
  pointer-events: none;\r
}\r
\r
/* While the picture is made. Turning needs nothing from the page, which is busy drawing. */\r
.scan-making {\r
  position: absolute;\r
  inset: 0;\r
  z-index: 2;\r
  display: grid;\r
  place-items: center;\r
  background: color-mix(in srgb, var(--paper) 62%, transparent);\r
  animation: fade-in 0.16s var(--ease);\r
}\r
\r
.scan-making-note {\r
  display: flex;\r
  align-items: center;\r
  gap: 10px;\r
  padding: 10px 16px;\r
  border-radius: 10px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  color: var(--ink);\r
  font-size: 13px;\r
}\r
\r
.scan-making-spin {\r
  width: 14px;\r
  height: 14px;\r
  border-radius: 50%;\r
  border: 2px solid color-mix(in srgb, var(--yl-theme) 22%, transparent);\r
  border-top-color: var(--yl-theme);\r
  animation: making-turn 0.7s linear infinite;\r
}\r
\r
@keyframes making-turn {\r
  to {\r
    transform: rotate(360deg);\r
  }\r
}\r
\r
/* Being photographed, the slow way: nothing on the result that is not the result, and square\r
   and flat, or every screen brings its rounded corners and shadow into the joins. */\r
.scan-card[data-photographing] .scan-track,\r
.scan-card[data-photographing] .scan-making {\r
  visibility: hidden;\r
}\r
\r
.scan-card[data-photographing] {\r
  border-radius: 0;\r
  background: var(--paper);\r
  box-shadow: none;\r
}\r
\r
.scan-card[data-photographing] .scan-head {\r
  box-shadow: none;\r
}\r
\r
.scan-closing {\r
  animation: leave 0.17s var(--ease) forwards !important;\r
  pointer-events: none;\r
}\r
\r
.scan-track {\r
  position: absolute;\r
  top: 0;\r
  right: 0;\r
  bottom: 0;\r
  width: 12px;\r
  cursor: pointer;\r
  touch-action: none;\r
}\r
\r
.scan-thumb {\r
  position: absolute;\r
  top: 0;\r
  right: 3px;\r
  width: 6px;\r
  border-radius: 3px;\r
  background: rgba(20, 30, 50, 0.26);\r
  transition: background-color 0.15s, width 0.15s var(--ease);\r
}\r
\r
.scan-track:hover .scan-thumb {\r
  width: 8px;\r
  background: rgba(20, 30, 50, 0.42);\r
}\r
\r
/* Small until there is something to say. */\r
.scan-find {\r
  flex: none;\r
  display: flex;\r
  align-items: center;\r
  gap: 5px;\r
  width: 148px;\r
  height: 26px;\r
  margin: 0 6px 0 10px;\r
  padding: 0 4px 0 8px;\r
  border: 1px solid var(--line);\r
  border-radius: 7px;\r
  background: var(--paper);\r
  color: var(--muted);\r
  cursor: text;\r
  transition: width 0.2s var(--ease), border-color 0.15s;\r
}\r
\r
.scan-find:focus-within {\r
  border-color: var(--yl-theme);\r
}\r
\r
.scan-find[data-typed] {\r
  width: 214px;\r
}\r
\r
.scan-find > svg {\r
  flex: none;\r
  width: 13px;\r
  height: 13px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 1.6;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.scan-find-input {\r
  flex: 1;\r
  min-width: 0;\r
  height: 100%;\r
  padding: 0;\r
  border: 0;\r
  outline: 0;\r
  background: none;\r
  color: var(--ink);\r
  font: inherit;\r
  font-size: 12px;\r
  user-select: text;\r
}\r
\r
.scan-find-input::placeholder {\r
  color: var(--muted);\r
}\r
\r
.scan-find-count {\r
  flex: none;\r
  display: none;\r
  font-size: 11px;\r
  font-variant-numeric: tabular-nums;\r
}\r
\r
.scan-find .icon-btn {\r
  display: none;\r
  width: 20px;\r
  height: 20px;\r
  border-radius: 5px;\r
}\r
\r
.scan-find .icon-btn svg {\r
  width: 13px;\r
  height: 13px;\r
}\r
\r
.scan-find[data-typed] .scan-find-count,\r
.scan-find[data-found] .icon-btn {\r
  display: grid;\r
}\r
\r
.scan-find[data-typed] .scan-find-count {\r
  display: block;\r
}\r
\r
.scan-find[data-none] .scan-find-count {\r
  color: var(--error);\r
}\r
\r
.scan-animate {\r
  transition: top 0.3s var(--ease), left 0.3s var(--ease), height 0.3s var(--ease), bottom 0.3s var(--ease);\r
}\r
\r
.scan-backdrop {\r
  inset: 0;\r
  /* The page shows only through small holes in a veil, with its colour taken down: tidy on\r
     any page and with any theme colour. The same recipe as element-plus.org's navigation. */\r
  background-image: radial-gradient(transparent 1px, var(--paper) 1px);\r
  background-size: 4px 4px;\r
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(1.7);\r
  -webkit-backdrop-filter: var(--veil);\r
  backdrop-filter: var(--veil);\r
  animation: fade-in 0.28s var(--ease);\r
}\r
\r
/* A light page through a dark veil is a harsh grid unless the page comes down to its level. */\r
:host([data-appearance='dark']) .scan-backdrop {\r
  --veil: saturate(0.5) blur(4px) contrast(0.4) brightness(0.4);\r
}\r
\r
/* Only ever seen at full screen. */\r
.scan-card[data-hidden] {\r
  visibility: hidden;\r
  pointer-events: none;\r
}\r
\r
.scan-bar {\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  height: 36px;\r
  padding: 0 4px 0 12px;\r
  border: 1.5px solid transparent;\r
  border-radius: 10px;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  font-size: 12px;\r
  white-space: nowrap;\r
  animation: enter 0.2s var(--ease);\r
}\r
\r
.scan-bar .grow {\r
  margin-right: 8px;\r
}\r
\r
.scan-head {\r
  cursor: default;\r
}\r
\r
.scan-grip {\r
  position: absolute;\r
  z-index: 2;\r
  top: 0;\r
  left: 0;\r
  right: 0;\r
  height: 6px;\r
  cursor: ns-resize;\r
  touch-action: none;\r
}\r
\r
.scan-head {\r
  flex: none;\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  height: 36px;\r
  padding: 0 6px 0 14px;\r
  background: var(--sky);\r
  color: var(--ink);\r
  font-size: 12px;\r
  user-select: none;\r
}\r
\r
.scan-head .icon-btn {\r
  color: var(--ink);\r
}\r
\r
.scan-head .icon-btn:hover {\r
  background: var(--glass);\r
}\r
\r
.scan-head .grow {\r
  flex: 1 1 0;\r
  min-width: 0;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
/* Shows a copy of the page, whose text assumes the page's own background. */\r
.scan-body {\r
  background: #fff;\r
  position: relative;\r
  flex: 1;\r
  min-height: 0;\r
  overflow: hidden;\r
}\r
\r
.scan-body iframe {\r
  position: absolute;\r
  border: 0;\r
  background: transparent;\r
}\r
\r
/* ---- marquee -------------------------------------------------------------- */\r
\r
.marquee-shade {\r
  inset: 0;\r
  cursor: crosshair;\r
  background: rgba(20, 40, 80, 0.05);\r
  touch-action: none;\r
  user-select: none;\r
  animation: fade-in 0.15s var(--ease);\r
}\r
\r
.marquee-hint {\r
  left: 50%;\r
  top: 16px;\r
  translate: -50% 0;\r
  padding: 6px 12px;\r
  border-radius: 8px;\r
  border: 1.5px solid transparent;\r
  background: linear-gradient(var(--paper), var(--paper)) padding-box, var(--edge) border-box;\r
  box-shadow: var(--shadow);\r
  white-space: nowrap;\r
  pointer-events: none;\r
  animation: rise 0.2s var(--ease);\r
}\r
\r
.leaving {\r
  animation: leave 0.16s var(--ease) forwards !important;\r
  pointer-events: none;\r
}\r
\r
@keyframes frame-wait {\r
  to {\r
    opacity: 0.5;\r
  }\r
}\r
\r
@keyframes enter {\r
  from {\r
    opacity: 0;\r
    transform: translateY(6px) scale(0.985);\r
  }\r
}\r
\r
@keyframes leave {\r
  to {\r
    opacity: 0;\r
    transform: translateY(4px) scale(0.985);\r
  }\r
}\r
\r
@keyframes pop {\r
  from {\r
    opacity: 0;\r
    transform: scale(0.7);\r
  }\r
}\r
\r
@keyframes rise {\r
  from {\r
    opacity: 0;\r
    transform: translateY(6px);\r
  }\r
}\r
\r
@keyframes fade-in {\r
  from {\r
    opacity: 0;\r
  }\r
}\r
\r
@media (prefers-reduced-motion: reduce) {\r
  * {\r
    animation-duration: 0.01ms !important;\r
    transition-duration: 0.01ms !important;\r
  }\r
}\r
`;var Z="http://www.w3.org/2000/svg",rr=2,ir=3,sr=12,Se=[["0","#4da2ff"],["0.35","#55db9c"],["0.62","#ffd731"],["0.85","#fb4903"],["1","#5c4ade"]],ar=0,kt=2147483646;function Mt(o){for(let e of["keydown","keyup","keypress"])o.addEventListener(e,t=>t.stopPropagation())}function B(o){let e=devicePixelRatio||1;return Math.round(o*e)/e}var lr={copy:["M9 9h10v11H9z","M5 15V4h10"],speak:["M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z","M15.5 9a4 4 0 0 1 0 6","M18 6.5a8 8 0 0 1 0 11"],close:["M6 6l12 12","M18 6L6 18"],stop:["M7 7h10v10H7z"],check:["M5 12.5l4.5 4.5L19 7.5"],expand:["M4 9V4h5","M20 9V4h-5","M4 15v5h5","M20 15v5h-5"],collapse:["M9 4v5H4","M15 4v5h5","M9 20v-5H4","M15 20v-5h5"],search:["M11 5a6 6 0 1 1 0 12a6 6 0 0 1 0-12z","M15.5 15.5L20 20"],up:["M6 15l6-6 6 6"],down:["M6 9l6 6 6-6"],image:["M4 5h16v14H4z","M4 16l5-5 4 4 3-3 4 4","M15.5 8.5h.01"],download:["M12 4v11","M7.5 11L12 15.5 16.5 11","M5 19.5h14"],glossary:["M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z","M5 19.5A1.5 1.5 0 0 0 6.5 21H19","M12 7.5v6","M9 10.5h6"],translate:["M4 5h7","M9 3v2c0 4.418-2.239 8-5 8","M5 9c0 2.144 2.952 3.908 6.7 4","M12 20l4-9 4 9","M19.1 18h-6.2"]};function ue(o){let e=document.createElementNS(Z,"svg");e.setAttribute("viewBox","0 0 24 24");for(let t of lr[o]){let n=document.createElementNS(Z,"path");n.setAttribute("d",t),e.append(n)}return e}function w(o,e,t){let n=document.createElement(o);return n.className=e,t!==void 0&&(n.textContent=t),n}function $(o,e,t){let n=w("button","icon-btn");return n.type="button",n.title=e,n.setAttribute("aria-label",e),n.append(ue(o)),n.addEventListener("click",t),n}var Be=class{host;root;toastEl;toastTimer;theme;dark=!1;pageHost;pageRoot;overHost;overRoot;tooltipEl;setTheme(e,t){this.theme=e,this.dark=t;for(let n of[this.host,this.pageHost,this.overHost])n&&this.paint(n)}settleUnderBars(){let e=Ee(),t=e.stacking!==null&&e.stacking>1;return this.pageHost&&(this.pageHost.style.zIndex=String(t?e.stacking-1:kt)),t?{top:-1/0,bottom:1/0}:{top:e.top>0?e.top:-1/0,bottom:e.bottom<innerHeight?e.bottom:1/0}}paint(e){this.theme&&(e.style.setProperty("--yl-theme",this.theme),e.style.setProperty("--yl-on-theme",He("#ffffff",this.theme)>=3?"#ffffff":"#14161b")),e.dataset.appearance=this.dark?"dark":"light"}get hostElement(){return this.host}isHost(e){return!!e&&(e===this.host||e===this.pageHost||e===this.overHost)}ownsEvent(e){return e.composedPath().some(t=>t===this.host||t===this.pageHost||t===this.overHost)}ensurePage(){if(this.pageRoot&&this.pageHost?.isConnected)return this.pageRoot;this.pageHost=document.createElement("yl-ui"),this.pageHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${kt};`,this.paint(this.pageHost),Mt(this.pageHost),this.pageRoot=this.pageHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=Oe,this.pageRoot.append(e),document.documentElement.append(this.pageHost),this.pageRoot}ensureOver(){if(this.overRoot&&this.overHost?.isConnected)return this.overRoot;this.overHost=document.createElement("yl-ui"),this.overHost.style.cssText=`all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:${kt};`,this.paint(this.overHost),Mt(this.overHost),this.overRoot=this.overHost.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=Oe,this.overRoot.append(e),document.documentElement.append(this.overHost),this.overRoot}addToPage(e,t=!1){return e.classList.add("layer"),e.style.position="absolute",(t?this.ensureOver():this.ensurePage()).append(e),e}ensure(){if(this.root&&this.host?.isConnected)return this.root;this.host=document.createElement("yl-ui"),this.host.style.cssText="all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",this.paint(this.host),Mt(this.host),this.root=this.host.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=Oe,this.root.append(e),document.documentElement.append(this.host),this.root}add(e){return e.classList.add("layer"),this.ensure().append(e),e}addBelow(e,t){return e.classList.add("layer"),t.parentNode?.insertBefore(e,t),e}place(e,t,n=8,r){let{left:i,top:s}=this.spot(e,t,n,r);e.style.left=`${i}px`,e.style.top=`${s}px`}spot(e,t,n=8,r){let i=e.offsetWidth,s=e.offsetHeight,a=Ee(),l=Math.max(a.top,r?.top??0)+8,c=Math.min(a.bottom,r?.bottom??innerHeight)-8,d=Math.max(8,Math.min(t.left,innerWidth-i-8)),u=t.bottom+n;return u+s>c&&(u=t.top-s-n),{left:d,top:Math.max(l,Math.min(u,c-s))}}ring(e){let t=document.createElementNS(Z,"svg");t.setAttribute("class","flow-ring"),t.setAttribute("aria-hidden","true");let n=`yl-edge-${++ar}`,r=document.createElementNS(Z,"defs"),i=document.createElementNS(Z,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[u,h]of Se){let p=document.createElementNS(Z,"stop");p.setAttribute("offset",u),p.setAttribute("stop-color",h),i.append(p)}if(!matchMedia("(prefers-reduced-motion: reduce)").matches){let u=document.createElementNS(Z,"animateTransform");u.setAttribute("attributeName","gradientTransform"),u.setAttribute("type","rotate"),u.setAttribute("from","0 0.5 0.5"),u.setAttribute("to","360 0.5 0.5"),u.setAttribute("dur","6s"),u.setAttribute("repeatCount","indefinite"),i.append(u)}r.append(i);let s=Math.max(1/(devicePixelRatio||1),B(rr)),a=B(ir);t.style.left=t.style.top=`${-a}px`,t.style.width=`calc(100% + ${a*2}px)`,t.style.height=`calc(100% + ${a*2}px)`;let c=(u=>{let h=document.createElementNS(Z,"rect");return h.setAttribute("class",u),h.setAttribute("x",String(s/2)),h.setAttribute("y",String(s/2)),h.setAttribute("stroke-width",String(s)),h.setAttribute("rx",String(sr)),h})("flow-line");c.setAttribute("stroke",`url(#${n})`),t.append(r,c),e.append(t);let d=()=>{let u=e.getBoundingClientRect(),h=Math.max(0,u.width+a*2-s),p=Math.max(0,u.height+a*2-s);c.setAttribute("width",String(h)),c.setAttribute("height",String(p))};new ResizeObserver(d).observe(e),d()}addFrame(e=!1,t=!1,n=!1){let r=w("div","region-box");return e&&(r.dataset.pending=""),t?this.addToPage(r,n):this.add(r),this.ring(r),r}setFramePending(e,t){t?e.dataset.pending="":delete e.dataset.pending}dismiss(e){if(!e)return;e.classList.add("leaving");let t=()=>e.remove();e.addEventListener("animationend",t,{once:!0}),setTimeout(t,220)}toast(e,t,n=5e3){this.dismiss(this.toastEl),clearTimeout(this.toastTimer);let r=w("div","toast");if(r.setAttribute("role","status"),r.append(w("span","",e)),t){let i=w("button","",t.label);i.type="button",i.addEventListener("click",()=>{r.remove(),t.run()}),r.append(i)}this.toastEl=this.add(r),this.toastTimer=setTimeout(()=>this.dismiss(r),n)}showTooltip(e,t){this.hideTooltip();let n=w("div","tooltip",e);this.tooltipEl=this.add(n),this.place(n,t,6)}hideTooltip(){this.dismiss(this.tooltipEl),this.tooltipEl=void 0}errorMessage(e){return v(`error_${e}`)||v("error_unavailable")}};var Ct=8,un=o=>ie.find(e=>e.code===o)?.name??o;function $e(o,e,t,n,r){let i=w("div","lang-menu");i.setAttribute("role","dialog"),i.setAttribute("aria-label",n);let s=w("input","lang-menu-search");s.placeholder=v("searchLanguage");let a=w("div","lang-menu-list");a.setAttribute("role","listbox"),i.append(s,a),o.add(i);let l=[],c=Math.max(0,ie.findIndex(x=>x.code===t)),d=()=>{let x=s.value.trim().toLowerCase(),S=M=>!x||un(M).toLowerCase().includes(x)||M.toLowerCase().startsWith(x)||(cn[M]??"").includes(x);l=ie.map(M=>M.code).filter(S),c=Math.min(c,Math.max(0,l.length-1)),a.replaceChildren(...l.map((M,I)=>{let P=w("button","lang-menu-item",un(M));return P.type="button",P.toggleAttribute("data-active",I===c),P.toggleAttribute("data-current",M===t),P.addEventListener("mousedown",D=>D.preventDefault()),P.addEventListener("click",()=>m(M)),P})),l.length||a.append(w("div","lang-menu-empty",v("noLanguage"))),a.children[c]?.scrollIntoView({block:"nearest"})},u=!1,h=()=>u=!0,p=()=>{u=!1,setTimeout(()=>{u||f()})};i.addEventListener("pointerdown",h),addEventListener("pointerdown",p,!0);let f=()=>{removeEventListener("pointerdown",p,!0),i.remove()},m=x=>{f(),r(x)};s.addEventListener("input",()=>{c=0,d()}),s.addEventListener("keydown",x=>{x.key==="ArrowDown"||x.key==="ArrowUp"?(x.preventDefault(),c=(c+(x.key==="ArrowDown"?1:-1)+l.length)%Math.max(1,l.length),d()):x.key==="Enter"?(x.preventDefault(),l[c]&&m(l[c])):x.key==="Escape"&&(x.preventDefault(),x.stopPropagation(),f())}),d();let g=i.offsetHeight,y=i.offsetWidth,E=innerHeight-e.bottom-Ct;return i.style.left=`${Math.max(Ct,Math.min(e.left,innerWidth-y-Ct))}px`,i.style.top=`${E>=g||E>=e.top?e.bottom+4:e.top-g-4}px`,s.focus(),{close:f,isOpen:()=>i.isConnected}}var pn=700,hn=3,cr=5e3,dr=new Set(["","text","search"]),Q=8,ur=300,pr=360,hr=460,mr=o=>ie.find(e=>e.code===o)?.name??o;function fr(o){if(o instanceof HTMLTextAreaElement)return o.readOnly||o.disabled?null:o;if(o instanceof HTMLInputElement)return!dr.has(o.type.toLowerCase())||o.readOnly||o.disabled?null:o;if(o instanceof HTMLElement&&o.isContentEditable){let e=o;for(;e.parentElement?.isContentEditable;)e=e.parentElement;return e}return null}function pe(o){return o instanceof HTMLInputElement||o instanceof HTMLTextAreaElement}function mn(o){return(pe(o)?o.value:o.innerText??"").replace(/[\s ]+$/,"")}function fn(o){return!!o.trim()&&o.length<=cr&&new RegExp("\\p{L}","u").test(o)}function bn(o){let e=getSelection();e?.removeAllRanges(),e?.addRange(o)}function At(o,e,t){let n=o.value.slice(e,t);return{text:n,select(){let r=e;return o.value.slice(e,t)!==n&&(r=o.value.indexOf(n),r<0)?!1:(o.focus(),o.setSelectionRange(r,r+n.length),!0)}}}function Rt(o,e){return{text:e.toString(),select(){return!o.contains(e.commonAncestorContainer)||!e.toString().trim()?!1:(o.focus(),bn(e.cloneRange()),!0)}}}function gr(o){if(pe(o))return{...At(o,0,o.value.length),text:mn(o)};let e=document.createRange();return e.selectNodeContents(o),{...Rt(o,e),text:mn(o)}}function yn(o,e,t){for(;e<t&&/\s/.test(o[e]);)e++;for(;t>e&&/\s/.test(o[t-1]);)t--;return[e,t]}function vn(o){if(pe(o)){let{selectionStart:n,selectionEnd:r}=o;if(n===null||r===null||n===r)return null;let[i,s]=yn(o.value,n,r);return i<s?At(o,i,s):null}let e=getSelection();if(!e?.rangeCount||e.isCollapsed)return null;let t=e.getRangeAt(0);return!o.contains(t.commonAncestorContainer)||!t.toString().trim()?null:Rt(o,t.cloneRange())}function br(o){return vn(o)!==null}function yr(o){if(pe(o)){let n=o.selectionStart;if(n===null)return null;let r=o.value,i=r.lastIndexOf(`
`,n-1)+1,s=r.indexOf(`
`,n),[a,l]=yn(r,i,s<0?r.length:s);return a<l?At(o,a,l):null}let e=getSelection();if(!e?.rangeCount)return null;let t=e.getRangeAt(0).startContainer;if(!o.contains(t))return null;for(;t&&t!==o;t=t.parentNode){if(!(t instanceof HTMLElement))continue;let n=getComputedStyle(t).display;if(n.startsWith("inline")||n==="contents")continue;if(!t.innerText.trim())return null;let r=document.createRange();return r.selectNodeContents(t),Rt(o,r)}return null}function gn(o,e){if(!document.execCommand("insertText",!1,e))if(pe(o))o.setRangeText(e,o.selectionStart??0,o.selectionEnd??o.value.length,"end"),o.dispatchEvent(new Event("input",{bubbles:!0}));else{let t=getSelection()?.getRangeAt(0);t?.deleteContents(),t?.insertNode(document.createTextNode(e))}}function vr(o,e){if(pe(o)){if(o.selectionStart===null)return;let s=o.selectionStart,a=o.value.slice(Math.max(0,s-e),s);a.length===e&&!a.trim()&&(o.setSelectionRange(s-e,s),document.execCommand("delete")||o.setRangeText("",s-e,s,"end"));return}let t=getSelection();if(!t?.rangeCount||!t.isCollapsed)return;let{startContainer:n,startOffset:r}=t.getRangeAt(0);if(!(n instanceof Text)||r<e||!/^[  ]+$/.test(n.data.slice(r-e,r)))return;let i=document.createRange();i.setStart(n,r-e),i.setEnd(n,r),bn(i),document.execCommand("delete")}var Fe=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("keydown",this.onKeyDown,!0)}presses=[];preview;menu;update(e,t){this.settings=e,this.enabled=t,this.active||this.preview?.close(!1)}get active(){return this.enabled&&this.settings.inputTranslate&&F()}onKeyDown=e=>{if(!this.active||this.preview)return;if(e.key!==" "||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||e.repeat){this.release(),this.presses=[];return}let t=fr(e.composedPath()[0]??e.target);if(this.held&&this.held.field!==t&&this.release(),!t)return;let n=performance.now();this.presses=[...this.presses.filter(i=>n-i<pn),n];let r=this.presses.length>=hn;if(r&&(this.presses=[]),this.held||br(t)){if(e.preventDefault(),r){this.forget(),this.openPreview(t);return}let i=(this.held?.count??0)+1;this.forget(),this.held={field:t,count:i,timer:setTimeout(()=>this.release(),pn)},document.addEventListener("pointerdown",this.release,!0);return}r&&(e.preventDefault(),vr(t,hn-1),this.openPreview(t))};held;forget(){this.held&&(clearTimeout(this.held.timer),this.held=void 0,document.removeEventListener("pointerdown",this.release,!0))}release=()=>{let e=this.held;e&&(this.forget(),document.activeElement!==e.field&&!e.field.contains(document.activeElement)&&e.field.focus(),gn(e.field," ".repeat(e.count)))};openPreview(e){let t=gr(e);if(!fn(t.text))return;let n=vn(e),r=n??yr(e);r&&(!fn(r.text)||r.text.trim()===t.text.trim())&&(r=null);let i={part:r,all:t},s=r?"part":"all";this.preview?.close(!1);let a=w("div","write-pop");a.setAttribute("role","dialog"),a.setAttribute("aria-label",v("sectionInput"));let l=w("button","write-lang");l.type="button",l.title=v("inputOtherLanguage"),l.setAttribute("aria-haspopup","listbox");let c=w("span","","");l.append(c,w("i","write-chevron"));let d=$("close",v("close"),()=>C(!0));d.classList.add("write-close");let u=w("div","write-result",v("translating"));u.dataset.state="loading",u.tabIndex=-1;let h=w("div","write-foot"),p=w("button","write-copy",v("copy"));p.type="button";let f=w("button","write-replace",v("writeReplace"));f.type="button",h.append(l);let m=new Map;if(r){let b=w("div","write-scope");b.setAttribute("role","radiogroup");for(let[A,N]of[["part",v(n?"writeScopePicked":"writeScopeLine")],["all",v("writeScopeAll")]]){let q=w("button","",N);q.type="button",q.setAttribute("role","radio"),q.addEventListener("click",()=>{s!==A&&(s=A,g(),P(x))}),m.set(A,q),b.append(q)}h.append(b)}let g=()=>{for(let[b,A]of m)A.setAttribute("aria-checked",String(b===s))};g(),h.append(w("span","grow"),p,f),a.append(d,u,h),this.ui.add(a);let y=new Map,E=()=>i[s].text.trim(),x=this.settings.inputLang,S="",M=0,I=!1,P=async b=>{x=b,c.textContent=mr(b);let A=++M,N=`${s} ${b}`,q=E(),k=y.get(N);if(k!==void 0){D(k);return}S="",u.dataset.state="loading",u.textContent=v("translating"),f.setAttribute("aria-busy","true"),p.disabled=!0,T();try{let L=await _({type:"translate",items:[K(q)],from:"",to:b});if(A!==M||this.preview?.node!==a)return;let O=L?.results?.[0];if(O?.ok){let z=ae(O.text);y.set(N,z),D(z)}else j(this.ui.errorMessage(O?.code??"network"))}catch{A===M&&F()&&j(this.ui.errorMessage("network"))}},D=b=>{if(S=b,delete u.dataset.state,u.textContent=b,f.removeAttribute("aria-busy"),p.disabled=!1,I){U();return}T(),f.focus()},j=b=>{I=!1,f.removeAttribute("aria-busy"),u.dataset.state="error",u.textContent=b,T()},U=()=>{let b=S,A=i[s];C(!1),A.select()?gn(e,b):e.focus()},T=()=>{let b=e.getBoundingClientRect(),N=Math.min(hr,Math.max(r?pr:ur,b.width),innerWidth-Q*2);a.style.width=`${N}px`;let q=a.offsetHeight,k=b.top-q-Q,L=k>=Q?k:Math.min(b.bottom+Q,innerHeight-q-Q);a.style.left=`${Math.max(Q,Math.min(b.left,innerWidth-N-Q))}px`,a.style.top=`${Math.max(Q,L)}px`},C=b=>{++M,document.removeEventListener("pointerdown",R,!0),this.menu?.close(),this.menu=void 0,a.remove(),this.preview?.node===a&&(this.preview=void 0),b&&e.focus()},R=b=>{this.ui.ownsEvent(b)||C(!1)};f.addEventListener("click",()=>{S?U():u.dataset.state==="loading"&&(I=!0)}),p.addEventListener("click",()=>{S&&navigator.clipboard.writeText(S).then(()=>{p.textContent=v("copied"),setTimeout(()=>p.textContent=v("copy"),1200)})}),l.addEventListener("click",()=>{this.menu?.close(),this.menu=$e(this.ui,l.getBoundingClientRect(),x,v("inputLang"),b=>void P(b))}),a.addEventListener("keydown",b=>{if(b.key==="Escape"){b.preventDefault(),C(!0);return}if(!(b.ctrlKey||b.metaKey)||b.altKey||b.shiftKey)return;let A=b.key.toLowerCase();if(A==="a")b.preventDefault(),getSelection()?.selectAllChildren(u);else if(A==="c"&&S){let N=getSelection()?.toString()??"";(!N.trim()||!S.includes(N.trim()))&&(b.preventDefault(),navigator.clipboard.writeText(S))}}),document.addEventListener("pointerdown",R,!0),this.preview={node:a,field:e,close:C},T(),f.focus(),P(x)}};function wn(o,e){let t=new Set,n=r=>{let i=r.composedPath()[0];return i instanceof Element?i.localName==="yl-ui"?!0:i.matches("input,textarea,select")||!!i.closest('[contenteditable]:not([contenteditable="false"]),[role="textbox"]'):!1};window.addEventListener("keydown",r=>{if(en(r.code))return;t.add(r.code);let i=tn(r);if(n(r)&&!i.some(c=>c!=="Shift"))return;let s=[...i,...t],a=o();for(let c of Pe){let d=a[c];if(xt(d,s)){r.preventDefault(),r.stopPropagation(),r.repeat||e(c);return}}Pe.some(c=>{let{mods:d,keys:u}=nn(a[c]);return u.length>1&&u.includes(r.code)&&d.length===i.length&&d.every(h=>i.includes(h))})&&(r.preventDefault(),r.stopPropagation())},!0),window.addEventListener("keyup",r=>t.delete(r.code),!0),window.addEventListener("blur",()=>t.clear())}var xn=8,We=36,Ue=18,qe=class{constructor(e){this.ui=e}shade;box;hint;start;pointer={x:0,y:0};raf=0;onDone;get running(){return this.shade!==void 0}begin(e){this.running||(this.onDone=e,this.shade=this.ui.add(w("div","marquee-shade")),this.hint=this.ui.add(w("div","marquee-hint",v("marqueeHint"))),this.shade.addEventListener("pointerdown",this.onDown),this.shade.addEventListener("pointermove",this.onMove),this.shade.addEventListener("pointerup",this.onUp),this.shade.addEventListener("wheel",this.onWheel,{passive:!1}),addEventListener("keydown",this.onKey,!0),addEventListener("scroll",this.draw,!0),addEventListener("blur",this.cancel))}cancel=()=>this.end();end(){cancelAnimationFrame(this.raf),this.raf=0,removeEventListener("keydown",this.onKey,!0),removeEventListener("scroll",this.draw,!0),removeEventListener("blur",this.cancel),this.shade?.remove(),this.box?.remove(),this.hint?.remove(),this.shade=this.box=this.hint=void 0,this.start=void 0}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.end())};onDown=e=>{e.button===0&&(e.preventDefault(),this.shade.setPointerCapture(e.pointerId),this.start={x:e.clientX+scrollX,y:e.clientY+scrollY},this.pointer={x:e.clientX,y:e.clientY},this.box=this.ui.addFrame(),this.hint?.remove(),this.hint=void 0,this.draw(),this.raf=requestAnimationFrame(this.edgeScroll))};onMove=e=>{this.start&&(this.pointer={x:e.clientX,y:e.clientY},this.draw())};onUp=()=>{if(!this.start)return;let e=this.currentRect();this.end(),e.right-e.left>=xn&&e.bottom-e.top>=xn&&this.onDone?.(e)};onWheel=e=>{e.preventDefault(),this.scrollTarget().scrollBy(e.deltaX,e.deltaY)};scrollTarget(){let e=document.elementsFromPoint(this.pointer.x,this.pointer.y);for(let t of e)if(!this.ui.isHost(t)){for(let n=t;n&&n!==document.documentElement;n=n.parentElement){let r=getComputedStyle(n).overflowY;if((r==="auto"||r==="scroll")&&n.scrollHeight>n.clientHeight)return n}break}return window}edgeScroll=()=>{if(!this.start)return;let{x:e,y:t}=this.pointer,n=t<We?-Ue:t>innerHeight-We?Ue:0,r=e<We?-Ue:e>innerWidth-We?Ue:0;(r||n)&&window.scrollBy(r,n),this.raf=requestAnimationFrame(this.edgeScroll)};currentRect(){let e=this.start.x-scrollX,t=this.start.y-scrollY;return{left:Math.min(e,this.pointer.x),top:Math.min(t,this.pointer.y),right:Math.max(e,this.pointer.x),bottom:Math.max(t,this.pointer.y)}}draw=()=>{if(!this.start||!this.box)return;let e=this.currentRect();Object.assign(this.box.style,{left:`${B(e.left)}px`,top:`${B(e.top)}px`,width:`${B(e.right-e.left)}px`,height:`${B(e.bottom-e.top)}px`})}};var he=new Set(["yl-t","yl-r","yl-ui"]),wr=new Set(["script","style","noscript","template","head","meta","link","title","base","datalist","area","map","param","source","track","rp"]),xr=new Set(["pre","textarea","input","select","option","optgroup","canvas","video","audio","iframe","frame","frameset","object","embed","applet","listing","xmp","plaintext"]),Er=new Set(["code","kbd","samp","var","tt","img","picture","svg","math","ruby","wbr"]),Sr=new Set(["CodeMirror","cm-editor","cm-content","cm-line","monaco-editor","monaco-diff-editor","ace_editor","hljs","prism-code","shiki","astro-code","xterm","blob-code","blob-code-inner","blob-wrapper","blob-num","react-code-lines","react-code-text","react-file-line","react-syntax-highlighter","syntaxhighlighter","code-block","codeblock","code-toolbar","sourceCode","gist-file","gist-data","d2h-wrapper","d2h-file-wrapper","mw-highlight","rouge-table","rouge-code","linenums","line-numbers","lineno","hljs-ln","katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),Tr=new Set(["highlight","highlighter-rouge","codehilite","code","prism","terminal","gist","source","snippet","example"]),kr=["language-","lang-","highlight-source-","highlight-text-","brush:"],Mr=new Set(["code","textbox","searchbox","combobox","math","img","slider","spinbutton"]),Cr=/^\s*"?'?(monospace|ui-monospace|consolas|menlo|monaco|courier|courier new|lucida console|lucida sans typewriter|sfmono-regular|sf mono|fira code|fira mono|source code pro|jetbrains mono|roboto mono|ibm plex mono|dejavu sans mono|liberation mono|cascadia code|cascadia mono|ubuntu mono|hack|inconsolata)\b/i,Ar='nav,button,[role="navigation"],[role="menu"],[role="menubar"],[role="tablist"],[role="toolbar"],[role="button"],[role="menuitem"],[role="tab"]';function Nt(o){return Cr.test(o)}function En(o){let e=o.classList;for(let t=0;t<e.length;t++){let n=e[t];if(Sr.has(n)||(Tr.has(n)||kr.some(r=>n.startsWith(r)))&&Rr(o))return!0}return!1}function Rr(o){for(let e of Array.from(o.children)){let t=e.localName;if(t==="pre"||t==="code"||t==="table"||e.firstElementChild?.localName==="pre")return!0}return!1}var Nr=/^(material-icons(-[\w-]+)?|material-symbols(-[\w-]+)?|mdi|mdi-[\w-]+|fa|fas|far|fab|fal|fa-[\w-]+|bi|bi-[\w-]+|glyphicon|glyphicon-[\w-]+|iconfont|anticon|anticon-[\w-]+)$/;function Lr(o){if(o.childElementCount>0)return!1;let e=(o.textContent??"").trim();if(e.length>40||/\s/.test(e))return!1;let t=o.classList;for(let n=0;n<t.length;n++)if(Nr.test(t[n]))return!0;return o.getAttribute("aria-hidden")==="true"&&/^[a-z0-9_]+$/.test(e)}function Pr(o){if(o.getAttribute("translate")==="no")return!0;let e=o.getAttribute("contenteditable");if(e!==null&&e!=="false")return!0;let t=o.getAttribute("role");return!!(t&&Mr.has(t))}var je=class{excludeSelector=null;setExcludes(e){let t=e.split(`
`).map(n=>n.trim()).filter(n=>n&&Or(n));this.excludeSelector=t.length?t.join(","):null}classify(e){let t=e.localName;if(t==="br")return"br";if(he.has(t))return"own";if(wr.has(t))return"hidden";let n=getComputedStyle(e);if(xr.has(t))return n.display==="none"?"hidden":"skip";if(n.display==="none"||n.visibility==="hidden"||n.visibility==="collapse")return"collapsed";if(n.position==="absolute"&&parseFloat(n.width)<=1&&parseFloat(n.height)<=1)return"hidden";let r=Dr(n.display);if(Er.has(t)||Lr(e)||Pr(e)||En(e)||this.isExcluded(e))return r?"atomic":"skip";if(Nt(n.fontFamily)){let i=e.parentElement,s=i?Nt(getComputedStyle(i).fontFamily):!1;if(r&&!s)return"atomic";if(!r&&n.whiteSpace.startsWith("pre"))return"skip"}return t==="button"||e.getAttribute("role")==="button"||e.localName.includes("-")&&_r(e)?"block":r?"inline":"block"}isExcluded(e){return this.excludeSelector!==null&&e.matches(this.excludeSelector)}},Hr=new Set(["katex","katex-display","katex-html","MathJax","MathJax_Display","MathJax_Preview","mjx-container","notranslate","no-translate","translate-no"]),Ir=new Set(["pre","code","samp","kbd","listing","xmp","plaintext"]);function Sn(o){if(Ir.has(o.localName)||o.querySelector("pre"))return!0;let e=o.classList;for(let n=0;n<e.length;n++){let r=e[n];if(Hr.has(r))return!1}if(En(o))return!0;let t=getComputedStyle(o);return Nt(t.fontFamily)&&t.whiteSpace.startsWith("pre")}function ze(o){return o.matches(Ar)}function Tn(o,e){let t=n=>{let r=n.toLowerCase(),i=r.split("-")[0];return i!=="zh"&&i!=="yue"?i:/hant|-tw|-hk|-mo/.test(r)||i==="yue"?"zh-hant":"zh-hans"};return t(o)===t(e)}function Dr(o){return o==="inline"||o==="inline-block"||o==="inline-flex"||o==="inline-grid"||o===""||o==="ruby"}function me(o){if(o.shadowRoot)return o.shadowRoot;if(!o.localName.includes("-"))return null;try{return chrome.dom?.openOrClosedShadowRoot?.(o)??null}catch{return null}}function _r(o){return me(o)!==null}function Or(o){try{return document.createDocumentFragment().querySelector(o),!0}catch{return!1}}function Ge(o){let e=o.trim();return!new RegExp("\\p{L}","u").test(e)||/^(https?:\/\/|www\.)\S+$/i.test(e)||/^\S+@\S+\.\S+$/.test(e)?!1:!Br(e)}function Br(o){let e=o.replace(/^[("'“‘[]+|[.,:;!?)"'”’\]]+$/g,"");return/^[\w$.:/\\#()<>=\-[\]{}]+$/.test(e)?/\w_\w|\w\.\w|\(\)|::|^--|\w=|\w[/\\]\w|^[#$.]\w/.test(e):!1}var $r=/[這個們來時會對說為學國還過發現點開關與實體後經機於從無見長問間電動應當將麼樣邊裡寫話讀請]/,Fr=/[这个们来时会对说为学国还过发现点开关与实体后经机于从无见长问间电动应当将么样边里写话读请]/;function Te(o,e){let t=o.match(new RegExp("\\p{L}","gu"));if(!t)return!1;let n=i=>(o.match(i)?.length??0)/t.length,r=e.split("-")[0];return r==="zh"?/[぀-ヿ]/.test(o)||n(new RegExp("\\p{Script=Han}","gu"))<.6?!1:e==="zh-Hant"?!Fr.test(o):!$r.test(o):r==="ja"?n(/[぀-ヿ]/g)>.2:r==="ko"?n(new RegExp("\\p{Script=Hangul}","gu"))>.5:!1}var Wr=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,Ur=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,Cn="data-yl-mirror",kn=new Set(["script","noscript","iframe","frame","object","embed","meta","title","base","style","link","yl-ui","yl-t","yl-r"]),qr=["class","style","open","hidden"],Mn=`
*, *::before, *::after { visibility: hidden !important; transition: none !important; animation: none !important; }
html, body { visibility: visible !important; scroll-behavior: auto !important; overscroll-behavior: contain; }

* { scrollbar-color: transparent transparent !important; }
html { overflow-x: hidden !important; }
[data-yl-pinned], [data-yl-pinned] *, [data-yl-pinned]::before, [data-yl-pinned]::after { visibility: hidden !important; background: none !important; box-shadow: none !important; border-color: transparent !important; }
mark[data-yl-find] { background: rgba(255, 215, 49, 0.6) !important; color: inherit !important; border-radius: 2px; }
mark[data-yl-find][data-active] { background: #ff9632 !important; }
[data-yl-box] { visibility: visible !important; }
[data-yl-box]::before, [data-yl-box]::after { visibility: visible !important; }
yl-m { display: contents !important; }
yl-m, yl-m *, yl-m *::before, yl-m *::after,
[data-yl-all], [data-yl-all] *, [data-yl-all]::before, [data-yl-all]::after,
[data-yl-all] *::before, [data-yl-all] *::after { visibility: visible !important; }
yl-m[data-pending] > * , yl-m[data-pending] { opacity: 0.45; }
[data-yl-hidden] { display: none !important; }
`;function An(){try{return!!window.frameElement?.hasAttribute(Cn)}catch{return!1}}var Ke=class{constructor(e,t,n,r){this.sourceScroller=t;this.onClick=n;this.onKey=r;this.frame=document.createElement("iframe"),this.frame.setAttribute(Cn,""),this.frame.setAttribute("sandbox","allow-same-origin"),this.frame.setAttribute("tabindex","-1"),e.append(this.frame),this.build()}frame;doc;map=new WeakMap;observer;build(){let e=this.frame.contentDocument;if(!e)throw new Error("mirror frame has no document");this.doc=e;let t=e.importNode(document.documentElement,!0),n=[];this.pair(document.documentElement,t,n);for(let r of n)r.remove();e.replaceChild(t,e.documentElement),this.addStyles(t),e.addEventListener("click",this.handleClick,!0),e.addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutations),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:qr}),this.copyScroll()}pair(e,t,n){if(this.map.set(e,t),t.nodeType===Node.ELEMENT_NODE){let s=t;if(kn.has(s.localName)){n.push(s);return}this.clean(s);let a=me(e);a&&this.copyShadow(a,s,n)}let r=e.childNodes,i=t.childNodes;for(let s=0;s<r.length;s++){let a=r[s],l=i[s];a&&l&&this.pair(a,l,n)}}copyShadow(e,t,n){let r;try{r=t.attachShadow({mode:"open"})}catch{return}let i=this.doc.createElement("style");i.textContent=Mn,r.append(i);for(let s of Array.from(e.childNodes)){let a=this.doc.importNode(s,!0);r.append(a),!(s.nodeType===Node.ELEMENT_NODE&&s.localName==="style")&&this.pair(s,a,n)}}clean(e){for(let n of Array.from(e.attributes))n.name.toLowerCase().startsWith("on")&&e.removeAttribute(n.name);let t=e.localName;(t==="video"||t==="audio")&&(e.removeAttribute("autoplay"),e.removeAttribute("src")),t==="img"&&e.removeAttribute("loading")}addStyles(e){let t=e.querySelector("head");t||(t=this.doc.createElement("head"),e.prepend(t));let n=(i,s)=>{let a=this.doc.createElement("style");s&&(a.media=s),a.textContent=Array.from(i,l=>l.cssText).join(`
`),t.append(a)};for(let i of Array.from(document.styleSheets)){let s=i.ownerNode;if(s&&s.closest("yl-ui"))continue;let a=null;try{a=i.cssRules}catch{}if(a)n(a,i.media.mediaText||void 0);else if(i.href){let l=this.doc.createElement("link");l.rel="stylesheet",l.href=i.href,i.media.mediaText&&(l.media=i.media.mediaText);let c=s?.getAttribute("crossorigin");c!=null&&l.setAttribute("crossorigin",c),t.append(l)}}try{for(let i of Array.from(document.adoptedStyleSheets??[]))n(i.cssRules)}catch{}let r=this.doc.createElement("style");r.textContent=Mn,t.append(r)}onMutations=e=>{for(let t of e){if(t.type==="attributes"){let r=this.map.get(t.target),i=t.attributeName;if(!r||!i)continue;let s=t.target.getAttribute(i);s===null?r.removeAttribute(i):r.setAttribute(i,s);continue}let n=this.map.get(t.target);if(n)for(let r of Array.from(t.addedNodes)){if(this.map.has(r)||r.nodeType===Node.ELEMENT_NODE&&kn.has(r.localName))continue;let i=this.doc.importNode(r,!0),s=[];this.pair(r,i,s);for(let l of s)l.remove();let a=r.nextSibling?this.map.get(r.nextSibling):null;n.insertBefore(i,a&&a.parentNode===n?a:null)}}};handleClick=e=>{let t=e.target;if(!t||t.nodeType!==Node.ELEMENT_NODE)return;let n=t,r=n.closest("a[href]");if(e.preventDefault(),r&&/^https?:/i.test(r.href)){window.open(r.href,"_blank","noopener");return}this.onClick(n,e)};revealBoxes(e){for(let t=e;t&&t.nodeType===Node.ELEMENT_NODE;t=t.parentNode){let n=t;if(n.hasAttribute("data-yl-box"))return;n.setAttribute("data-yl-box","")}}showRun(e,t){let n=e.map(s=>this.map.get(s)).filter(s=>!!s&&!!s.parentNode),r=n[0];if(!r?.parentNode)return null;let i=this.doc.createElement("yl-m");t&&i.setAttribute("data-pending",""),r.parentNode.insertBefore(i,r);for(let s of n)i.append(s);return this.revealBoxes(i.parentNode),i}showWhole(e){let t=this.map.get(e);return t?(t.setAttribute("data-yl-all",""),this.revealBoxes(t.parentNode),t):null}setTranslation(e,t,n,r){let i=this.doc.createDocumentFragment();this.append(i,t,n);let s=le(t);for(let a of r){let l=n[a];if(l?.atomic&&!s.has(a)){let c=this.copyAtomic(l);c&&i.append(this.doc.createTextNode(" "),c)}}e.replaceChildren(i),e.removeAttribute("data-pending")}setKept(e){e.removeAttribute("data-pending")}copyAtomic(e){let t=this.map.get(e.el);return t?t.cloneNode(!0):this.doc.importNode(e.el,!0)}append(e,t,n){t.forEach((r,i)=>{if(typeof r=="string"){r.split(`
`).forEach((c,d)=>{d>0&&e.appendChild(this.doc.createElement("br")),c&&e.appendChild(this.doc.createTextNode(c))});return}let s=n[r.slot];if(!s)return;if(s.atomic){let c=t[i-1],d=t[i+1];typeof c=="string"&&Wr.test(c)&&e.appendChild(this.doc.createTextNode(" "));let u=this.copyAtomic(s);u&&e.appendChild(u),typeof d=="string"&&Ur.test(d)&&e.appendChild(this.doc.createTextNode(" "));return}let a=this.map.get(s.el),l=a?a.cloneNode(!1):this.doc.importNode(s.el,!1);this.append(l,r.children,n),e.appendChild(l)})}get scroller(){return this.sourceScroller?this.map.get(this.sourceScroller)??null:this.doc.scrollingElement}copyScroll(){let e=this.scroller;e&&(e.scrollTop=this.sourceScroller?this.sourceScroller.scrollTop:scrollY)}get scrollerTop(){let e=this.scroller;return!e||e===this.doc.scrollingElement?0:Math.max(0,e.getBoundingClientRect().top)}alignTo(e,t){let n=this.scroller;if(!n)return;let r=this.doc.createRange();r.selectNodeContents(e);let i=r.getBoundingClientRect();if(!i.width&&!i.height)return;let s=i.top-t;Math.abs(s)>.5&&(n.scrollTop+=s)}hidePinned(){for(let e of Array.from(this.doc.querySelectorAll("body *"))){let t=this.frame.contentWindow?.getComputedStyle(e).position;(t==="fixed"||t==="sticky")&&e.setAttribute("data-yl-pinned","")}}textOf(e){return e.textContent??""}destroy(){this.observer?.disconnect(),this.observer=void 0,this.frame.remove()}};var jr=new Set(["a","b","strong","i","em","u","s","del","ins","mark","sub","sup","abbr","cite","q","small","big","font","dfn","strike","label"]),zr=["fontWeight","fontStyle","color","backgroundColor","textDecorationLine","fontSize","fontFamily"];function Gr(o){let e=o.parentElement;if(!e)return!0;let t=getComputedStyle(o),n=getComputedStyle(e);return t.display!=="inline"?!0:zr.some(r=>t[r]!==n[r])}var Rn=4;function Lt(o){return o==="inline-block"||o==="inline-flex"||o==="inline-grid"}function Kr(o){let e=getComputedStyle(o);return Lt(e.display)?!0:parseFloat(e.marginLeft)>=Rn||parseFloat(e.marginRight)>=Rn}function Xr(o){let e=[];for(let n of o)if(n.nodeType===Node.TEXT_NODE)e.push(n);else if(n.nodeType===Node.ELEMENT_NODE){let r=document.createTreeWalker(n,NodeFilter.SHOW_TEXT);for(let i=r.nextNode();i;i=r.nextNode())e.push(i)}let t=[];for(let n=e.length-1;n>=0;n--){let r=e[n];if(Xe(r.data)||t.some(s=>s.contains(r)))continue;let i=Vr(r,o);if(!i)break;t.unshift(i)}return new Set(t)}function Vr(o,e){let t=null;for(let n=o.parentElement;n;n=n.parentElement){if(e.includes(n))return t;Lt(getComputedStyle(n).display)&&(t=n)}return null}function Xe(o){return!/[^ \t\r\n\f]/.test(o)}var fe=class{classifier=new je;kinds=new WeakMap;blockDescendant=new WeakMap;reset(){this.kinds=new WeakMap,this.blockDescendant=new WeakMap}kindOf(e){let t=this.kinds.get(e);return t===void 0&&(t=this.classifier.classify(e),this.kinds.set(e,t)),t}*scan(e,t,n=!1){let r=[],i=0,s=()=>{if(r.length){let a=this.buildRun(r,e,n);a?t.emit(a):t.plain?.(r,e)}r=[],i=0};for(let a of Array.from(e.childNodes)){if(t.consume(a)){s();continue}if(a.nodeType===Node.TEXT_NODE){let d=Xe(a.data);d||(i=0),(!d||r.length)&&r.push(a);continue}if(a.nodeType!==Node.ELEMENT_NODE)continue;let l=a;switch(this.kindOf(l)){case"own":case"hidden":break;case"collapsed":yield*this.scan(l,t,n||ze(l));break;case"skip":s(),t.skipped?.(l);break;case"br":r.length&&r.push(l),++i>=2&&s();break;case"atomic":i=0,r.push(l);break;case"inline":this.isolatedInlineBlock(l,e)||this.hasBlockDescendant(l)?(s(),yield*this.scan(l,t,n||ze(l))):(i=0,r.push(l));break;case"block":{s();let d=n||ze(l);yield*this.scan(l,t,d);let u=me(l);u&&(t.shadowRoot(u),yield*this.scan(u,t,d)),yield;break}}}if(s(),e.nodeType===Node.ELEMENT_NODE&&!Yr(e)){let a=me(e);a&&(t.shadowRoot(a),yield*this.scan(a,t,n))}}isolatedInlineBlock(e,t){if(!Lt(getComputedStyle(e).display))return!1;for(let n of Array.from(t.childNodes))if(n.nodeType===Node.TEXT_NODE&&!Xe(n.data))return!1;return!0}hasBlockDescendant(e){let t=this.blockDescendant.get(e);if(t!==void 0)return t;let n=!1;for(let r of Array.from(e.children)){let i=this.kindOf(r);if(i==="block"||i==="skip"||i==="inline"&&this.hasBlockDescendant(r)){n=!0;break}}return this.blockDescendant.set(e,n),n}buildRun(e,t,n){let r=[],i=t.nodeType===Node.ELEMENT_NODE?t:t.host,s=getComputedStyle(i).whiteSpace,a=s==="pre-line"||s==="pre-wrap"||s==="pre"||s==="break-spaces",l=[],c=[],d=Xr(e);for(let p of e)this.serialize(p,a,r,c,l,d);for(let p of d){c.push(`
`);let f=r.length;this.serialize(p,a,r,c,l);let m=r[f];m&&(m.detached=!0)}let u=Nn(l.join(""));if(!Ge(u))return null;let h=e.slice();for(;h.length>1;){let p=h[h.length-1];if(!(p.nodeType===Node.TEXT_NODE?Xe(p.data):p.localName==="br"))break;h.pop()}return{nodes:h,parent:t,markup:Nn(c.join("")),slots:r,text:u,compact:n}}serialize(e,t,n,r,i,s){if(s?.has(e))return;if(e.nodeType===Node.TEXT_NODE){let h=e.data,p=t?h.replace(/[ \t\r\f]+/g," "):h.replace(/[ \t\r\n\f]+/g," ");r.push(K(p)),i.push(p);return}if(e.nodeType!==Node.ELEMENT_NODE)return;let a=e,l=this.kindOf(a);if(l==="br"){r.push(`
`),i.push(`
`);return}if(l==="hidden"||l==="collapsed"||l==="own"||l==="skip")return;if(l==="atomic"){let h=n.length;n.push({el:a,atomic:!0});let p=(a.textContent??"").replace(/\s+/g," ").trim()||a.getAttribute("alt")||"•";r.push(`<x${h}>${K(p)}</x${h}>`);return}let c=jr.has(a.localName)||Gr(a),d=c?n.length:-1,u=Kr(a);u&&(r.push(" "),i.push(" ")),c&&(n.push({el:a,atomic:!1}),r.push(`<x${d}>`));for(let h of Array.from(a.childNodes))this.serialize(h,t,n,r,i,s);c&&r.push(`</x${d}>`),u&&(r.push(" "),i.push(" "))}};function Yr(o){return o.localName.includes("-")}function Nn(o){return o.replace(/ *\n */g,`
`).replace(/ {2,}/g," ").trim()}function Ln(o,e){let t=o.nodeType===Node.ELEMENT_NODE?o:o.parentNode;for(;t;){if(t.nodeType===Node.DOCUMENT_FRAGMENT_NODE)return t;if(t.nodeType!==Node.ELEMENT_NODE)return null;let n=t,r=e.kindOf(n);if(r==="block"||r==="collapsed"||n===document.body)return n;if(r==="skip"||r==="hidden")return null;t=n.parentNode}return null}var Ve=new WeakSet;function Pt(o){for(let e of Array.from(o.querySelectorAll("yl-t,yl-r")))Ve.has(e)||e.remove();for(let e of Array.from(o.querySelectorAll("[data-yl-hidden]")))Ve.has(e)||e.removeAttribute("data-yl-hidden")}var Jr=.98;function Zr(o){let e=/^rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(o);return e?.2126*Number(e[1])+.7152*Number(e[2])+.0722*Number(e[3])>140:!1}function Ye(o,e,t){if(!e||!o.detected||o.score===void 0||o.score>=Jr)return!1;let n=o.detected.split("-")[0];return n!==e&&n!==t.split("-")[0]}var Ht=new WeakMap,Qr=24,ei=new Set(["en","fr","de","es","pt","it","nl","pl","tr","vi","id"]),ti=/[⺀-鿿豈-﫿぀-ヿ가-힯]$/,ni=/^[⺀-鿿豈-﫿぀-ヿ가-힯]/,ge=class{constructor(e){this.run=e;this.wire=e.markup}state="idle";raw;wire;from="";fallback;hoverHost=null;tree;renderedMode;inserted;textBackup=new Map;written=new Map;hidden=[];unclamped;get markup(){return this.run.markup}get text(){return this.run.text}get compact(){return this.run.compact}get isRendered(){return this.renderedMode!==void 0}get rendersInPlace(){return this.renderedMode==="replace"}get anchor(){let e=this.parentElement;for(let t of this.run.nodes)if(t.nodeType===Node.ELEMENT_NODE){e=t;break}for(;e.parentElement&&getComputedStyle(e).display==="contents";)e=e.parentElement;return e}get parentElement(){let e=this.run.parent;return e.nodeType===Node.ELEMENT_NODE?e:e.host}sourceHint(){if(this.text.length>Qr||/[^\p{Script=Latin}\P{L}]/u.test(this.text))return"";let t=this.parentElement.closest("[lang]")?.getAttribute("lang")?.split("-")[0]?.toLowerCase()??"";return ei.has(t)?t:""}regionContent(e){let t=this.parentElement,n=this.sourceHint();if(this.rendersInPlace){let g=this.hoverHost;return{markup:this.markup,slots:this.run.slots,text:this.text,hint:n,block:t,rect:()=>g?.getBoundingClientRect()??null}}let r=new Map(this.run.slots.map((g,y)=>[g.el,y])),i=[],s=[],a=g=>{let y=g.left+g.width/2,E=g.top+g.height/2;return g.width>0&&y>=e.left&&y<=e.right&&E>=e.top&&E<=e.bottom},l=document.createRange(),c=!1,d=(g,y,E,x)=>{c||(l.setStart(g,y),c=!0),l.setEnd(E,x)},u=new Intl.Segmenter(void 0,{granularity:"word"}),h=document.createRange(),p=g=>{if(g.nodeType===Node.TEXT_NODE){for(let S of u.segment(g.data)){if(!S.isWordLike&&!/\S/.test(S.segment)){i.push(" "),s.push(" ");continue}h.setStart(g,S.index),h.setEnd(g,S.index+S.segment.length),a(h.getBoundingClientRect())&&(i.push(K(S.segment)),s.push(S.segment),d(g,S.index,g,S.index+S.segment.length))}return}if(g.nodeType!==Node.ELEMENT_NODE)return;let y=g;if(y.localName==="br"){i.push(`
`);return}if(he.has(y.localName))return;let E=r.get(y);if(E!==void 0&&this.run.slots[E].atomic){if(Array.from(y.getClientRects()).some(a)){i.push(`<x${E}>${K((y.textContent??"").trim()||"•")}</x${E}>`);let S=y.parentNode,M=Array.from(S.childNodes).indexOf(y);d(S,M,S,M+1)}return}let x=i.length;E!==void 0&&i.push(`<x${E}>`);for(let S of Array.from(y.childNodes))p(S);E!==void 0&&(i.slice(x+1).join("").trim()?i.push(`</x${E}>`):i.length=x)};for(let g of this.run.nodes)p(g);let f=i.join("").replace(/\s+/g,g=>g.includes(`
`)?`
`:" ").trim(),m=s.join("").replace(/\s+/g," ").trim();return!c||!Ge(m)?null:{markup:f,slots:this.run.slots,text:m,hint:n,block:t,rect:()=>l.getBoundingClientRect()}}clientRects(){let e=this.run.nodes,t=e[0],n=e[e.length-1];if(!t||!n||!t.isConnected)return[];if(this.rendersInPlace&&this.inserted)return Array.from(this.inserted.getClientRects());let r=document.createRange();return r.setStartBefore(t),r.setEndAfter(n),Array.from(r.getClientRects())}setTranslation(e){this.raw=e;let t=new Set(this.run.slots.map((n,r)=>r));this.tree=xe(X(e,t),n=>!!this.run.slots[n]?.detached)}renderStatus(e,t,n){if(t.mode!=="dual"||this.renderedMode||this.compact)return;this.removeInserted();let r=document.createElement("yl-t");r.setAttribute("data-state",e),r.style.setProperty("--yl-theme",t.theme),e==="error"&&(r.setAttribute("data-yl-retry",""),r.textContent=n),this.insertAfterRun(r),this.inserted=r}clearStatus(){this.renderedMode||this.removeInserted()}render(e){this.tree&&(this.unrender(),e.mode==="dual"&&!this.compact?(this.renderDual(e),this.renderedMode="dual"):(this.renderReplace(e),this.renderedMode="replace"))}unrender(){this.removeInserted();for(let[e,t]of this.textBackup)e.data===this.written.get(e)&&(e.data=t);this.textBackup.clear(),this.written.clear();for(let e of this.hidden)e.removeAttribute("data-yl-hidden");this.hidden=[],this.unclamped?.removeAttribute("data-yl-unclamp"),this.unclamped=void 0,this.renderedMode=void 0,this.hoverHost=null}isIntact(){for(let e of this.run.nodes)if(!e.isConnected||e.parentNode!==this.run.parent)return!1;for(let[e,t]of this.written)if(e.data!==t)return!1;return!0}applyDualStyle(e){this.renderedMode==="dual"&&this.inserted&&this.decorate(this.inserted,e)}renderDual(e){let t=document.createElement("yl-t");t.setAttribute("lang",e.targetLang),t.setAttribute("dir","auto"),this.decorate(t,e),this.shouldBeInline()&&t.setAttribute("data-inline","");let n=document.createElement("yl-i");n.append(this.buildFragment()),t.append(n),this.insertAfterRun(t),this.inserted=t,this.hoverHost=t;let r=this.parentElement;getComputedStyle(r).webkitLineClamp!=="none"&&getComputedStyle(r).webkitLineClamp!==""&&(r.setAttribute("data-yl-unclamp",""),this.unclamped=r)}decorate(e,t){t.dualStyle==="plain"?e.removeAttribute("data-style"):e.setAttribute("data-style",t.dualStyle);let n=e,r=Zr(getComputedStyle(this.parentElement).color);n.style.setProperty("--yl-theme",De(t.theme,r?sn:Ie)),r?e.setAttribute("data-tone","dark"):e.removeAttribute("data-tone"),n.style.fontSize=t.fontScale===100?"":`${t.fontScale}%`}shouldBeInline(){let e=this.parentElement,t=getComputedStyle(e);return t.whiteSpace==="nowrap"||t.whiteSpace==="pre"||t.display==="inline"||t.display==="inline-block"?!0:t.display.includes("flex")?!t.flexDirection.startsWith("column"):t.display.includes("grid")}renderReplace(e){let t=this.run.nodes,n=this.tree.some(s=>typeof s=="string"&&s.includes(`
`));if(t.every(s=>s.nodeType===Node.TEXT_NODE)&&!n&&this.run.slots.length===0){let s=this.tree.map(a=>typeof a=="string"?a:"").join("");t.forEach((a,l)=>{let c=a;this.textBackup.set(c,c.data);let d="";l===0&&(d=(/^\s/.test(c.data)?" ":"")+s),c.data=d,this.written.set(c,d)}),this.hoverHost=this.parentElement;return}for(let s of t)if(s.nodeType===Node.TEXT_NODE){let a=s;this.textBackup.set(a,a.data),a.data="",this.written.set(a,"")}else if(s.nodeType===Node.ELEMENT_NODE){let a=s;a.setAttribute("data-yl-hidden",""),Ve.add(a),this.hidden.push(a)}let i=document.createElement("yl-r");i.setAttribute("lang",e.targetLang),i.append(this.buildFragment()),this.insertAfterRun(i),this.inserted=i,this.hoverHost=i}insertAfterRun(e){Ve.add(e);let t=this.run.nodes[this.run.nodes.length-1];t.parentNode?.insertBefore(e,t.nextSibling)}removeInserted(){this.inserted?.remove(),this.inserted=void 0}buildFragment(){let e=document.createDocumentFragment();this.appendNodes(e,this.tree);let t=le(this.tree);return this.run.slots.forEach((n,r)=>{n.atomic&&!t.has(r)&&e.append(" ",this.cloneSlot(n))}),e}appendNodes(e,t){t.forEach((n,r)=>{if(typeof n=="string"){this.appendText(e,n);return}let i=this.run.slots[n.slot];if(!i)return;if(i.atomic){let a=t[r-1],l=t[r+1];typeof a=="string"&&ti.test(a)&&e.appendChild(document.createTextNode(" ")),e.appendChild(this.cloneSlot(i)),typeof l=="string"&&ni.test(l)&&e.appendChild(document.createTextNode(" "));return}let s=this.cloneShell(i);this.appendNodes(s,n.children),e.appendChild(s)})}appendText(e,t){t.split(`
`).forEach((r,i)=>{i>0&&e.appendChild(document.createElement("br")),r&&e.appendChild(document.createTextNode(r))})}cloneSlot(e){let t=e.el.cloneNode(!0);t.removeAttribute("id"),t.removeAttribute("data-yl-hidden");for(let n of t.querySelectorAll("[id]"))n.removeAttribute("id");return t}cloneShell(e){let t=e.el.cloneNode(!1);return t.removeAttribute("id"),t.removeAttribute("data-yl-hidden"),Ht.set(t,e.el),t.style?.setProperty("--yl-c",getComputedStyle(e.el).color),t}};var Pn=`/* Injected into pages and shadow roots. Fonts and colours are inherited on purpose. */

yl-t {
  display: block !important;
  margin: 0.3em 0 0 !important;
  padding: 0;
  font-family: inherit;
  font-weight: inherit;
  line-height: inherit;
  color: inherit;
  white-space: normal !important;
  text-indent: 0;
  letter-spacing: normal;
  overflow-wrap: break-word;
  max-width: 100%;
  float: none !important;
  position: static !important;
}

yl-t[data-inline] {
  display: inline !important;
  margin: 0 0 0 0.5em !important;
  white-space: inherit !important;
}

yl-r {
  display: inline;
  font: inherit;
  color: inherit;
}

/*
 * One colour the reader picks, the same on every page. Its value is set on each translation.
 * The full palette belongs on thin frames only.
 */
/* Copying allowed again, by the reader's choice: text can be selected whatever the page says. */
html[data-yl-unlock] *:not(input):not(textarea) {
  -webkit-user-select: text !important;
  user-select: text !important;
}

yl-t {
  --yl-theme: #1f77f3;
  --yl-pen: 30%;
}

/* See-through colour dims over black: this much more looks the same as it does on white. */
yl-t[data-tone='dark'] {
  --yl-pen: 62%;
}

yl-t[data-style='accent'] {
  color: var(--yl-theme);
}

/* Links stay recognisably links; other coloured text leans to the ink. */
yl-t[data-style='accent'] a[style*='--yl-c'] {
  color: color-mix(in oklab, var(--yl-c) 65%, var(--yl-theme)) !important;
}

yl-t[data-style='accent'] [style*='--yl-c']:not(a) {
  color: color-mix(in oklab, var(--yl-c) 20%, var(--yl-theme)) !important;
}

yl-t[data-style='faded'] {
  opacity: 0.72;
}

yl-t[data-style='underline'] {
  text-decoration: underline dashed 1px var(--yl-theme);
  text-underline-offset: 0.32em;
}

/* A capsule that stops short of the block's ends, so it sits beside the text and not on it. */
yl-t[data-style='bar']:not([data-inline]) {
  position: relative !important;
  padding-left: 0.8em !important;
}

yl-t[data-style='bar']:not([data-inline])::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0.22em;
  bottom: 0.22em;
  width: 3px;
  border-radius: 3px;
  background: linear-gradient(180deg, var(--yl-theme), color-mix(in srgb, var(--yl-theme) 55%, transparent));
}

yl-t[data-style='bar'][data-inline] {
  color: var(--yl-theme);
}

/*
 * A highlighter pen that fades out upward, with no top edge to read as a band. It has to be
 * drawn on an inline box, because that is what follows each line of the text.
 */
yl-i {
  display: inline;
}

yl-t[data-style='highlight'] yl-i {
  background: linear-gradient(to top, color-mix(in srgb, var(--yl-theme) var(--yl-pen), transparent), transparent 78%);
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}

yl-t[data-state='loading'] {
  display: inline-block !important;
  width: 1.5em;
  height: 0.7em;
  margin: 0 0 0 0.4em !important;
  vertical-align: baseline;
  background-image:
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent),
    radial-gradient(circle closest-side, var(--yl-theme) 92%, transparent);
  background-position: 0 50%, 50% 50%, 100% 50%;
  background-repeat: no-repeat;
  background-size: 0.26em 0.26em;
  opacity: 0.7;
  animation: yl-wave 1.05s ease-in-out infinite;
}

yl-t[data-state='error'] {
  font-size: 0.82em;
  color: #c62828;
  cursor: pointer;
  text-decoration: underline;
  text-underline-offset: 0.2em;
}

[data-yl-hidden] {
  display: none !important;
}

[data-yl-unclamp] {
  -webkit-line-clamp: unset !important;
  max-height: none !important;
  overflow: visible !important;
}

@keyframes yl-wave {
  0%,
  100% {
    background-size: 0.42em 0.42em, 0.26em 0.26em, 0.26em 0.26em;
  }
  33% {
    background-size: 0.26em 0.26em, 0.42em 0.42em, 0.26em 0.26em;
  }
  66% {
    background-size: 0.26em 0.26em, 0.26em 0.26em, 0.42em 0.42em;
  }
}

@media (prefers-reduced-motion: reduce) {
  yl-t[data-state='loading'] {
    animation: none;
  }
}
`;var ee=class{constructor(e,t){this.node=e;this.scrollers=t}animations=[];ranges="";movedByY=[];movedByX=[];left=NaN;top=NaN;place(e,t){this.follow();let n=this.node.getRootNode(),r=n instanceof ShadowRoot?n.host.getBoundingClientRect():{left:0,top:0},i=e-r.left,s=t-r.top;for(let a of this.movedByX)i+=a.scrollLeft;for(let a of this.movedByY)s+=a.scrollTop;Math.abs(i-this.left)<.5&&Math.abs(s-this.top)<.5||(this.left=i,this.top=s,this.node.style.left=`${i}px`,this.node.style.top=`${s}px`)}follow(){let e=globalThis.ScrollTimeline;if(!e)return;let t=this.scrollers.map(r=>[r,r.scrollHeight-r.clientHeight,r.scrollWidth-r.clientWidth]),n=t.map(([,r,i])=>`${r},${i}`).join(";");if(n!==this.ranges){this.ranges=n;for(let r of this.animations)r.cancel();this.animations=[],this.movedByY=[],this.movedByX=[];for(let[r,i,s]of t)i>0&&(this.animations.push(this.travel(new e({source:r,axis:"block"}),`translateY(${-i}px)`)),this.movedByY.push(r)),s>0&&(this.animations.push(this.travel(new e({source:r,axis:"inline"}),`translateX(${-s}px)`)),this.movedByX.push(r))}}travel(e,t){return this.node.animate({transform:["translate(0, 0)",t]},{timeline:e,fill:"both",easing:"linear",composite:"add"})}};var Hn=4,te=8,ri=.6,ii=.8;function be(o){let e=[];for(let t=o;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t);(/auto|scroll/.test(n.overflowY)||/auto|scroll/.test(n.overflowX))&&(t.scrollHeight>t.clientHeight+1||t.scrollWidth>t.clientWidth+1)&&e.push({el:t,top:t.scrollTop,left:t.scrollLeft})}return e}function si(o){if(o.scrollHeight<=o.clientHeight+1&&o.scrollWidth<=o.clientWidth+1)return!1;let e=getComputedStyle(o);return/auto|scroll/.test(e.overflowY)||/auto|scroll/.test(e.overflowX)}function In(o,e){let t=e.getBoundingClientRect();if(o.left>t.left+te||o.right<t.right-te)return!1;let n=Math.max(t.top,0),r=Math.min(t.bottom,innerHeight);return r<=n?!1:Math.min(o.bottom,r)-Math.max(o.top,n)>=(r-n)*ii}function Dn(o){let e=[];for(let t of Array.from(document.querySelectorAll("body *")))!si(t)||!In(o,t)||e.some(n=>n.contains(t))||e.push(t);return e}function ai(o,e){if(In(e,o))return!1;let t=o.getBoundingClientRect();if(e.top>=t.top-te&&e.bottom<=t.bottom+te&&e.left>=t.left-te&&e.right<=t.right+te)return!0;let r=getComputedStyle(o);return/auto|scroll/.test(r.overflowY)&&o.scrollHeight>o.clientHeight+1&&o.clientHeight>=innerHeight*ri}var Je=class{constructor(e){this.ui=e}box;rect;scrollers=[];windowTop=0;windowLeft=0;frameRequest=0;bounds={top:-1/0,bottom:1/0};framePin;over=!1;beyondArea=!1;showPending(e){this.close();let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scrollers=be(t).filter(i=>ai(i.el,e)),this.windowTop=scrollY,this.windowLeft=scrollX;let n=Ee();this.over=n.top>0&&e.top<n.top-1||n.bottom<innerHeight&&e.bottom>n.bottom+1;let r=this.scrollers[0]?.el.getBoundingClientRect();this.beyondArea=!!r&&(e.top<r.top-te||e.bottom>r.bottom+te),this.rect=this.visible(e),this.box=this.ui.addFrame(!0,!0,this.over),this.framePin=new ee(this.box,this.scrollers.map(i=>i.el)),this.reposition(),addEventListener("scroll",this.requestReposition,!0),addEventListener("resize",this.requestReposition)}visible(e){let t=Hn+2,n=this.beyondArea?void 0:this.scrollers[0]?.el.getBoundingClientRect(),r={left:t,right:(document.documentElement.clientWidth||innerWidth)-t,top:Math.max(0,n?.top??0)+t,bottom:Math.min(innerHeight,n?.bottom??1/0)-t},i={...e},s=Math.max(e.left,r.left),a=Math.min(e.right,r.right);a-s>t*2&&Object.assign(i,{left:s,right:a});let l=Math.max(e.top,r.top),c=Math.min(e.bottom,r.bottom);return c-l>t*2&&Object.assign(i,{top:l,bottom:c}),i}settle(e){return e?(this.box&&(this.ui.setFramePending(this.box,!1),this.ui.addToPage(this.box,this.over)),!0):(this.close(),!1)}clip(e,t,n,r){let i=t?.getBoundingClientRect(),s=this.over?{top:-1/0,bottom:1/0}:this.bounds,a=Math.max(0,Math.max(i?.top??-1/0,s.top)-n),l=Math.max(0,r-Math.min(i?.bottom??1/0,s.bottom)),c=Hn,d=u=>u?`${u}px`:`-${c}px`;e.style.clipPath=a||l?`inset(${d(a)} -${c}px ${d(l)} -${c}px)`:""}requestReposition=()=>{this.frameRequest||(this.frameRequest=requestAnimationFrame(this.reposition))};reposition=()=>{this.frameRequest=0,this.bounds=this.ui.settleUnderBars();let e=this.rect;if(!this.box||!e)return;let t=this.windowTop-scrollY,n=this.windowLeft-scrollX;for(let s of this.scrollers)t+=s.top-s.el.scrollTop,n+=s.left-s.el.scrollLeft;let r=e.top+t,i=e.bottom-e.top;this.framePin?.place(B(e.left+n),B(r)),Object.assign(this.box.style,{width:`${B(e.right-e.left)}px`,height:`${B(i)}px`}),this.clip(this.box,this.beyondArea?void 0:this.scrollers[0]?.el,r,r+i)};close(){removeEventListener("scroll",this.requestReposition,!0),removeEventListener("resize",this.requestReposition),cancelAnimationFrame(this.frameRequest),this.frameRequest=0,this.box?.remove(),this.box=void 0,this.framePin=void 0,this.over=!1,this.beyondArea=!1,this.rect=void 0,this.scrollers=[]}get emptyMessage(){return v("marqueeEmpty")}};var li=3e4,_n=150,ci=30,di=5e3,On=4,ui=60,pi=400,hi=300,mi=8,fi="800px 0px",gi=8,bi=3e4,yi=450,vi=2,wi=3e3,Ze=class{constructor(e,t){this.ui=t;this.settings=e,this.scanner.classifier.setExcludes(e.excludeSelectors),document.addEventListener("click",this.onClick,!0),document.addEventListener("mouseover",this.onMouseOver,!0),document.addEventListener("mouseout",this.onMouseOut,!0)}settings;scanner=new fe;segments=new Set;byNode=new WeakMap;byAnchor=new Map;styledRoots=new WeakSet;watchedRoots=[];pageActive=!1;generation=0;io;mo;queue=[];inFlight=0;flushTimer;dirty=new Set;dirtyTimer;rebuilds=new WeakMap;lastError;errorToastShown=!1;statusTimer;pageLang;hoverTimer;hoverSeg;hoverHosts=new WeakMap;get active(){return this.pageActive}get hasTranslations(){for(let e of this.segments)if(e.isRendered||e.state==="loading"||e.state==="queued")return!0;return!1}get hasPageTranslations(){for(let e of this.segments)if(!this.regionSegs.has(e)&&(e.isRendered||e.state==="loading"||e.state==="queued"))return!0;return!1}setPageLang(e){this.pageLang=e}get display(){let e=this.settings;return{mode:e.mode,dualStyle:e.dualStyle,fontScale:e.fontScale,targetLang:e.targetLang,theme:de(e.themeColor)}}regionSegs=new Set;displayFor(e){return this.regionSegs.has(e)?{...this.display,mode:"replace"}:this.display}async translateRegion(e){if(!document.body)return 0;await this.scanRoot(document.body);let t=Dn(e),n=[];for(let r of this.segments)r.state==="done"&&!this.regionSegs.has(r)||!t.some(s=>s.contains(r.parentElement))&&!Ei(r.clientRects(),e)||Te(r.text,this.settings.targetLang)||n.push(r);this.ownWrite(()=>{for(let r of n)this.regionSegs.add(r),r.state==="done"?(r.render(this.displayFor(r)),r.hoverHost&&this.hoverHosts.set(r.hoverHost,r)):r.state==="failed"&&(r.clearStatus(),r.state="idle")});for(let r of n)this.enqueue(r);return this.reportStatus(),n.length}async regionSettled(){for(let e=0;e<li;e+=_n){if(![...this.regionSegs].some(t=>t.state==="queued"||t.state==="loading"))return;await new Promise(t=>setTimeout(t,_n))}}restoreRegion(){this.regionSegs.size&&(this.ownWrite(()=>{for(let e of this.regionSegs)e.unrender(),e.clearStatus(),e.state="idle",this.queue=this.queue.filter(t=>t!==e),this.pageActive&&this.enqueue(e)}),this.regionSegs.clear(),this.ui.hideTooltip(),this.pruneIdle(),this.reportStatus())}status(){let e=0,t=0,n=0,r=0;for(let s of this.segments)s.state!=="idle"&&(e++,s.state==="done"||s.state==="same"?t++:s.state==="failed"?n++:r++);let i={active:this.pageActive||this.hasTranslations,mode:this.settings.mode,total:e,done:t,failed:n,pending:r};return this.pageLang&&(i.pageLang=this.pageLang),location.hostname&&(i.host=location.hostname),n>0&&this.lastError&&(i.error=this.lastError),i}reportStatus(){this.statusTimer===void 0&&(this.statusTimer=setTimeout(()=>{this.statusTimer=void 0,F()&&_({type:"status",status:this.status()}).catch(()=>{})},150))}async startPage(){this.pageActive||!document.body||(this.pageActive=!0,this.errorToastShown=!1,this.startObservers(),await this.scanRoot(document.body),this.observeAllEligible(),this.reportStatus())}togglePage(){this.pageActive||this.hasPageTranslations?this.restore():this.startPage()}retire(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.ownWrite(()=>{for(let e of this.segments)e.state==="loading"&&e.clearStatus()})}restore(){this.pageActive=!1,this.generation++,this.stopObservers(),clearTimeout(this.flushTimer),this.flushTimer=void 0,clearTimeout(this.dirtyTimer),this.dirty.clear(),this.queue=[],this.lastError=void 0;for(let e of this.segments)this.dropSegment(e,!0);this.segments.clear(),this.regionSegs.clear(),this.byAnchor.clear(),this.ui.hideTooltip(),this.reportStatus()}setMode(e){this.settings={...this.settings,mode:e},this.rerenderAll(),this.pageActive&&this.observeAllEligible(),this.reportStatus()}retryFailed(){this.errorToastShown=!1,this.lastError=void 0;for(let e of this.segments)e.state==="failed"&&(e.clearStatus(),this.enqueue(e))}applySettings(e){let t=this.settings;if(this.settings=e,e.excludeSelectors!==t.excludeSelectors&&this.scanner.classifier.setExcludes(e.excludeSelectors),(t.targetLang!==e.targetLang||t.sourceLang!==e.sourceLang)&&(this.pageActive||this.hasTranslations)){let r=this.pageActive,i=[...this.segments].filter(s=>s.isRendered);this.generation++,this.queue=[];for(let s of this.segments)s.unrender(),s.clearStatus(),s.state="idle",s.raw=void 0,s.wire=s.markup,s.from="",s.fallback=void 0;if(r)this.observeAllEligible();else for(let s of i)this.enqueue(s);return}t.mode!==e.mode?this.setMode(e.mode):(t.dualStyle!==e.dualStyle||t.fontScale!==e.fontScale||t.themeColor!==e.themeColor)&&this.ownWrite(()=>{for(let r of this.segments)r.applyDualStyle(this.display)})}pruneIdle(){if(!this.pageActive){for(let e of this.segments)if(e.state==="idle"&&!e.isRendered){this.segments.delete(e);for(let t of e.run.nodes)this.byNode.delete(t)}}}hooks={consume:e=>{let t=this.byNode.get(e);return t?.rendersInPlace?t.isIntact()?(this.seen?.add(t),!0):(this.ownWrite(()=>this.dropSegment(t,!0)),this.segments.delete(t),!1):!1},emit:e=>this.register(e),shadowRoot:e=>this.adoptShadowRoot(e)};seen;async scanRoot(e){this.ownWrite(()=>Pt(e)),this.scanner.reset(),this.seen=new Set;let t=this.scanner.scan(e,this.hooks),n=performance.now();for(let r=t.next();!r.done;r=t.next())performance.now()-n>mi&&(await new Promise(i=>setTimeout(i,0)),n=performance.now());this.seen=void 0}register(e){let t=e.nodes[0],n=this.byNode.get(t);if(n&&n.markup===e.markup){this.seen?.add(n);return}n&&(this.ownWrite(()=>this.dropSegment(n,!0)),this.segments.delete(n));let r=new ge(e);this.segments.add(r),this.seen?.add(r);for(let i of e.nodes)this.byNode.set(i,r);this.pageActive&&this.observeSegment(r)}observeSegment(e){if(!this.io||e.state!=="idle")return;let t=e.anchor,n=this.byAnchor.get(t);n||(n=new Set,this.byAnchor.set(t,n),this.io.observe(t)),n.add(e)}observeAllEligible(){for(let e of this.segments)this.observeSegment(e)}dropSegment(e,t){t&&(e.unrender(),e.clearStatus()),e.state="idle";for(let r of e.run.nodes)this.byNode.get(r)===e&&this.byNode.delete(r);let n=this.byAnchor.get(e.anchor);n&&(n.delete(e),n.size||(this.byAnchor.delete(e.anchor),this.io?.unobserve(e.anchor)))}adoptShadowRoot(e){if(this.styledRoots.has(e))return;this.styledRoots.add(e);let t=document.createElement("style");t.setAttribute("data-yl",""),t.textContent=Pn,e.append(t),this.watchedRoots.push(e),this.mo?.observe(e,It)}startObservers(){this.io=new IntersectionObserver(this.onIntersect,{rootMargin:fi}),this.mo=new MutationObserver(this.onMutations),document.body&&this.mo.observe(document.body,It);for(let e of this.watchedRoots)this.mo.observe(e,It)}stopObservers(){this.io?.disconnect(),this.mo?.disconnect(),this.io=void 0,this.mo=void 0}onIntersect=e=>{for(let t of e){if(!t.isIntersecting)continue;let n=this.byAnchor.get(t.target);if(n){for(let r of n)this.enqueue(r);this.byAnchor.delete(t.target)}this.io?.unobserve(t.target)}};ownWrite(e){let t=this.mo?.takeRecords();t?.length&&this.onMutations(t),e(),this.mo?.takeRecords()}onMutations=e=>{for(let t of e){if(Bn(t.target))continue;if(t.type==="childList"){let r=[...Array.from(t.addedNodes),...Array.from(t.removedNodes)];if(r.length&&r.every(Bn))continue}let n=Ln(t.target,this.scanner);n&&this.dirty.add(n)}this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},hi))};async flushDirty(){let e=this.generation,t=[...this.dirty].filter(n=>{for(let r of this.dirty)if(r!==n&&r.contains(n))return!1;return n.isConnected});this.dirty.clear();for(let n of t){if(e!==this.generation||!this.pageActive)return;if(!this.allowRebuild(n)){this.dirty.add(n);continue}let r=[...this.segments].filter(s=>n.contains(s.run.parent));this.ownWrite(()=>Pt(n)),this.scanner.reset(),this.seen=new Set;let i=this.seen;for(let s of this.scanner.scan(n,this.hooks));this.seen=void 0;for(let s of r)i.has(s)||(this.ownWrite(()=>this.dropSegment(s,!0)),this.segments.delete(s))}for(let n of this.segments)n.anchor.isConnected||(this.dropSegment(n,!1),this.segments.delete(n));this.dirty.size&&this.dirtyTimer===void 0&&(this.dirtyTimer=setTimeout(()=>{this.dirtyTimer=void 0,this.flushDirty()},wi)),this.reportStatus()}allowRebuild(e){let t=Date.now(),n=this.rebuilds.get(e);return!n||t-n.since>bi?(this.rebuilds.set(e,{n:1,since:t}),!0):(n.n++,n.n<=gi)}enqueue(e,t=!1){if(!(e.state==="done"||e.state==="loading"||e.state==="same")&&!(e.state==="queued"&&!t)){if(Te(e.text,this.settings.targetLang)){e.state="same";return}e.state!=="queued"&&(e.state="queued",t||this.queue.push(e)),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},ui)),this.reportStatus()}}prioritizeQueue(){if(this.queue=this.queue.filter(n=>n.state==="queued"),this.queue.length<2)return;let e=innerHeight,t=new Map;for(let n of this.queue){let r=n.anchor.getBoundingClientRect();t.set(n,r.bottom<0?-r.bottom:r.top>e?r.top-e:0)}this.queue.sort((n,r)=>t.get(n)-t.get(r))}pump(){if(!(this.inFlight>=On))for(this.prioritizeQueue();this.inFlight<On&&this.queue.length;){let e=this.settings.sourceLang||this.queue[0].from,t=[],n=[],r=0;for(let i of this.queue)t.length<ci&&(t.length===0||r+i.wire.length<=di)&&(this.settings.sourceLang||i.from)===e?(t.push(i),r+=i.wire.length):n.push(i);this.queue=n,this.sendBatch(t,e)}}async sendBatch(e,t){let n=this.generation;this.inFlight++;for(let s of e)s.state="loading";let r=setTimeout(()=>{n===this.generation&&this.ownWrite(()=>{for(let s of e)s.state==="loading"&&s.renderStatus("loading",this.displayFor(s),"")})},pi),i;for(let s=0;s<=vi&&!i;s++)try{let a=await _({type:"translate",items:e.map(l=>l.wire),from:t,to:this.settings.targetLang});a?.results?.length===e.length&&(i=a.results)}catch{if(!F())break}if(clearTimeout(r),this.inFlight--,!F()){this.retire();return}n===this.generation&&this.applyResults(e,i),this.pump(),this.reportStatus()}applyResults(e,t){this.ownWrite(()=>{e.forEach((n,r)=>{if(!this.segments.has(n))return;let i=t?.[r]??{ok:!1,code:"network"};if(!i.ok){n.state="failed",this.lastError=i.code,n.clearStatus(),n.renderStatus("error",this.displayFor(n),v("retryInline"));return}if(n.clearStatus(),!this.settings.sourceLang&&!n.from&&Ye(i,n.sourceHint(),this.settings.targetLang)){n.fallback=i.text,n.from=n.sourceHint(),n.state="idle",this.enqueue(n);return}let s=n.fallback!==void 0&&this.isUnchanged(n,i.text,void 0)?n.fallback:i.text;if(this.isUnchanged(n,s,i.detected)){if(n.wire===n.markup&&/\s[—–]\s/.test(n.markup)){n.wire=n.markup.replace(/\s[—–]\s/g," - "),n.state="idle",this.enqueue(n);return}n.state="same";return}n.setTranslation(s),n.state="done",n.render(this.displayFor(n)),n.hoverHost&&this.hoverHosts.set(n.hoverHost,n)})}),this.lastError&&!this.errorToastShown&&e.some(n=>n.state==="failed")&&(this.errorToastShown=!0,this.ui.toast(this.ui.errorMessage(this.lastError),{label:v("retry"),run:()=>this.retryFailed()}))}isUnchanged(e,t,n){if(!t.trim())return!0;let r=this.settings.targetLang;return n&&n.split("-")[0]===r.split("-")[0]&&(n===r||!r.startsWith("zh"))?!0:re(X(t)).trim()===re(X(e.markup)).trim()}rerenderAll(){this.ownWrite(()=>{for(let e of this.segments)e.state==="done"?(e.render(this.displayFor(e)),e.hoverHost&&this.hoverHosts.set(e.hoverHost,e)):e.state==="failed"&&(e.clearStatus(),e.renderStatus("error",this.displayFor(e),v("retryInline")))})}onClick=e=>{let t=e.composedPath();for(let n of t){if(!(n instanceof Element))continue;if(n.localName==="yl-t"&&n.hasAttribute("data-yl-retry")){e.preventDefault(),e.stopPropagation(),this.retryFailed();return}let r=Ht.get(n);if(r){if(e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault(),e.stopPropagation(),r.click();return}if(he.has(n.localName))return}};onMouseOver=e=>{if(!this.settings.showOriginalOnHover)return;let t=this.segmentAt(e);if(t===this.hoverSeg||(this.hoverSeg=t,clearTimeout(this.hoverTimer),this.ui.hideTooltip(),!t?.hoverHost))return;let n=t.hoverHost;this.hoverTimer=setTimeout(()=>{t.isRendered&&n.isConnected&&this.ui.showTooltip(re(X(t.markup)),xi(n))},yi)};onMouseOut=e=>{this.hoverSeg&&!e.relatedTarget&&(this.hoverSeg=void 0,clearTimeout(this.hoverTimer),this.ui.hideTooltip())};segmentAt(e){for(let t of e.composedPath()){if(!(t instanceof Element))continue;let n=this.hoverHosts.get(t);if(n?.rendersInPlace)return n;if(t===document.body)break}}},It={childList:!0,characterData:!0,subtree:!0};function Bn(o){let e=o;for(;e;){if(e.nodeType===Node.ELEMENT_NODE&&he.has(e.localName))return!0;e=e.parentNode}return!1}function xi(o){return o.getBoundingClientRect()}function Ei(o,e){for(let t of o){let n=Math.min(t.bottom,e.bottom)-Math.max(t.top,e.top),r=Math.min(t.right,e.right)-Math.max(t.left,e.left),i=t.bottom-t.top;if(i>0&&n>=i/2&&r>=Math.min(24,(t.right-t.left)/2))return!0}return!1}var Si={curl:"bash",bash:"bash",shell:"bash","command line":"bash",命令行:"bash",ruby:"ruby",python:"python",node:"javascript","node.js":"javascript",javascript:"javascript",typescript:"typescript",go:"go",java:"java",php:"php",".net":"csharp","c#":"csharp",html:"html",css:"css",json:"json",yaml:"yaml",sql:"sql"},$n={js:"javascript",jsx:"jsx",ts:"typescript",tsx:"tsx",py:"python",rb:"ruby",sh:"bash",html:"html",css:"css",json:"json",yml:"yaml",yaml:"yaml",go:"go",java:"java",php:"php",cs:"csharp",sql:"sql",md:"markdown",vue:"vue"};function Fn(o){return o.ownerDocument.defaultView?.getComputedStyle(o)??null}function Wn(o){return o.getAttribute("aria-hidden")==="true"?!0:Fn(o)?.userSelect==="none"}function Ti(o){let e=Fn(o)?.display??"";return e==="block"||e==="flex"||e==="grid"||e==="list-item"||e==="table-row"}function Un(o,e){for(let t of Array.from(o.childNodes))if(t.nodeType===3)e.push(t.data);else if(t.nodeType===1){let n=t;if(Wn(n))continue;if(n.localName==="br"){e.push(`
`);continue}Un(n,e),Ti(n)&&!(e[e.length-1]??"").endsWith(`
`)&&e.push(`
`)}}function ki(o){let e=o.localName==="pre"?o:o.querySelector("pre")??o,t=[];return Un(e,t),t.join("").replace(/\n+$/,"")}function Mi(o){let e=[o,...Array.from(o.querySelectorAll("pre,code"))];for(let t of e){let n=/(?:^|\s)(?:language|lang|highlight-source)-([\w+#-]+)/.exec(t.getAttribute("class")??"");if(n?.[1])return n[1].toLowerCase()}return""}function qn(o){let e=o.trim().toLowerCase(),t=/\.([a-z0-9]+)$/.exec(e);return t?.[1]&&$n[t[1]]?$n[t[1]]:Si[e]??""}function Ci(o){let e=o.parentElement;for(let t=0;e&&t<4;t++,e=e.parentElement){if(e.querySelectorAll("pre").length>1)return"";for(let n of Array.from(e.querySelectorAll("*"))){if(n.children.length||o.contains(n))continue;let r=qn(n.textContent??"");if(r)return r}}return""}function Ai(o){let e=2;for(let t of o.matchAll(/`+/g))e=Math.max(e,t[0].length);return"`".repeat(e+1)}function Ri(o){let e=o.replace(/\s+/g," ").trim();return e?(e.includes("`")?"``":"`")==="``"?`\`\` ${e} \`\``:`\`${e}\``:""}function Dt(o,e){let t=/^(\s*)([\s\S]*?)(\s*)$/.exec(e);return t?.[2]?`${t[1]}${o}${t[2]}${o}${t[3]}`:e}function se(o){let e="";for(let t of Array.from(o.childNodes)){if(t.nodeType===3){e+=t.data.replace(/\s+/g," ");continue}if(t.nodeType!==1)continue;let n=t,r=n.localName;if(r==="br")e+=`  
`;else if(r==="code"||r==="kbd"||r==="samp"||r==="tt")e+=Ri(n.textContent??"");else if(r==="strong"||r==="b")e+=Dt("**",se(n));else if(r==="em"||r==="i")e+=Dt("*",se(n));else if(r==="del"||r==="s")e+=Dt("~~",se(n));else if(r==="img"){let i=n.getAttribute("src");i&&(e+=`![${n.getAttribute("alt")??""}](${n.src||i})`)}else if(r==="a"){let i=se(n).trim(),s=n.href;e+=i&&/^https?:/i.test(s)?`[${i}](${s})`:i}else r!=="svg"&&!Wn(n)&&(e+=se(n))}return e}function Ni(o){let e=0;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&e++;return Math.max(0,e-1)}function Li(o){let e=o;for(let t=o.parentElement;t;t=t.parentElement)(t.localName==="ul"||t.localName==="ol")&&(e=t);return e}function Pi(o){if(o.closest('button,[role="button"],nav,[role="navigation"],[role="tablist"]'))return null;let e=se(o).replace(/[ \t]+/g," ").trim();if(!e)return null;let t=o.closest("h1,h2,h3,h4,h5,h6");if(t)return{text:`${"#".repeat(Number(t.localName[1]))} ${e.replace(/\s*\n\s*/g," ")}`};let n=o.closest("li");if(n){let r=n.parentElement,i=r?.localName==="ol"?`${Array.from(r.children).indexOf(n)+1}.`:"-";return{text:`${"  ".repeat(Ni(n))}${i} ${e}`,group:Li(n)}}return o.closest("blockquote")?{text:e.split(`
`).map(r=>`> ${r}`).join(`
`)}:{text:e}}function Hi(o){if((o.textContent??"").trim().length>40)return null;let e=o.parentElement;for(let t=0;e&&t<6;t++,e=e.parentElement){if(e.localName==="body"||e.localName==="main"||e.localName==="article")return null;let n=e.querySelectorAll("pre");if(n.length===1)return n[0];if(n.length>1)return null}return null}function Ii(o){let e=new Map,t=new Set;for(let{copy:n}of o){let r=n.closest("table");if(!r||t.has(r))continue;t.add(r);let i=Array.from(r.querySelectorAll("tr")).map(a=>Array.from(a.children).map(l=>se(l).replace(/\s+/g," ").replace(/\|/g,"\\|").trim())).filter(a=>a.some(Boolean));if(!i.length)continue;let s=i.map(a=>`| ${a.join(" | ")} |`);s.splice(1,0,`| ${i[0].map(()=>"---").join(" | ")} |`),e.set(r,s.join(`
`))}return e}function jn(o){let e=new Map,t=new Set;for(let a of o){if(a.kind==="code")continue;let l=Hi(a.copy);if(!l)continue;t.add(a.copy);let c=qn(a.copy.textContent??"");c&&!e.has(l)&&e.set(l,c)}let n=Ii(o),r=new Set,i=[];for(let a of o){if(t.has(a.copy))continue;if(a.kind==="code"){let d=ki(a.copy);if(!d.trim())continue;let u=a.copy.localName==="pre"?a.copy:a.copy.querySelector("pre"),h=u&&(e.get(u)||Ci(u))||Mi(a.copy),p=Ai(d);i.push({text:`${p}${h}
${d}
${p}`});continue}let l=a.copy.closest("table");if(l&&n.has(l)){r.has(l)||i.push({text:n.get(l)}),r.add(l);continue}let c=Pi(a.copy);c&&i.push(c)}let s="";return i.forEach((a,l)=>{l&&(s+=a.group&&a.group===i[l-1].group?`
`:`

`),s+=a.text}),s}var ke=16,Di=32,_i=28,Oi="data-yl-find",Qe=class{constructor(e,t,n){this.mirror=e;this.copies=n;this.track.append(this.thumb),t.append(this.track),this.mirror.doc.addEventListener("scroll",this.onScroll,!0),this.track.addEventListener("pointerdown",this.onPointerDown)}track=w("div","scan-track");thumb=w("i","scan-thumb");min=0;max=0;visible=0;origin=0;open=!1;marks=[];active=-1;measure(){let e=1/0,t=-1/0,n=this.mirror.doc.createRange();for(let r of this.copies()){if(!r.isConnected)continue;n.selectNodeContents(r);let i=n.getBoundingClientRect();!i.width&&!i.height||(e=Math.min(e,i.top),t=Math.max(t,i.bottom))}return e===1/0?null:{top:e,bottom:t}}get contentHeight(){let e=this.measure();return e?e.bottom-e.top+ke*2:0}start(e,t){let n=this.mirror.scroller,r=this.measure();if(this.visible=e,this.origin=t,this.open=!0,!n||!r)return;let i=n.scrollTop;this.min=i+r.top-t-ke,this.max=Math.max(this.min,i+r.bottom+ke-t-e),this.scrollTo(Math.max(this.min,Math.min(i,this.max))),this.alignToBlock(),this.paint()}alignToBlock(){let e=this.mirror.doc.createRange(),t=1/0;for(let n of this.copies()){if(!n.isConnected)continue;e.selectNodeContents(n);let r=e.getBoundingClientRect();(r.width||r.height)&&r.bottom>this.origin&&r.top<t&&(t=r.top)}t!==1/0&&this.scrollBy(t-this.origin-Di)}stop(){this.open=!1,this.clearFind(),this.track.style.display="none"}get extent(){return{from:this.min,to:this.max,visible:this.visible}}get position(){return this.mirror.scroller?.scrollTop??0}moveTo(e){this.scrollTo(e)}scrollBy(e){let t=this.mirror.scroller;t&&this.scrollTo(t.scrollTop+e)}scrollTo(e){let t=this.mirror.scroller;t&&(t.scrollTop=Math.max(this.min,Math.min(e,this.max)))}onScroll=()=>{if(!this.open)return;let e=this.mirror.scroller;e&&((e.scrollTop<this.min-1||e.scrollTop>this.max+1)&&this.scrollTo(e.scrollTop),this.paint())};thumbHeight(){return Math.max(_i,this.visible*this.visible/(this.max-this.min+this.visible))}paint(){let e=this.mirror.scroller,t=this.max-this.min;if(!e||t<=0){this.track.style.display="none";return}this.track.style.display="";let n=this.thumbHeight();this.thumb.style.height=`${n}px`,this.thumb.style.transform=`translateY(${(e.scrollTop-this.min)/t*(this.visible-n)}px)`}onPointerDown=e=>{e.preventDefault(),this.track.setPointerCapture(e.pointerId);let t=this.track.getBoundingClientRect().top,n=this.thumbHeight(),r=this.max-this.min,i=this.thumb.getBoundingClientRect().top,s=e.target===this.thumb?e.clientY-i:n/2,a=c=>{let d=(c.clientY-t-s)/(this.visible-n);this.scrollTo(this.min+Math.max(0,Math.min(1,d))*r)};a(e);let l=()=>{this.track.removeEventListener("pointermove",a),this.track.removeEventListener("pointerup",l)};this.track.addEventListener("pointermove",a),this.track.addEventListener("pointerup",l)};get hasQuery(){return this.marks.length>0}clearFind(){let e=new Set;for(let t of this.marks){let n=t.parentNode;n&&(t.replaceWith(...Array.from(t.childNodes)),e.add(n))}for(let t of e)t.normalize();this.marks=[],this.active=-1}find(e){this.clearFind();let t=e.trim().toLowerCase();if(!t)return 0;let n=this.mirror.doc;for(let r of this.copies()){if(!r.isConnected)continue;let i=n.createTreeWalker(r,NodeFilter.SHOW_TEXT),s=[];for(let a=i.nextNode();a;a=i.nextNode())s.push(a);for(let a of s)this.markIn(a,t)}return this.step(1),this.marks.length}markIn(e,t){let n=[],r=e;for(let i=r.data.toLowerCase().indexOf(t);i!==-1;i=r.data.toLowerCase().indexOf(t)){let s=r.splitText(i);r=s.splitText(t.length);let a=this.mirror.doc.createElement("mark");a.setAttribute(Oi,""),s.replaceWith(a),a.append(s),n.push(a)}this.marks.push(...n)}step(e){if(!this.marks.length)return 0;this.marks[this.active]?.removeAttribute("data-active"),this.active=(this.active+e+this.marks.length)%this.marks.length;let t=this.marks[this.active];t.setAttribute("data-active","");let n=t.getBoundingClientRect(),r=n.top-this.origin;return(r<ke||n.bottom-this.origin>this.visible-ke)&&this.scrollBy(r-this.visible/3),this.active+1}};var Jn="[modern-screenshot]",ne=typeof window<"u",Bi=ne&&"Worker"in window,sc=ne&&"atob"in window,ac=ne&&"btoa"in window,Bt=ne?window.navigator?.userAgent:"",Zn=Bt.includes("Chrome"),et=Bt.includes("AppleWebKit")&&!Zn,$t=Bt.includes("Firefox"),$i=o=>o&&"__CONTEXT__"in o,Fi=o=>o.constructor.name==="CSSFontFaceRule",Wi=o=>o.constructor.name==="CSSImportRule",Ui=o=>o.constructor.name==="CSSLayerBlockRule",V=o=>o.nodeType===1,Re=o=>typeof o.className=="object",Qn=o=>o.tagName==="image",qi=o=>o.tagName==="use",Me=o=>V(o)&&typeof o.style<"u"&&!Re(o),ji=o=>o.nodeType===8,zi=o=>o.nodeType===3,ve=o=>o.tagName==="IMG",tt=o=>o.tagName==="VIDEO",Gi=o=>o.tagName==="CANVAS",Ki=o=>o.tagName==="TEXTAREA",Xi=o=>o.tagName==="INPUT",Vi=o=>o.tagName==="STYLE",Yi=o=>o.tagName==="SCRIPT",Ji=o=>o.tagName==="SELECT",Zi=o=>o.tagName==="SLOT",Qi=o=>o.tagName==="IFRAME",es=(...o)=>console.warn(Jn,...o);function ts(o){let e=o?.createElement?.("canvas");return e&&(e.height=e.width=1),!!e&&"toDataURL"in e&&!!e.toDataURL("image/webp").includes("image/webp")}var _t=o=>o.startsWith("data:");function eo(o,e){if(o.match(/^[a-z]+:\/\//i))return o;if(ne&&o.match(/^\/\//))return window.location.protocol+o;if(o.match(/^[a-z]+:/i)||!ne)return o;let t=nt().implementation.createHTMLDocument(),n=t.createElement("base"),r=t.createElement("a");return t.head.appendChild(n),t.body.appendChild(r),e&&(n.href=e),r.href=o,r.href}function nt(o){return(o&&V(o)?o?.ownerDocument:o)??window.document}var ot="http://www.w3.org/2000/svg";function ns(o,e,t){let n=nt(t).createElementNS(ot,"svg");return n.setAttributeNS(null,"width",o.toString()),n.setAttributeNS(null,"height",e.toString()),n.setAttributeNS(null,"viewBox",`0 0 ${o} ${e}`),n}function os(o,e){let t=new XMLSerializer().serializeToString(o);return e&&(t=t.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu,"")),`data:image/svg+xml;charset=utf-8,${encodeURIComponent(t)}`}function rs(o,e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t(r.result),r.onerror=()=>n(r.error),r.onabort=()=>n(new Error(`Failed read blob to ${e}`)),e==="dataUrl"?r.readAsDataURL(o):e==="arrayBuffer"&&r.readAsArrayBuffer(o)})}var is=o=>rs(o,"dataUrl");function ye(o,e){let t=nt(e).createElement("img");return t.decoding="sync",t.loading="eager",t.src=o,t}function Ce(o,e){return new Promise(t=>{let{timeout:n,ownerDocument:r,onError:i,onWarn:s}=e??{},a=typeof o=="string"?ye(o,nt(r)):o,l=null,c=null;function d(){t(a),l&&clearTimeout(l),c?.()}if(n&&(l=setTimeout(d,n)),tt(a)){let u=a.currentSrc||a.src;if(!u)return a.poster?Ce(a.poster,e).then(t):d();if(a.readyState>=2)return d();let h=d,p=f=>{s?.("Failed video load",u,f),i?.(f),d()};c=()=>{a.removeEventListener("loadeddata",h),a.removeEventListener("error",p)},a.addEventListener("loadeddata",h,{once:!0}),a.addEventListener("error",p,{once:!0})}else{let u=Qn(a)?a.href.baseVal:a.currentSrc||a.src;if(!u)return d();let h=async()=>{if(ve(a)&&"decode"in a)try{await a.decode()}catch(f){s?.("Failed to decode image, trying to render anyway",a.dataset.originalSrc||u,f)}d()},p=f=>{s?.("Failed image load",a.dataset.originalSrc||u,f),d()};if(ve(a)&&a.complete)return h();c=()=>{a.removeEventListener("load",h),a.removeEventListener("error",p)},a.addEventListener("load",h,{once:!0}),a.addEventListener("error",p,{once:!0})}})}async function ss(o,e){Me(o)&&(ve(o)||tt(o)?await Ce(o,e):await Promise.all(["img","video"].flatMap(t=>Array.from(o.querySelectorAll(t)).map(n=>Ce(n,e)))))}var to=function(){let e=0,t=()=>`0000${(Math.random()*36**4<<0).toString(36)}`.slice(-4);return()=>(e+=1,`u${t()}${e}`)}();function no(o){return o?.split(",").map(e=>e.trim().replace(/"|'/g,"").toLowerCase()).filter(Boolean)}var zn=0;function as(o){let e=`${Jn}[#${zn}]`;return zn++,{time:t=>o&&console.time(`${e} ${t}`),timeEnd:t=>o&&console.timeEnd(`${e} ${t}`),warn:(...t)=>o&&es(...t)}}function ls(o){return{cache:o?"no-cache":"force-cache"}}async function oo(o,e){return $i(o)?o:Ft(o,{...e,autoDestruct:!0})}async function Ft(o,e){let{scale:t=1,workerUrl:n,workerNumber:r=1}=e||{},i=!!e?.debug,s=e?.features??!0,a=o.ownerDocument??(ne?window.document:void 0),l=o.ownerDocument?.defaultView??(ne?window:void 0),c=new Map,d={width:0,height:0,quality:1,type:"image/png",scale:t,backgroundColor:null,style:null,filter:null,maximumCanvasSize:0,timeout:3e4,progress:null,debug:i,fetch:{requestInit:ls(e?.fetch?.bypassingCache),placeholderImage:"data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",bypassingCache:!1,...e?.fetch},fetchFn:null,font:{},drawImageInterval:100,workerUrl:null,workerNumber:r,onCloneEachNode:null,onCloneNode:null,onEmbedNode:null,onCreateForeignObjectSvg:null,includeStyleProperties:null,autoDestruct:!1,...e,__CONTEXT__:!0,log:as(i),node:o,ownerDocument:a,ownerWindow:l,dpi:t===1?null:96*t,svgStyleElement:ro(a),svgDefsElement:a?.createElementNS(ot,"defs"),svgStyles:new Map,defaultComputedStyles:new Map,workers:[...Array.from({length:Bi&&n&&r?r:0})].map(()=>{try{let p=new Worker(n);return p.onmessage=async f=>{let{url:m,result:g}=f.data;g?c.get(m)?.resolve?.(g):c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},p.onmessageerror=f=>{let{url:m}=f.data;c.get(m)?.reject?.(new Error(`Error receiving message from worker: ${m}`))},p}catch(p){return d.log.warn("Failed to new Worker",p),null}}).filter(Boolean),fontFamilies:new Map,fontCssTexts:new Map,acceptOfImage:`${[ts(a)&&"image/webp","image/svg+xml","image/*","*/*"].filter(Boolean).join(",")};q=0.8`,requests:c,drawImageCount:0,tasks:[],features:s,isEnable:p=>p==="restoreScrollPosition"?typeof s=="boolean"?!1:s[p]??!1:typeof s=="boolean"?s:s[p]??!0,shadowRoots:[]};d.log.time("wait until load"),await ss(o,{timeout:d.timeout,onWarn:d.log.warn}),d.log.timeEnd("wait until load");let{width:u,height:h}=cs(o,d);return d.width=u,d.height=h,d}function ro(o){if(!o)return;let e=o.createElement("style"),t=e.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);return e.appendChild(t),e}function cs(o,e){let{width:t,height:n}=e;if(V(o)&&(!t||!n)){let r=o.getBoundingClientRect();t=t||r.width||Number(o.getAttribute("width"))||0,n=n||r.height||Number(o.getAttribute("height"))||0}return{width:t,height:n}}async function ds(o,e){let{log:t,timeout:n,drawImageCount:r,drawImageInterval:i}=e;t.time("image to canvas");let s=await Ce(o,{timeout:n,onWarn:e.log.warn}),{canvas:a,context2d:l}=us(o.ownerDocument,e),c=()=>{try{l?.drawImage(s,0,0,a.width,a.height)}catch(d){e.log.warn("Failed to drawImage",d)}};if(c(),e.isEnable("fixSvgXmlDecode"))for(let d=0;d<r;d++)await new Promise(u=>{setTimeout(()=>{l?.clearRect(0,0,a.width,a.height),c(),u()},d+i)});return e.drawImageCount=0,t.timeEnd("image to canvas"),a}function us(o,e){let{width:t,height:n,scale:r,backgroundColor:i,maximumCanvasSize:s}=e,a=o.createElement("canvas");a.width=Math.floor(t*r),a.height=Math.floor(n*r),a.style.width=`${t}px`,a.style.height=`${n}px`,s&&(a.width>s||a.height>s)&&(a.width>s&&a.height>s?a.width>a.height?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s):a.width>s?(a.height*=s/a.width,a.width=s):(a.width*=s/a.height,a.height=s));let l=a.getContext("2d");return l&&i&&(l.fillStyle=i,l.fillRect(0,0,a.width,a.height)),{canvas:a,context2d:l}}function io(o,e){if(o.ownerDocument)try{let i=o.toDataURL();if(i!=="data:,")return ye(i,o.ownerDocument)}catch(i){e.log.warn("Failed to clone canvas",i)}let t=o.cloneNode(!1),n=o.getContext("2d"),r=t.getContext("2d");try{return n&&r&&r.putImageData(n.getImageData(0,0,o.width,o.height),0,0),t}catch(i){e.log.warn("Failed to clone canvas",i)}return t}function ps(o,e){try{if(o?.contentDocument?.documentElement)return Wt(o.contentDocument.documentElement,e)}catch(t){e.log.warn("Failed to clone iframe",t)}return o.cloneNode(!1)}function hs(o){let e=o.cloneNode(!1);return o.currentSrc&&o.currentSrc!==o.src&&(e.src=o.currentSrc,e.srcset=""),e.loading==="lazy"&&(e.loading="eager"),e}async function ms(o,e){if(o.ownerDocument&&!o.currentSrc&&o.poster)return ye(o.poster,o.ownerDocument);let t=o.cloneNode(!1);t.crossOrigin="anonymous",o.currentSrc&&o.currentSrc!==o.src&&(t.src=o.currentSrc);let n=t.ownerDocument;if(n){let r=!0;if(await Ce(t,{onError:()=>r=!1,onWarn:e.log.warn}),!r)return o.poster?ye(o.poster,o.ownerDocument):t;t.currentTime=o.currentTime,await new Promise(s=>{t.addEventListener("seeked",s,{once:!0})});let i=n.createElement("canvas");i.width=o.offsetWidth,i.height=o.offsetHeight;try{let s=i.getContext("2d");s&&s.drawImage(t,0,0,i.width,i.height)}catch(s){return e.log.warn("Failed to clone video",s),o.poster?ye(o.poster,o.ownerDocument):t}return io(i,e)}return t}function fs(o,e){return Gi(o)?io(o,e):Qi(o)?ps(o,e):ve(o)?hs(o):tt(o)?ms(o,e):o.cloneNode(!1)}function gs(o){let e=o.sandbox;if(!e){let{ownerDocument:t}=o;try{t&&(e=t.createElement("iframe"),e.id=`__SANDBOX__${to()}`,e.width="0",e.height="0",e.style.visibility="hidden",e.style.position="fixed",t.body.appendChild(e),e.srcdoc='<!DOCTYPE html><meta charset="UTF-8"><title></title><body>',o.sandbox=e)}catch(n){o.log.warn("Failed to getSandBox",n)}}return e}var bs=["width","height","-webkit-text-fill-color"],ys=["stroke","fill"];function so(o,e,t){let{defaultComputedStyles:n}=t,r=o.nodeName.toLowerCase(),i=Re(o)&&r!=="svg",s=i?ys.map(m=>[m,o.getAttribute(m)]).filter(([,m])=>m!==null):[],a=[i&&"svg",r,s.map((m,g)=>`${m}=${g}`).join(","),e].filter(Boolean).join(":");if(n.has(a))return n.get(a);let c=gs(t)?.contentWindow;if(!c)return new Map;let d=c?.document,u,h;i?(u=d.createElementNS(ot,"svg"),h=u.ownerDocument.createElementNS(u.namespaceURI,r),s.forEach(([m,g])=>{h.setAttributeNS(null,m,g)}),u.appendChild(h)):u=h=d.createElement(r),h.textContent=" ",d.body.appendChild(u);let p=c.getComputedStyle(h,e),f=new Map;for(let m=p.length,g=0;g<m;g++){let y=p.item(g);bs.includes(y)||f.set(y,p.getPropertyValue(y))}return d.body.removeChild(u),n.set(a,f),f}function ao(o,e,t){let n=new Map,r=[],i=new Map;if(t)for(let a of t)s(a);else for(let a=o.length,l=0;l<a;l++){let c=o.item(l);s(c)}for(let a=r.length,l=0;l<a;l++)i.get(r[l])?.forEach((c,d)=>n.set(d,c));function s(a){let l=o.getPropertyValue(a),c=o.getPropertyPriority(a),d=a.lastIndexOf("-"),u=d>-1?a.substring(0,d):void 0;if(u){let h=i.get(u);h||(h=new Map,i.set(u,h)),h.set(a,[l,c])}e.get(a)===l&&!c||(u?r.push(u):n.set(a,[l,c]))}return n}function vs(o,e,t,n){let{ownerWindow:r,includeStyleProperties:i,currentParentNodeStyle:s}=n,a=e.style,l=r.getComputedStyle(o),c=so(o,null,n);s?.forEach((u,h)=>{c.delete(h)});let d=ao(l,c,i);d.delete("transition-property"),d.delete("all"),d.delete("d"),d.delete("content"),t&&(d.delete("position"),d.delete("margin-top"),d.delete("margin-right"),d.delete("margin-bottom"),d.delete("margin-left"),d.delete("margin-block-start"),d.delete("margin-block-end"),d.delete("margin-inline-start"),d.delete("margin-inline-end"),d.set("box-sizing",["border-box",""])),d.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text"),Zn&&(d.has("font-kerning")||d.set("font-kerning",["normal",""]),(d.get("overflow-x")?.[0]==="hidden"||d.get("overflow-y")?.[0]==="hidden")&&d.get("text-overflow")?.[0]==="ellipsis"&&o.scrollWidth===o.clientWidth&&d.set("text-overflow",["clip",""]));for(let u=a.length,h=0;h<u;h++)a.removeProperty(a.item(h));return d.forEach(([u,h],p)=>{a.setProperty(p,u,h)}),d}function ws(o,e){(Ki(o)||Xi(o)||Ji(o))&&e.setAttribute("value",o.value)}var xs=["::before","::after"],Es=["::-webkit-scrollbar","::-webkit-scrollbar-button","::-webkit-scrollbar-thumb","::-webkit-scrollbar-track","::-webkit-scrollbar-track-piece","::-webkit-scrollbar-corner","::-webkit-resizer"];function Ss(o,e,t,n,r){let{ownerWindow:i,svgStyleElement:s,svgStyles:a,currentNodeStyle:l}=n;if(!s||!i)return;function c(d){let u=i.getComputedStyle(o,d),h=u.getPropertyValue("content");if(!h||h==="none")return;r?.(h),h=h.replace(/(')|(")|(counter\(.+\))/g,"");let p=[to()],f=so(o,d,n);l?.forEach((x,S)=>{f.delete(S)});let m=ao(u,f,n.includeStyleProperties);m.delete("content"),m.delete("-webkit-locale"),m.get("background-clip")?.[0]==="text"&&e.classList.add("______background-clip--text");let g=[`content: '${h}';`];if(m.forEach(([x,S],M)=>{g.push(`${M}: ${x}${S?" !important":""};`)}),g.length===1)return;try{e.className=[e.className,...p].join(" ")}catch(x){n.log.warn("Failed to copyPseudoClass",x);return}let y=g.join(`
  `),E=a.get(y);E||(E=[],a.set(y,E)),E.push(`.${p[0]}${d}`)}xs.forEach(c),t&&Es.forEach(c)}var Gn=new Set(["symbol"]);async function Kn(o,e,t,n,r){if(V(t)&&(Vi(t)||Yi(t))||n.filter&&!n.filter(t))return;Gn.has(e.nodeName)||Gn.has(t.nodeName)?n.currentParentNodeStyle=void 0:n.currentParentNodeStyle=n.currentNodeStyle;let i=await Wt(t,n,!1,r);n.isEnable("restoreScrollPosition")&&Ts(o,i),e.appendChild(i)}async function Xn(o,e,t,n){let r=o.firstChild;V(o)&&o.shadowRoot&&(r=o.shadowRoot?.firstChild,t.shadowRoots.push(o.shadowRoot));for(let i=r;i;i=i.nextSibling)if(!ji(i))if(V(i)&&Zi(i)&&typeof i.assignedNodes=="function"){let s=i.assignedNodes();for(let a=0;a<s.length;a++)await Kn(o,e,s[a],t,n)}else await Kn(o,e,i,t,n)}function Ts(o,e){if(!Me(o)||!Me(e))return;let{scrollTop:t,scrollLeft:n}=o;if(!t&&!n)return;let{transform:r}=e.style,i=new DOMMatrix(r),{a:s,b:a,c:l,d:c}=i;i.a=1,i.b=0,i.c=0,i.d=1,i.translateSelf(-n,-t),i.a=s,i.b=a,i.c=l,i.d=c,e.style.transform=i.toString()}function ks(o,e){let{backgroundColor:t,width:n,height:r,style:i}=e,s=o.style;if(t&&s.setProperty("background-color",t,"important"),n&&s.setProperty("width",`${n}px`,"important"),r&&s.setProperty("height",`${r}px`,"important"),i)for(let a in i)s[a]=i[a]}var Ms=/^[\w-:]+$/;async function Wt(o,e,t=!1,n){let{ownerDocument:r,ownerWindow:i,fontFamilies:s,onCloneEachNode:a}=e;if(r&&zi(o))return n&&/\S/.test(o.data)&&n(o.data),r.createTextNode(o.data);if(r&&i&&V(o)&&(Me(o)||Re(o))){let c=await fs(o,e);if(e.isEnable("removeAbnormalAttributes")){let m=c.getAttributeNames();for(let g=m.length,y=0;y<g;y++){let E=m[y];Ms.test(E)||c.removeAttribute(E)}}let d=e.currentNodeStyle=vs(o,c,t,e);t&&ks(c,e);let u=!1;if(e.isEnable("copyScrollbar")){let m=[d.get("overflow-x")?.[0],d.get("overflow-y")?.[0]];u=m.includes("scroll")||(m.includes("auto")||m.includes("overlay"))&&(o.scrollHeight>o.clientHeight||o.scrollWidth>o.clientWidth)}let h=d.get("text-transform")?.[0],p=no(d.get("font-family")?.[0]),f=p?m=>{h==="uppercase"?m=m.toUpperCase():h==="lowercase"?m=m.toLowerCase():h==="capitalize"&&(m=m[0].toUpperCase()+m.substring(1)),p.forEach(g=>{let y=s.get(g);y||s.set(g,y=new Set),m.split("").forEach(E=>y.add(E))})}:void 0;return Ss(o,c,u,e,f),ws(o,c),tt(o)||await Xn(o,c,e,f),await a?.(c),c}let l=o.cloneNode(!1);return await Xn(o,l,e),await a?.(l),l}function Cs(o){if(o.ownerDocument=void 0,o.ownerWindow=void 0,o.svgStyleElement=void 0,o.svgDefsElement=void 0,o.svgStyles.clear(),o.defaultComputedStyles.clear(),o.sandbox){try{o.sandbox.remove()}catch(e){o.log.warn("Failed to destroyContext",e)}o.sandbox=void 0}o.workers=[],o.fontFamilies.clear(),o.fontCssTexts.clear(),o.requests.clear(),o.tasks=[],o.shadowRoots=[]}function As(o){let{url:e,timeout:t,responseType:n,...r}=o,i=new AbortController,s=t?setTimeout(()=>i.abort(),t):void 0;return fetch(e,{signal:i.signal,...r}).then(a=>{if(!a.ok)throw new Error("Failed fetch, not 2xx response",{cause:a});switch(n){case"arrayBuffer":return a.arrayBuffer();case"dataUrl":return a.blob().then(is);case"text":default:return a.text()}}).finally(()=>clearTimeout(s))}function Ae(o,e){let{url:t,requestType:n="text",responseType:r="text",imageDom:i}=e,s=t,{timeout:a,acceptOfImage:l,requests:c,fetchFn:d,fetch:{requestInit:u,bypassingCache:h,placeholderImage:p},font:f,workers:m,fontFamilies:g}=o;n==="image"&&(et||$t)&&o.drawImageCount++;let y=c.get(t);if(!y){h&&h instanceof RegExp&&h.test(s)&&(s+=(/\?/.test(s)?"&":"?")+new Date().getTime());let E=n.startsWith("font")&&f&&f.minify,x=new Set;E&&n.split(";")[1].split(",").forEach(P=>{g.has(P)&&g.get(P).forEach(D=>x.add(D))});let S=E&&x.size,M={url:s,timeout:a,responseType:S?"arrayBuffer":r,headers:n==="image"?{accept:l}:void 0,...u};y={type:n,resolve:void 0,reject:void 0,response:null},y.response=(async()=>{if(d&&n==="image"){let I=await d(t);if(I)return I}return!et&&t.startsWith("http")&&m.length?new Promise((I,P)=>{m[c.size&m.length-1].postMessage({rawUrl:t,...M}),y.resolve=I,y.reject=P}):As(M)})().catch(I=>{if(c.delete(t),n==="image"&&p)return o.log.warn("Failed to fetch image base64, trying to use placeholder image",s),typeof p=="string"?p:p(i);throw I}),c.set(t,y)}return y.response}async function lo(o,e,t,n){if(!co(o))return o;for(let[r,i]of Rs(o,e))try{let s=await Ae(t,{url:i,requestType:n?"image":"text",responseType:"dataUrl"});o=o.replace(Ns(r),`$1${s}$3`)}catch(s){t.log.warn("Failed to fetch css data url",r,s)}return o}function co(o){return/url\((['"]?)([^'"]+?)\1\)/.test(o)}var uo=/url\((['"]?)([^'"]+?)\1\)/g;function Rs(o,e){let t=[];return o.replace(uo,(n,r,i)=>(t.push([i,eo(i,e)]),n)),t.filter(([n])=>!_t(n))}function Ns(o){let e=o.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1");return new RegExp(`(url\\(['"]?)(${e})(['"]?\\))`,"g")}var Ls=["background-image","border-image-source","-webkit-border-image","-webkit-mask-image","list-style-image"];function Ps(o,e){return Ls.map(t=>{let n=o.getPropertyValue(t);return!n||n==="none"?null:((et||$t)&&e.drawImageCount++,lo(n,null,e,!0).then(r=>{!r||n===r||o.setProperty(t,r,o.getPropertyPriority(t))}))}).filter(Boolean)}function Hs(o,e){if(ve(o)){let t=o.currentSrc||o.src;if(!_t(t))return[Ae(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.srcset="",o.dataset.originalSrc=t,o.src=n||"")})];(et||$t)&&e.drawImageCount++}else if(Re(o)&&!_t(o.href.baseVal)){let t=o.href.baseVal;return[Ae(e,{url:t,imageDom:o,requestType:"image",responseType:"dataUrl"}).then(n=>{n&&(o.dataset.originalSrc=t,o.href.baseVal=n||"")})]}return[]}function Is(o,e){let{ownerDocument:t,svgDefsElement:n}=e,r=o.getAttribute("href")??o.getAttribute("xlink:href");if(!r)return[];let[i,s]=r.split("#");if(s){let a=`#${s}`,l=e.shadowRoots.reduce((c,d)=>c??d.querySelector(`svg ${a}`),t?.querySelector(`svg ${a}`));if(i&&o.setAttribute("href",a),n?.querySelector(a))return[];if(l)return n?.appendChild(l.cloneNode(!0)),[];if(i)return[Ae(e,{url:i,responseType:"text"}).then(c=>{n?.insertAdjacentHTML("beforeend",c)})]}return[]}function po(o,e){let{tasks:t}=e;V(o)&&((ve(o)||Qn(o))&&t.push(...Hs(o,e)),qi(o)&&t.push(...Is(o,e))),Me(o)&&t.push(...Ps(o.style,e)),o.childNodes.forEach(n=>{po(n,e)})}async function Ds(o,e){let{ownerDocument:t,svgStyleElement:n,fontFamilies:r,fontCssTexts:i,tasks:s,font:a}=e;if(!(!t||!n||!r.size))if(a&&a.cssText){let l=Yn(a.cssText,e);n.appendChild(t.createTextNode(`${l}
`))}else{let l=Array.from(t.styleSheets).filter(p=>{try{return"cssRules"in p&&!!p.cssRules.length}catch(f){return e.log.warn(`Error while reading CSS rules from ${p.href}`,f),!1}}),c=t.implementation.createHTMLDocument(""),d=c.createElement("style");c.head.appendChild(d);let u=d.sheet;await Promise.all(l.flatMap(p=>Array.from(p.cssRules).map(async f=>{if(Wi(f)){let m=f.href,g="";try{g=await Ae(e,{url:m,requestType:"text",responseType:"text"})}catch(E){e.log.warn(`Error fetch remote css import from ${m}`,E)}let y=g.replace(uo,(E,x,S)=>E.replace(S,eo(S,m)));for(let E of Os(y))try{u.insertRule(E,u.cssRules.length)}catch(x){e.log.warn("Error inserting rule from remote css import",{rule:E,error:x})}}}))),u.cssRules.length&&l.push(u);let h=[];l.forEach(p=>{Ot(p.cssRules,h)}),h.filter(p=>Fi(p)&&co(p.style.getPropertyValue("src"))&&no(p.style.getPropertyValue("font-family"))?.some(f=>r.has(f))).forEach(p=>{let f=p,m=i.get(f.cssText);m?n.appendChild(t.createTextNode(`${m}
`)):s.push(lo(f.cssText,f.parentStyleSheet?f.parentStyleSheet.href:null,e).then(g=>{g=Yn(g,e),i.set(f.cssText,g),n.appendChild(t.createTextNode(`${g}
`))}))})}}var _s=/(\/\*[\s\S]*?\*\/)/g,Vn=/((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;function Os(o){if(o==null)return[];let e=[],t=o.replace(_s,"");for(;;){let i=Vn.exec(t);if(!i)break;e.push(i[0])}t=t.replace(Vn,"");let n=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,r=new RegExp("((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})","gi");for(;;){let i=n.exec(t);if(i)r.lastIndex=n.lastIndex;else if(i=r.exec(t),i)n.lastIndex=r.lastIndex;else break;e.push(i[0])}return e}var Bs=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,$s=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function Yn(o,e){let{font:t}=e,n=t?t?.preferredFormat:void 0;return n?o.replace($s,r=>{for(;;){let[i,,s]=Bs.exec(r)||[];if(!s)return"";if(s===n)return`src: ${i};`}}):o}function Ot(o,e=[]){for(let t of Array.from(o))Ui(t)?e.push(...Ot(t.cssRules)):"cssRules"in t?Ot(t.cssRules,e):e.push(t);return e}var Fs=/\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;function Ws(o){return Fs.test(o.innerHTML)}async function Us(o,e){let t=await oo(o,e);if(V(t.node)&&Re(t.node)&&!Ws(t.node))return t.node;let{ownerDocument:n,log:r,tasks:i,svgStyleElement:s,svgDefsElement:a,svgStyles:l,font:c,progress:d,autoDestruct:u,onCloneNode:h,onEmbedNode:p,onCreateForeignObjectSvg:f}=t;r.time("clone node");let m=await Wt(t.node,t,!0);if(s&&n){let S="";l.forEach((M,I)=>{S+=`${M.join(`,
`)} {
  ${I}
}
`}),s.appendChild(n.createTextNode(S))}r.timeEnd("clone node"),await h?.(m),c!==!1&&V(m)&&(r.time("embed web font"),await Ds(m,t),r.timeEnd("embed web font")),r.time("embed node"),po(m,t);let g=i.length,y=0,E=async()=>{for(;;){let S=i.pop();if(!S)break;try{await S}catch(M){t.log.warn("Failed to run task",M)}d?.(++y,g)}};d?.(y,g),await Promise.all([...Array.from({length:4})].map(E)),r.timeEnd("embed node"),await p?.(m);let x=qs(m,t);return a&&x.insertBefore(a,x.children[0]),s&&x.insertBefore(s,x.children[0]),u&&Cs(t),await f?.(x),x}function qs(o,e){let{width:t,height:n}=e,r=ns(t,n,o.ownerDocument),i=r.ownerDocument.createElementNS(r.namespaceURI,"foreignObject");return i.setAttributeNS(null,"x","0%"),i.setAttributeNS(null,"y","0%"),i.setAttributeNS(null,"width","100%"),i.setAttributeNS(null,"height","100%"),i.append(o),r.appendChild(i),r}async function ho(o,e){let t=await oo(o,e),n=await Us(t),r=os(n,t.isEnable("removeControlCharacter"));t.autoDestruct||(t.svgStyleElement=ro(t.ownerDocument),t.svgDefsElement=t.ownerDocument?.createElementNS(ot,"defs"),t.svgStyles.clear());let i=ye(r,n.ownerDocument);return await ds(i,t)}var mo=3e4;async function fo(o){return o.startsWith("data:")?o:await _({type:"asset:fetch",url:o}).catch(()=>null)??!1}async function go(o,e,t){if(e.height*t>mo||e.width*t>mo)throw new Error("too large");let n=qt(o),r=await Ft(document.createElement("div"),{scale:t,backgroundColor:n,width:e.width,height:e.height,style:{width:`${o.offsetWidth}px`,height:`${o.scrollHeight}px`,maxHeight:"none",counterReset:zs(o),overflow:"visible",margin:"0",transformOrigin:"0 0",transform:`translate(${-e.left}px, ${-e.top}px)`},fetchFn:fo,timeout:15e3,filter:js(o,e),autoDestruct:!0,includeStyleProperties:Ks(o),features:{fixSvgXmlDecode:!1}});r.node=o;let i=new Ut(o.ownerDocument.defaultView??window);r.ownerWindow=i.view,r.onCreateForeignObjectSvg=l=>i.restore(l);let s=await ho(r),a=s.getContext("2d");if(!a)throw new Error("no canvas");if(Xs(a,s))throw new Error("blank");return s}function js(o,e){let t=new WeakSet,n,r=o.ownerDocument.defaultView??window,i=o.getBoundingClientRect(),s=o!==o.ownerDocument.body,a=s?o.scrollTop:0,l=s?o.scrollLeft:0,c=e.top,d=e.top+e.height,u=e.left,h=e.left+e.width;return p=>{let f=p.parentNode;if(f&&t.has(f))return!1;if(p.nodeType!==Node.ELEMENT_NODE)return!0;let m=p,g=r.getComputedStyle(m).display;if(g==="none")return!1;if(g.startsWith("inline")||g==="contents"||g.startsWith("table-"))return!0;let y=m.getBoundingClientRect(),E=y.top-i.top+a,x=y.left-i.left+l;return(E+y.height<c||E>d||x+y.width<u||x>h)&&(E>d||!(n??=Gs(o,r)).has(m))&&t.add(m),!0}}function zs(o){let e=o.ownerDocument.defaultView??window,t=[];for(let n=o;n;n=n.parentElement){let r=e.getComputedStyle(n).counterReset;r&&r!=="none"&&t.unshift(r)}return t.join(" ")||"none"}function Gs(o,e){let t=(r,i)=>{let s=e.getComputedStyle(r,i);return s.counterIncrement!=="none"||s.counterReset!=="none"||s.counterSet!=="none"},n=new WeakSet;for(let r of Array.from(o.querySelectorAll("*")))if(!(!t(r)&&!t(r,"::before")&&!t(r,"::after")))for(let i=r;i&&i!==o&&!n.has(i);i=i.parentElement)n.add(i);return n}var Ut=class{kept=[];view;constructor(e){let t=(n,r)=>{let i=e.getComputedStyle(n,r);if(!r||!i.content.includes("counter"))return i;let s=this.keep(i.content);return new Proxy(i,{get:(a,l)=>{if(l==="getPropertyValue")return d=>d==="content"?s:a.getPropertyValue(d);let c=Reflect.get(a,l,a);return typeof c=="function"?c.bind(a):c}})};this.view={getComputedStyle:t}}keep(e){return this.kept.push(e),`YLKEPT${this.kept.length-1}X`}async restore(e){let t=e.querySelector("style");if(!t?.textContent)return;let n=t.textContent.replace(/content: 'YLKEPT(\d+)X';/g,(i,s)=>`content: ${this.kept[Number(s)]};`),r=new Set(Array.from(n.matchAll(/url\("(https?:[^"]+)"\)/g),i=>i[1]));await Promise.all(Array.from(r,async i=>{let s=await fo(i);s&&(n=n.split(i).join(s))})),t.textContent=n}};function qt(o){let e=o.ownerDocument.defaultView??window;for(let t=o;t;t=t.parentElement){let n=e.getComputedStyle(t).backgroundColor;if(n&&n!=="transparent"&&!/rgba(.*, 0)$/.test(n))return n}return"#ffffff"}function Ks(o){let e=(o.ownerDocument.defaultView??window).getComputedStyle(o),t=[];for(let n=0;n<e.length;n++){let r=e.item(n);!r.startsWith("--")&&!/^(animation|transition|view-timeline|scroll-timeline|animation-timeline)/.test(r)&&t.push(r)}return t}function Xs(o,e){let t=Math.max(1,Math.floor(e.height/400)),{data:n}=o.getImageData(0,0,e.width,e.height),[r,i,s]=[n[0],n[1],n[2]];for(let a=0;a<e.height;a+=t)for(let l=0;l<e.width;l+=3){let c=(a*e.width+l)*4;if(n[c]!==r||n[c+1]!==i||n[c+2]!==s)return!1}return!0}var G={margin:12,line:1.5,radius:12,top:18,foot:38};function bo(o,e,t,n){let r=(G.margin+G.line)*n,i=document.createElement("canvas");i.width=o.width+Math.round(r*2),i.height=o.height+Math.round(r*2+(G.top+G.foot)*n);let s=i.getContext("2d");if(!s)throw new Error("no canvas");let{width:a,height:l}=i;s.fillStyle="#ffffff",s.fillRect(0,0,a,l),s.fillStyle=e,s.fillRect(0,0,a,l);let[c=255,d=255,u=255]=s.getImageData(0,0,1,1).data,h=.299*c+.587*d+.114*u<128;return s.save(),s.beginPath(),s.roundRect(r,r,a-r*2,l-r*2,G.radius*n),s.clip(),s.drawImage(o,Math.round(r),Math.round(r+G.top*n)),s.restore(),s.fillStyle=h?"#9aa3ae":"#7c828b",s.font=`${12*n}px -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif`,s.textAlign="center",s.textBaseline="middle",s.fillText(t,a/2,l-r-G.foot/2*n),Vs(s,a,l,n),i}function Vs(o,e,t,n){let r=(G.margin+G.line/2)*n,i=(G.radius+G.line/2)*n,s={x:e-r,y:t-r},a=e/2,l=[],c=r+i,d=s.y-i;l.push([0,0,e,c,r,0,s.x,0],[a,c,a,d-c,0,c,0,d],[0,d,e,t-d,s.x,0,r,0],[0,c,a,d-c,0,d,0,c]);for(let[u,h,p,f,m,g,y,E]of l){let x=o.createLinearGradient(m,g,y,E);for(let[S,M]of Se)x.addColorStop(Number(S),M);o.save(),o.beginPath(),o.rect(u,h,p,f),o.clip(),o.beginPath(),o.roundRect(r,r,s.x-r,s.y-r,i),o.lineWidth=G.line*n,o.strokeStyle=x,o.stroke(),o.restore()}}function yo(o){let e=new Set;for(let t of o.matchAll(/<x(\d+)>/g))e.add(Number(t[1]));return e}var vo=o=>re(X(o)).trim();async function wo(o,e,t){let r=(await _({type:"translate",items:o.map(i=>i.markup),from:e,to:t}))?.results;return!r||r.length!==o.length?o.map(()=>({ok:!1,code:"network"})):(e||await Promise.all(r.map(async(i,s)=>{let a=o[s];if(!i.ok||!Ye(i,a.hint,t))return;let c=(await _({type:"translate",items:[a.markup],from:a.hint,to:t}))?.results?.[0];c?.ok&&c.text.trim()&&vo(c.text)!==vo(a.markup)&&(r[s]=c)})),r)}var Ys=200,Js=700,Zs=8,Qs=120,ea=20,ta=2,na=360,xo=180,Ne=16,Eo=18,jt=39,oa=36,rt=8,ra=.25,ia=24,sa=260,aa=170,la=120,ca=560,da=80,ua=3e4,pa=60,ha='img,svg,picture,hr,video,canvas,button,input,select,textarea,yl-r,[role="button"],[role="img"]';function ma(){return new Promise(o=>{let e=setTimeout(o,120);requestAnimationFrame(()=>requestAnimationFrame(()=>{clearTimeout(e),o()}))})}function So(o){return new Promise((e,t)=>o.toBlob(n=>n?e(n):t(new Error("no image")),"image/png"))}function fa(o){let e=atob(o.slice(o.indexOf(",")+1)),t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return new Blob([t],{type:"image/png"})}function To(o){let e=o[0],t=o[o.length-1];if(!e||!t||!e.isConnected||!t.isConnected)return null;let n=document.createRange();return n.setStartBefore(e),n.setEndAfter(t),n.getBoundingClientRect()}function it(o){return getComputedStyle(o).visibility==="visible"}function st(o,e){let t=[],n=!1;for(let r=o;r;r=r.parentElement){let i=e.get(r);if(i!==void 0){n=i;break}t.push(r);let s=getComputedStyle(r).position;if(s==="fixed"||s==="sticky"){n=!0;break}}for(let r of t)e.set(r,n);return n}var at=class{constructor(e,t,n){this.ui=e;this.settings=t;this.pageTranslated=n}rect;scroller=null;band={top:0,bottom:0};box;card;body;bar;labels=[];mirror;scanner=new fe;entries=[];byCopy=new WeakMap;seenNodes=new WeakSet;seenText=new Map;queue=[];inFlight=0;scanTimer;flushTimer;scanning=!1;rescan=!1;frame=0;backdrop;view;findInput;findCount;closeTimer;exporting=!1;restoreCard;observer;session=0;get running(){return this.rect!==void 0}start(e){this.stop(),this.session++,this.rect=e,this.scanner.classifier.setExcludes(this.settings().excludeSelectors);let t=document.elementFromPoint((e.left+e.right)/2,(e.top+e.bottom)/2);this.scroller=t?this.findScroller(t):null,this.band={top:this.toContent(e.top),bottom:this.toContent(e.bottom)},this.box=this.ui.addFrame(),Object.assign(this.box.style,{left:`${B(e.left)}px`,top:`${B(e.top)}px`,width:`${B(e.right-e.left)}px`,height:`${B(e.bottom-e.top)}px`}),this.buildBar(e),this.buildCard(e),addEventListener("scroll",this.onScroll,!0),addEventListener("resize",this.syncView),addEventListener("keydown",this.onKey,!0),this.observer=new MutationObserver(this.onMutation),document.body&&this.observer.observe(document.body,{childList:!0,subtree:!0}),this.scan()}stop(){this.session++,removeEventListener("scroll",this.onScroll,!0),removeEventListener("resize",this.syncView),removeEventListener("keydown",this.onKey,!0),this.observer?.disconnect(),this.observer=void 0,clearTimeout(this.scanTimer),clearTimeout(this.flushTimer),cancelAnimationFrame(this.frame),this.scanTimer=this.flushTimer=void 0,this.frame=0,clearTimeout(this.closeTimer),this.closeTimer=void 0,this.exporting=!1,this.view=this.findInput=this.findCount=void 0,this.mirror?.destroy(),this.mirror=void 0;for(let e of this.entries)e.segment?.unrender();this.box?.remove(),this.ui.dismiss(this.bar),this.ui.dismiss(this.card),this.box=this.bar=this.card=this.body=void 0,this.labels=[],this.rect=void 0,this.scroller=null,this.entries=[],this.byCopy=new WeakMap,this.queue=[],this.seenNodes=new WeakSet,this.seenText.clear(),this.inFlight=0,this.scanning=!1,this.rescan=!1,this.backdrop?.remove(),this.backdrop=void 0,this.restoreCard=void 0}findScroller(e){for(let t=e;t&&t!==document.body&&t!==document.documentElement;t=t.parentElement){let n=getComputedStyle(t).overflowY;if((n==="auto"||n==="scroll")&&t.scrollHeight>t.clientHeight+1)return t}return null}get origin(){return this.scroller?this.scroller.getBoundingClientRect().top+this.scroller.clientTop:0}get scrollPos(){return this.scroller?this.scroller.scrollTop:scrollY}atScrollEnd(){let e=this.scroller;if(e)return e.scrollTop+e.clientHeight>=e.scrollHeight-2;let t=document.documentElement;return scrollY+innerHeight>=t.scrollHeight-2}toContent(e){return e-this.origin+this.scrollPos}onKey=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),this.exporting?this.exporting=!1:this.findInput?.value?this.clearFind():this.restoreCard?this.exitImmersive():this.stop())};enterImmersive(){let e=this.card,t=this.view;if(!e||!t||this.restoreCard)return;let n=e.getBoundingClientRect();this.restoreCard={left:e.style.left,top:e.style.top,bottom:e.style.bottom,height:e.style.height};let r=this.ui.addBelow(w("div","scan-backdrop"),e);r.addEventListener("click",()=>this.exitImmersive()),r.addEventListener("wheel",a=>a.preventDefault(),{passive:!1}),this.backdrop=r,e.removeAttribute("data-hidden"),this.mirror?.hidePinned(),this.placeFrame();let i=innerHeight-ia*2,s=Math.min(i,Math.max(sa,t.contentHeight+jt));t.start(s-jt,this.mirror?.scrollerTop??0),e.style.top=`${n.top}px`,e.style.bottom="auto",e.style.left=`${n.left}px`,e.style.height=`${n.height}px`,e.offsetHeight,e.classList.add("scan-animate","scan-immersive"),e.style.top=`${Math.round((innerHeight-s)/2)}px`,e.style.left=`${Math.round((innerWidth-n.width)/2)}px`,e.style.height=`${s}px`}exitImmersive(){let e=this.card;!e||!this.restoreCard||this.closeTimer!==void 0||(this.ui.dismiss(this.backdrop),this.backdrop=void 0,e.classList.add("scan-closing"),this.closeTimer=setTimeout(()=>{this.closeTimer=void 0;let t=this.restoreCard;this.restoreCard=void 0,this.clearFind(),this.view?.stop(),e.classList.remove("scan-immersive","scan-animate","scan-closing"),e.setAttribute("data-hidden",""),t&&Object.assign(e.style,t),this.placeFrame(),this.requestSync()},aa))}clearFind(){this.findInput&&(this.findInput.value=""),this.view?.clearFind(),this.paintFind(0,0,!1)}paintFind(e,t,n){this.findCount&&(this.findCount.textContent=t?`${e}/${t}`:n?"0/0":"");let r=this.findInput?.parentElement;r?.toggleAttribute("data-none",n),r?.toggleAttribute("data-found",t>0),r?.toggleAttribute("data-typed",t>0||n)}buildFind(){let e=w("div","scan-find"),t=w("input","scan-find-input");t.type="text",t.placeholder=v("findPlaceholder"),t.spellcheck=!1;let n=w("span","scan-find-count","");e.addEventListener("click",()=>t.focus({preventScroll:!0})),this.findInput=t,this.findCount=n;let r=0,i,s=c=>{r&&this.paintFind(this.view?.step(c)??0,r,!1)};t.addEventListener("input",()=>{clearTimeout(i),i=setTimeout(()=>{r=this.view?.find(t.value)??0,this.paintFind(r?1:0,r,!r&&!!t.value.trim())},la)}),t.addEventListener("keydown",c=>{c.stopPropagation(),c.key==="Enter"&&(c.preventDefault(),s(c.shiftKey?-1:1))});for(let c of["keyup","keypress"])t.addEventListener(c,d=>d.stopPropagation());let a=$("up",v("findPrevious"),()=>s(-1)),l=$("down",v("findNext"),()=>s(1));for(let c of[a,l])c.addEventListener("mousedown",d=>d.preventDefault());return e.append(ue("search"),t,n,a,l),e}onScroll=e=>{if(this.ui.ownsEvent(e))return;if(this.scroller&&e.target!==this.scroller){this.requestSync();return}let t=this.rect;if(!t)return;let n=this.toContent(t.top),r=this.toContent(t.bottom),i=n<this.band.top||r>this.band.bottom;this.band.top=Math.min(this.band.top,n),this.band.bottom=Math.max(this.band.bottom,r);let s=this.atScrollEnd()&&this.band.bottom!==1/0;s&&(this.band.bottom=1/0),(i||s)&&this.scheduleScan(Ys),this.requestSync()};onMutation=()=>this.scheduleScan(Js);scheduleScan(e){this.scanTimer===void 0&&(this.scanTimer=setTimeout(()=>{this.scanTimer=void 0,this.scan()},e))}isCovered(e){let t=this.rect;if(!t||!e.width||!e.height)return!1;let n=Math.min(e.right,t.right)-Math.max(e.left,t.left),r=t.right-t.left;if(n<e.width*.5&&n<r*.6)return!1;let i=this.toContent(e.top),s=this.toContent(e.bottom);return Math.min(s,this.band.bottom)-Math.max(i,this.band.top)>=(s-i)*.5}async scan(){if(!this.rect)return;if(this.scanning){this.rescan=!0;return}this.scanning=!0;let e=this.session;this.scanner.reset();let t=new Map,n=this.settings().targetLang,r=this.scroller??document.body;if(r){let i={consume:()=>!1,shadowRoot:()=>{},emit:a=>this.considerRun(a,n,t),skipped:a=>this.considerSkipped(a,t),plain:(a,l)=>this.considerPlain(a,l,t)},s=performance.now();for(let a of this.scanner.scan(r,i))if(performance.now()-s>Zs){if(await new Promise(l=>setTimeout(l,0)),e!==this.session)return;s=performance.now()}this.revealLeaves(r,t)}this.scanning=!1,this.requestSync(),this.rescan&&(this.rescan=!1,this.scan())}revealLeaves(e,t){for(let n of Array.from(e.querySelectorAll(ha)))this.seenNodes.has(n)||st(n,t)||!it(n)||this.isCovered(n.getBoundingClientRect())&&(this.seenNodes.add(n),this.mirror?.showWhole(n))}alreadyHave(e,t,n){return this.seenNodes.has(e)?!0:!!this.seenText.get(t)?.some(r=>Math.abs(r-n)<pa)}remember(e,t,n){this.seenNodes.add(e);let r=this.seenText.get(t);r?r.push(n):this.seenText.set(t,[n])}considerRun(e,t,n){let r=e.nodes[0];if(this.seenNodes.has(r))return;let i=new ge(e),s=i.parentElement;if(st(s,n)||!it(s))return;let a=To(e.nodes);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,e.markup,l))return;this.remember(r,e.markup,l);let c=Te(e.text,t),d=this.mirror?.showRun(e.nodes,!c);if(!d)return;let u=this.addEntry("text",a,d);u.segment=i,c?this.setState(u,"kept"):(this.queue.push(u),this.scheduleFlush())}considerSkipped(e,t){if(this.seenNodes.has(e)||st(e,t)||!it(e))return;let n=e.getBoundingClientRect();if(!this.isCovered(n))return;let r=e.textContent??"",i=Sn(e)&&!!r.trim(),s=this.toContent(n.top);if(i&&this.alreadyHave(e,r,s))return;i?this.remember(e,r,s):this.seenNodes.add(e);let a=this.mirror?.showWhole(e);if(!a||!i)return;let l=this.addEntry("code",n,a);this.setState(l,"kept")}considerPlain(e,t,n){let r=e[0];if(!r||this.seenNodes.has(r))return;let i=e.map(u=>u.textContent??"").join("").trim();if(!i)return;let s=t.nodeType===Node.ELEMENT_NODE?t:t.host;if(st(s,n)||!it(s))return;let a=To(e);if(!a||!this.isCovered(a))return;let l=this.toContent(a.top);if(this.alreadyHave(r,i,l))return;this.remember(r,i,l);let c=this.mirror?.showRun(e,!1);if(!c)return;let d=this.addEntry("verbatim",a,c);this.setState(d,"kept")}addEntry(e,t,n){let r={kind:e,state:"pending",top:this.toContent(t.top),bottom:this.toContent(t.bottom),left:t.left,right:t.right,copy:n};this.byCopy.set(n,r);let i=this.entries.length;for(;i>0;){let s=this.entries[i-1];if(s.top<r.top||s.top===r.top&&s.left<=r.left)break;i--}return this.entries.splice(i,0,r),this.updateLabel(),r}setState(e,t){e.state=t,this.updateLabel()}buildBar(e){let t=w("div","scan-bar"),n=w("span","grow","");this.labels.push(n),t.append(n,$("expand",v("immersive"),()=>this.enterImmersive()),$("copy",v("copyMarkdown"),()=>this.copyAll()),$("close",v("close"),()=>this.stop()));let r=e.top-oa-rt;Object.assign(t.style,{top:`${B(r>=rt?r:e.top+rt)}px`,right:`${B(Math.max(rt,innerWidth-e.right))}px`}),this.bar=this.ui.add(t)}buildCard(e){let t=w("div","scan-card");t.setAttribute("role","log"),t.setAttribute("aria-label",v("marqueeScan")),t.setAttribute("data-hidden","");let n=w("div","scan-head"),r=w("span","grow","");this.labels.push(r),n.append(r,this.buildFind(),$("image",v("copyImage"),()=>this.copyImage()),$("download",v("exportImage"),()=>void this.saveImage()),$("collapse",v("exitImmersive"),()=>this.exitImmersive()),$("copy",v("copyMarkdown"),()=>this.copyAll()),$("close",v("close"),()=>this.stop())),n.addEventListener("wheel",c=>{c.preventDefault(),this.view?.scrollBy(c.deltaY)},{passive:!1});let i=w("div","scan-body");t.append(n,i),this.body=i;let s=e.bottom-e.top+jt,a=innerHeight-e.bottom-Ne*2,l=a>=xo?Math.min(a,s):Math.round(innerHeight*.42);Object.assign(t.style,{height:`${Math.max(xo,l)}px`,bottom:`${Ne}px`}),this.card=this.ui.add(t),this.updateLabel(),this.mirror=new Ke(i,this.scroller,()=>{},this.onKey),this.view=new Qe(this.mirror,i,()=>this.entries.map(c=>c.copy)),this.view.stop(),this.placeFrame()}placeFrame(){let e=this.mirror?.frame,t=this.rect,n=this.body,r=this.card;if(!e||!t||!n||!r)return;let i=(t.right-t.left)*ra,s=t.left,a=t.right;for(let l of this.entries)s=Math.min(s,Math.max(l.left,t.left-i)),a=Math.max(a,Math.min(l.right,t.right+i));if(s=Math.max(0,s-Eo),a=Math.min(innerWidth,a+Eo),!this.restoreCard){let l=Math.min(innerWidth-Ne*2,Math.max(na,a-s));r.style.width=`${l}px`,r.style.left=`${Math.max(Ne,Math.min(s,innerWidth-l-Ne))}px`}if(this.restoreCard){let l=this.mirror?.scrollerTop??0;Object.assign(e.style,{left:`${-s}px`,top:`${-l}px`,width:`${innerWidth}px`,height:`${innerHeight+l}px`});return}Object.assign(e.style,{left:`${-s}px`,top:`${-t.top}px`,width:`${innerWidth}px`,height:`${Math.max(innerHeight,t.top+n.clientHeight)}px`})}paintPending(){this.box&&this.ui.setFramePending(this.box,this.inFlight>0||this.queue.length>0)}scheduleFlush(){this.paintPending(),this.flushTimer===void 0&&(this.flushTimer=setTimeout(()=>{this.flushTimer=void 0,this.pump()},Qs))}pump(){for(;this.inFlight<ta&&this.queue.length;)this.send(this.queue.splice(0,ea))}async send(e){let t=this.session,n=this.settings();this.inFlight++;let r;try{r=await wo(e.map(s=>({markup:s.segment.markup,hint:s.segment.sourceHint()})),n.sourceLang,n.targetLang)}catch{r=void 0}if(t!==this.session||!F())return;this.inFlight--;let i;e.forEach((s,a)=>{let l=r?.[a],c=s.segment.run;if(l?.ok&&l.text.trim()){let d=new Set(c.slots.map((u,h)=>h));this.mirror?.setTranslation(s.copy,xe(X(l.text,d),u=>!!c.slots[u]?.detached),c.slots,yo(c.markup)),this.replaceOnPage(s,l.text,n),this.setState(s,"done")}else this.mirror?.setKept(s.copy),this.setState(s,"failed"),i??=l&&!l.ok?l.code:"network"}),i&&this.ui.toast(this.ui.errorMessage(i)),this.requestSync(),this.pump(),this.paintPending()}replaceOnPage(e,t,n){let r=e.segment;!r||this.pageTranslated()||(r.setTranslation(t),r.render({mode:"replace",dualStyle:"plain",fontScale:100,targetLang:n.targetLang,theme:de(n.themeColor)}))}updateLabel(){if(!this.labels.length)return;let e=0,t=0;for(let n of this.entries)n.kind==="code"?t++:n.state==="done"&&e++;for(let n of this.labels)n.textContent=v("scanStatus",String(e),String(t))}copyAll(){let e=jn(this.entries);navigator.clipboard.writeText(e).then(()=>{for(let t of this.labels)t.textContent=v("copied");setTimeout(()=>this.updateLabel(),1200)})}async withPicture(e){let t=this.card;if(!t||!this.restoreCard||this.exporting)return;this.exporting=!0;let n=this.session;t.setAttribute("data-exporting",""),this.clearFind();let r=w("div","scan-making"),i=w("div","scan-making-note");i.append(w("span","scan-making-spin"),w("span","",v("exportingFast"))),r.append(i),this.body?.append(r),await ma();try{let s=await this.drawResult().catch(()=>null)??await this.photographResult();if(!s||n!==this.session)return;let a=this.mirror?.scroller??this.mirror?.doc.body;return await e(bo(s,a?qt(a):"#ffffff",v("pictureMark",v("extName")),devicePixelRatio||1))}catch{this.ui.toast(v("exportFailed"));return}finally{r.remove(),n===this.session&&(this.exporting=!1,t.removeAttribute("data-exporting"),this.updateLabel())}}async drawResult(){let e=this.mirror,t=this.view,n=this.body,r=e?.scroller;if(!e||!t||!n||!r)throw new Error("not ready");let i=r!==e.doc.scrollingElement,s=i?r:e.doc.body,{from:a,to:l,visible:c}=t.extent,d=devicePixelRatio||1,u=n.getBoundingClientRect().left-e.frame.getBoundingClientRect().left,h=s.getBoundingClientRect();return go(s,{left:u-h.left,top:i?a:a-(h.top+(e.doc.defaultView?.scrollY??0)),width:n.clientWidth,height:l-a+c},d)}async photographResult(){let e=this.view,t=this.body;if(!e||!t)return null;let n=this.session,r=e.position;this.card?.setAttribute("data-photographing","");try{await new Promise(p=>setTimeout(p,340));let{from:i,to:s,visible:a}=e.extent,l=t.getBoundingClientRect(),c=devicePixelRatio||1,d=document.createElement("canvas");d.width=Math.round(l.width*c),d.height=Math.min(Math.round((s-i+a)*c),ua);let u=d.getContext("2d");if(!u)throw new Error("no canvas");let h=Math.ceil(d.height/c/a);for(let p=0;p<h;p++){if(!this.exporting||n!==this.session)return null;for(let y of this.labels)y.textContent=v("exporting",String(p+1),String(h));e.moveTo(i+p*a),await new Promise(y=>setTimeout(y,p?ca:da));let f=await _({type:"capture:screen"});if(!f)throw new Error("refused");let m=await createImageBitmap(fa(f)),g=m.width/innerWidth;u.drawImage(m,l.left*g,l.top*g,l.width*g,l.height*g,0,Math.round((e.position-i)*c),d.width,Math.round(l.height*c)),m.close()}return d}finally{this.card?.removeAttribute("data-photographing"),n===this.session&&e.moveTo(r)}}async saveImage(){await this.withPicture(async e=>{let t=await So(e),n=document.createElement("a");n.href=URL.createObjectURL(t),n.download=`yilan-${location.hostname}-${new Date().toISOString().slice(0,10)}.png`,n.click(),setTimeout(()=>URL.revokeObjectURL(n.href),1e4)})}copyImage(){if(!this.restoreCard||this.exporting)return;if(!navigator.clipboard?.write){this.ui.toast(v("copyImageFailed"));return}let e=()=>{},t=()=>{},n=new Promise((i,s)=>{e=i,t=s}),r=navigator.clipboard.write([new ClipboardItem({"image/png":n})]);this.withPicture(async i=>(e(await So(i)),await r,this.ui.toast(v("copiedImage"),void 0,1800),!0)).then(i=>{i||t(new Error("no picture"))}),r.catch(()=>this.ui.toast(v("copyImageFailed")))}requestSync(){this.frame||(this.frame=requestAnimationFrame(this.syncView))}syncView=()=>{this.frame=0;let e=this.rect;if(!e)return;this.placeFrame();let t=this.toContent(e.top),n=this.toContent(e.bottom),r=this.entries.find(i=>i.bottom>t&&i.top<n);r&&!this.restoreCard&&this.mirror?.alignTo(r.copy,e.top+(r.top-t))}};var we="http://www.w3.org/2000/svg",ut=8,zt=5,Kt=16,oe=8,lt=13,ct=8,ga=24,ba=22,ya=1.6,va=2e3,wa=80,xa=48,Ea=96,dt=3,Sa=1100,Ta=0;function ka(o){for(let e=o.parentElement;e;e=e.parentElement){let t=getComputedStyle(e).display;if(!t.startsWith("inline")&&t!=="contents")return e}return null}function ko(o){let e=o.commonAncestorContainer,t=new Map,n=document.createRange(),r=i=>{if(!i.data.trim()||!o.intersectsNode(i))return;let s=i===o.startContainer?o.startOffset:0,a=i===o.endContainer?o.endOffset:i.length;n.setStart(i,s),n.setEnd(i,a);let l=Array.from(n.getClientRects()).filter(u=>u.width&&u.height);if(!l.length)return;let c=ka(i);if(!c)return;let d=t.get(c);d?(d.rects.push(...l),d.end=[i,a]):t.set(c,{el:c,rects:l,start:[i,s],end:[i,a]})};if(e.nodeType===Node.TEXT_NODE)r(e);else{let i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let s=i.nextNode(),a=0;s&&a<va;s=i.nextNode(),a++)r(s)}return Array.from(t.values())}function Mo(o){return ko(o).map(e=>({el:e.el,members:[e.el],lines:Co(e.rects)}))}function Co(o){let e=[];for(let n of o){let r=e.find(i=>Math.min(i.bottom,n.bottom)-Math.max(i.top,n.top)>Math.min(i.bottom-i.top,n.bottom-n.top)/2);r?(r.left=Math.min(r.left,n.left),r.right=Math.max(r.right,n.right),r.top=Math.min(r.top,n.top),r.bottom=Math.max(r.bottom,n.bottom)):e.push({left:n.left,top:n.top,right:n.right,bottom:n.bottom})}return e.sort((n,r)=>n.top-r.top),e.some((n,r)=>r>0&&(n.left>e[r-1].right||n.right<e[r-1].left))?[{left:Math.min(...e.map(n=>n.left)),top:e[0].top,right:Math.max(...e.map(n=>n.right)),bottom:Math.max(...e.map(n=>n.bottom))}]:e}function Ma(o){for(let e=o;e&&e!==document.body;e=e.parentElement)if(/fixed|sticky/.test(getComputedStyle(e).position))return!0;return!1}function pt(o){return{left:Math.min(...o.map(e=>e.left)),top:Math.min(...o.map(e=>e.top)),right:Math.max(...o.map(e=>e.right)),bottom:Math.max(...o.map(e=>e.bottom))}}function Ao(o,e){let t=Math.max(o.left,e.left)-Math.min(o.right,e.right),n=Math.max(o.top,e.top)-Math.min(o.bottom,e.bottom);return t<=0&&n<=wa||n<=0&&t<=xa}function Ca(o){let e=o.map(t=>({el:t.el,members:[...t.members],lines:[...t.lines]}));for(let t=!0;t;){t=!1;for(let n=0;n<e.length&&!t;n++)for(let r=n+1;r<e.length&&!t;r++)Ao(pt(e[n].lines),pt(e[r].lines))&&(e[n].lines.push(...e[r].lines),e[n].members.push(...e[r].members),e.splice(r,1),t=!0)}return e.map(t=>({el:t.el,members:t.members,lines:Co(t.lines)}))}function mt(o){let e=Mo(o).map(r=>({el:r.el,members:r.members,lines:r.lines.filter(i=>i.top>=0&&i.bottom<=innerHeight&&i.left>=0&&i.right<=innerWidth)})).filter(r=>r.lines.length),t=e.filter(r=>!Ma(r.el)),n=Ca(t.length?t:e);return n.length===1?{tail:n[0]}:null}function Ro(o){let e=[];for(let t of ko(o)){let n=pt(t.rects),r=e[e.length-1],i=!!r&&Math.min(r.box.bottom,n.bottom)>Math.max(r.box.top,n.top)&&n.left-r.box.right<=Ea;if(r&&i){r.range.setEnd(t.end[0],t.end[1]),r.box=pt([r.box,n]);continue}let s=document.createRange();s.setStart(t.start[0],t.start[1]),s.setEnd(t.end[0],t.end[1]),e.push({el:t.el,range:s,newPlace:!!r&&!Ao(r.box,n),box:n})}return e}function No(o,e){let t=w("div","source-flash");for(let n of Mo(e).flatMap(r=>r.lines)){let r=w("div","source-flash-line");r.style.left=`${n.left-3}px`,r.style.top=`${n.top-2}px`,r.style.width=`${n.right-n.left+6}px`,r.style.height=`${n.bottom-n.top+4}px`,t.append(r)}o.add(t),setTimeout(()=>t.remove(),Sa)}function Aa(o){let e=[];for(let t of o){let n=e[e.length-1];(!n||Math.abs(n[0]-t[0])>.5||Math.abs(n[1]-t[1])>.5)&&e.push(t)}return e.filter((t,n)=>{let r=e[(n-1+e.length)%e.length],i=e[(n+1)%e.length];return!(Math.abs(r[0]-t[0])<.5&&Math.abs(i[0]-t[0])<.5)&&!(Math.abs(r[1]-t[1])<.5&&Math.abs(i[1]-t[1])<.5)})}function Ra(o){let e=o.length,t="";return o.forEach((n,r)=>{let i=o[(r-1+e)%e],s=o[(r+1)%e],a=Math.hypot(i[0]-n[0],i[1]-n[1]),l=Math.hypot(s[0]-n[0],s[1]-n[1]),c=Math.min(Kt,a/2,l/2),d=[n[0]+(i[0]-n[0])/a*c,n[1]+(i[1]-n[1])/a*c],u=[n[0]+(s[0]-n[0])/l*c,n[1]+(s[1]-n[1])/l*c];t+=`${r?"L":"M"}${d[0]} ${d[1]}Q${n[0]} ${n[1]} ${u[0]} ${u[1]}`}),`${t}Z`}function Na(o){let e=document.createElementNS(we,"path");e.setAttribute("d",o);let t=e.getTotalLength(),n=Math.max(10,Math.round(t/ba)),r=[];for(let i=0;i<n;i++){let s=e.getPointAtLength(i/n*t);r.push([s.x,s.y])}return r.map((i,s)=>{let a=r[(s-1+n)%n],l=r[(s+1)%n],c=l[0]-a[0],d=l[1]-a[1],u=Math.hypot(c,d)||1,h=ya*(Math.sin(s*.9)*.6+Math.sin(s*.37+1.3)*.7);return[i[0]+d/u*-h,i[1]+c/u*h]})}function Gt(o,e,t){let n=o.length,r=s=>o[(s%n+n)%n],i="";for(let s=0;s<t;s++){let a=e+s,[l,c,d,u]=[r(a-1),r(a),r(a+1),r(a+2)];i+=`C${c[0]+(d[0]-l[0])/6} ${c[1]+(d[1]-l[1])/6} ${d[0]-(u[0]-c[0])/6} ${d[1]-(u[1]-c[1])/6} ${d[0]} ${d[1]}`}return i}function La(o){let{lines:e}=o,t=e[0],n=e[e.length-1],r=parseFloat(getComputedStyle(o.el).lineHeight),i=t.bottom-t.top,s=zt+(r>i&&r<i*3?(r-i)/2:0),a=Math.max(dt,t.top-s),l=Math.min(innerHeight-dt,n.bottom+s),c=p=>Math.max(dt,p.left-ut),d=p=>Math.min(innerWidth-dt,p.right+ut),u=[[c(t),a],[d(t),a]],h=(p,f,m)=>(p.bottom+f.top)/2+(m?zt:-zt);e.forEach((p,f)=>{let m=e[f+1];if(!m)return;let g=h(p,m,d(p)>d(m));u.push([d(p),g],[d(m),g])}),u.push([d(n),l],[c(n),l]);for(let p=e.length-1;p>0;p--){let f=h(e[p-1],e[p],c(e[p-1])<c(e[p]));u.push([c(e[p]),f],[c(e[p-1]),f])}return{points:Na(Ra(Aa(u))),top:a,bottom:l,padY:s}}function Lo(o,e,t,n=!0){let{points:r,top:i,bottom:s,padY:a}=La(o),l=o.lines[0],c=o.lines[o.lines.length-1],d=s+lt+t<=innerHeight-oe,u=i-lt-t>=oe;if(!n||!d&&!u)return{path:"M"+r[0][0]+" "+r[0][1]+Gt(r,0,r.length)+"Z",left:Math.max(oe,Math.min(l.left,innerWidth-e-oe)),top:Math.max(oe,innerHeight-t-oe)};let h=d,p=h?c:l,f=h?s:i,m=p.left-ut+Kt+ct,g=p.right+ut-Kt-ct,y=h?g-12:m+12,E=g>m?Math.max(m,Math.min(y,g)):(p.left+p.right)/2,x=h?f+lt:f-lt,S=Math.min(ga,e/2),M=Math.max(oe,E-e+S),I=Math.min(innerWidth-e-oe,E-S),P=Math.max(M,Math.min(l.left,I)),D=r.length,j=-1,U=-1;r.forEach((b,A)=>{if(Math.abs(b[1]-f)>=a+6)return;let N=b[0]-E;N>=ct*.6&&(j<0||N<r[j][0]-E)&&(j=A),N<=-ct*.6&&(U<0||N>r[U][0]-E)&&(U=A)});let[T,C]=h?[j,U]:[U,j],R;if(T<0||C<0)R=`M${r[0][0]} ${r[0][1]}${Gt(r,0,D)}Z`;else{let b=(T-C+D)%D||D;R=`M${r[C][0]} ${r[C][1]}${Gt(r,C,b)}L${E} ${x}Z`}return{path:R,left:P,top:h?x-1:x-t+1}}function Po(o,e=!0){let t=document.createElementNS(we,"svg");t.setAttribute("class","bubble-ring"),t.setAttribute("aria-hidden","true");let n=`yl-ring-${++Ta}`,r=document.createElementNS(we,"defs"),i=document.createElementNS(we,"linearGradient");i.id=n,i.setAttribute("x2","1"),i.setAttribute("y2","0.3");for(let[s,a]of Se){let l=document.createElementNS(we,"stop");l.setAttribute("offset",s),l.setAttribute("stop-color",a),i.append(l)}r.append(i),t.append(r);for(let s of o){let a=document.createElementNS(we,"path");a.setAttribute("d",s),e&&a.setAttribute("pathLength","1"),a.setAttribute("stroke",`url(#${n})`),t.append(a)}return t}function Ho(o,e,t){let{path:n,left:r,top:i}=Lo(t.tail,e.offsetWidth,e.offsetHeight);e.style.left=`${r}px`,e.style.top=`${i}px`,o.insertBefore(Po([n]),e)}var ht=class{constructor(e,t,n){this.range=t;this.anchor=n.tail.el;let r=this.anchor.getBoundingClientRect();this.first={plan:n,top:r.top,left:r.left};let i=be(this.anchor).map(s=>s.el);this.area=i[0],e.addToPage(this.node),this.pin=new ee(this.node,i)}node=w("div","source-ring");pin;area;anchor;first;get anchorBox(){return this.anchor.getBoundingClientRect()}retarget(e){this.anchor=e}tailless=!1;detachTail(){this.tailless=!0}setPending(e){this.node.toggleAttribute("data-pending",e)}layout(e,t){let n=this.anchor.getBoundingClientRect(),r=Math.abs(n.top-this.first.top)<1&&Math.abs(n.left-this.first.left)<1,i=mt(this.range)??(r?this.first.plan:null);if(!i)return null;let{path:s,left:a,top:l}=Lo(i.tail,e,t,!this.tailless),c=this.anchorBox,d=Po([s],!1);return d.style.left=`${-c.left}px`,d.style.top=`${-c.top}px`,this.node.replaceChildren(d),this.pin.place(c.left,c.top),{left:a,top:l}}follow(){let e=this.anchorBox;(e.width||e.height)&&this.pin.place(e.left,e.top)}clip(e,t){let n=this.area?.getBoundingClientRect();_e(this.node,Math.max(e,n?.top??-1/0),Math.min(t,n?.bottom??1/0))}remove(){this.node.remove()}};function Pa(o){return o==="zh-Hans"?"zh-CN":o==="zh-Hant"?"zh-TW":o==="yue"?"zh-HK":o}function Ha(o,e){let t=e.toLowerCase(),n=t.split("-")[0],r=a=>{let l=a.lang.toLowerCase().replace("_","-");return l!==t&&l.split("-")[0]!==n?-1:(l===t?2:0)+(a.localService?1:0)},i,s=-1;for(let a of o){let l=r(a);l>s&&(i=a,s=l)}return i}function Ia(o,e,t){let n=Intl.Segmenter;if(!n)return Math.min(o.length,e+1);for(let r of new n(t,{granularity:"word"}).segment(o.slice(e)))if(r.segment.trim())return e+r.index+r.segment.length;return o.length}var ft=class{constructor(e,t=n=>new SpeechSynthesisUtterance(n)){this.synth=e;this.create=t}current;callbacks;get reading(){return this.current!==void 0}start(e,t,n){this.stop();let r=Pa(t),i=this.synth.getVoices(),s=Ha(i,r);if(i.length&&!s){n.onEnd("noVoice");return}let a=this.create(e);a.lang=r,s&&(a.voice=s),a.onboundary=l=>{a!==this.current||l.name==="sentence"||n.onWord(l.charIndex,l.charLength?l.charIndex+l.charLength:Ia(e,l.charIndex,r))},a.onend=()=>this.finish(a),a.onerror=l=>this.finish(a,l.error==="canceled"||l.error==="interrupted"?void 0:"failed"),this.current=a,this.callbacks=n,this.synth.speak(a)}stop(){let e=this.callbacks,t=this.current!==void 0;this.current=void 0,this.callbacks=void 0,t&&(this.synth.cancel(),e?.onEnd())}finish(e,t){if(e!==this.current)return;let n=this.callbacks;this.current=void 0,this.callbacks=void 0,n?.onEnd(t)}};var _a=5e3,Oa='yl-t,yl-r,pre,code,kbd,samp,textarea,input,select,[contenteditable]:not([contenteditable="false"]),.CodeMirror,.cm-editor,.monaco-editor,.ace_editor,.blob-code,.hljs,[role="textbox"],[role="code"]',Ba="yl-t,yl-ui,script,style,noscript,template",$a=3e3,Fa=4,gt="	";function Wa(o){let e=o;for(;e.parentElement&&getComputedStyle(e).display.startsWith("inline");)e=e.parentElement;return e}function Ua(o,e){return Math.min(o.bottom,e.bottom)-Math.max(o.top,e.top)>=Math.min(o.height,e.height)/2}function Io(o){let e=o.commonAncestorContainer,t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),n=[""],r,i=0;for(let s=e.nodeType===Node.TEXT_NODE?e:t.nextNode();s;s=t.nextNode()){if(++i>$a)return"";if(!o.intersectsNode(s))continue;let a=s.parentElement;if(!a||a.closest(Ba))continue;let l=getComputedStyle(a);if(l.visibility!=="visible"||l.userSelect==="none")continue;let c=s.data,d=s===o.startContainer?o.startOffset:0,u=s===o.endContainer?o.endOffset:c.length,h=document.createRange();h.setStart(s,d),h.setEnd(s,u);let p=h.getClientRects(),f=p[0],m=p[p.length-1];if(!f||!m||!f.width)continue;let y=l.whiteSpace.startsWith("pre")||l.whiteSpace==="break-spaces"?c.slice(d,u).replace(/\t/g,"  "):c.slice(d,u).replace(/\s+/g," ");if(!y.trim()&&!r)continue;let E=Wa(a);if(r){let S=Ua(r.rect,f);r.flow!==E&&!S?n.push(""):r.flow!==E?n[n.length-1]+=gt:S&&f.left-r.rect.right>=Fa&&(n[n.length-1]+=" ")}let x=y.split(`
`);n[n.length-1]+=x[0]??"",n.push(...x.slice(1)),y.trim()&&(r={flow:E,rect:m})}return n.map(s=>s.replace(/ {2,}/g," ").replace(/ *\t[ \t]*/g,gt).replace(/^\t+|\t+$/g,"").trim()).filter(Boolean).join(`
`)}function qa(o,e){let t=[...o.matchAll(/[\t\n]/g)].map(r=>r[0]),n=e.split(`
`);return!t.includes(gt)||n.length!==t.length+1?e:n.reduce((r,i,s)=>r+(t[s-1]===gt?" ":`
`)+i)}function Do(o,e){try{return new Intl.DisplayNames([e],{type:"language"}).of(o)??o}catch{return o}}var _o=60,ja=6,za=40,Fo=.6;function Oo(o){if(!o)return;let e=o.startContainer,t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement,n=be(t).map(i=>i.el).find(i=>i.clientHeight>=innerHeight*Fo);if(!n)return;let r=n.getBoundingClientRect();return{top:r.top,bottom:r.bottom}}async function Ga(o){let e=NaN,t=0,n=performance.now();for(;t<5&&performance.now()-n<1200;){await new Promise(i=>requestAnimationFrame(i));let r=o.getBoundingClientRect().top;t=r===e?t+1:0,e=r}}function Bo(o,e){return new DOMRect(o,e,0,0)}var bt=class{constructor(e,t,n){this.settings=e;this.ui=t;this.enabled=n;document.addEventListener("mouseup",this.onMouseUp),document.addEventListener("mousedown",this.onMouseDown,!0),document.addEventListener("keydown",this.onKeyDown,!0),addEventListener("scroll",this.onScroll,{passive:!0,capture:!0}),addEventListener("resize",this.onResize)}bubble;card;followFrame=0;reader=new ft(speechSynthesis);update(e,t){this.settings=e,this.enabled=t,t||this.closeAll()}translateText(e){let t=getSelection(),n=t&&t.rangeCount?t.getRangeAt(0).cloneRange():void 0,r=n?.getBoundingClientRect();n&&r&&r.width?this.openCard(e,r,{range:n,plan:mt(n),x:r.right,y:r.bottom}):this.openCard(e,new DOMRect(innerWidth/2-240,80,0,0))}isOwnEvent(e){return this.ui.ownsEvent(e)}onMouseDown=e=>{this.isOwnEvent(e)||this.closeAll()};onKeyDown=e=>{e.key==="Escape"&&this.closeAll()};onScroll=e=>{this.isOwnEvent(e)||(this.bubble?.remove(),this.bubble=void 0,this.followFrame||(this.followFrame=requestAnimationFrame(this.followSource)))};onResize=()=>{this.card&&this.placeCard(this.card)};followSource=()=>{this.followFrame=0;let e=this.card;if(!e?.ring)return;e.ring.follow();let t=e.ring.anchorBox;(t.width||t.height)&&e.pin?.place(t.left+e.dx,t.top+e.dy),this.clearOfBars(e)};placeCard(e){if(!e.ring||!e.pin)return;let t=e.ring.anchorBox,n=()=>e.pin?.place(t.left+e.dx,t.top+e.dy);if(t.bottom<0||t.top>innerHeight){n();return}let r=e.ring.layout(e.node.offsetWidth,e.node.offsetHeight);if(!r||e.moved){n();return}e.dx=r.left-t.left,e.dy=r.top-t.top,e.pin.place(r.left,r.top),this.clearOfBars(e)}clearOfBars(e){if(!e.ring)return;let t=this.ui.settleUnderBars(),n=e.area&&e.area.clientHeight>=innerHeight*Fo?e.area.getBoundingClientRect():void 0,r=Math.max(t.top,n?.top??-1/0),i=Math.min(t.bottom,n?.bottom??1/0);_e(e.node,r,i),e.ring.clip(t.top,t.bottom)}closeCard(e){e.alive=!1,e.menu?.close(),this.card===e&&(this.card=void 0),this.reader.stop(),e.ring?.remove(),this.ui.dismiss(e.node)}onMouseUp=e=>{F()&&(!this.enabled||this.settings.selectionTrigger==="off"||this.isOwnEvent(e)||setTimeout(()=>this.evaluate(e),0))};evaluate(e){let t=getSelection();if(!t||t.isCollapsed||!t.rangeCount)return;let n=t.getRangeAt(0),r=Io(n)||t.toString().trim();if(!r||r.length>_a||!new RegExp("\\p{L}","u").test(r)||Ka(n))return;let i=n.getBoundingClientRect();if(!i.width&&!i.height)return;let s=n.cloneRange(),a=mt(s);if(this.settings.selectionTrigger==="auto"){this.openCard(r,Bo(e.clientX,e.clientY),{range:s,plan:a,x:e.clientX,y:e.clientY});return}this.showBubble(r,e.clientX,e.clientY,s,a)}showBubble(e,t,n,r,i){this.bubble?.remove();let s=w("div","bubble"),a=w("div","bubble-tab"),l=w("button","bubble-action");l.type="button",l.title=v("selectionBubble"),l.setAttribute("aria-label",v("selectionBubble")),l.append(ue("translate"),w("span","",v("selectionAction"))),l.addEventListener("click",()=>{s.remove(),this.bubble=void 0,this.openCard(e,Bo(t,n),{range:r,plan:i,x:t,y:n})}),a.append(l),s.append(a),this.bubble=this.ui.add(s),i?Ho(s,a,i):(a.style.left=`${Math.max(8,Math.min(t+6,innerWidth-a.offsetWidth-8))}px`,a.style.top=`${Math.max(8,Math.min(n+10,innerHeight-a.offsetHeight-8))}px`)}glossaryEditor(e,t,n,r){let i=w("div","card-glossary"),s=w("input","card-glossary-input");s.value=e,s.setAttribute("aria-label",v("glossaryTerm"));let a=w("input","card-glossary-input");a.value=t.length<=_o?t:"",a.placeholder=v("glossaryKeep"),a.setAttribute("aria-label",v("glossaryTranslation"));let l=w("button","card-glossary-save",v("glossarySave"));l.type="button";let c=async()=>{let d=s.value.trim();if(!d)return;let u=(await chrome.storage.sync.get("glossary")).glossary,h=a.value.trim(),p=h?{from:d,to:h,lang:n}:{from:d,to:""},f=(u??[]).filter(m=>!(m.from.toLowerCase()===d.toLowerCase()&&(m.lang??"")===(p.lang??"")));await chrome.storage.sync.set({glossary:[...f,p].slice(-200)}),i.remove(),r(v("glossaryAdded"),1800)};l.addEventListener("click",()=>void c());for(let d of[s,a])d.addEventListener("keydown",u=>{u.key==="Enter"&&c()});return i.append(s,w("span","card-glossary-arrow","→"),a,l),setTimeout(()=>a.focus(),0),i}startDrag(e,t,n){if(n.button!==0)return;n.preventDefault(),t.setPointerCapture(n.pointerId);let r={x:n.clientX,y:n.clientY},i=e.node.getBoundingClientRect(),s={dx:e.dx,dy:e.dy};e.node.toggleAttribute("data-dragging",!0),e.moved||(e.moved=!0,e.ring?.detachTail(),e.ring?.layout(e.node.offsetWidth,e.node.offsetHeight));let a=c=>{let d=Math.max(8,Math.min(i.left+c.clientX-r.x,innerWidth-i.width-8)),u=Math.max(8,Math.min(i.top+c.clientY-r.y,innerHeight-40));if(e.ring&&e.pin){e.dx=s.dx+d-i.left,e.dy=s.dy+u-i.top;let h=e.ring.anchorBox;e.pin.place(h.left+e.dx,h.top+e.dy)}else e.node.style.left=`${d}px`,e.node.style.top=`${u}px`},l=()=>{t.removeEventListener("pointermove",a),t.removeEventListener("pointerup",l),t.removeEventListener("pointercancel",l),e.node.removeAttribute("data-dragging"),this.clearOfBars(e)};t.addEventListener("pointermove",a),t.addEventListener("pointerup",l),t.addEventListener("pointercancel",l)}async jumpTo(e,t){let n=t.el.getBoundingClientRect();if(!(n.top>=0&&n.bottom<=innerHeight)){if(t.el.scrollIntoView({block:"center",behavior:"instant"}),await Ga(t.el),!e.alive)return;e.ring&&(e.ring.retarget(t.el),this.placeCard(e))}No(this.ui,t.range)}openCard(e,t,n){this.closeAll();let r=this.settings.targetLang,i=w("div","card");i.setAttribute("role","dialog"),i.setAttribute("aria-label",v("selectionBubble"));let s=w("div","card-body"),l=(n?Ro(n.range):[]).map(k=>({segment:k,text:Io(k.range)||k.range.toString().trim()})).filter(k=>new RegExp("\\p{L}","u").test(k.text)),d=(l.length>1&&l.length<=za?l:[{segment:void 0,text:e}]).map(k=>{let L=w("div","card-seg"),O=w("div","card-source",k.text);O.title=k.text;let z=w("div","card-result",v("translating"));z.dataset.state="loading",L.append(O,z);let{segment:H}=k;if(H){L.title=v("jumpToSource"),L.dataset.jump="";let Y=[0,0];L.addEventListener("mousedown",W=>Y=[W.clientX,W.clientY]),L.addEventListener("click",W=>{Math.hypot(W.clientX-Y[0],W.clientY-Y[1])<4&&this.jumpTo(b,H)})}return s.append(L),{text:k.text,result:z,translated:"",start:0}}),u=Zt(),h=w("span","grow card-langs"),p=w("span","card-from"),f=w("button","card-lang");f.type="button",f.title=v("targetLang"),f.setAttribute("aria-haspopup","listbox");let m=w("span","");f.append(m,w("i","card-lang-chevron"));let g="",y=()=>{p.textContent=g&&g!==r?`${Do(g,u)} → `:"",m.textContent=Do(r,u),h.replaceChildren(p,f)};y();let E,x=(k,L)=>{h.replaceChildren(k),clearTimeout(E),E=setTimeout(y,L)},S="",M=$("copy",v("copy"),()=>{navigator.clipboard.writeText(S).then(()=>x(v("copied"),1200))}),I=(k,L)=>{let O=d.find(J=>J.translated&&k>=J.start&&k<J.start+J.translated.length);if(!O)return;for(let J of d)J!==O&&J.translated&&(J.result.textContent=J.translated);let z=k-O.start,H=Math.min(L-O.start,O.translated.length),Y=w("mark","card-word",O.translated.slice(z,H));O.result.replaceChildren(O.translated.slice(0,z),Y,O.translated.slice(H));let W=Y.offsetTop-s.offsetTop;(W<s.scrollTop||W+Y.offsetHeight>s.scrollTop+s.clientHeight)&&(s.scrollTop=W-24)},P=k=>{if(D.toggleAttribute("data-on",k),D.title=k?v("stopSpeaking"):v("speak"),D.setAttribute("aria-label",D.title),D.replaceChildren(ue(k?"stop":"speak")),!k)for(let L of d)L.translated&&(L.result.textContent=L.translated)},D=$("speak",v("speak"),()=>{if(this.reader.reading){this.reader.stop();return}S&&(P(!0),this.reader.start(S,r,{onWord:I,onEnd:k=>{P(!1),k&&x(v(k==="noVoice"?"noVoice":"speakFailed"),2400)}}))}),j=$("close",v("close"),()=>this.closeCard(b)),U=w("div","card-foot"),T=d.length===1&&e.length<=_o&&e.split(/\s+/).length<=ja,C=$("glossary",v("addToGlossary"),()=>{i.querySelector(".card-glossary")||(i.insertBefore(this.glossaryEditor(e.trim(),d[0]?.translated??"",r,x),U),this.placeCard(b))});T?U.append(h,C,M,D,j):U.append(h,M,D,j);let R=w("div","card-grip");R.title=v("moveCard"),R.setAttribute("aria-label",v("moveCard")),R.addEventListener("pointerdown",k=>this.startDrag(b,R,k)),i.append(R,s,U);let b={node:i,dx:0,dy:0,alive:!0};if(this.card=b,n?.plan){let k=be(n.plan.tail.el).map(L=>L.el);b.area=k[0],b.ring=new ht(this.ui,n.range,n.plan),b.ring.setPending(!0),i.dataset.onPage="",this.ui.addToPage(i),b.pin=new ee(i,k),this.placeCard(b)}else this.ui.add(i),this.ui.place(i,t,8,Oo(n?.range));let A=0,N=async()=>{let k=++A;try{let L=await _({type:"translate",items:d.map(H=>K(H.text.replace(/\t/g,`
`))),from:this.settings.sourceLang,to:r});if(!b.alive||k!==A)return;d.forEach((H,Y)=>{let W=L?.results?.[Y];W?.ok?(delete H.result.dataset.state,H.translated=qa(H.text,ae(W.text)),H.result.textContent=H.translated,W.detected&&(g=W.detected,y())):(H.result.dataset.state="error",H.result.textContent=this.ui.errorMessage(W?.code??"network"))});let O=0,z=d.filter(H=>H.translated);for(let H of z)H.start=O,O+=H.translated.length+2;S=z.map(H=>H.translated).join(`

`)}catch{if(!b.alive||k!==A||!F())return;for(let L of d)L.result.dataset.state="error",L.result.textContent=this.ui.errorMessage("network")}!b.alive||k!==A||(b.ring?.setPending(!1),s.style.overscrollBehavior=s.scrollHeight>s.clientHeight?"contain":"",b.ring?this.placeCard(b):b.moved||this.ui.place(i,t,8,Oo(n?.range)))},q=!1;f.addEventListener("pointerdown",()=>q=!!b.menu?.isOpen()),f.addEventListener("click",()=>{if(q){b.menu?.close(),b.menu=void 0;return}b.menu=$e(this.ui,f.getBoundingClientRect(),r,v("targetLang"),k=>{if(b.menu=void 0,k!==r){r=k,this.reader.stop(),S="";for(let L of d)L.translated="",L.result.dataset.state="loading",L.result.textContent=v("translating");y(),b.ring?.setPending(!0),N()}})}),N()}closeAll(){this.ui.dismiss(this.bubble),this.bubble=void 0,this.card&&this.closeCard(this.card)}};function Ka(o){let e=o.commonAncestorContainer;if($o(e))return!0;if(e.nodeType===Node.TEXT_NODE)return!1;let t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let n=t.nextNode();n;n=t.nextNode()){if(!o.intersectsNode(n))continue;let r=n,i=n===o.startContainer?o.startOffset:0,s=n===o.endContainer?o.endOffset:r.length;if(r.data.slice(i,s).trim()&&!$o(n))return!1}return!0}function $o(o){return!!(o.nodeType===Node.ELEMENT_NODE?o:o.parentElement)?.closest(Oa)}var Wo="__yilan_region_ask__",jo=1500,Xa=2e3,zo="__yilan_handover__",Uo=globalThis;async function Va(){let o=document.documentElement.lang?.trim();if(o)return o;let e=document.body?.innerText?.slice(0,jo)??"";if(e.trim())try{let n=(await chrome.i18n.detectLanguage(e)).languages?.[0];return n&&n.percentage>=50?n.language:void 0}catch{return}}async function qo(o){let e=document.body?.innerText?.slice(0,jo)??"",t;if(e.trim())try{let r=(await chrome.i18n.detectLanguage(e)).languages?.[0];r&&r.percentage>=50&&(t=r.language)}catch{}return t??=document.documentElement.lang?.trim()||void 0,t!==void 0&&!Tn(t,o)}function Ya(o,e){let t=o.toLowerCase().split("-")[0];return e.some(n=>n.toLowerCase()===o.toLowerCase()||n.toLowerCase().split("-")[0]===t)}async function Ja(){let o=await St();Jt(T=>_({type:"i18n:messages",locale:T})),await vt(o.uiLang);let e=location.hostname,t=T=>!Tt(e,T.neverSites),n=new Be,r=()=>{let T=an(o.appearance);n.setTheme(De(de(o.themeColor),T?rn:Ie),T)};r(),matchMedia("(prefers-color-scheme: dark)").addEventListener("change",r);let i=new Ze(o,n),s=new bt(o,n,t(o)),a=new Fe(o,n,t(o)),l=new Je(n),c=new at(n,()=>o,()=>i.hasPageTranslations),d=new Set,u=(T,C)=>{let R=0;for(let b of Array.from(document.querySelectorAll("iframe"))){let A=b.getBoundingClientRect(),N={left:T.left-A.left-b.clientLeft,top:T.top-A.top-b.clientTop,right:T.right-A.left-b.clientLeft,bottom:T.bottom-A.top-b.clientTop};N.right<=0||N.bottom<=0||N.left>=A.width||N.top>=A.height||(b.contentWindow?.postMessage({[Wo]:!0,rect:N,token:C},"*"),R++)}return R},h=async T=>{let C=window===window.top;C&&l.showPending(T);let R=await i.translateRegion(T);return R&&await i.regionSettled(),C?l.settle(R>0):R>0};addEventListener("message",T=>{let C=T.data;if(!C||typeof C!="object"||typeof C.token!="string"||!(Wo in C)||T.source!==parent||!d.has(C.token)||!C.rect)return;let{left:R,top:b,right:A,bottom:N}=C.rect;[R,b,A,N].every(Number.isFinite)&&(u({left:R,top:b,right:A,bottom:N},C.token),h({left:R,top:b,right:A,bottom:N}))});let p=()=>{l.close(),i.restoreRegion(),c.stop()},f=()=>{p(),_({type:"region:closeAll"}).catch(()=>{})},m=!1,g=T=>{T.key!=="Escape"||!m||(T.preventDefault(),T.stopPropagation(),m=!1,removeEventListener("keydown",g,!0),f())},y=new qe(n),E=T=>{if(window!==top){_({type:"marquee:request",mode:T}).catch(()=>{});return}f(),focus(),y.begin(C=>{if(T==="scan"){c.start(C);return}m=!0,addEventListener("keydown",g,!0);let R=crypto.randomUUID();(async()=>{await _({type:"region:arm",token:R}).catch(()=>{}),await new Promise(N=>setTimeout(N,50));let b=u(C,R);!await h(C)&&!b&&n.toast(l.emptyMessage)})()})},x=!1,S=!1,M=()=>{x||(x=!0,clearInterval(I),m=!1,removeEventListener("keydown",g,!0),y.cancel(),p(),i.retire(),s.update(o,!1),a.update(o,!1))},I=setInterval(()=>{F()||M()},Xa);addEventListener(zo,()=>{F()||(S=!0,M())});let P=v("refreshAfterUpdate");return wn(()=>o.shortcuts,T=>{if(!F()){M(),S||n.toast(P);return}T==="marquee"?E("cover"):T==="sweep"?E("scan"):_({type:"shortcut:page",action:T}).catch(()=>{})}),ln(T=>{!o.autoTranslate&&T.autoTranslate&&t(T)&&qo(T.targetLang).then(C=>C?i.startPage():void 0),T.uiLang!==o.uiLang&&vt(T.uiLang),o=T,r(),i.applySettings(T),s.update(T,t(T)),a.update(T,t(T))}),{handle:(T,C)=>{switch(T.type){case"page:translate":f(),i.startPage();break;case"page:restore":f(),i.restore();break;case"page:toggle":f(),i.togglePage();break;case"page:retry":i.retryFailed();break;case"page:status":C(i.status());return;case"mode:toggle":{let R=o.mode==="dual"?"replace":"dual";o={...o,mode:R},i.setMode(R),window===top&&chrome.storage.sync.set({mode:R});break}case"marquee:start":E(T.mode??"cover");break;case"region:arm":d.add(T.token),setTimeout(()=>d.delete(T.token),5e3);break;case"region:close":p();break;case"selection:translate":s.translateText(T.text);break}C(!0)},afterReady:async()=>{let T=await Va();i.setPageLang(T),(t(o)&&(Tt(e,o.alwaysSites)||T!==void 0&&Ya(T,o.alwaysLangs)||o.autoTranslate&&await qo(o.targetLang))||await _({type:"tab:hello"}).catch(()=>!1))&&await i.startPage()}}}function Za(){if(document.contentType!=="text/html"&&document.contentType!=="application/xhtml+xml"||An()||Uo.__yilanAlive?.())return;Uo.__yilanAlive=F,dispatchEvent(new Event(zo));let o=Ja();chrome.runtime.onMessage.addListener((e,t,n)=>(o.then(({handle:r})=>r(e,n)),!0)),o.then(({afterReady:e})=>e())}Za();})();
